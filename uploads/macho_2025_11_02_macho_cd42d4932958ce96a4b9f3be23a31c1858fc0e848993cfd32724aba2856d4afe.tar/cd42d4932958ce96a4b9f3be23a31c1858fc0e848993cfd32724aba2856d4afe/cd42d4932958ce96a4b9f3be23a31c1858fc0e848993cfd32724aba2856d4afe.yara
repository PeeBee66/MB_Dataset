
rule MB_cd42d493
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-01T23:00:35.115275"
        sha256 = "cd42d4932958ce96a4b9f3be23a31c1858fc0e848993cfd32724aba2856d4afe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
