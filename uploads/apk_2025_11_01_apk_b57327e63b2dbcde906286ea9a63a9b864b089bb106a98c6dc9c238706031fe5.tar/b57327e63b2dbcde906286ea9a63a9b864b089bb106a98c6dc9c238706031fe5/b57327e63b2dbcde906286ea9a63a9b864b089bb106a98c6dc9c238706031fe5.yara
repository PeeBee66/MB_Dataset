
rule MB_b57327e6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:16.661155"
        sha256 = "b57327e63b2dbcde906286ea9a63a9b864b089bb106a98c6dc9c238706031fe5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
