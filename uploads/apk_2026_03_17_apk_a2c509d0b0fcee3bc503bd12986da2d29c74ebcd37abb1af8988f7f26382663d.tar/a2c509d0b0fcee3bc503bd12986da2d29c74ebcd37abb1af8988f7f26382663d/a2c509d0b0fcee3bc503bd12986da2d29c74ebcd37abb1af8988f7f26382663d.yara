
rule MB_a2c509d0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-16T23:00:19.739386"
        sha256 = "a2c509d0b0fcee3bc503bd12986da2d29c74ebcd37abb1af8988f7f26382663d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
