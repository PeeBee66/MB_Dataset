
rule MB_0f159a71
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:07.214957"
        sha256 = "0f159a71c6bfa5b2999f49edbdaf3ed6b0ed436b9978fb4bfa9e1804d3178958"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
