
rule MB_59bb6819
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:45:29.327945"
        sha256 = "59bb681961028642190f780266e2932a0f928b6ec44881165e1cecd0988c8029"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
