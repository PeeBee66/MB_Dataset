
rule MB_140ff94d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:27.566592"
        sha256 = "140ff94d5b3e2354ef7e8bfe029b712cb603a522edecee6abd792c27954e16e7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
