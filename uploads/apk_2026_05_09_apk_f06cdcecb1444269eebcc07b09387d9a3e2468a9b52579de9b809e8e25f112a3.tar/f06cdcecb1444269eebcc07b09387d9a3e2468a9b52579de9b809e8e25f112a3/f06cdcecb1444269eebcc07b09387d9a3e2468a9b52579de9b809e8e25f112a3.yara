
rule MB_f06cdcec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:11.009559"
        sha256 = "f06cdcecb1444269eebcc07b09387d9a3e2468a9b52579de9b809e8e25f112a3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
