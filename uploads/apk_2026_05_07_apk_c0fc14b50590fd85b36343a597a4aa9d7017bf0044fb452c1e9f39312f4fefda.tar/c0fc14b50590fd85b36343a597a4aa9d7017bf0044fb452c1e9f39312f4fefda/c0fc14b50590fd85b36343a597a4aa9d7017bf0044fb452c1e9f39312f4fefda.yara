
rule MB_c0fc14b5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:46.750416"
        sha256 = "c0fc14b50590fd85b36343a597a4aa9d7017bf0044fb452c1e9f39312f4fefda"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
