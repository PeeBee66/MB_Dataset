
rule MB_293d8f81
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:57.154291"
        sha256 = "293d8f81a3f2f7b41a72baca8913fac85f1b71a6dd30662417aac0f5437f533a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
