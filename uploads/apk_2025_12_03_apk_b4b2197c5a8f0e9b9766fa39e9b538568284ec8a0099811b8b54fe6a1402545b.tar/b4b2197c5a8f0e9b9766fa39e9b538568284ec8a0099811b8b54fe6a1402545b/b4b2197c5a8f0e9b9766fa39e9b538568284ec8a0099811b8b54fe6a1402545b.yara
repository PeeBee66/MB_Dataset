
rule MB_b4b2197c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:28.023302"
        sha256 = "b4b2197c5a8f0e9b9766fa39e9b538568284ec8a0099811b8b54fe6a1402545b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
