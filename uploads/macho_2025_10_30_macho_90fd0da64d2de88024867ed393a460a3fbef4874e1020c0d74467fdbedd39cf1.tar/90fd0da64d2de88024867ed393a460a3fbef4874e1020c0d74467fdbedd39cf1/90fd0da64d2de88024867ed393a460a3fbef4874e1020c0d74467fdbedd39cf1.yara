
rule MB_90fd0da6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-29T23:00:20.395798"
        sha256 = "90fd0da64d2de88024867ed393a460a3fbef4874e1020c0d74467fdbedd39cf1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
