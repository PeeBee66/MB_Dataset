
rule MB_a0edfa97
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:00:47.598344"
        sha256 = "a0edfa97344c870ee24aa7c008cec40e85e616c21e86522b8f6fce0324b356f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
