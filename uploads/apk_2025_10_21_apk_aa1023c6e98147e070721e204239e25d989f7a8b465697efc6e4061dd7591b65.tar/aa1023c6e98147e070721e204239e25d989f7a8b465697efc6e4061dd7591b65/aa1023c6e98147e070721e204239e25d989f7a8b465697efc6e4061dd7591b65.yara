
rule MB_aa1023c6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:51.020389"
        sha256 = "aa1023c6e98147e070721e204239e25d989f7a8b465697efc6e4061dd7591b65"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
