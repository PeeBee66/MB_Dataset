
rule MB_8657cc17
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:33.628741"
        sha256 = "8657cc17bab09845e3c8375fe77770ae1bba4095a015215c04e9e96d1c20ff03"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
