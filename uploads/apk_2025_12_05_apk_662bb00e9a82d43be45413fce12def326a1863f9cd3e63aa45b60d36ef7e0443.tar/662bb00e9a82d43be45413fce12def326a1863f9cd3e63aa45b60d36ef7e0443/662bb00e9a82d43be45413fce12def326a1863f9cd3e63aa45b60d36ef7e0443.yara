
rule MB_662bb00e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:58.829940"
        sha256 = "662bb00e9a82d43be45413fce12def326a1863f9cd3e63aa45b60d36ef7e0443"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
