
rule MB_2688b8a5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:08.426847"
        sha256 = "2688b8a5aa042e3cdf55a83ff18f0e03ed10fbdce724ae2533a407e379d0d334"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
