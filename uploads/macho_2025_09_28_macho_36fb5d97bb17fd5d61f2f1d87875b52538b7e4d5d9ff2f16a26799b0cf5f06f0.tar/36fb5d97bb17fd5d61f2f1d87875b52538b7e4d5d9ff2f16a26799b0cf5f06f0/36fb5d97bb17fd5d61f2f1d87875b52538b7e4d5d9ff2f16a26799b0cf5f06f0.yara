
rule MB_36fb5d97
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-25T00:01:05.313587"
        sha256 = "36fb5d97bb17fd5d61f2f1d87875b52538b7e4d5d9ff2f16a26799b0cf5f06f0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
