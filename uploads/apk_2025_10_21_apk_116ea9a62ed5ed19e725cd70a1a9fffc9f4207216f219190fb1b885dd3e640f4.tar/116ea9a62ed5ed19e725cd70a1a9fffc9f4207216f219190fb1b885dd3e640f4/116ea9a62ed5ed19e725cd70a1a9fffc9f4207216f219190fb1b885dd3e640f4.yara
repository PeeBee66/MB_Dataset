
rule MB_116ea9a6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:36.533445"
        sha256 = "116ea9a62ed5ed19e725cd70a1a9fffc9f4207216f219190fb1b885dd3e640f4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
