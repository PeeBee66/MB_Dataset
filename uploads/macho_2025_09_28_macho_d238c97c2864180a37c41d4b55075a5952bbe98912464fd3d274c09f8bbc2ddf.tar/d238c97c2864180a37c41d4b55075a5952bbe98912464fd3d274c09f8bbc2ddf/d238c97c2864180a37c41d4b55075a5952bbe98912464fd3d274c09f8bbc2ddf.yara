
rule MB_d238c97c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:01.196604"
        sha256 = "d238c97c2864180a37c41d4b55075a5952bbe98912464fd3d274c09f8bbc2ddf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
