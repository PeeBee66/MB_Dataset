
rule MB_d9d7c1c0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:18.815137"
        sha256 = "d9d7c1c0e0c9d0fbf6f3b6aa52b6b9bd588706b346c1cf008fd7d169e1342b78"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
