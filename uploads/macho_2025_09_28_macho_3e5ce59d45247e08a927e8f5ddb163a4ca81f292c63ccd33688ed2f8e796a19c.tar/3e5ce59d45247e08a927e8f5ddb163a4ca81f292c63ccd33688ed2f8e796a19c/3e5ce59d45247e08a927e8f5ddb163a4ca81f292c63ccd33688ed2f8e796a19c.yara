
rule MB_3e5ce59d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:54.404071"
        sha256 = "3e5ce59d45247e08a927e8f5ddb163a4ca81f292c63ccd33688ed2f8e796a19c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
