
rule MB_dbfc18d9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:28.744343"
        sha256 = "dbfc18d920ae1c2acab8aeb4eda81da4f3acd39dd3d5c8faa0cb20dfd85593d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
