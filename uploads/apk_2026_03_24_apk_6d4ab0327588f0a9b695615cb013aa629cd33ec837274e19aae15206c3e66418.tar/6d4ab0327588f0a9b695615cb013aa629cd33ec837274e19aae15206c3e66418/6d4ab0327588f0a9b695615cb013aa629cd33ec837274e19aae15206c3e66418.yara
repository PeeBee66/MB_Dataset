
rule MB_6d4ab032
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:44.491994"
        sha256 = "6d4ab0327588f0a9b695615cb013aa629cd33ec837274e19aae15206c3e66418"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
