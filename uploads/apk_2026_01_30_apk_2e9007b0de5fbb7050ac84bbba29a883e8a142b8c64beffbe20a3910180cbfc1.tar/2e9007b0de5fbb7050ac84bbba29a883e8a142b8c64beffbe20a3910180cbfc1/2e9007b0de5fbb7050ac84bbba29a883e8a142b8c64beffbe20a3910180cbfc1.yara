
rule MB_2e9007b0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:20.029249"
        sha256 = "2e9007b0de5fbb7050ac84bbba29a883e8a142b8c64beffbe20a3910180cbfc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
