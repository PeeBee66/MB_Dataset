
rule MB_7a38b6a3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:11.515504"
        sha256 = "7a38b6a39aae047fe9dfb54cd729caf0ba427ef83713067ed33c30ca030f4eb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
