
rule MB_1427e680
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:59.955922"
        sha256 = "1427e68049bc40258763a5ef0680a8c53096d1b0f1159478f503392f3f28a11e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
