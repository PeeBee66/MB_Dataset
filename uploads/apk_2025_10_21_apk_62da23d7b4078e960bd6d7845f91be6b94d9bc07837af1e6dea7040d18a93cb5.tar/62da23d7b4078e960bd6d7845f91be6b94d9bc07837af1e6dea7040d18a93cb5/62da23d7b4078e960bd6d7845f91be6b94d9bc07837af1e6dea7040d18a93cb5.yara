
rule MB_62da23d7
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:18:18.906301"
        sha256 = "62da23d7b4078e960bd6d7845f91be6b94d9bc07837af1e6dea7040d18a93cb5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
