
rule MB_447978c7
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:53.205336"
        sha256 = "447978c7e1a5627d0fe5b0ed9d61c809eea1005600ef16724ae1ced2e95d5e89"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
