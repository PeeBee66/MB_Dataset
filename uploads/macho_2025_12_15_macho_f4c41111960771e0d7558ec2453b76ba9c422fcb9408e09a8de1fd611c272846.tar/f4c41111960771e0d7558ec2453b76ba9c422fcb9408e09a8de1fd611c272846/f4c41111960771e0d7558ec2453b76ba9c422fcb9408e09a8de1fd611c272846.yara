
rule MB_f4c41111
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-14T23:00:18.088546"
        sha256 = "f4c41111960771e0d7558ec2453b76ba9c422fcb9408e09a8de1fd611c272846"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
