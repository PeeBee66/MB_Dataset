
rule MB_a801d00f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:14.392679"
        sha256 = "a801d00ffac15c36f4e1adc594c3de789a1200f3e9d3f7fd96ac1725e94a9046"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
