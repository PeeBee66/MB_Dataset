
rule MB_cf0f0fe9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:01:09.212284"
        sha256 = "cf0f0fe9939cf486cd12dee0ab15f82513a56cd05efd2bf83621cfd789ff8ec0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
