
rule MB_4637ff68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:24.412356"
        sha256 = "4637ff68777ec315d0b3f383177059a3630308f15e66e882889b67f1bba57bb7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
