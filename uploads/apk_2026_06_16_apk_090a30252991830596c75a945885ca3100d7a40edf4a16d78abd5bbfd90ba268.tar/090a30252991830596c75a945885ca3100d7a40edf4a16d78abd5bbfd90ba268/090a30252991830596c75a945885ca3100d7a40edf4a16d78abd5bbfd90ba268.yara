
rule MB_090a3025
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:56.570170"
        sha256 = "090a30252991830596c75a945885ca3100d7a40edf4a16d78abd5bbfd90ba268"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
