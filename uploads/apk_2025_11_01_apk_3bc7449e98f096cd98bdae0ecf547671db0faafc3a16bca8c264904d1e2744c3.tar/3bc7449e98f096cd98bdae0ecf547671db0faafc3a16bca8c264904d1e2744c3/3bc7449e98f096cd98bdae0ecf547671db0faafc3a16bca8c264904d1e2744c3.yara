
rule MB_3bc7449e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:13.619612"
        sha256 = "3bc7449e98f096cd98bdae0ecf547671db0faafc3a16bca8c264904d1e2744c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
