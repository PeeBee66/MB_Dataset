
rule MB_8d407ed3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:39:43.104395"
        sha256 = "8d407ed32c1f2130dd4baeae449d788356ad9a7895acfb99945c765772a8fb29"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
