
rule MB_d3c9c421
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-11-21T23:01:54.812068"
        sha256 = "d3c9c4214a61d6c9f88e36f319515667d48d69057798cfda5e1d34de2be5a066"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
