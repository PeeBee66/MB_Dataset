
rule MB_57a0a81e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-29T23:00:12.566045"
        sha256 = "57a0a81eebdf6c1e0a5ab0489165f167856712121b86959f0c34ce5c24014266"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
