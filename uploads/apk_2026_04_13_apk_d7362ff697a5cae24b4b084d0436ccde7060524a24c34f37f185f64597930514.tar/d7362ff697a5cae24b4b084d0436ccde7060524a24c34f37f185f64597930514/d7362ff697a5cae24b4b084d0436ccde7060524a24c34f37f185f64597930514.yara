
rule MB_d7362ff6
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-13T00:00:44.019117"
        sha256 = "d7362ff697a5cae24b4b084d0436ccde7060524a24c34f37f185f64597930514"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
