
rule MB_d4e111ed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:01:31.828572"
        sha256 = "d4e111ed8e2916342a1e625f7790d7a9fe3e30e3eee04c5d5f7d003cf4303dc3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
