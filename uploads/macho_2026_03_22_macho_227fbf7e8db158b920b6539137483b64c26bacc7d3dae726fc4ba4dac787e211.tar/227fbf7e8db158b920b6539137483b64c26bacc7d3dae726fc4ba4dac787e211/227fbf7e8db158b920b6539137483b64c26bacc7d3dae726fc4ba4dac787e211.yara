
rule MB_227fbf7e
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:35.643166"
        sha256 = "227fbf7e8db158b920b6539137483b64c26bacc7d3dae726fc4ba4dac787e211"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
