
rule MB_ef122ecf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:41.513562"
        sha256 = "ef122ecfc48cf5c29d82339f4ae05de304c5b067dda831427f912b96b3a5e16f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
