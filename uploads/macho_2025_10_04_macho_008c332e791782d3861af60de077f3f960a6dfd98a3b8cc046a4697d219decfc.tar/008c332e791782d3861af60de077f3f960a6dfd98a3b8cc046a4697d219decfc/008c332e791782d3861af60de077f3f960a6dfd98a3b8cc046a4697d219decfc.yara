
rule MB_008c332e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:33.316334"
        sha256 = "008c332e791782d3861af60de077f3f960a6dfd98a3b8cc046a4697d219decfc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
