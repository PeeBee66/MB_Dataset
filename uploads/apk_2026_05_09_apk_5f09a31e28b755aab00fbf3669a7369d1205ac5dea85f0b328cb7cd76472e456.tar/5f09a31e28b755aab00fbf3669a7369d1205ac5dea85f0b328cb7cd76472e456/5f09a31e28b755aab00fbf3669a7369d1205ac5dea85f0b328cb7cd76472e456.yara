
rule MB_5f09a31e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:58.127635"
        sha256 = "5f09a31e28b755aab00fbf3669a7369d1205ac5dea85f0b328cb7cd76472e456"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
