
rule MB_373e9faf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:01:03.083289"
        sha256 = "373e9fafc22638a9b35cf75a608c8945df75f1fe35b15e50dfda69a98a4c76dd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
