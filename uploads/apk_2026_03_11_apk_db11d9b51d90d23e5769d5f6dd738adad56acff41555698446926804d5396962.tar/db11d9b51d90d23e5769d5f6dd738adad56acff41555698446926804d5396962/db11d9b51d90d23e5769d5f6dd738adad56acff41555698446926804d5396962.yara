
rule MB_db11d9b5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:00:35.384809"
        sha256 = "db11d9b51d90d23e5769d5f6dd738adad56acff41555698446926804d5396962"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
