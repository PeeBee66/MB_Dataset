
rule MB_62c1ea27
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-13T23:00:17.643146"
        sha256 = "62c1ea27e19ddd45471069ac5a535c58db108081f8504e27660157d82f42981c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
