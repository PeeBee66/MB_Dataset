
rule MB_5c3dd390
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:00:53.469212"
        sha256 = "5c3dd390340a7c7f2536f469b3157be47c3957eccd4ceeb83cd2405e458e2ce0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
