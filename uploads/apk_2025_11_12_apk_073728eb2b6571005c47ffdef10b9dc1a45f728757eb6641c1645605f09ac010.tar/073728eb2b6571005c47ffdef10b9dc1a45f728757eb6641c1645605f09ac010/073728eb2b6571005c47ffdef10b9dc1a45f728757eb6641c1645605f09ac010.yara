
rule MB_073728eb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:36.624567"
        sha256 = "073728eb2b6571005c47ffdef10b9dc1a45f728757eb6641c1645605f09ac010"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
