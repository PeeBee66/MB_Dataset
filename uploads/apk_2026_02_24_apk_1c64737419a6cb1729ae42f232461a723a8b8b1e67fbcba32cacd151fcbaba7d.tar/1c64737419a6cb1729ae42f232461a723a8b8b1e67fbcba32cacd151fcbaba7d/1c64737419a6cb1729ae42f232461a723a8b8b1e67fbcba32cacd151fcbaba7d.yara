
rule MB_1c647374
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:59.337262"
        sha256 = "1c64737419a6cb1729ae42f232461a723a8b8b1e67fbcba32cacd151fcbaba7d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
