
rule MB_554e5113
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:11.904649"
        sha256 = "554e5113e0bb62d123242f09e273ba77cbb64e5a2ea9afa6faa8999d0e2594e5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
