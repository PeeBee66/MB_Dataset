
rule MB_b1a89410
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:00:35.029557"
        sha256 = "b1a8941063751656e11bbc6ab44d348cd6795d51bfc890424595c4ac76e52013"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
