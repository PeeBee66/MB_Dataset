
rule MB_c251df83
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:44.448768"
        sha256 = "c251df83fd43149f21db90641baa885c4dcd7c8b868c8046b456afbbb01f76f9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
