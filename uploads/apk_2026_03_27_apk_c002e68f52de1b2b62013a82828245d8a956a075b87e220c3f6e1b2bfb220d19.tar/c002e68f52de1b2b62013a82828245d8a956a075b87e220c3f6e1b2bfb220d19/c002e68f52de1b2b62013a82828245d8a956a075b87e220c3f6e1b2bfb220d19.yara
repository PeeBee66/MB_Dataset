
rule MB_c002e68f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-26T23:00:28.221610"
        sha256 = "c002e68f52de1b2b62013a82828245d8a956a075b87e220c3f6e1b2bfb220d19"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
