
rule MB_6d1a13b0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:18.792321"
        sha256 = "6d1a13b02f4cf945999a2a92a4c363ffe84f5fe1836069753d000967c668d714"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
