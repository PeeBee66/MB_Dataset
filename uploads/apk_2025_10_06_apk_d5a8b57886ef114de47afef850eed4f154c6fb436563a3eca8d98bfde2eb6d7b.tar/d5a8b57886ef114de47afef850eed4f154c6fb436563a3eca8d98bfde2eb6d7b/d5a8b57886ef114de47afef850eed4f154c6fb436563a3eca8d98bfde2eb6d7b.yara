
rule MB_d5a8b578
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-05T23:00:20.411466"
        sha256 = "d5a8b57886ef114de47afef850eed4f154c6fb436563a3eca8d98bfde2eb6d7b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
