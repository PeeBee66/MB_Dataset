
rule MB_691fafd3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:37.779903"
        sha256 = "691fafd3298f362bbafe3dbe1298f593971c8377ed252fdafc52fbae88c42ee6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
