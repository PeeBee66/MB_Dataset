
rule MB_9980f069
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:43.296047"
        sha256 = "9980f0690a0ac82bff26348b4315b7af8b895fce21682859884e6b030fe9350f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
