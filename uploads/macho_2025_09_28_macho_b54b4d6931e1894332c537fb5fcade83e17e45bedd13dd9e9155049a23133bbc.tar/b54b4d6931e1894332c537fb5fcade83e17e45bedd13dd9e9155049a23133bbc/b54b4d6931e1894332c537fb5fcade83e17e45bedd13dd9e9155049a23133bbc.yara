
rule MB_b54b4d69
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:17.373840"
        sha256 = "b54b4d6931e1894332c537fb5fcade83e17e45bedd13dd9e9155049a23133bbc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
