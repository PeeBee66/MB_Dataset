
rule MB_f3cbb8ed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-10T00:00:19.597197"
        sha256 = "f3cbb8ed8891e5068021dfc3a945405548c69d6798f6f972055a63950454e310"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
