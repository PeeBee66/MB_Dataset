
rule MB_02cd74a2
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-12-30T23:00:11.612721"
        sha256 = "02cd74a277a19ef59375d44e6111c5c887a2dd2313a2a7129c98e5967dc69ecc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
