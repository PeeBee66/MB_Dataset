
rule MB_9801aae7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:45.333290"
        sha256 = "9801aae7cb9f3506a9fbb85b0a22b26501313c15cd94a1e33f1fbeaf45fe1829"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
