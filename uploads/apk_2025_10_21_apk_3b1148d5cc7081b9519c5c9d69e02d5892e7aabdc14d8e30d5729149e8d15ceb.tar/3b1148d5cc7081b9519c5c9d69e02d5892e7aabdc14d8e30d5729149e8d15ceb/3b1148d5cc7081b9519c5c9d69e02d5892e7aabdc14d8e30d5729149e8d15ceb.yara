
rule MB_3b1148d5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:34.776121"
        sha256 = "3b1148d5cc7081b9519c5c9d69e02d5892e7aabdc14d8e30d5729149e8d15ceb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
