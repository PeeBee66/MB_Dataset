
rule MB_1657544b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:48.461331"
        sha256 = "1657544b1c70f59fdb749b084dfd312fda19e1788a5b80e8be28f2017f7f53ab"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
