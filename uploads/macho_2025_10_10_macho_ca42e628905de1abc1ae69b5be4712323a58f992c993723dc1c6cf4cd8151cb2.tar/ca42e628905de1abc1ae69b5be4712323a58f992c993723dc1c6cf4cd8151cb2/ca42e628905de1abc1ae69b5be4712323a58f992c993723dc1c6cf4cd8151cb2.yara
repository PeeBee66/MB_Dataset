
rule MB_ca42e628
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:45.727665"
        sha256 = "ca42e628905de1abc1ae69b5be4712323a58f992c993723dc1c6cf4cd8151cb2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
