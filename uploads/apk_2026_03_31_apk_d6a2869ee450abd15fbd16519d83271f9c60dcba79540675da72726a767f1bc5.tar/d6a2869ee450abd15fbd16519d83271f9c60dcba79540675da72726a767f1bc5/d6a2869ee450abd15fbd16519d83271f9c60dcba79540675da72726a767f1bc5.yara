
rule MB_d6a2869e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-30T23:00:18.302695"
        sha256 = "d6a2869ee450abd15fbd16519d83271f9c60dcba79540675da72726a767f1bc5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
