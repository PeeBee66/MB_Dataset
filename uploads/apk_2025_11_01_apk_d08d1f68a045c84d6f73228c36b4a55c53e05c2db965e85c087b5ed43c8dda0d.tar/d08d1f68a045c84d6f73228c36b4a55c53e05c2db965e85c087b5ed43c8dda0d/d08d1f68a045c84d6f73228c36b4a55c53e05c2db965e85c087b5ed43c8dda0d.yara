
rule MB_d08d1f68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:01.449203"
        sha256 = "d08d1f68a045c84d6f73228c36b4a55c53e05c2db965e85c087b5ed43c8dda0d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
