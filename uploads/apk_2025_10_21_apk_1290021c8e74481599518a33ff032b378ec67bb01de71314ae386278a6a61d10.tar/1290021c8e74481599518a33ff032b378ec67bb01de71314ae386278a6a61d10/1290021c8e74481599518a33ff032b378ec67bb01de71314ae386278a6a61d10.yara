
rule MB_1290021c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:10.622841"
        sha256 = "1290021c8e74481599518a33ff032b378ec67bb01de71314ae386278a6a61d10"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
