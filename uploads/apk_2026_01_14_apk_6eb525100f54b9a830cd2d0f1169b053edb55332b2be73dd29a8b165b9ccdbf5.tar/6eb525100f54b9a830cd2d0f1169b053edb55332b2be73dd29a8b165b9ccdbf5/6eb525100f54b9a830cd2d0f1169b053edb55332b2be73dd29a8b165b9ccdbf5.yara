
rule MB_6eb52510
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2026-01-13T23:00:13.175876"
        sha256 = "6eb525100f54b9a830cd2d0f1169b053edb55332b2be73dd29a8b165b9ccdbf5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
