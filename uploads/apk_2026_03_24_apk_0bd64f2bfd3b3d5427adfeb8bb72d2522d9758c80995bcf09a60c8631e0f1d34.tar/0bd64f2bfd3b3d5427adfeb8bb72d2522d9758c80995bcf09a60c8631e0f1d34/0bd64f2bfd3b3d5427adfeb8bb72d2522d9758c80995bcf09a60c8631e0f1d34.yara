
rule MB_0bd64f2b
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-23T23:00:20.756694"
        sha256 = "0bd64f2bfd3b3d5427adfeb8bb72d2522d9758c80995bcf09a60c8631e0f1d34"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
