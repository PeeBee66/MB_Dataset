
rule MB_8276dfa8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:46.517357"
        sha256 = "8276dfa8b20de40a22eeb2b931625f3655b7e95e48d597c1252ca4a52475ca04"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
