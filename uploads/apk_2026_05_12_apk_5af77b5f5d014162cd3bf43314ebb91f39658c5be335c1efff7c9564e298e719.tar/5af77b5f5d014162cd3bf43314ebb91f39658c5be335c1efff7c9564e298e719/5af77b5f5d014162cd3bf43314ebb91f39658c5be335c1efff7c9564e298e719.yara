
rule MB_5af77b5f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-12T00:00:27.441305"
        sha256 = "5af77b5f5d014162cd3bf43314ebb91f39658c5be335c1efff7c9564e298e719"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
