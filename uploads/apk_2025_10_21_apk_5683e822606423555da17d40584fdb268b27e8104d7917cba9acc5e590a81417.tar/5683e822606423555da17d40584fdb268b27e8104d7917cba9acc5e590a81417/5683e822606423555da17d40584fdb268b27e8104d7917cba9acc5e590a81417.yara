
rule MB_5683e822
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:47.200778"
        sha256 = "5683e822606423555da17d40584fdb268b27e8104d7917cba9acc5e590a81417"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
