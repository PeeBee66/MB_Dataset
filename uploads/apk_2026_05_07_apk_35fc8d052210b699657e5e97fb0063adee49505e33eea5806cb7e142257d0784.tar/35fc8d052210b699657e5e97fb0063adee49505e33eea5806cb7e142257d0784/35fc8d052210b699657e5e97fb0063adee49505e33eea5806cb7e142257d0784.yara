
rule MB_35fc8d05
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:27.748519"
        sha256 = "35fc8d052210b699657e5e97fb0063adee49505e33eea5806cb7e142257d0784"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
