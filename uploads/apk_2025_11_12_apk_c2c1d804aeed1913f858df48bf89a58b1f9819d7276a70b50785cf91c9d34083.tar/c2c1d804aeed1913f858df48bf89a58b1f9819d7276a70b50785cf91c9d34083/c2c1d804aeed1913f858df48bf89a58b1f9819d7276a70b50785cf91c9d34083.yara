
rule MB_c2c1d804
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:11.497275"
        sha256 = "c2c1d804aeed1913f858df48bf89a58b1f9819d7276a70b50785cf91c9d34083"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
