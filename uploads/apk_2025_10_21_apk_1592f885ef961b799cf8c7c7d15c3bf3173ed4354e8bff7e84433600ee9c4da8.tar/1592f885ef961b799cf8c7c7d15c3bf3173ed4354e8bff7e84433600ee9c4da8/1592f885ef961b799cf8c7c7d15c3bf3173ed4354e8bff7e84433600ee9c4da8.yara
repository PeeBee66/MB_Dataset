
rule MB_1592f885
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:09.879417"
        sha256 = "1592f885ef961b799cf8c7c7d15c3bf3173ed4354e8bff7e84433600ee9c4da8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
