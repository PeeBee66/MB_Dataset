
rule MB_df589f3d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:52.191364"
        sha256 = "df589f3d0776028b7d2e2b143942cc12d1f4c842fa3bb612d09e28a7c4577466"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
