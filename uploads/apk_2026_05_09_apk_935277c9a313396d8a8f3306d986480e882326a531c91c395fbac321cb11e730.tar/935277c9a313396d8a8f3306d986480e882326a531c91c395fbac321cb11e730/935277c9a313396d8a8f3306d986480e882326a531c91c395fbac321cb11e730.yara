
rule MB_935277c9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:01.130595"
        sha256 = "935277c9a313396d8a8f3306d986480e882326a531c91c395fbac321cb11e730"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
