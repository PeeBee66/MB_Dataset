
rule MB_dda6331e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:43.828599"
        sha256 = "dda6331e422540056046d59bf02d682b5510eefe5d42f174144090db29ea5e15"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
