
rule MB_d2a36b49
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:06.720327"
        sha256 = "d2a36b49bae41580ef175166e5fbdbc3f7a70f6c6fcbe41a902d58dbb3654f97"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
