
rule MB_2f451d9c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:28.012343"
        sha256 = "2f451d9cfda5d91b2063a62ed5ad482cd733e899b9ee39ee8bd332b518b3b865"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
