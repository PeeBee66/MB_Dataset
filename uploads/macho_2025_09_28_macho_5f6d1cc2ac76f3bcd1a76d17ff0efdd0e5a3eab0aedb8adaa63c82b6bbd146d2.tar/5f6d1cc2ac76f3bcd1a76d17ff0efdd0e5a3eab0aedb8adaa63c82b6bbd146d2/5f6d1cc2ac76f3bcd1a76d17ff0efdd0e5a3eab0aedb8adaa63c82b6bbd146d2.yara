
rule MB_5f6d1cc2
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:33.306596"
        sha256 = "5f6d1cc2ac76f3bcd1a76d17ff0efdd0e5a3eab0aedb8adaa63c82b6bbd146d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
