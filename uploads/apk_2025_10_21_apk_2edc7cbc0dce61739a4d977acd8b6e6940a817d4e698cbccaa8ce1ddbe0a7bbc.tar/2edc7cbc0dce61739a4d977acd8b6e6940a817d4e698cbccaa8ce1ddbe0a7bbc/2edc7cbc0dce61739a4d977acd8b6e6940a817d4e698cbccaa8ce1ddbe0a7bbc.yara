
rule MB_2edc7cbc
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:17:48.997266"
        sha256 = "2edc7cbc0dce61739a4d977acd8b6e6940a817d4e698cbccaa8ce1ddbe0a7bbc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
