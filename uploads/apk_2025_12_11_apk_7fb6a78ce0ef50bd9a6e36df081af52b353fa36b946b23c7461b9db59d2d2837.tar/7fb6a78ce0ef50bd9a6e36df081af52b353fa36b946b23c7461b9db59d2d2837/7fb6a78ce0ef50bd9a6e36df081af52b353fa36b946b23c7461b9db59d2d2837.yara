
rule MB_7fb6a78c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-10T23:00:50.595712"
        sha256 = "7fb6a78ce0ef50bd9a6e36df081af52b353fa36b946b23c7461b9db59d2d2837"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
