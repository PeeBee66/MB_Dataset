
rule MB_6742251d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:48.631325"
        sha256 = "6742251d4129900c4dfd768e499a6e19856d79ac8a28187013b7d6dbd231b437"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
