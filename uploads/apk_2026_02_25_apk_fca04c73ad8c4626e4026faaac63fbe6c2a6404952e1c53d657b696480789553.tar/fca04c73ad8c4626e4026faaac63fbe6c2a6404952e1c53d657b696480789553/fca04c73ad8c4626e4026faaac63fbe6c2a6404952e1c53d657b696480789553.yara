
rule MB_fca04c73
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-24T23:00:15.862881"
        sha256 = "fca04c73ad8c4626e4026faaac63fbe6c2a6404952e1c53d657b696480789553"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
