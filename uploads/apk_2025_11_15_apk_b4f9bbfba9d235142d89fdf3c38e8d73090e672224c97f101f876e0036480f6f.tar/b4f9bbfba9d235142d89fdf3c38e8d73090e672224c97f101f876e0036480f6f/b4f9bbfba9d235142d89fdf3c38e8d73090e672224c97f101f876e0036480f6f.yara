
rule MB_b4f9bbfb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-14T23:00:54.462566"
        sha256 = "b4f9bbfba9d235142d89fdf3c38e8d73090e672224c97f101f876e0036480f6f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
