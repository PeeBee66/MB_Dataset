
rule MB_9d47ec9b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:38:09.277689"
        sha256 = "9d47ec9b02626d3e375776d99b920039d822e6f45c5d06b8b017cbc925cb5cdf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
