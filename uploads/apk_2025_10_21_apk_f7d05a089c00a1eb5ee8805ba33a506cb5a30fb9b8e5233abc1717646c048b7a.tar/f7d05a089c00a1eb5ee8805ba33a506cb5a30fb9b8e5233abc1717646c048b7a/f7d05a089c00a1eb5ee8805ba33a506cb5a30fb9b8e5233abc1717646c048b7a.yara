
rule MB_f7d05a08
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:30.461261"
        sha256 = "f7d05a089c00a1eb5ee8805ba33a506cb5a30fb9b8e5233abc1717646c048b7a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
