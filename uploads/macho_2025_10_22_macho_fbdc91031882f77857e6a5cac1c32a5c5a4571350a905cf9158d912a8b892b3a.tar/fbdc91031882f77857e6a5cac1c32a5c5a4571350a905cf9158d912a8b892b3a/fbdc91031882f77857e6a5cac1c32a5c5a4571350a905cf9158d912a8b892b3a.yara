
rule MB_fbdc9103
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-21T23:00:19.946404"
        sha256 = "fbdc91031882f77857e6a5cac1c32a5c5a4571350a905cf9158d912a8b892b3a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
