
rule MB_9c4631a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:47.444204"
        sha256 = "9c4631a29177b7b10aac871b2e7936ec0f93496676a764a02a7cd7aea11fb59b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
