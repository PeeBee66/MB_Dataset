
rule MB_77545c57
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:32.165158"
        sha256 = "77545c577129310cd7ea308927da93987da484160add03c1ccfdf3c5fe5b0503"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
