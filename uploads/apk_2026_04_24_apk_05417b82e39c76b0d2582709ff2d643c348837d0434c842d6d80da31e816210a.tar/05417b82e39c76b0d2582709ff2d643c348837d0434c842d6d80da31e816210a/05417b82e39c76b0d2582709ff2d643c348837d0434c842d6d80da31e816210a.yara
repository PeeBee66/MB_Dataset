
rule MB_05417b82
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:00:38.331391"
        sha256 = "05417b82e39c76b0d2582709ff2d643c348837d0434c842d6d80da31e816210a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
