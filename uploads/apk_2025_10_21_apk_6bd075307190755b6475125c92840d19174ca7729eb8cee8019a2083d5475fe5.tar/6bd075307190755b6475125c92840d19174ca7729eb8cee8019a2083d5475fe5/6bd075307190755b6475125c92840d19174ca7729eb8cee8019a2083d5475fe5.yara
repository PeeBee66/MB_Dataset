
rule MB_6bd07530
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:32.980969"
        sha256 = "6bd075307190755b6475125c92840d19174ca7729eb8cee8019a2083d5475fe5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
