
rule MB_94a99ec6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-06T23:00:33.938000"
        sha256 = "94a99ec6423e03f30661c0a83f9b1856f7708e99412456b8f83055484e9ecb3a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
