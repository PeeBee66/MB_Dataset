
rule MB_06afaf8f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:55.618648"
        sha256 = "06afaf8f3e93104a066dfe8fc9967e1e48f41000557b39ae9d373be3a807c6b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
