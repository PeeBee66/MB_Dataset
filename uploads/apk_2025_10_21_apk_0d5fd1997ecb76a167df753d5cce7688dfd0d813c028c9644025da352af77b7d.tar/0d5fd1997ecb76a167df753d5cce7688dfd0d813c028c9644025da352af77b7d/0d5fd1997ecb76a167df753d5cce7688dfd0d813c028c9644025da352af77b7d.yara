
rule MB_0d5fd199
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:17:05.874002"
        sha256 = "0d5fd1997ecb76a167df753d5cce7688dfd0d813c028c9644025da352af77b7d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
