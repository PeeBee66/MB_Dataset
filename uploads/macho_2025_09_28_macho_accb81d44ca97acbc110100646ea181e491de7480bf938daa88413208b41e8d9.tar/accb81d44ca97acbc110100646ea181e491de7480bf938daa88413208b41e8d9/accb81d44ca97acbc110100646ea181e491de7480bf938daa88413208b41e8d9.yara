
rule MB_accb81d4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:36.360497"
        sha256 = "accb81d44ca97acbc110100646ea181e491de7480bf938daa88413208b41e8d9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
