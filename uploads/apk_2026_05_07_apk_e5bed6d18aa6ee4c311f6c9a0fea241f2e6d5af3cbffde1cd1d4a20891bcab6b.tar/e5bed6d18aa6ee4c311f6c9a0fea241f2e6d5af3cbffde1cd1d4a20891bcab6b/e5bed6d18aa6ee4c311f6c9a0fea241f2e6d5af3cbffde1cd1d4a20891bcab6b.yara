
rule MB_e5bed6d1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:52.209592"
        sha256 = "e5bed6d18aa6ee4c311f6c9a0fea241f2e6d5af3cbffde1cd1d4a20891bcab6b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
