
rule MB_2308afb5
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:14.301046"
        sha256 = "2308afb58c08eec15d0ad9048e751eeca001bd17a2106484803c45ef351af752"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
