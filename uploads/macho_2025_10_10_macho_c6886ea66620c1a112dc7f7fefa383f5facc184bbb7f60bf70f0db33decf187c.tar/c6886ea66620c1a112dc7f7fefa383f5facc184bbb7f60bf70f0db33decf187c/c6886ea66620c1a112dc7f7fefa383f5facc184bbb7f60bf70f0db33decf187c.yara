
rule MB_c6886ea6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:55.305268"
        sha256 = "c6886ea66620c1a112dc7f7fefa383f5facc184bbb7f60bf70f0db33decf187c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
