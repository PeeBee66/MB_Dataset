
rule MB_deb74329
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:41.749183"
        sha256 = "deb74329c23d7ac2e3264bd2cdf4e740b0174cc2dae299e6507f848e9ac69dc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
