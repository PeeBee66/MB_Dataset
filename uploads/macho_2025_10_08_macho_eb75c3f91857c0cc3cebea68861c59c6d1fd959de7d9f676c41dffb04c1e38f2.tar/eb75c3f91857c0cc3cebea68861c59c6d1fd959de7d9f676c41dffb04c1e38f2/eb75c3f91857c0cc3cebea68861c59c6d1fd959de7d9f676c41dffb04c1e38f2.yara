
rule MB_eb75c3f9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:28.792776"
        sha256 = "eb75c3f91857c0cc3cebea68861c59c6d1fd959de7d9f676c41dffb04c1e38f2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
