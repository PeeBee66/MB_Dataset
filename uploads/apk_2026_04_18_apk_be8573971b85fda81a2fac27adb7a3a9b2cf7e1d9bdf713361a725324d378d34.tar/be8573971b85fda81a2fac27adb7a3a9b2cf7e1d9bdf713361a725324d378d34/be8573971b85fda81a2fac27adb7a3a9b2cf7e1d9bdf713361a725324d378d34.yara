
rule MB_be857397
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:37.174834"
        sha256 = "be8573971b85fda81a2fac27adb7a3a9b2cf7e1d9bdf713361a725324d378d34"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
