
rule MB_7bac2d43
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:21.958587"
        sha256 = "7bac2d436cb09fe90c3f6b0515263626e876f5c02b9d761661c0c0c94eed5486"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
