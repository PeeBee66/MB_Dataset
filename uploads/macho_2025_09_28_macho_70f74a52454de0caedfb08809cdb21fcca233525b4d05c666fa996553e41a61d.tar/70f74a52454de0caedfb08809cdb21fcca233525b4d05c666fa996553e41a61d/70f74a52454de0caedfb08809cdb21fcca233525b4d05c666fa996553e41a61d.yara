
rule MB_70f74a52
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:58.802285"
        sha256 = "70f74a52454de0caedfb08809cdb21fcca233525b4d05c666fa996553e41a61d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
