
rule MB_e85c0862
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:40.733250"
        sha256 = "e85c0862bb52da419cb43463200e2666f3dcfa065f4284fb0631a59563b58590"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
