
rule MB_8de3ebe6
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:43.066335"
        sha256 = "8de3ebe6fd8eef3d2bfa439913cac77ecb562c754a8935b1eb08eeae93b16173"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
