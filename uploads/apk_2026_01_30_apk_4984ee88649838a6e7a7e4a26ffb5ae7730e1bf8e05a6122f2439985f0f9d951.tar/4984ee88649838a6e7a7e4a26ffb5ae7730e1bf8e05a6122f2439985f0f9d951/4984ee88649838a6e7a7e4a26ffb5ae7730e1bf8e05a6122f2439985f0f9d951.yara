
rule MB_4984ee88
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:01:05.134451"
        sha256 = "4984ee88649838a6e7a7e4a26ffb5ae7730e1bf8e05a6122f2439985f0f9d951"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
