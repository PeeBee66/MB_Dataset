
rule MB_9e5ebe42
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:50.126148"
        sha256 = "9e5ebe42b070c2100b55fff12c8b84361fb1b627911c95d9f7eedf110aa2e1ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
