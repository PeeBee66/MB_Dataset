
rule MB_545f3ae8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-10T23:00:48.801061"
        sha256 = "545f3ae82e2addca3e5f647d55bea79ee299324400269978ab137f5fbfd84a9f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
