
rule MB_eda7b569
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-22T23:00:29.546871"
        sha256 = "eda7b5698cc90a97e44fa863f16d19526a830b57769a9f89097659df88e985fa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
