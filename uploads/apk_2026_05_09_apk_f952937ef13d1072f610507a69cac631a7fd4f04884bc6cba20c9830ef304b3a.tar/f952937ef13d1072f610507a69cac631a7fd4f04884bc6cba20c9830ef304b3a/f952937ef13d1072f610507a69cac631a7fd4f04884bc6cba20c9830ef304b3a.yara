
rule MB_f952937e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:14.035233"
        sha256 = "f952937ef13d1072f610507a69cac631a7fd4f04884bc6cba20c9830ef304b3a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
