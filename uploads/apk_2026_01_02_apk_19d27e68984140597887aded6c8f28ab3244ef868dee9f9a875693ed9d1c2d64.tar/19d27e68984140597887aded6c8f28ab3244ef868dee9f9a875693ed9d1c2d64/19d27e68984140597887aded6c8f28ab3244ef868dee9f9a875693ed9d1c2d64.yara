
rule MB_19d27e68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-01T23:00:18.780008"
        sha256 = "19d27e68984140597887aded6c8f28ab3244ef868dee9f9a875693ed9d1c2d64"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
