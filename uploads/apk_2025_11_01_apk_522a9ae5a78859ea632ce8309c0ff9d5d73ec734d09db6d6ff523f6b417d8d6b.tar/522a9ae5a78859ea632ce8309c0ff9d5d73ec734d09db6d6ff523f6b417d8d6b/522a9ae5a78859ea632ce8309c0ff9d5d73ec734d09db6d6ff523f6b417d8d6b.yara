
rule MB_522a9ae5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:12.929007"
        sha256 = "522a9ae5a78859ea632ce8309c0ff9d5d73ec734d09db6d6ff523f6b417d8d6b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
