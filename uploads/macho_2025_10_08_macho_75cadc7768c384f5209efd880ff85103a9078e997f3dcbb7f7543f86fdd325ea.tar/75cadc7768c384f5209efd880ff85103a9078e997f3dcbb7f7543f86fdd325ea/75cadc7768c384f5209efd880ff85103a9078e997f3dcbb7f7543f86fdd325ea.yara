
rule MB_75cadc77
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:26.358419"
        sha256 = "75cadc7768c384f5209efd880ff85103a9078e997f3dcbb7f7543f86fdd325ea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
