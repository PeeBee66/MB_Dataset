
rule MB_00cd451c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:11.120423"
        sha256 = "00cd451cc73c6e1d8082a69ca36c216f9fd5516688d2c7b5a3b9a41f7af442d8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
