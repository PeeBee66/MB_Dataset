
rule MB_cc93d01b
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:35.437013"
        sha256 = "cc93d01b68b59314a789c5355ac70b8e6965b9f64bb331b0337aac9d2da8aede"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
