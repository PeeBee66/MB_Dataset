
rule MB_7267a3a0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:16.644608"
        sha256 = "7267a3a0354cfb763ab3c143b7f23a45484b4f681d7064d351d64b9f0548bb1b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
