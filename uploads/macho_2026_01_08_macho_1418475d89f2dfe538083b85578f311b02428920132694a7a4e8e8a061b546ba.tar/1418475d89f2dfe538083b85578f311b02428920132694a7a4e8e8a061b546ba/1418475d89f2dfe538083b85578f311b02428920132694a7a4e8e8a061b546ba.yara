
rule MB_1418475d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-07T23:00:28.186547"
        sha256 = "1418475d89f2dfe538083b85578f311b02428920132694a7a4e8e8a061b546ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
