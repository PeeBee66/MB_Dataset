
rule MB_088cb599
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:42.935610"
        sha256 = "088cb59978c66e293a21d7ebb110e7679c34f4dc3b6b0bb20d779d477e934f33"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
