
rule MB_10d5dc36
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:19.169707"
        sha256 = "10d5dc363f4cdeb89bde365e84ece2b1173474a3a60fd8ac2649bc0dc9b90907"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
