
rule MB_9e7d743c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:48.728048"
        sha256 = "9e7d743c341329104a12cfbcf53cc19a9b16c4ec1a874f8d4b42b33e9a68c1f8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
