
rule MB_bb4523d3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:12.700277"
        sha256 = "bb4523d3bd77d76cc66e76cd28ba193fa9333d24a8bd9c1f248fc193b52029e3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
