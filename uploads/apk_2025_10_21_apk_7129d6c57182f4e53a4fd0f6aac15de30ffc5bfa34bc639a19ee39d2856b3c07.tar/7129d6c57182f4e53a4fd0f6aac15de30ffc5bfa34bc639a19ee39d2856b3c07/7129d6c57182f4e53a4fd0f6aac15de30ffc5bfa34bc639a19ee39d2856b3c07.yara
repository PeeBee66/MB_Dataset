
rule MB_7129d6c5
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:04:59.941814"
        sha256 = "7129d6c57182f4e53a4fd0f6aac15de30ffc5bfa34bc639a19ee39d2856b3c07"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
