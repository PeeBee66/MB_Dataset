
rule MB_a3e60274
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:04.830199"
        sha256 = "a3e60274256546f3b7ef72bf2a9531ca767b6bbac4dd484d0935c750b6441989"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
