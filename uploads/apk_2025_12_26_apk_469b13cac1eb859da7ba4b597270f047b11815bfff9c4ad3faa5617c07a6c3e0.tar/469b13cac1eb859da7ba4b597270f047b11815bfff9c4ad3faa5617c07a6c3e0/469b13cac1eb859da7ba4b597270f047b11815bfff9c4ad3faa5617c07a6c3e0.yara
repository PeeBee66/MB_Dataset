
rule MB_469b13ca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-25T23:00:19.452858"
        sha256 = "469b13cac1eb859da7ba4b597270f047b11815bfff9c4ad3faa5617c07a6c3e0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
