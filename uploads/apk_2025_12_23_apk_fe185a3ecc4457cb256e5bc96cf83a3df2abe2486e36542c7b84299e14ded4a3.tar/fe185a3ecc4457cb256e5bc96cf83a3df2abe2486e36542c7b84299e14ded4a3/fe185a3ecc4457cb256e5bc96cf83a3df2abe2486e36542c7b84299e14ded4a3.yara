
rule MB_fe185a3e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-22T23:00:35.257006"
        sha256 = "fe185a3ecc4457cb256e5bc96cf83a3df2abe2486e36542c7b84299e14ded4a3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
