
rule MB_42daa3cb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-08T23:00:14.474621"
        sha256 = "42daa3cb520f43efac1f9724956ae793ce81c322d5935f6a5a1ba8dbf88b13bc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
