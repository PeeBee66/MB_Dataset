
rule MB_1a100ebf
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:59.701719"
        sha256 = "1a100ebfc14624c4f654f38d24640d65fad67baf71f1a05e082c486953d897b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
