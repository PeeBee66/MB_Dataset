
rule MB_545fb5d5
{
    meta:
        description = "Auto-generated rule for Crocodilus"
        author = "MB-Collector"
        date = "2025-10-20T11:52:27.275936"
        sha256 = "545fb5d571cab5d861d1259d4c31cd292795189aee79041821c9d9221c570e9c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
