
rule MB_e4276287
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:38.035825"
        sha256 = "e427628799c9db6842f856a6d9ebb68d7dc5cf6f9fa107119e5b83c5acfd62f6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
