
rule MB_4a899a3b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-15T00:00:21.471506"
        sha256 = "4a899a3b0fd61937ce8555cb0da53daf72dadc7dd299c63e90b4a203e5a14db1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
