
rule MB_ade64aee
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:52.668624"
        sha256 = "ade64aeec6149158044df73122fa6af2be069b2e1853aa109bab64a0c1d72e14"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
