
rule MB_761044b1
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-23T23:00:17.685448"
        sha256 = "761044b1d527d9275746bbd3db90fa3fb7ddf63de366aa8d542a4b8d3a4eeca7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
