
rule MB_28923e66
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:03:00.021246"
        sha256 = "28923e66d5c112fc897efa70a106f5802c29f6bc2e964c52e84e7d352868222b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
