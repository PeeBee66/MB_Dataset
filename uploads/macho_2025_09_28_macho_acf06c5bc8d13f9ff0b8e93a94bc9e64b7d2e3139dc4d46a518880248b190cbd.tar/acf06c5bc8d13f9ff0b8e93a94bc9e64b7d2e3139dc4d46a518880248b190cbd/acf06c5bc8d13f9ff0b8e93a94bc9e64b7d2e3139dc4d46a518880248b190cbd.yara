
rule MB_acf06c5b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:19.407565"
        sha256 = "acf06c5bc8d13f9ff0b8e93a94bc9e64b7d2e3139dc4d46a518880248b190cbd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
