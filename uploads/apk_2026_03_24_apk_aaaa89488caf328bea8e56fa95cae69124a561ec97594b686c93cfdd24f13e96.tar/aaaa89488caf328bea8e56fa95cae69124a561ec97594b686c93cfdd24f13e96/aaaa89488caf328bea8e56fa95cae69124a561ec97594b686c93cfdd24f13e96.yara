
rule MB_aaaa8948
{
    meta:
        description = "Auto-generated rule for Mirai"
        author = "MB-Collector"
        date = "2026-03-23T23:00:42.666534"
        sha256 = "aaaa89488caf328bea8e56fa95cae69124a561ec97594b686c93cfdd24f13e96"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
