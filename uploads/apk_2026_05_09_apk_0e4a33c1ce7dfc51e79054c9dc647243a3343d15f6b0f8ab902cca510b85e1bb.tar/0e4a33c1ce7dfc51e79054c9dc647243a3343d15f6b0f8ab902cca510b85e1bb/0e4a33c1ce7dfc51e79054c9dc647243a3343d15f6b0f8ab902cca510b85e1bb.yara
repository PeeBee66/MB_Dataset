
rule MB_0e4a33c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:43.163412"
        sha256 = "0e4a33c1ce7dfc51e79054c9dc647243a3343d15f6b0f8ab902cca510b85e1bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
