
rule MB_cb860174
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:01:01.069045"
        sha256 = "cb86017411708eb6e5384fc0288b0ec4692ea45ef38586b7c67f99148e1117c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
