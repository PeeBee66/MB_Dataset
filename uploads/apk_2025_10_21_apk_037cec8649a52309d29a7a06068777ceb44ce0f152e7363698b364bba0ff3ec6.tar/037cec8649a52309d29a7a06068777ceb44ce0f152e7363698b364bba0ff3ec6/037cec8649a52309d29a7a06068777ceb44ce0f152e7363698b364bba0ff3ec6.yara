
rule MB_037cec86
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:13.287413"
        sha256 = "037cec8649a52309d29a7a06068777ceb44ce0f152e7363698b364bba0ff3ec6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
