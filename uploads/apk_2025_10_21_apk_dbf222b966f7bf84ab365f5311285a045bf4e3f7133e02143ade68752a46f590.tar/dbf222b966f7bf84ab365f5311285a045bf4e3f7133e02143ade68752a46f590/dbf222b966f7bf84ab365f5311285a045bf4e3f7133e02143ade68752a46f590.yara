
rule MB_dbf222b9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:00:26.404803"
        sha256 = "dbf222b966f7bf84ab365f5311285a045bf4e3f7133e02143ade68752a46f590"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
