
rule MB_9c3e564d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:05.048521"
        sha256 = "9c3e564dd99a0548cd7a42018f01cdb091b00528bef7b3603aea24ddf99b7e51"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
