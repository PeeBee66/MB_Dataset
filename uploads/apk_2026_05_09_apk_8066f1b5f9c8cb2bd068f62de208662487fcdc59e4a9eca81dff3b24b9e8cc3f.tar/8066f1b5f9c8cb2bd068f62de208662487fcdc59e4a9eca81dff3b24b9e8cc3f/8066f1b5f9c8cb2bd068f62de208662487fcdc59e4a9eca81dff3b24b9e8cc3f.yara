
rule MB_8066f1b5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:35.342583"
        sha256 = "8066f1b5f9c8cb2bd068f62de208662487fcdc59e4a9eca81dff3b24b9e8cc3f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
