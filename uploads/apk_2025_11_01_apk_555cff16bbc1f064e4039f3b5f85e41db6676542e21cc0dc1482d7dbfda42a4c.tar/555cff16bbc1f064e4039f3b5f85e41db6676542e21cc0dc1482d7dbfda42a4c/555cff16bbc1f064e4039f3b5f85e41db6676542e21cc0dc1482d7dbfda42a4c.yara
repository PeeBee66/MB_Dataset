
rule MB_555cff16
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:05.996446"
        sha256 = "555cff16bbc1f064e4039f3b5f85e41db6676542e21cc0dc1482d7dbfda42a4c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
