
rule MB_28e883f4
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:49:16.540367"
        sha256 = "28e883f496dcb23f5674e525d11af181f787c5914b849f232e22712792dfe18b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
