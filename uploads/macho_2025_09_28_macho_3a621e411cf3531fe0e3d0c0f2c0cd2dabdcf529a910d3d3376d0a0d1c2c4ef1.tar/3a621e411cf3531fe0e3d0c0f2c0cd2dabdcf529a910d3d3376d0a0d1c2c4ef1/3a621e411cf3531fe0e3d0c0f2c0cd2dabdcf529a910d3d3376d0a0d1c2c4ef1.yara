
rule MB_3a621e41
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-25T00:00:57.160492"
        sha256 = "3a621e411cf3531fe0e3d0c0f2c0cd2dabdcf529a910d3d3376d0a0d1c2c4ef1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
