
rule MB_db0540c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:09.840200"
        sha256 = "db0540c5310619b9a8751d532da20ed5ed61a930f966b729f764756bd1a4fca4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
