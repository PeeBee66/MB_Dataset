
rule MB_0ef295b8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:01.138575"
        sha256 = "0ef295b8e4eeb1374d44f9fcf68e28815a7ec8eabb22e3d3ddb5b20d9dc1f4dd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
