
rule MB_48fd2d06
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:09.351320"
        sha256 = "48fd2d06ac032974c6033587964f33e55dca7b6fb425e99c8b143fe137268827"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
