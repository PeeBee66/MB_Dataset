
rule MB_58380f0d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:54:41.887313"
        sha256 = "58380f0d29fd512ce93a9dbd49c0ced812cdb7d124733a0bd43558954f400853"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
