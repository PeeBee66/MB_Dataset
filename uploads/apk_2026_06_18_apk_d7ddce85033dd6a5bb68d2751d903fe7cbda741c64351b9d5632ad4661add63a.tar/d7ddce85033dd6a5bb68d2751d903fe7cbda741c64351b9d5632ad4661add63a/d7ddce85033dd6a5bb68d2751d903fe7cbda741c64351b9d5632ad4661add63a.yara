
rule MB_d7ddce85
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:37.847073"
        sha256 = "d7ddce85033dd6a5bb68d2751d903fe7cbda741c64351b9d5632ad4661add63a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
