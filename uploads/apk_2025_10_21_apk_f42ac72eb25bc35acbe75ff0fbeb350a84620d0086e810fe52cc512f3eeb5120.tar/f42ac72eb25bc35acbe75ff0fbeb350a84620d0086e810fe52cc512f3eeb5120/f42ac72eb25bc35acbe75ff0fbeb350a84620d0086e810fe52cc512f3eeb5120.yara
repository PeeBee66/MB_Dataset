
rule MB_f42ac72e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:23.098967"
        sha256 = "f42ac72eb25bc35acbe75ff0fbeb350a84620d0086e810fe52cc512f3eeb5120"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
