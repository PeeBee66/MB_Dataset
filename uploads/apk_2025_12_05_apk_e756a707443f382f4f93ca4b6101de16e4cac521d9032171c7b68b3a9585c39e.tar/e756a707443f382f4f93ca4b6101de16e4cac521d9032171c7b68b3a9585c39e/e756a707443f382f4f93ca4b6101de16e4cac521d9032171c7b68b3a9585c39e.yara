
rule MB_e756a707
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:36.432175"
        sha256 = "e756a707443f382f4f93ca4b6101de16e4cac521d9032171c7b68b3a9585c39e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
