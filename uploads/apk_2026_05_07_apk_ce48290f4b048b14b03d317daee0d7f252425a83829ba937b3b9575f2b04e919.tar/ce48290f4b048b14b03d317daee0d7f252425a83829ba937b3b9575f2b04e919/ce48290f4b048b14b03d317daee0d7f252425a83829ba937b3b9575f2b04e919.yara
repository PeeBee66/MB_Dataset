
rule MB_ce48290f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:29.346586"
        sha256 = "ce48290f4b048b14b03d317daee0d7f252425a83829ba937b3b9575f2b04e919"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
