
rule MB_4b8a473a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-11T23:00:22.753118"
        sha256 = "4b8a473a8079c2a502d9c633b1766245cbf29b8dcf39a39b4233264639afeadf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
