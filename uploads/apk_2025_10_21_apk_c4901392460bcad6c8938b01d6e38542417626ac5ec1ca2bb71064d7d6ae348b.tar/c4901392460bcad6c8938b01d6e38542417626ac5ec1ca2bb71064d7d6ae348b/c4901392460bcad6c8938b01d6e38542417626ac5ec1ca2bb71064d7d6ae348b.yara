
rule MB_c4901392
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:41.766171"
        sha256 = "c4901392460bcad6c8938b01d6e38542417626ac5ec1ca2bb71064d7d6ae348b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
