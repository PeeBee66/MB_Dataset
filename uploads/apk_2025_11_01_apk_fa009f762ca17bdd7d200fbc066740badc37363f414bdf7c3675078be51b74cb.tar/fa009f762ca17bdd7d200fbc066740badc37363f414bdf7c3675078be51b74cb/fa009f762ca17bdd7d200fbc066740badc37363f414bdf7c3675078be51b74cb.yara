
rule MB_fa009f76
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:21.694791"
        sha256 = "fa009f762ca17bdd7d200fbc066740badc37363f414bdf7c3675078be51b74cb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
