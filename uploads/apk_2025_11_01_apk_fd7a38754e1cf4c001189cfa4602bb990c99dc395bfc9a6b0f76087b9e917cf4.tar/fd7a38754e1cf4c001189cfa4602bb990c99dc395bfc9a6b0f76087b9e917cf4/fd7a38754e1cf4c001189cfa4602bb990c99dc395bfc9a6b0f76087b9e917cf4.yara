
rule MB_fd7a3875
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:49.774158"
        sha256 = "fd7a38754e1cf4c001189cfa4602bb990c99dc395bfc9a6b0f76087b9e917cf4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
