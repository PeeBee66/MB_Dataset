
rule MB_4de47d8a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:22.887353"
        sha256 = "4de47d8a15aae4aa5333c99cca6908a81e9a3e0a0157882a278a6ccaa756980c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
