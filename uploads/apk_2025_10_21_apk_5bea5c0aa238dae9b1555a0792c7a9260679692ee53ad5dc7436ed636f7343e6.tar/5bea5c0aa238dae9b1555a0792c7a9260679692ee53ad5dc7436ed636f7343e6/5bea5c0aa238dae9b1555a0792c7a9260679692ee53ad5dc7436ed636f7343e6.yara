
rule MB_5bea5c0a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:15.042525"
        sha256 = "5bea5c0aa238dae9b1555a0792c7a9260679692ee53ad5dc7436ed636f7343e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
