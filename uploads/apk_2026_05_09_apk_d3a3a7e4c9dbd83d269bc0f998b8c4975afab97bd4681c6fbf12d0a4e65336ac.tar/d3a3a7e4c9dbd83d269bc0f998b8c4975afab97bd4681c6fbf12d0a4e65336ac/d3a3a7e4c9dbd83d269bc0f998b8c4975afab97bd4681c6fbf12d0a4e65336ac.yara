
rule MB_d3a3a7e4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:59.624774"
        sha256 = "d3a3a7e4c9dbd83d269bc0f998b8c4975afab97bd4681c6fbf12d0a4e65336ac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
