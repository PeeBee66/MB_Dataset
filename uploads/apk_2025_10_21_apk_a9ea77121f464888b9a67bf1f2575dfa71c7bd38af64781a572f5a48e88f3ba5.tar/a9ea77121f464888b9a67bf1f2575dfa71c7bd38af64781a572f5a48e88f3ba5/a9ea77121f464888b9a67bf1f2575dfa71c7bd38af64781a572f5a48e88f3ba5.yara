
rule MB_a9ea7712
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:07.950719"
        sha256 = "a9ea77121f464888b9a67bf1f2575dfa71c7bd38af64781a572f5a48e88f3ba5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
