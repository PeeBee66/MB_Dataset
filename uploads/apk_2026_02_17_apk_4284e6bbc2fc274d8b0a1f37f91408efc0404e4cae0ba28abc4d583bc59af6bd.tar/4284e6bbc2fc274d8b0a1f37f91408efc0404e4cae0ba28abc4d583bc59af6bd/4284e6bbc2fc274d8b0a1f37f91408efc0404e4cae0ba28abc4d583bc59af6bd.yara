
rule MB_4284e6bb
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2026-02-16T23:00:15.809015"
        sha256 = "4284e6bbc2fc274d8b0a1f37f91408efc0404e4cae0ba28abc4d583bc59af6bd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
