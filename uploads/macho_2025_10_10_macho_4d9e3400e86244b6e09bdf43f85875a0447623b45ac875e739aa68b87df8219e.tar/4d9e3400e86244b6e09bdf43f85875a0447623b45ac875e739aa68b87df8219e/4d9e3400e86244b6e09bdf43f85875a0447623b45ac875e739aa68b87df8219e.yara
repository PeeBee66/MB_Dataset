
rule MB_4d9e3400
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:52.929380"
        sha256 = "4d9e3400e86244b6e09bdf43f85875a0447623b45ac875e739aa68b87df8219e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
