
rule MB_8613f7b6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-02T23:00:47.044800"
        sha256 = "8613f7b6df514d53aa419355b0a3e8d032b8448bd45296d4158b848998015e3d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
