
rule MB_141fd0af
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:55.187137"
        sha256 = "141fd0af3686045a572de816e277047cdb740279beb8c89dd37591745d6c1754"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
