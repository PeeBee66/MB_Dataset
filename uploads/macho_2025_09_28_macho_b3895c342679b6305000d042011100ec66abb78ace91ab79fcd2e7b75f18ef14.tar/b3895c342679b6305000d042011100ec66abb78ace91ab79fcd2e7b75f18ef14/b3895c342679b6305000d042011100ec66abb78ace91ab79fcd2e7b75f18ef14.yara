
rule MB_b3895c34
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:11.732784"
        sha256 = "b3895c342679b6305000d042011100ec66abb78ace91ab79fcd2e7b75f18ef14"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
