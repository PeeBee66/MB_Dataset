
rule MB_3616fd60
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:24.638088"
        sha256 = "3616fd6004678159e531fb7e5a173b333c08bd0097aa1f6a4e9f503db4a9999a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
