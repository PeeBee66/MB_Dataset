
rule MB_4ff07276
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-28T23:00:15.852459"
        sha256 = "4ff07276c35f5e9c6f8ec37deaa0bc4f01f033a4e717ef8ce76ef371e8eee29b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
