
rule MB_9b13974c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:00:14.876969"
        sha256 = "9b13974c79f4a82b0503d09be90b48c38a1fd1b1a41528e98f6375a30aaa9ff5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
