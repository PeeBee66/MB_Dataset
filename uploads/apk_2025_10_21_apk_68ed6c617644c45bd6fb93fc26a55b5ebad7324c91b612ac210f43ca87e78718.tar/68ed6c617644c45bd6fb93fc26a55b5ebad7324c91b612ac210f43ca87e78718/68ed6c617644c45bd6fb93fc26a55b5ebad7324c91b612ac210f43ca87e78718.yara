
rule MB_68ed6c61
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:07.565633"
        sha256 = "68ed6c617644c45bd6fb93fc26a55b5ebad7324c91b612ac210f43ca87e78718"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
