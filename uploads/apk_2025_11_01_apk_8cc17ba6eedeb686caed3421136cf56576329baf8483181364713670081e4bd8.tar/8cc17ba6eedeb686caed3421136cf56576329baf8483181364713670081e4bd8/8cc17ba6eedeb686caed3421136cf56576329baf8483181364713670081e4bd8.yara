
rule MB_8cc17ba6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:06.733653"
        sha256 = "8cc17ba6eedeb686caed3421136cf56576329baf8483181364713670081e4bd8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
