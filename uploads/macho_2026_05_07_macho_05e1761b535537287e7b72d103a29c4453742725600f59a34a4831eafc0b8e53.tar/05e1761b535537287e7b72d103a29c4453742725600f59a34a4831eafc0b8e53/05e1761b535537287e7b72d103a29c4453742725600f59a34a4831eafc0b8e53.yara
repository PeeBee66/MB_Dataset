
rule MB_05e1761b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:45.204128"
        sha256 = "05e1761b535537287e7b72d103a29c4453742725600f59a34a4831eafc0b8e53"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
