
rule MB_abf614c3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:36.509239"
        sha256 = "abf614c388216d3e04e3a4a8faf5e851205fa22af4a7313278d994934dc124da"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
