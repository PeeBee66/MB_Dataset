
rule MB_948106b2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:04:00.447801"
        sha256 = "948106b2510f03410c01bf4c0ad14d4aea216a1b890147da22d31ea7529cd744"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
