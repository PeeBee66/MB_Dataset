
rule MB_01a5f06c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:00:54.639727"
        sha256 = "01a5f06c4f2e7b181000fdac309c70b0d52f878df3cf8e4f1af25fb512dcc930"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
