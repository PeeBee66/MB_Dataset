
rule MB_7dc0abdc
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:35.565447"
        sha256 = "7dc0abdc72016c3394e804cd865d40d9433bdc0ee13d8e4511c202b12b947af0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
