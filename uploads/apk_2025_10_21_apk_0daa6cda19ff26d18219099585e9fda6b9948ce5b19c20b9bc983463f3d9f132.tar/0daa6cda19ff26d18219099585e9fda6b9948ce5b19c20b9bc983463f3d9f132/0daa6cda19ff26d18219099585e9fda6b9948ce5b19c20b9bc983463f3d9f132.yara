
rule MB_0daa6cda
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:22:17.125103"
        sha256 = "0daa6cda19ff26d18219099585e9fda6b9948ce5b19c20b9bc983463f3d9f132"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
