
rule MB_8ea78d33
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:22.721005"
        sha256 = "8ea78d335b8b931b49945e3ce36d12b1576647e7fb797840d3d1fa61b2f42200"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
