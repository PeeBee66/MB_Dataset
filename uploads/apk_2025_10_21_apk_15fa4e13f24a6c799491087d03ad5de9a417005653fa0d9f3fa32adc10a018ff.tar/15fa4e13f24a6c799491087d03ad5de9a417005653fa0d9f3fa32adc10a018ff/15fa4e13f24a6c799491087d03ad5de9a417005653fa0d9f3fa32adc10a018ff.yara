
rule MB_15fa4e13
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:58.792841"
        sha256 = "15fa4e13f24a6c799491087d03ad5de9a417005653fa0d9f3fa32adc10a018ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
