
rule MB_e5701b3e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:09.564048"
        sha256 = "e5701b3ec6b8d1132295098f1544a5ac98617eb9d188db7f625627cb57c1895d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
