
rule MB_35142083
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:00:55.073629"
        sha256 = "35142083739865cae3d077b2bc96cdc348f871dc7d0d9d3e2bbfb27a91b7af75"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
