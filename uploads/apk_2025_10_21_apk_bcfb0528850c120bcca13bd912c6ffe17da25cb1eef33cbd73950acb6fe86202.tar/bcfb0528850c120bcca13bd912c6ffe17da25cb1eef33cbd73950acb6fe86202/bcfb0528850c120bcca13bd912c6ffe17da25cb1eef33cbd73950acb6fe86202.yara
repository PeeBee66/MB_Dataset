
rule MB_bcfb0528
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:07:05.682553"
        sha256 = "bcfb0528850c120bcca13bd912c6ffe17da25cb1eef33cbd73950acb6fe86202"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
