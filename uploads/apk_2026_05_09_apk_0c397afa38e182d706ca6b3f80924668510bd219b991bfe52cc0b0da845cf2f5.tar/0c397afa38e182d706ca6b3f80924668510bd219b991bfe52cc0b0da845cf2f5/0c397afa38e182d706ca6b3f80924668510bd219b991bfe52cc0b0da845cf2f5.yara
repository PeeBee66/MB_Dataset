
rule MB_0c397afa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:31.681431"
        sha256 = "0c397afa38e182d706ca6b3f80924668510bd219b991bfe52cc0b0da845cf2f5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
