
rule MB_0b1ec2ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:35.678250"
        sha256 = "0b1ec2ec785de0e27f3e2f3cbe912917503581530a2978b8c2f49836c811aafa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
