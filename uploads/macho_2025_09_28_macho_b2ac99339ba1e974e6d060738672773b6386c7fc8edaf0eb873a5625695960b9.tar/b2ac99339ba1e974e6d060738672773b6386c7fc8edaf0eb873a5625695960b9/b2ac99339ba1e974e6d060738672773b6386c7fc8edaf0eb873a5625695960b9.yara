
rule MB_b2ac9933
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:17.160638"
        sha256 = "b2ac99339ba1e974e6d060738672773b6386c7fc8edaf0eb873a5625695960b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
