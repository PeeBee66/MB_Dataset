
rule MB_2d1ac347
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:01.216544"
        sha256 = "2d1ac347eba661bf71ef7a01ce269c626b8b05dda9e415d613d812c38907debe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
