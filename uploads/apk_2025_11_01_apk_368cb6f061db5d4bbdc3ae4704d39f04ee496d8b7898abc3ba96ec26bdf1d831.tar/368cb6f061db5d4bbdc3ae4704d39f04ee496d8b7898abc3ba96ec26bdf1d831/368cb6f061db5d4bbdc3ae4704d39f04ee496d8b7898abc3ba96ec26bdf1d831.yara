
rule MB_368cb6f0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:32.104971"
        sha256 = "368cb6f061db5d4bbdc3ae4704d39f04ee496d8b7898abc3ba96ec26bdf1d831"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
