
rule MB_b600af54
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:01:11.754843"
        sha256 = "b600af54745d2cf6529d048e701b579368af19ff69a08b5ae26d1f0d0a706047"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
