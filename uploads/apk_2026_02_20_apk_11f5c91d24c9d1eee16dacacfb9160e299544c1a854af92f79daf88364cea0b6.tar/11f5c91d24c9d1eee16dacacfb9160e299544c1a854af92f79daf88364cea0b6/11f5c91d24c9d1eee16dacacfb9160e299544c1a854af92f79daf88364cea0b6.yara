
rule MB_11f5c91d
{
    meta:
        description = "Auto-generated rule for PromptSpy"
        author = "MB-Collector"
        date = "2026-02-19T23:00:51.157447"
        sha256 = "11f5c91d24c9d1eee16dacacfb9160e299544c1a854af92f79daf88364cea0b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
