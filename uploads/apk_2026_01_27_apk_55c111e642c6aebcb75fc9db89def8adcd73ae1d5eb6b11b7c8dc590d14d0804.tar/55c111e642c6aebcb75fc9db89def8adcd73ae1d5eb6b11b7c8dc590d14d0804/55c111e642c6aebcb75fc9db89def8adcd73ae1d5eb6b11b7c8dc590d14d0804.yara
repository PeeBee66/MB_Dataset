
rule MB_55c111e6
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2026-01-26T23:00:13.381035"
        sha256 = "55c111e642c6aebcb75fc9db89def8adcd73ae1d5eb6b11b7c8dc590d14d0804"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
