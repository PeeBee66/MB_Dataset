
rule MB_a635ac1a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:29:10.393422"
        sha256 = "a635ac1add91cd134d2047cf0f26627ae0cbebb9605a834ccc7b90af3da0c85e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
