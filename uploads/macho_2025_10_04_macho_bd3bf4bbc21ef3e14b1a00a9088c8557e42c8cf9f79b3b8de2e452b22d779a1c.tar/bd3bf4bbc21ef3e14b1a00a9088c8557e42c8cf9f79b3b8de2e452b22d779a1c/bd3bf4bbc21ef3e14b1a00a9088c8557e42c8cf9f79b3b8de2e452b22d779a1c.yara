
rule MB_bd3bf4bb
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:25.019587"
        sha256 = "bd3bf4bbc21ef3e14b1a00a9088c8557e42c8cf9f79b3b8de2e452b22d779a1c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
