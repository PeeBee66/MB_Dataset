
rule MB_6d9fd392
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T12:05:51.459156"
        sha256 = "6d9fd3927896151176c9f84d128b78a94bdc3e432ba9d3885fa3080d7593a599"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
