
rule MB_51ed3d9e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:24:51.803416"
        sha256 = "51ed3d9ef4dd6d029c9b26d469b125ad911b69a256eeb210f030e1e414632da9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
