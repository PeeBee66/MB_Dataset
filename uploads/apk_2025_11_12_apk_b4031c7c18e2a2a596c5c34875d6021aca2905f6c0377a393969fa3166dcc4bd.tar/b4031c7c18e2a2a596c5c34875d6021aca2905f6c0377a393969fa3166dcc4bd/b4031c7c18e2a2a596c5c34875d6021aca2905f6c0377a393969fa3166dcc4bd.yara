
rule MB_b4031c7c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:27.643356"
        sha256 = "b4031c7c18e2a2a596c5c34875d6021aca2905f6c0377a393969fa3166dcc4bd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
