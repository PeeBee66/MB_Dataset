
rule MB_80ebc347
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:26.710786"
        sha256 = "80ebc347f3256dd2c0b505f25c9620f334bf9fd716f17f1b45a020671d3a69f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
