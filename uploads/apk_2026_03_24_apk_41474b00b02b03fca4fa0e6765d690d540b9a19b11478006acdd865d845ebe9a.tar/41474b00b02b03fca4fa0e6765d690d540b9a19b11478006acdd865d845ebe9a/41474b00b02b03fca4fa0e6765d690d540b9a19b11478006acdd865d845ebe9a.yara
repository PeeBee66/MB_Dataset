
rule MB_41474b00
{
    meta:
        description = "Auto-generated rule for Mirai"
        author = "MB-Collector"
        date = "2026-03-23T23:01:00.067770"
        sha256 = "41474b00b02b03fca4fa0e6765d690d540b9a19b11478006acdd865d845ebe9a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
