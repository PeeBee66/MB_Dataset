
rule MB_a964e75e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:40.543830"
        sha256 = "a964e75ef08d5527030c1ffa8aeaaf1c71a137ea8e36d529504b65c469cb9a20"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
