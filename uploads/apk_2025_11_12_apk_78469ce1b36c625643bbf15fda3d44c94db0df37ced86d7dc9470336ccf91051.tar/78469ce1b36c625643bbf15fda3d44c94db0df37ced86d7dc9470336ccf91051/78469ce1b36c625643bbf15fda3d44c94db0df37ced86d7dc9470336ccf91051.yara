
rule MB_78469ce1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:23.361754"
        sha256 = "78469ce1b36c625643bbf15fda3d44c94db0df37ced86d7dc9470336ccf91051"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
