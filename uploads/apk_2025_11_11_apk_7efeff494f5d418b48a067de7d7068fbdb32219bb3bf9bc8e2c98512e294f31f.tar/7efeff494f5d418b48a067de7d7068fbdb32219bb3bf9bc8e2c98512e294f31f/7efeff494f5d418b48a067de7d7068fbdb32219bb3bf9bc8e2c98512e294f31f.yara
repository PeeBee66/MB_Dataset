
rule MB_7efeff49
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:00:29.556736"
        sha256 = "7efeff494f5d418b48a067de7d7068fbdb32219bb3bf9bc8e2c98512e294f31f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
