
rule MB_60d956cf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:20.975338"
        sha256 = "60d956cfec82e4b42a43df8fb9f396d4df4e4384ef905f2259c29fcdbab68daf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
