
rule MB_72b96c8e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:55.141471"
        sha256 = "72b96c8eece36bc61e42c47fea308d009945da34c1464f741d6be75496e58fda"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
