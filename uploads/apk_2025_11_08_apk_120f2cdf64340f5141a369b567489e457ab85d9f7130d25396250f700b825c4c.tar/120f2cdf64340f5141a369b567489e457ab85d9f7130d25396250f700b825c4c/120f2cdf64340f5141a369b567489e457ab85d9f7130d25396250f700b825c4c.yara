
rule MB_120f2cdf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:00:21.710773"
        sha256 = "120f2cdf64340f5141a369b567489e457ab85d9f7130d25396250f700b825c4c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
