
rule MB_fc63ee55
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-30T23:00:16.213385"
        sha256 = "fc63ee556571cc26cf5a1d7ba1daee536a85438847d0f21886006fff3731124e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
