
rule MB_8898c2c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:45.716746"
        sha256 = "8898c2c1e80a204c0a4ef3eac952bb98cfdae323d24c6ba79a3f53015eaf77ed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
