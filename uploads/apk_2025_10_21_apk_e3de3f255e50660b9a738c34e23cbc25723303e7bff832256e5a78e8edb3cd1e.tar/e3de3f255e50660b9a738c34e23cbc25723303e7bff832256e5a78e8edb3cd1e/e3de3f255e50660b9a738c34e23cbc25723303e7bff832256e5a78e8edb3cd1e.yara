
rule MB_e3de3f25
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:16.566316"
        sha256 = "e3de3f255e50660b9a738c34e23cbc25723303e7bff832256e5a78e8edb3cd1e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
