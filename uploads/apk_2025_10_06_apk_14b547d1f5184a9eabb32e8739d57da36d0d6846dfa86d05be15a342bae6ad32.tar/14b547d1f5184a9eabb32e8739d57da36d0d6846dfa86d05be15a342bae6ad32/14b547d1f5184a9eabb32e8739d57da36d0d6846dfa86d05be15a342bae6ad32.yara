
rule MB_14b547d1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-05T23:00:12.544249"
        sha256 = "14b547d1f5184a9eabb32e8739d57da36d0d6846dfa86d05be15a342bae6ad32"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
