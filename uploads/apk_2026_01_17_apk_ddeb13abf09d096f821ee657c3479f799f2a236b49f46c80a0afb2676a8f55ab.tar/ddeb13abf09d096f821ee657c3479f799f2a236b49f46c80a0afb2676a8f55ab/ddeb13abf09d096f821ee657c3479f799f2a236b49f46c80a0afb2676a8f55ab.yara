
rule MB_ddeb13ab
{
    meta:
        description = "Auto-generated rule for FantasyHub"
        author = "MB-Collector"
        date = "2026-01-16T23:00:49.261335"
        sha256 = "ddeb13abf09d096f821ee657c3479f799f2a236b49f46c80a0afb2676a8f55ab"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
