
rule MB_d2d12dc0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:54.701388"
        sha256 = "d2d12dc0df33a61d78a8466be97f5852241853f671f2afd8d4de130bca9886d0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
