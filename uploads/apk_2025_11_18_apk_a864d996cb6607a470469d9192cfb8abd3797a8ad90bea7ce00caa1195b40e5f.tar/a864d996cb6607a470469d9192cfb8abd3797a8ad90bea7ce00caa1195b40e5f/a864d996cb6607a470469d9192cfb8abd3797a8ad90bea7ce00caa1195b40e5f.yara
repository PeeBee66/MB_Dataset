
rule MB_a864d996
{
    meta:
        description = "Auto-generated rule for ClayRat"
        author = "MB-Collector"
        date = "2025-11-17T23:00:23.113623"
        sha256 = "a864d996cb6607a470469d9192cfb8abd3797a8ad90bea7ce00caa1195b40e5f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
