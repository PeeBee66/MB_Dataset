
rule MB_f5301973
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:46:58.417741"
        sha256 = "f5301973ed33987cb2647b64e165c2732288d401aba6d63281b1d8956cc0fde7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
