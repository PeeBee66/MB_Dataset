
rule MB_4b9a92bc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:38.465447"
        sha256 = "4b9a92bc2ba87c302fa3fc5090d588d9c2dc86a35b3caf61bba460a81b65dc9a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
