
rule MB_814cd115
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-21T23:00:21.397744"
        sha256 = "814cd115a30c5b4bfbb276524774a3ad2396e7f346c9f083983131b3e08200d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
