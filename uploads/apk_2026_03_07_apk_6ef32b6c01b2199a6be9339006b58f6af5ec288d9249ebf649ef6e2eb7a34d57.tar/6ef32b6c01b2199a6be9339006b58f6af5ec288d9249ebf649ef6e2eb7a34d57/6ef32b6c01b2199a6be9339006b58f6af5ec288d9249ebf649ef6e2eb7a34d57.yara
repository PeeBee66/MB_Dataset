
rule MB_6ef32b6c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-06T23:00:15.977443"
        sha256 = "6ef32b6c01b2199a6be9339006b58f6af5ec288d9249ebf649ef6e2eb7a34d57"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
