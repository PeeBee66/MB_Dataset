
rule MB_7bb8109e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:57.525287"
        sha256 = "7bb8109ee9b333a946198e120ba255255e8faf5afc766549b8e9aee8653516a9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
