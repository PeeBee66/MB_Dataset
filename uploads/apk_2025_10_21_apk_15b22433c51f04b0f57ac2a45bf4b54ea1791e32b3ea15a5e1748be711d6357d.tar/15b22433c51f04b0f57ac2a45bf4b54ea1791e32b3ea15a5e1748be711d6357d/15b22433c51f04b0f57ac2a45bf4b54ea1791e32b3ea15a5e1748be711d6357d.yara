
rule MB_15b22433
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:28.980408"
        sha256 = "15b22433c51f04b0f57ac2a45bf4b54ea1791e32b3ea15a5e1748be711d6357d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
