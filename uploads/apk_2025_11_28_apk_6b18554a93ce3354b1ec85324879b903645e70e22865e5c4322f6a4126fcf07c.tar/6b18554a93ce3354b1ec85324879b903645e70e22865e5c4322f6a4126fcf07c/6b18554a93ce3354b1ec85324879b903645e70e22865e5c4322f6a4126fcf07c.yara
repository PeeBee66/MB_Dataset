
rule MB_6b18554a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-27T23:00:24.949053"
        sha256 = "6b18554a93ce3354b1ec85324879b903645e70e22865e5c4322f6a4126fcf07c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
