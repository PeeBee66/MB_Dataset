
rule MB_3cc1c8da
{
    meta:
        description = "Auto-generated rule for SpyLoan"
        author = "MB-Collector"
        date = "2025-10-20T11:47:19.832834"
        sha256 = "3cc1c8da58c90c2bfd6e6e034e34cbee1eeda1052fbeadd4a2e491814fbf715b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
