
rule MB_458bb197
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:31.890168"
        sha256 = "458bb197cf9a7a0f939c96c5878c8ef6a1c8c2e907191e903d611fdcde097bba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
