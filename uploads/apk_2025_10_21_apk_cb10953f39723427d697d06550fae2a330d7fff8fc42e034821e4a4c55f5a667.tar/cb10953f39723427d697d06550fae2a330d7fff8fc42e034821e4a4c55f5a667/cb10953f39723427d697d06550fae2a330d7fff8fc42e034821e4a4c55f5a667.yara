
rule MB_cb10953f
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:27:19.993207"
        sha256 = "cb10953f39723427d697d06550fae2a330d7fff8fc42e034821e4a4c55f5a667"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
