
rule MB_c7901737
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:01:08.383845"
        sha256 = "c7901737aac985af2419bc008a3b5c89f2c6386c1cff9b16d91aac664f14d455"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
