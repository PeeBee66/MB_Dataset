
rule MB_edfd0754
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:07.126469"
        sha256 = "edfd075428d8c9642cfc074c6a4fae10314576851990f028e6af1ef769f930c9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
