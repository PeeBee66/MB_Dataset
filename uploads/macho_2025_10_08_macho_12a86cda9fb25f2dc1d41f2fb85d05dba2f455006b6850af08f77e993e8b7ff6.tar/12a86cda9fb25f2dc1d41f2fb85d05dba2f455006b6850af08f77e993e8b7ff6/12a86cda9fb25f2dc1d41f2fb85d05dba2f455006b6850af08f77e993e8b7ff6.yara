
rule MB_12a86cda
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:52.795076"
        sha256 = "12a86cda9fb25f2dc1d41f2fb85d05dba2f455006b6850af08f77e993e8b7ff6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
