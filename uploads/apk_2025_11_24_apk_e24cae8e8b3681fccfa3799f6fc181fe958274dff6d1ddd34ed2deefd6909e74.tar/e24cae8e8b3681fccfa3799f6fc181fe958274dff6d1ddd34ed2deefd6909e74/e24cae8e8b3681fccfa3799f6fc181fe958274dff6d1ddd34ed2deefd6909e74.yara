
rule MB_e24cae8e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:29.799648"
        sha256 = "e24cae8e8b3681fccfa3799f6fc181fe958274dff6d1ddd34ed2deefd6909e74"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
