
rule MB_c6aa6db2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:48.768449"
        sha256 = "c6aa6db2256152000c341a4a16007f27665a01571e241e7f306428bb36cd35b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
