
rule MB_1efebfa4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:52.728487"
        sha256 = "1efebfa40c0c675012dd148d80ab0f5a6c293423efc73a966ec56b26af64a288"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
