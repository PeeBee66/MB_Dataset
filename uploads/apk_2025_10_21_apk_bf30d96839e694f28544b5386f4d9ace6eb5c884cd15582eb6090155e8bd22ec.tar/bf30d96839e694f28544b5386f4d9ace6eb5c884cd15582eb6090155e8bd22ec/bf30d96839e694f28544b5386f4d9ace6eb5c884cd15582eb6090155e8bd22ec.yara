
rule MB_bf30d968
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:29:43.226522"
        sha256 = "bf30d96839e694f28544b5386f4d9ace6eb5c884cd15582eb6090155e8bd22ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
