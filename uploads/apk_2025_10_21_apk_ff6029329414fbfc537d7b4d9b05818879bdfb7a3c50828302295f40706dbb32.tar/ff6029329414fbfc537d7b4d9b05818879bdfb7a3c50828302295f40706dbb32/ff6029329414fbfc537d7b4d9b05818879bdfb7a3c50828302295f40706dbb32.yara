
rule MB_ff602932
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:11:37.915395"
        sha256 = "ff6029329414fbfc537d7b4d9b05818879bdfb7a3c50828302295f40706dbb32"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
