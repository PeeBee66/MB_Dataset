
rule MB_aad56bf3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:14.183382"
        sha256 = "aad56bf3869df1c921ef233463897985bb89b16d0f3cb0e78ef70d3847d6b76c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
