
rule MB_efcff956
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:57.685280"
        sha256 = "efcff9561554664b31eced79801af2c1f5ea6f541c2b88053b04c422d9989043"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
