
rule MB_83b454aa
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-10T23:00:19.888312"
        sha256 = "83b454aa3ae08b286b571ae5e05958b217b9fff13f0553e202853b6e11d53f84"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
