
rule MB_0b028b78
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-08T00:00:47.525875"
        sha256 = "0b028b781950641818800fee2b4bf68e4ef2bcee53fe71a21755275ba108783d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
