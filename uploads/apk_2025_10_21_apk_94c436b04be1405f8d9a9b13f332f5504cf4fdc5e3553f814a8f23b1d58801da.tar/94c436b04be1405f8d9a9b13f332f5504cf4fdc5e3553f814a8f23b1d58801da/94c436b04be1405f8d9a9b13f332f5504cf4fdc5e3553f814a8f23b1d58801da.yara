
rule MB_94c436b0
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:11:47.681665"
        sha256 = "94c436b04be1405f8d9a9b13f332f5504cf4fdc5e3553f814a8f23b1d58801da"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
