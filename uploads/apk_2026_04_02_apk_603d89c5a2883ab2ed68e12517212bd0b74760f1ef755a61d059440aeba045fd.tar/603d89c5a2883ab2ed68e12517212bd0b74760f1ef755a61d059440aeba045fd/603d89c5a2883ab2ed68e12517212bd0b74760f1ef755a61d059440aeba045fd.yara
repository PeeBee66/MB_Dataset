
rule MB_603d89c5
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-01T23:00:29.934994"
        sha256 = "603d89c5a2883ab2ed68e12517212bd0b74760f1ef755a61d059440aeba045fd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
