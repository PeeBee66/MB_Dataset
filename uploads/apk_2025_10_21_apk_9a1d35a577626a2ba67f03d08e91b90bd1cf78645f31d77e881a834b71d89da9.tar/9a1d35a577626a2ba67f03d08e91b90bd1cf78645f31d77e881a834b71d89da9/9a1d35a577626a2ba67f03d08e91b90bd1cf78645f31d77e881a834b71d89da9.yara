
rule MB_9a1d35a5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:31.277216"
        sha256 = "9a1d35a577626a2ba67f03d08e91b90bd1cf78645f31d77e881a834b71d89da9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
