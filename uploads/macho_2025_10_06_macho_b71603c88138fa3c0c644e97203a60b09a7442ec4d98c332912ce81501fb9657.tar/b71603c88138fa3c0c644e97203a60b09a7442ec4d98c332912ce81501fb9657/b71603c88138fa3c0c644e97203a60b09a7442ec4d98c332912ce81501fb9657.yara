
rule MB_b71603c8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:35.866781"
        sha256 = "b71603c88138fa3c0c644e97203a60b09a7442ec4d98c332912ce81501fb9657"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
