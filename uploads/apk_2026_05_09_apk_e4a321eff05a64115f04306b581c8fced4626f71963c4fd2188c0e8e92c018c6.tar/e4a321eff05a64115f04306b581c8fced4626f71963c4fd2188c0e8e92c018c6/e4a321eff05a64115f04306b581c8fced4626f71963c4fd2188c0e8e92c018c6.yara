
rule MB_e4a321ef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:00:25.058572"
        sha256 = "e4a321eff05a64115f04306b581c8fced4626f71963c4fd2188c0e8e92c018c6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
