
rule MB_b16a65ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:15.061489"
        sha256 = "b16a65ec48ea5469c2c51c4d88a44da4823c59e746ddc51d2c5ea865f3e0f4f8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
