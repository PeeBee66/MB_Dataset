
rule MB_810926f8
{
    meta:
        description = "Auto-generated rule for Hydra"
        author = "MB-Collector"
        date = "2026-04-03T23:01:32.101833"
        sha256 = "810926f89430144fd258ed4a95f1d77215f657a4e7dac2ce0c410bcffbdca99e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
