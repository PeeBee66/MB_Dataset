
rule MB_108ca43c
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:00:46.625981"
        sha256 = "108ca43c5a62640b5e3d71df33c00549c46634c1109c1ac6690df89fbc4211fd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
