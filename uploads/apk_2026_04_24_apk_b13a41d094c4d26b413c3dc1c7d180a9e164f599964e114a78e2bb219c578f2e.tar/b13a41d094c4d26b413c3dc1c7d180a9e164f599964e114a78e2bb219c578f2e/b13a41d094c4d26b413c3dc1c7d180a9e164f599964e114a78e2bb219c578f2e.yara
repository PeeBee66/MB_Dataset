
rule MB_b13a41d0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:00:23.604872"
        sha256 = "b13a41d094c4d26b413c3dc1c7d180a9e164f599964e114a78e2bb219c578f2e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
