
rule MB_5e48bbe1
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-31T23:00:15.866987"
        sha256 = "5e48bbe1c62da18d4c0f2cca0f8855219c5a05f81c5fb64c1b4a0a6871fa8736"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
