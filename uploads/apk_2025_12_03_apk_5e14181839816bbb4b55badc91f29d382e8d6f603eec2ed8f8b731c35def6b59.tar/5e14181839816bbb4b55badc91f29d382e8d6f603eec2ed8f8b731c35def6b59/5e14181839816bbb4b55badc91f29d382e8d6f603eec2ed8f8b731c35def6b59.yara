
rule MB_5e141818
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:14.317857"
        sha256 = "5e14181839816bbb4b55badc91f29d382e8d6f603eec2ed8f8b731c35def6b59"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
