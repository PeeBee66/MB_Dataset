
rule MB_c6f25537
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-28T23:00:12.139088"
        sha256 = "c6f2553734e73ffbafab7acba0194ad545cdce3364e60e2014f37b0e49e1ab64"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
