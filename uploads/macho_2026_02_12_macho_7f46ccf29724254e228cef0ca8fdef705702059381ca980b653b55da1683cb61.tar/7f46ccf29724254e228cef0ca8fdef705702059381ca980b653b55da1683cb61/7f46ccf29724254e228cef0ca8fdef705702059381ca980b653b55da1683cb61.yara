
rule MB_7f46ccf2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-11T23:00:33.655287"
        sha256 = "7f46ccf29724254e228cef0ca8fdef705702059381ca980b653b55da1683cb61"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
