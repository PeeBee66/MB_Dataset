
rule MB_2c6b914f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:41.803875"
        sha256 = "2c6b914f9e27482152f704d3baea6c8030da859c9f5807be4e615680f93563a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
