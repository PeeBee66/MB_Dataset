
rule MB_4bcbb3d7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-10T00:00:41.330281"
        sha256 = "4bcbb3d7a3a687fefb0c848711e334645b3df2700cdf751a74d30dc101c601d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
