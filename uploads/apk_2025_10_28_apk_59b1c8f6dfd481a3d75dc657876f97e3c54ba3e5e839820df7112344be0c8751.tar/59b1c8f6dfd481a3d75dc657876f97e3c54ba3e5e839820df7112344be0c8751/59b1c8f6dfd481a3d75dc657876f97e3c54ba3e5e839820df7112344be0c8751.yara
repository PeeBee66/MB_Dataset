
rule MB_59b1c8f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-27T23:00:13.830348"
        sha256 = "59b1c8f6dfd481a3d75dc657876f97e3c54ba3e5e839820df7112344be0c8751"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
