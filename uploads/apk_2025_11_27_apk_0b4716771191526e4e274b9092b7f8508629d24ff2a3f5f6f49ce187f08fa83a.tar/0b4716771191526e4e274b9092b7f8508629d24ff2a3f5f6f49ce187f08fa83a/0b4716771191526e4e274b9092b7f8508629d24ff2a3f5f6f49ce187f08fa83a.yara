
rule MB_0b471677
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:01:11.868329"
        sha256 = "0b4716771191526e4e274b9092b7f8508629d24ff2a3f5f6f49ce187f08fa83a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
