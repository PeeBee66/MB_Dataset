
rule MB_98f2667a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:02.097052"
        sha256 = "98f2667aec5f74c0701467ea86c6a45a53604075f968263c12650759d157ba59"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
