
rule MB_cf3ac726
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:16.664319"
        sha256 = "cf3ac7265631cf1cb96f617addee7b4100f4e582e215a7e4a190c9730c49044f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
