
rule MB_06f7dfdf
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-28T23:00:29.603068"
        sha256 = "06f7dfdfbff03719082750fb11ca1f1fe720daa57f11c7d30d3b3277bfeceb13"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
