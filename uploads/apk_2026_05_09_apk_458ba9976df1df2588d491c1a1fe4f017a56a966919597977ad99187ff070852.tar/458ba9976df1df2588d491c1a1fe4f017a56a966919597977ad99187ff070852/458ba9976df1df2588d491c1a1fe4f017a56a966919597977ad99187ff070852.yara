
rule MB_458ba997
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:25.723649"
        sha256 = "458ba9976df1df2588d491c1a1fe4f017a56a966919597977ad99187ff070852"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
