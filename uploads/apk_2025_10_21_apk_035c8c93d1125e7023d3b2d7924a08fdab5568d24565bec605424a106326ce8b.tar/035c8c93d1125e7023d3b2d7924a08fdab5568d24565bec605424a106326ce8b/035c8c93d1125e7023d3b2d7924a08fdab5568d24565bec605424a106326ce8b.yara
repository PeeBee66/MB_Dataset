
rule MB_035c8c93
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:04.187790"
        sha256 = "035c8c93d1125e7023d3b2d7924a08fdab5568d24565bec605424a106326ce8b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
