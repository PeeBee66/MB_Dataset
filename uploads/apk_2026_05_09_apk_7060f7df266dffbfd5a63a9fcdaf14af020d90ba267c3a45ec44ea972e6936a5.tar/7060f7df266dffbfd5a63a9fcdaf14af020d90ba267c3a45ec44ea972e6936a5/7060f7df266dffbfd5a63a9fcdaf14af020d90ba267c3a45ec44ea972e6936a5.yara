
rule MB_7060f7df
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:09.386687"
        sha256 = "7060f7df266dffbfd5a63a9fcdaf14af020d90ba267c3a45ec44ea972e6936a5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
