
rule MB_75706716
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:53.738716"
        sha256 = "75706716dde40f477eb8aef34d3ca01c66e999db3d104a427aa8a63ba7f0230c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
