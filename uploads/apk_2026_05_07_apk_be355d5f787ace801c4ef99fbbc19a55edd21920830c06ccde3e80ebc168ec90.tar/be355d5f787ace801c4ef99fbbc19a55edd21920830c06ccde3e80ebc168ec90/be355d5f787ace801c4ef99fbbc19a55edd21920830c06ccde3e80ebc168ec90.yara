
rule MB_be355d5f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:36.787771"
        sha256 = "be355d5f787ace801c4ef99fbbc19a55edd21920830c06ccde3e80ebc168ec90"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
