
rule MB_4382590c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:09.627286"
        sha256 = "4382590c4605e1334bce2deca145e484963deaae9ab9ef0888a80bc495b96d7a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
