
rule MB_d603f89f
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:11:42.827079"
        sha256 = "d603f89f249ae676d41d244dd7cc89ab876edc652c2a18d051dfabde9b568fab"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
