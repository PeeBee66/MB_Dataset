
rule MB_cbbc0cf0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-16T23:00:32.105930"
        sha256 = "cbbc0cf0cbc3d13250a22276d46d3ecbcd283a1635bdee3030c1970b05997955"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
