
rule MB_b5258372
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-01T23:01:16.408974"
        sha256 = "b525837273dde06b86b5f93f9aec2c29665324105b0b66f6df81884754f8080d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
