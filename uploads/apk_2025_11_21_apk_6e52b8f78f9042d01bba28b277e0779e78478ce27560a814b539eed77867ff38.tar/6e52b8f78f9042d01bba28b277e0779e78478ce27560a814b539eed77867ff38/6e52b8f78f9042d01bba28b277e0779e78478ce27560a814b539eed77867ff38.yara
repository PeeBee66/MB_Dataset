
rule MB_6e52b8f7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:00:17.852399"
        sha256 = "6e52b8f78f9042d01bba28b277e0779e78478ce27560a814b539eed77867ff38"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
