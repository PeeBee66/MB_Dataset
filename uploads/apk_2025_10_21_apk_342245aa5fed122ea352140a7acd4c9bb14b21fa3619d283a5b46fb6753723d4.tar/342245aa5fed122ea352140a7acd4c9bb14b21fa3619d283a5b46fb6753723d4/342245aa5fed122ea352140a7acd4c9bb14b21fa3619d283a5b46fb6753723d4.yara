
rule MB_342245aa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:12.808069"
        sha256 = "342245aa5fed122ea352140a7acd4c9bb14b21fa3619d283a5b46fb6753723d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
