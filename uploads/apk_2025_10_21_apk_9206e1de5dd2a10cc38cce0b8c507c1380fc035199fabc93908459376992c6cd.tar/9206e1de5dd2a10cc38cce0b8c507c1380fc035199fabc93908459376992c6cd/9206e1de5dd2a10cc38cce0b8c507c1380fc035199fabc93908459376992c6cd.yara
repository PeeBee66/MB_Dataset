
rule MB_9206e1de
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:46:14.064342"
        sha256 = "9206e1de5dd2a10cc38cce0b8c507c1380fc035199fabc93908459376992c6cd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
