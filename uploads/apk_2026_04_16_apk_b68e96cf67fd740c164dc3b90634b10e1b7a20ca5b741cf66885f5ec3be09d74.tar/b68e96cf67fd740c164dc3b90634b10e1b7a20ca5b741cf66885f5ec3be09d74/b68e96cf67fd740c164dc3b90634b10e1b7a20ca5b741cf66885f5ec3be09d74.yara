
rule MB_b68e96cf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:28.682355"
        sha256 = "b68e96cf67fd740c164dc3b90634b10e1b7a20ca5b741cf66885f5ec3be09d74"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
