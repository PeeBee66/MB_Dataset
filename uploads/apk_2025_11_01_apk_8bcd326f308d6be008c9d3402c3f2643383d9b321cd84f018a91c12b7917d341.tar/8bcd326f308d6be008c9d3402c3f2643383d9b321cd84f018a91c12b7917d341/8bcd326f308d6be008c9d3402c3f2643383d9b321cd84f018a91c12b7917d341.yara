
rule MB_8bcd326f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:02.406276"
        sha256 = "8bcd326f308d6be008c9d3402c3f2643383d9b321cd84f018a91c12b7917d341"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
