
rule MB_3d8da226
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:31.231384"
        sha256 = "3d8da22674ee343bd02296a4351e90198ffc786f8541747e42cdcf3438f16b3e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
