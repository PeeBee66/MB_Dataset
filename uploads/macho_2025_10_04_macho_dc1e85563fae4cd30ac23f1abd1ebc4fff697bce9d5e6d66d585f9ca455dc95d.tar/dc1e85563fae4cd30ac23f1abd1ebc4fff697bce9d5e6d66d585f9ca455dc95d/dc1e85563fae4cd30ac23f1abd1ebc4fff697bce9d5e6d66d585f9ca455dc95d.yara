
rule MB_dc1e8556
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:19.900421"
        sha256 = "dc1e85563fae4cd30ac23f1abd1ebc4fff697bce9d5e6d66d585f9ca455dc95d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
