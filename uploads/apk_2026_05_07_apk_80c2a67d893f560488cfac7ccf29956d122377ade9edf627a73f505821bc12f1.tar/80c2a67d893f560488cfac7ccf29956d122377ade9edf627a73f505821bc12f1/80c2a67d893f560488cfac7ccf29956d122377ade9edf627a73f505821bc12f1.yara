
rule MB_80c2a67d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:48.890812"
        sha256 = "80c2a67d893f560488cfac7ccf29956d122377ade9edf627a73f505821bc12f1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
