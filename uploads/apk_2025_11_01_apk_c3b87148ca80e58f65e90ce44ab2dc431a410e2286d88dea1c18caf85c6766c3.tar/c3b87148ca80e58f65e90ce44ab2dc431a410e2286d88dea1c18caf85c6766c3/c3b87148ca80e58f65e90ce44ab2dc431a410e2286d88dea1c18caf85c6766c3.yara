
rule MB_c3b87148
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:30.470490"
        sha256 = "c3b87148ca80e58f65e90ce44ab2dc431a410e2286d88dea1c18caf85c6766c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
