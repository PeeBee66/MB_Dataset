
rule MB_fef611ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-06T23:00:15.930809"
        sha256 = "fef611ec877bebdb9b9a5b454b23dc5b9d0e3cbcd8743501392f71c5e6d2b661"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
