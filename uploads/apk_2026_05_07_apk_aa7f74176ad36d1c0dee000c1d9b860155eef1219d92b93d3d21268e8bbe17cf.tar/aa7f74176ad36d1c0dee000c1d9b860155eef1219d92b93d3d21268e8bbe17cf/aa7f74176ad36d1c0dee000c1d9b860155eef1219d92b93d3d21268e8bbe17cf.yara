
rule MB_aa7f7417
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:11.004269"
        sha256 = "aa7f74176ad36d1c0dee000c1d9b860155eef1219d92b93d3d21268e8bbe17cf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
