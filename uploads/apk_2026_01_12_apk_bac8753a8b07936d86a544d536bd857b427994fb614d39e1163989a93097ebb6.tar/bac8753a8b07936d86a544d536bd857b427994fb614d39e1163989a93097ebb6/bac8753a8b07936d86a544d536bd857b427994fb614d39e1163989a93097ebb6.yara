
rule MB_bac8753a
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2026-01-11T23:00:12.934962"
        sha256 = "bac8753a8b07936d86a544d536bd857b427994fb614d39e1163989a93097ebb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
