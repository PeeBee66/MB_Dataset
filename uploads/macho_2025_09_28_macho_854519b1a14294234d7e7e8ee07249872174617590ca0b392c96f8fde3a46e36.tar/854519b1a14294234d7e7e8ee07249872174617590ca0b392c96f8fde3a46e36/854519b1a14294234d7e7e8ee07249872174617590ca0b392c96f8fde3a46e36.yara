
rule MB_854519b1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-25T00:01:10.396124"
        sha256 = "854519b1a14294234d7e7e8ee07249872174617590ca0b392c96f8fde3a46e36"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
