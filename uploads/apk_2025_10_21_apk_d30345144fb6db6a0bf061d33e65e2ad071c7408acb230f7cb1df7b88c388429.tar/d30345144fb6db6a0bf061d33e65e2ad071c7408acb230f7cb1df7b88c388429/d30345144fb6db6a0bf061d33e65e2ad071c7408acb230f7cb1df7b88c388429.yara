
rule MB_d3034514
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:11.022658"
        sha256 = "d30345144fb6db6a0bf061d33e65e2ad071c7408acb230f7cb1df7b88c388429"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
