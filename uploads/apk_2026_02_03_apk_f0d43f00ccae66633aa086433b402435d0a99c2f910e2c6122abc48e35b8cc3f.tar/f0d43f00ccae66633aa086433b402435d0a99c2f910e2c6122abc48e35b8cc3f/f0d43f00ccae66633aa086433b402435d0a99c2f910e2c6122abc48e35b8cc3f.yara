
rule MB_f0d43f00
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:34.561103"
        sha256 = "f0d43f00ccae66633aa086433b402435d0a99c2f910e2c6122abc48e35b8cc3f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
