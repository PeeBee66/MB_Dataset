
rule MB_c673e831
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:38.261959"
        sha256 = "c673e831680f75ae07aba3f2f806d2f080e009d04bf27b4eabdda58fece12c86"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
