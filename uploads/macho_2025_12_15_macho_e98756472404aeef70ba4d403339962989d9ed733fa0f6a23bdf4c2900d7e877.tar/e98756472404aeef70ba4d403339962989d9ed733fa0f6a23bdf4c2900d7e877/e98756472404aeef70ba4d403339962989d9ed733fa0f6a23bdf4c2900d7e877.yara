
rule MB_e9875647
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-14T23:00:25.414179"
        sha256 = "e98756472404aeef70ba4d403339962989d9ed733fa0f6a23bdf4c2900d7e877"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
