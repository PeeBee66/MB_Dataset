
rule MB_29b1bc28
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:35:40.251437"
        sha256 = "29b1bc286e219ec38f1520a7ed2fec9e11b39bb3bcb96d7fe9a3eb66a41a9ed9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
