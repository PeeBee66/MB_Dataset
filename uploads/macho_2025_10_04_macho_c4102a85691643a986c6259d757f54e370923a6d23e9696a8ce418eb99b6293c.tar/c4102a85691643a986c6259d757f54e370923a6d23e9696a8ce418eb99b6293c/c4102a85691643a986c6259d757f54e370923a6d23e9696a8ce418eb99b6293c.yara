
rule MB_c4102a85
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:16.645809"
        sha256 = "c4102a85691643a986c6259d757f54e370923a6d23e9696a8ce418eb99b6293c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
