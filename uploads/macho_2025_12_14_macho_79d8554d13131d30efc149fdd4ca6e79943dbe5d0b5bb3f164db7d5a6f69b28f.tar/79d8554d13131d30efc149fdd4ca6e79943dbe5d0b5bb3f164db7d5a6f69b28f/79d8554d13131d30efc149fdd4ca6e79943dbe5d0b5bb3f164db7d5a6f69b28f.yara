
rule MB_79d8554d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:01:04.242915"
        sha256 = "79d8554d13131d30efc149fdd4ca6e79943dbe5d0b5bb3f164db7d5a6f69b28f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
