
rule MB_9d8b9090
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-12T23:00:52.245011"
        sha256 = "9d8b9090972ec013f3ad0236f5210bd70fe4ba87402fdefeac399cf11dba2efe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
