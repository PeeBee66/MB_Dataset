
rule MB_ad79962c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:53.069216"
        sha256 = "ad79962c1152ec553c885f545f42c7b0672ca186399a0089401dca4952bd1f5e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
