
rule MB_34e0789d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:00:45.542679"
        sha256 = "34e0789d21c0a8339f27d4b681e4648d789c5217811842239287e804e3073c45"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
