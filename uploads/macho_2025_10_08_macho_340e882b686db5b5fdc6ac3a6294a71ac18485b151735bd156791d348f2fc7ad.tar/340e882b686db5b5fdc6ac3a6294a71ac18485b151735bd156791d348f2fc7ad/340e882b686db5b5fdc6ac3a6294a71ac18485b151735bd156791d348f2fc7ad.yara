
rule MB_340e882b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:02.441314"
        sha256 = "340e882b686db5b5fdc6ac3a6294a71ac18485b151735bd156791d348f2fc7ad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
