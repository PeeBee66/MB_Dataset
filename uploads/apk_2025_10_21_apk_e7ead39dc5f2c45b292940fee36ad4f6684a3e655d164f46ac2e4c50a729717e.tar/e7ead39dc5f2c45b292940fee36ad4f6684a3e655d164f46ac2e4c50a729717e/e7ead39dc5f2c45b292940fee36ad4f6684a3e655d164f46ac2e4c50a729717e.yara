
rule MB_e7ead39d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:37:56.347254"
        sha256 = "e7ead39dc5f2c45b292940fee36ad4f6684a3e655d164f46ac2e4c50a729717e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
