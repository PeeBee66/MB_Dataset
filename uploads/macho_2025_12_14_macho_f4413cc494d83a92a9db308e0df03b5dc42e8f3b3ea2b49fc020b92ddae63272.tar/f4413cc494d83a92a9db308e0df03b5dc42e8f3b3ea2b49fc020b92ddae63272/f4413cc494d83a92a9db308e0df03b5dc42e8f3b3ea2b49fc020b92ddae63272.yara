
rule MB_f4413cc4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:51.204989"
        sha256 = "f4413cc494d83a92a9db308e0df03b5dc42e8f3b3ea2b49fc020b92ddae63272"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
