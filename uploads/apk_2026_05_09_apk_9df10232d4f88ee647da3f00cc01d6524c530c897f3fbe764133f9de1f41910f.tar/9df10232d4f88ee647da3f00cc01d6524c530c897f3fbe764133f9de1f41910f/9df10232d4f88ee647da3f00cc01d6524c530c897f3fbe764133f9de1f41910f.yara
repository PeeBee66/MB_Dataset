
rule MB_9df10232
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:52.621462"
        sha256 = "9df10232d4f88ee647da3f00cc01d6524c530c897f3fbe764133f9de1f41910f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
