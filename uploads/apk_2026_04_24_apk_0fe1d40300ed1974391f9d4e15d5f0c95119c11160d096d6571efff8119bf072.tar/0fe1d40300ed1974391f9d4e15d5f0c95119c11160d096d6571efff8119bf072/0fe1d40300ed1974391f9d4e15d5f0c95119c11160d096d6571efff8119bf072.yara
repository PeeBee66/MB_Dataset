
rule MB_0fe1d403
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:44.327141"
        sha256 = "0fe1d40300ed1974391f9d4e15d5f0c95119c11160d096d6571efff8119bf072"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
