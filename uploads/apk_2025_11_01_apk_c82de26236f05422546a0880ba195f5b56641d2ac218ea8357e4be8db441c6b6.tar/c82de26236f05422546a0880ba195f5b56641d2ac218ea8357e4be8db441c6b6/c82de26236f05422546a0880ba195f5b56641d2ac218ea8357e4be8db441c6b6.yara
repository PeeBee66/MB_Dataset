
rule MB_c82de262
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:05:32.431683"
        sha256 = "c82de26236f05422546a0880ba195f5b56641d2ac218ea8357e4be8db441c6b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
