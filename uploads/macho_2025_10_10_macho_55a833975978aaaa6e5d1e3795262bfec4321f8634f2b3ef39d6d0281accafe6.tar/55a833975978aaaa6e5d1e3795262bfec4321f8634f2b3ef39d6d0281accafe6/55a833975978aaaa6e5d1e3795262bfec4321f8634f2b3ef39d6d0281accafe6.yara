
rule MB_55a83397
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:39.070355"
        sha256 = "55a833975978aaaa6e5d1e3795262bfec4321f8634f2b3ef39d6d0281accafe6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
