
rule MB_161380a5
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:03.581269"
        sha256 = "161380a5c63982bf148d5283014cbd3431d19973a98fbb9dd72b26a7d8bb029f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
