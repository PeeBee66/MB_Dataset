
rule MB_656de37b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:11.893869"
        sha256 = "656de37bf47199a81584811885707959267cc06a1fc77daee6bbd01692da815c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
