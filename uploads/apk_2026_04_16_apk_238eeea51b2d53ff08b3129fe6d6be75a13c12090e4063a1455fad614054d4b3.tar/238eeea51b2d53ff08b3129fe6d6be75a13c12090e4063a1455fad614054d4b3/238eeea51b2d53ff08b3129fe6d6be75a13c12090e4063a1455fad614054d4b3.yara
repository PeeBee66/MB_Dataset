
rule MB_238eeea5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:49.434817"
        sha256 = "238eeea51b2d53ff08b3129fe6d6be75a13c12090e4063a1455fad614054d4b3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
