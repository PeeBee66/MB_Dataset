
rule MB_efd2c0ae
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:58.906809"
        sha256 = "efd2c0ae5c35330c8ce96417eee0ae3dfe0ffa62ddff9da5eadb19bf8a62bc01"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
