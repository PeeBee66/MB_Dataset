
rule MB_a77159ac
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:07.224702"
        sha256 = "a77159ac51e32c65c3f1a2b12e0adc42a33263758d9d422fc5226b3b34c52956"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
