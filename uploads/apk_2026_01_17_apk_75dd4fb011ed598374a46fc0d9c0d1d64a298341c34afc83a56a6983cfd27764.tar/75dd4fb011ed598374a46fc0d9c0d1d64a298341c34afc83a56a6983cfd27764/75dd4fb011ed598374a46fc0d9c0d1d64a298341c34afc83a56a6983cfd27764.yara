
rule MB_75dd4fb0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-16T23:00:15.491141"
        sha256 = "75dd4fb011ed598374a46fc0d9c0d1d64a298341c34afc83a56a6983cfd27764"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
