
rule MB_185a01ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:51.830926"
        sha256 = "185a01ec24938cd5a9af4fd66a0814e8bfaf2e1ff8cfa2396a30c3e4f6e66b98"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
