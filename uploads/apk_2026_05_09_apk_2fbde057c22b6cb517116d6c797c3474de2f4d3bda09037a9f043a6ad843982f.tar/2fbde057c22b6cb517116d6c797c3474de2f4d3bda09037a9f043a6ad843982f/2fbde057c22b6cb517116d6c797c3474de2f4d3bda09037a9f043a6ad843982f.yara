
rule MB_2fbde057
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:42.356895"
        sha256 = "2fbde057c22b6cb517116d6c797c3474de2f4d3bda09037a9f043a6ad843982f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
