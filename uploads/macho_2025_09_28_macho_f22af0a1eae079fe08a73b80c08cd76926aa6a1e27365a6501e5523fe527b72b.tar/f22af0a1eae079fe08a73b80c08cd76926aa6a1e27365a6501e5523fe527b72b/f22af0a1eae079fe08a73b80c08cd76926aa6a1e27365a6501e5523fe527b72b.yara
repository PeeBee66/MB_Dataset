
rule MB_f22af0a1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:26.446707"
        sha256 = "f22af0a1eae079fe08a73b80c08cd76926aa6a1e27365a6501e5523fe527b72b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
