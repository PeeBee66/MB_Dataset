
rule MB_c7f225a9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:22.659880"
        sha256 = "c7f225a9f54d7b83865a2885872c082722ecff638a1b2779e56013c31c46ffac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
