
rule MB_3a5705ac
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:14.341552"
        sha256 = "3a5705acc39fb96b67cd78182ec27e774d7e4e9a27a34ccedf02c5dcd34c036c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
