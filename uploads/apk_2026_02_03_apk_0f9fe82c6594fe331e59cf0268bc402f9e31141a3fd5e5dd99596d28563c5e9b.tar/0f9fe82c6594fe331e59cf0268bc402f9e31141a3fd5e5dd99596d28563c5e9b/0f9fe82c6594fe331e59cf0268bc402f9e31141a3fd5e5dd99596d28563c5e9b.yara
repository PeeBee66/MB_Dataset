
rule MB_0f9fe82c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:48.506128"
        sha256 = "0f9fe82c6594fe331e59cf0268bc402f9e31141a3fd5e5dd99596d28563c5e9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
