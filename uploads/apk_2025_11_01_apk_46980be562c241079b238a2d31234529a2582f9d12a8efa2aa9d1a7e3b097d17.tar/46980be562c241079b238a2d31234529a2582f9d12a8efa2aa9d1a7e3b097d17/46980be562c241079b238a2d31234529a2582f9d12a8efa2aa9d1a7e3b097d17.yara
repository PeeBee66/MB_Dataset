
rule MB_46980be5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:39.065684"
        sha256 = "46980be562c241079b238a2d31234529a2582f9d12a8efa2aa9d1a7e3b097d17"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
