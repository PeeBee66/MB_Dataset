
rule MB_b35d06e5
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:51:41.949433"
        sha256 = "b35d06e5bd966768f3f6955af7d0e1ce861e103a6b2862ca969b7bc6aff8634b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
