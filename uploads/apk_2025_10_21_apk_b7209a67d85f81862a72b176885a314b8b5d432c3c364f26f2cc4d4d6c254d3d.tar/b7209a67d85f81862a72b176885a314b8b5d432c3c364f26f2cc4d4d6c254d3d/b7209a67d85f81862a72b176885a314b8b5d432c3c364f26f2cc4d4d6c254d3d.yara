
rule MB_b7209a67
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:44:38.188674"
        sha256 = "b7209a67d85f81862a72b176885a314b8b5d432c3c364f26f2cc4d4d6c254d3d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
