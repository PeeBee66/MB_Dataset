
rule MB_327a404f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-06T23:00:21.260011"
        sha256 = "327a404f2ff2562d7e7f49e9fca68bb814128eef47dfea688680de3da91b04cd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
