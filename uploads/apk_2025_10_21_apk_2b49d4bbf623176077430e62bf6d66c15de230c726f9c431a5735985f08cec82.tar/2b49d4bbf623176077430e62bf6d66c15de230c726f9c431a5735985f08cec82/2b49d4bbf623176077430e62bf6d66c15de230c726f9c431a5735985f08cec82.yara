
rule MB_2b49d4bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:20:25.057284"
        sha256 = "2b49d4bbf623176077430e62bf6d66c15de230c726f9c431a5735985f08cec82"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
