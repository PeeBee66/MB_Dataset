
rule MB_82764c52
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:14.576596"
        sha256 = "82764c5242b2b3592a98ebac4c0046b93c1a3f1ab47b434b1222fb14adf12cd5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
