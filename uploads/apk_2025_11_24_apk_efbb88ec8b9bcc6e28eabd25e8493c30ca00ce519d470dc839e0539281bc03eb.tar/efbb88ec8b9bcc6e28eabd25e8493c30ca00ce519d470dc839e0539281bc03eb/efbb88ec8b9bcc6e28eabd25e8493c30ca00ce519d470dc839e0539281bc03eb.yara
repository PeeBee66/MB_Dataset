
rule MB_efbb88ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:50.217700"
        sha256 = "efbb88ec8b9bcc6e28eabd25e8493c30ca00ce519d470dc839e0539281bc03eb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
