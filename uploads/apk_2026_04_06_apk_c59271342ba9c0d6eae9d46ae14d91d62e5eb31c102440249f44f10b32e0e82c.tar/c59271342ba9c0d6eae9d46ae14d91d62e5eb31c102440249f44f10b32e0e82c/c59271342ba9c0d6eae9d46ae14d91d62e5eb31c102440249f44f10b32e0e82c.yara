
rule MB_c5927134
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-06T00:00:36.272044"
        sha256 = "c59271342ba9c0d6eae9d46ae14d91d62e5eb31c102440249f44f10b32e0e82c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
