
rule MB_bca248d3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-05T00:00:13.593232"
        sha256 = "bca248d31bf87b605e8cca7587a9753d58a9ad9a8f7e6f7f882d03150d72869f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
