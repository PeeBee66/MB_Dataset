
rule MB_c9f964b3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:57.621723"
        sha256 = "c9f964b319cb2100b0535dfe2ce1956aafdda8d255fd462753f443176e17a74e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
