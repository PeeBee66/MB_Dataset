
rule MB_e7dff6e8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:38.441248"
        sha256 = "e7dff6e814997210437c64256114064184f2219ac5dd7ef04379095d972b6f41"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
