
rule MB_cadcce6d
{
    meta:
        description = "Auto-generated rule for BankBot"
        author = "MB-Collector"
        date = "2026-03-23T23:01:09.020324"
        sha256 = "cadcce6d4088c72fd0779d59d00f5753eaab585a263e3c92374df29ae767ac15"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
