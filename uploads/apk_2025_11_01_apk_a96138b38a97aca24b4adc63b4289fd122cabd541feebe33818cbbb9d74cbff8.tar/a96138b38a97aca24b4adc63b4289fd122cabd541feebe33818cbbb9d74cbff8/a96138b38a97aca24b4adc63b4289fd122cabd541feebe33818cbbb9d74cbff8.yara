
rule MB_a96138b3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:30.739781"
        sha256 = "a96138b38a97aca24b4adc63b4289fd122cabd541feebe33818cbbb9d74cbff8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
