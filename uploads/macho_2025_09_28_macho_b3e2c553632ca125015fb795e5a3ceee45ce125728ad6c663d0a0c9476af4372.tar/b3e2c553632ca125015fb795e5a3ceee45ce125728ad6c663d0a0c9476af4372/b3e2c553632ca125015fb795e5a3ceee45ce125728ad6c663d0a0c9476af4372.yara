
rule MB_b3e2c553
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:06.622536"
        sha256 = "b3e2c553632ca125015fb795e5a3ceee45ce125728ad6c663d0a0c9476af4372"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
