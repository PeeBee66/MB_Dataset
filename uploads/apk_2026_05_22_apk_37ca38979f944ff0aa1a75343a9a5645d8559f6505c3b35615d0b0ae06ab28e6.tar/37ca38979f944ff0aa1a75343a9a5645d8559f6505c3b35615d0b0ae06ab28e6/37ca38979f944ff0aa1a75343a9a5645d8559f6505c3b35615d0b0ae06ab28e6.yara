
rule MB_37ca3897
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2026-05-22T00:00:22.310190"
        sha256 = "37ca38979f944ff0aa1a75343a9a5645d8559f6505c3b35615d0b0ae06ab28e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
