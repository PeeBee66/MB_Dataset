
rule MB_7922ffb7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:01:12.024974"
        sha256 = "7922ffb7deea4e27a59fde82551a869354d12c3c8d57a49e4604cc809854df24"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
