
rule MB_d7fa31c0
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:08.284708"
        sha256 = "d7fa31c0d576f506c18b6b1a8263d5c3183a8391301535792cdf1eadbd797201"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
