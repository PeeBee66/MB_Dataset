
rule MB_83d254b4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-26T00:01:24.269950"
        sha256 = "83d254b42b6d447d93585819ac5e0165e729b247e63fb658c3d2e5c1c1acdd00"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
