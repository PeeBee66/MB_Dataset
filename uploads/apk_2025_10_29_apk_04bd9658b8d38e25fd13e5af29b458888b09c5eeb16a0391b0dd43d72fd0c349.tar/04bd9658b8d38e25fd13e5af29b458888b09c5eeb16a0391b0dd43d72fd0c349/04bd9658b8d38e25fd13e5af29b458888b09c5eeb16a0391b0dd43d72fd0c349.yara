
rule MB_04bd9658
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:01:01.451245"
        sha256 = "04bd9658b8d38e25fd13e5af29b458888b09c5eeb16a0391b0dd43d72fd0c349"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
