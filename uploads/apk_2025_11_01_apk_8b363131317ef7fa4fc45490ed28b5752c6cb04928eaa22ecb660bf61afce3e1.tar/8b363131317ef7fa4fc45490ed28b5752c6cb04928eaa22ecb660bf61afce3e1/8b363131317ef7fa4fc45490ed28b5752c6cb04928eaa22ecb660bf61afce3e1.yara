
rule MB_8b363131
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:30.740168"
        sha256 = "8b363131317ef7fa4fc45490ed28b5752c6cb04928eaa22ecb660bf61afce3e1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
