
rule MB_60e130c5
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-09T23:00:55.354136"
        sha256 = "60e130c50beca82b0b740c6ca0da1f7b5e76b639ab0fe5303476da11f66e9f4c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
