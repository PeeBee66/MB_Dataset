
rule MB_fe541678
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:54:36.666673"
        sha256 = "fe54167868c6f13410ec5eec4f7ccde08a4638c3a95e766b57834eb4ab436bea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
