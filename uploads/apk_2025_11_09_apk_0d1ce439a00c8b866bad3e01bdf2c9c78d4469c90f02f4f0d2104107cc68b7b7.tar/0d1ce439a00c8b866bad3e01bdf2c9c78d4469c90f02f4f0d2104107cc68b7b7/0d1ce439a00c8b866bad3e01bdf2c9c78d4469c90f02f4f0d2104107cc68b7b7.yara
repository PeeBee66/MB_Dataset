
rule MB_0d1ce439
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-08T23:00:33.132031"
        sha256 = "0d1ce439a00c8b866bad3e01bdf2c9c78d4469c90f02f4f0d2104107cc68b7b7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
