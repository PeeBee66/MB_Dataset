
rule MB_2b7e044e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:59.792126"
        sha256 = "2b7e044edadb6932c251f2169da0a777bf553a549a263c5c8a0cf9d888cee704"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
