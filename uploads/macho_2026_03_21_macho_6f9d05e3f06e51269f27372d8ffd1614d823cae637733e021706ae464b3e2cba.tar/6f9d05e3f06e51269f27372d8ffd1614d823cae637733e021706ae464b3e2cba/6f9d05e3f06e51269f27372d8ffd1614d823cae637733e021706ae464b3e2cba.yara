
rule MB_6f9d05e3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:01:00.475623"
        sha256 = "6f9d05e3f06e51269f27372d8ffd1614d823cae637733e021706ae464b3e2cba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
