
rule MB_800ff188
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:57.672606"
        sha256 = "800ff188c6cbc899bebc9852cd287a21965c7d4ee2b4688a64b1a642d62ccb6b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
