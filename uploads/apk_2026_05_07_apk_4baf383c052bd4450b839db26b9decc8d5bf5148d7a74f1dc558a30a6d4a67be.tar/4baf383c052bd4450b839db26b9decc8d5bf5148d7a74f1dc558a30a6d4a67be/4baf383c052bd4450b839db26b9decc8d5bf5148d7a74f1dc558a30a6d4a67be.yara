
rule MB_4baf383c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:17.061775"
        sha256 = "4baf383c052bd4450b839db26b9decc8d5bf5148d7a74f1dc558a30a6d4a67be"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
