
rule MB_d8e50b48
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-01T23:00:25.066879"
        sha256 = "d8e50b489b345f7b96e50e157411407f5e3d414203524f1064db38b27ee747ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
