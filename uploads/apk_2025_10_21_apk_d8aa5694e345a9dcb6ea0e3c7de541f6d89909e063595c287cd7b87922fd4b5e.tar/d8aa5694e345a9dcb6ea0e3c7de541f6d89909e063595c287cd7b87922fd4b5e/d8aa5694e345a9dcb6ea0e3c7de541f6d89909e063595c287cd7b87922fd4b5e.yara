
rule MB_d8aa5694
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:20:09.666705"
        sha256 = "d8aa5694e345a9dcb6ea0e3c7de541f6d89909e063595c287cd7b87922fd4b5e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
