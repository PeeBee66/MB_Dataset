
rule MB_b9fb2177
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:01:05.899889"
        sha256 = "b9fb2177e55ad47b2df74ff642bd3ee5058d392c3e2e272b93bec263aa30eeef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
