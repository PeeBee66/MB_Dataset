
rule MB_17574320
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:22.001980"
        sha256 = "17574320d84b8449039f50df5ac81a32df59ad8edf7b766e5b507af2de63a6ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
