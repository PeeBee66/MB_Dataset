
rule MB_723ad24f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:01:23.872190"
        sha256 = "723ad24f74213cd9e780302bd15f8042af521549c1c9b24c8787961250aa25e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
