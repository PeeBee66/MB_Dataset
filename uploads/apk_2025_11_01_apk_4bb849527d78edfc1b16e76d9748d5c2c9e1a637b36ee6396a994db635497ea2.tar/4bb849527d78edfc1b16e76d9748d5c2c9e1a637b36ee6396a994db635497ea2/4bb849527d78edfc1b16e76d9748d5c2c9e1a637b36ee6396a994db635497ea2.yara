
rule MB_4bb84952
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:33.655962"
        sha256 = "4bb849527d78edfc1b16e76d9748d5c2c9e1a637b36ee6396a994db635497ea2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
