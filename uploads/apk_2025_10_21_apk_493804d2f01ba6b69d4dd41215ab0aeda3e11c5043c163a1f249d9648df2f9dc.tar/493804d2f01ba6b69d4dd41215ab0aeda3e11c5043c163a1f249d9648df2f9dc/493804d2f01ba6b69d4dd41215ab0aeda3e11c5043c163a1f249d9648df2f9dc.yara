
rule MB_493804d2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:19:57.700199"
        sha256 = "493804d2f01ba6b69d4dd41215ab0aeda3e11c5043c163a1f249d9648df2f9dc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
