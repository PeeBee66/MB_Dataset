
rule MB_019cd4ca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:50.222089"
        sha256 = "019cd4ca5c50bf4e733bc0bee66b5a0c97cf8b0e297d396ccdeabd697ac8d566"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
