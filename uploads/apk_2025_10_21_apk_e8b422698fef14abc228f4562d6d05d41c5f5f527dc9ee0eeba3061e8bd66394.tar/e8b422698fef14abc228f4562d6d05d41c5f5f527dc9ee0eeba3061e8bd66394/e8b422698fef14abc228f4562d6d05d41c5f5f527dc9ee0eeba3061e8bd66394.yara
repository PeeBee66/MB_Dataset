
rule MB_e8b42269
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:58.539420"
        sha256 = "e8b422698fef14abc228f4562d6d05d41c5f5f527dc9ee0eeba3061e8bd66394"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
