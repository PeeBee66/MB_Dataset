
rule MB_73054f1b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:01:04.808251"
        sha256 = "73054f1bcfa67fa27db7e95cbbd59de8a630ca09826ff7bacc738c0300c119c7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
