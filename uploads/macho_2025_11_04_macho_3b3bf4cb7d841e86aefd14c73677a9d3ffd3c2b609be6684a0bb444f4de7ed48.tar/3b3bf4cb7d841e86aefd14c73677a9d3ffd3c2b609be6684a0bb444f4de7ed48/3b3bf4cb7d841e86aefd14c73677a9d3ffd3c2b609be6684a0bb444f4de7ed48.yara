
rule MB_3b3bf4cb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-03T23:00:45.598841"
        sha256 = "3b3bf4cb7d841e86aefd14c73677a9d3ffd3c2b609be6684a0bb444f4de7ed48"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
