
rule MB_0027c816
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2026-01-29T23:01:09.263082"
        sha256 = "0027c816cc740251e8f2d271cbaf7397706a1db07cc14b842d962fee8991daf6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
