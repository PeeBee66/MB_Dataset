
rule MB_1f4d5bac
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:47.209692"
        sha256 = "1f4d5bacd470295c0a22b3148f9fea0a1a3963a6c79854c09c9cce67f82d3c38"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
