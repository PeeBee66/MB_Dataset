
rule MB_61de2b90
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:41.586515"
        sha256 = "61de2b90778e9debcdd15e2e57f8558f57745225f1e723ef8f8c2b24d22d36a6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
