
rule MB_9c4315da
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-30T23:00:14.167767"
        sha256 = "9c4315dad05f9f70982630ff023a6073d6badaed840130ce1342ca9ebf3bb5d1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
