
rule MB_ac66b10b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:00:30.068231"
        sha256 = "ac66b10b91edd97a66d9961e4fb13d3e01cc4630dbd882caa7e7a5711ca18cc0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
