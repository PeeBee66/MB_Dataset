
rule MB_d4498b6b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-05T23:00:17.176469"
        sha256 = "d4498b6baef034c6134eb4fd77d1cdc260889076f80e16f2cc23f154f75bf054"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
