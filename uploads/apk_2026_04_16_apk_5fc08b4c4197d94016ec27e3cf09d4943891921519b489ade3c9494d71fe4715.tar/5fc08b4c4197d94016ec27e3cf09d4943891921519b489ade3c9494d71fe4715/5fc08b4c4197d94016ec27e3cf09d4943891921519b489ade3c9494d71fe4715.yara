
rule MB_5fc08b4c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:19.775678"
        sha256 = "5fc08b4c4197d94016ec27e3cf09d4943891921519b489ade3c9494d71fe4715"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
