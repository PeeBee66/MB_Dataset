
rule MB_f0d77adf
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:39.960389"
        sha256 = "f0d77adf36b5a1e17f082a032c8a894ccd61836067d00d7f7101df52819edfc4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
