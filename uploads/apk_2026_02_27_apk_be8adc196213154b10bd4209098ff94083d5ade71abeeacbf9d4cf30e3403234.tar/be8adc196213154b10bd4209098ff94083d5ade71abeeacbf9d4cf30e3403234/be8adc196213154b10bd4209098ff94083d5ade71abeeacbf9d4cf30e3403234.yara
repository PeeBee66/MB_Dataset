
rule MB_be8adc19
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-26T23:00:15.370393"
        sha256 = "be8adc196213154b10bd4209098ff94083d5ade71abeeacbf9d4cf30e3403234"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
