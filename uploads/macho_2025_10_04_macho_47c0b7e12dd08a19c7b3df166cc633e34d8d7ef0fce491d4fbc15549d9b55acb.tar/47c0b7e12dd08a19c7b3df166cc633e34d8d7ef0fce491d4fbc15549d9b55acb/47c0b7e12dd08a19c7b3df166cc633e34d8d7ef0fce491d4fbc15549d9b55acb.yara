
rule MB_47c0b7e1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:57.106556"
        sha256 = "47c0b7e12dd08a19c7b3df166cc633e34d8d7ef0fce491d4fbc15549d9b55acb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
