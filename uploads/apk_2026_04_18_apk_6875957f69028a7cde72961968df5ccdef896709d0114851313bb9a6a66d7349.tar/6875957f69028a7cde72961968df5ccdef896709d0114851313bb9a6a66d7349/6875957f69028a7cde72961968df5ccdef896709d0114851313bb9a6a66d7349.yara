
rule MB_6875957f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:14.396086"
        sha256 = "6875957f69028a7cde72961968df5ccdef896709d0114851313bb9a6a66d7349"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
