
rule MB_a4c26781
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-24T23:00:24.217322"
        sha256 = "a4c267819d38e8c1e85e1764115032db61bf8985711d4a5a3384891404a176fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
