
rule MB_9ddb1f7c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:19.251485"
        sha256 = "9ddb1f7c615e58e94e6f845b6ee1cd1c68ee1af199d5952059ddcb28962ff8d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
