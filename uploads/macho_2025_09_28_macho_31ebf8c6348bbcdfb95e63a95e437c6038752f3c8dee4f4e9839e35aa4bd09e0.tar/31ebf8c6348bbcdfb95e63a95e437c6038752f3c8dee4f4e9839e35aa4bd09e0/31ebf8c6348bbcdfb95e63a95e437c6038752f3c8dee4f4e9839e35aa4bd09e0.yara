
rule MB_31ebf8c6
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:49.533050"
        sha256 = "31ebf8c6348bbcdfb95e63a95e437c6038752f3c8dee4f4e9839e35aa4bd09e0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
