
rule MB_b89620a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:24:42.996783"
        sha256 = "b89620a28ce37d0c986b41e63dc9ef73e59c4ffa050db03917529b201e41ff69"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
