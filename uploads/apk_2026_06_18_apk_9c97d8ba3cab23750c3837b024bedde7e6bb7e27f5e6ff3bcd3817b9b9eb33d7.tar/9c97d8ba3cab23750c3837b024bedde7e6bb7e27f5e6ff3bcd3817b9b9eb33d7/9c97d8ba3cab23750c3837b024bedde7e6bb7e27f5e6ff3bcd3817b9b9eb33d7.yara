
rule MB_9c97d8ba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:01:11.382055"
        sha256 = "9c97d8ba3cab23750c3837b024bedde7e6bb7e27f5e6ff3bcd3817b9b9eb33d7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
