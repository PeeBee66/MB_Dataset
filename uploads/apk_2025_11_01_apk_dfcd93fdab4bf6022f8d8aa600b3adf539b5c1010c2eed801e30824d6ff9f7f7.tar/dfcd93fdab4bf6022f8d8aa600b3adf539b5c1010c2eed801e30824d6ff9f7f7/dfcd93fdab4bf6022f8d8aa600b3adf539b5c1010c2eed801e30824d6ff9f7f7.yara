
rule MB_dfcd93fd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:00.387641"
        sha256 = "dfcd93fdab4bf6022f8d8aa600b3adf539b5c1010c2eed801e30824d6ff9f7f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
