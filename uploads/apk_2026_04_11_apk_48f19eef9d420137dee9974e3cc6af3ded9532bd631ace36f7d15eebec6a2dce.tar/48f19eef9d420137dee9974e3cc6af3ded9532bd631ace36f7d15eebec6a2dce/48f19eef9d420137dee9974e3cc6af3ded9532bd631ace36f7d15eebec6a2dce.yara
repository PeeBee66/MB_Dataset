
rule MB_48f19eef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:00:41.256040"
        sha256 = "48f19eef9d420137dee9974e3cc6af3ded9532bd631ace36f7d15eebec6a2dce"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
