
rule MB_c6dc47b2
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:04:56.081539"
        sha256 = "c6dc47b2d185e6a0d82b489e19f58d73a3688a5e2a452037bad14a4ed646f434"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
