
rule MB_578d3b5d
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:47:27.549532"
        sha256 = "578d3b5dbb35738f47165ee053138021f88c4bebfe5ebb2b79dbb998600eaa16"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
