
rule MB_b4111e87
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-11T23:00:13.821477"
        sha256 = "b4111e8710771fa2ff758c8b949895a030698a0f177220704c7f1f763f576c99"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
