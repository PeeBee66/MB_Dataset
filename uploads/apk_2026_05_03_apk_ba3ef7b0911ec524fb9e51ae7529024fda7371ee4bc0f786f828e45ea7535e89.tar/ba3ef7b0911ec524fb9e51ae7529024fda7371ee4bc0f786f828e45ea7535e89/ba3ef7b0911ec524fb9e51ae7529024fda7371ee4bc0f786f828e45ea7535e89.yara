
rule MB_ba3ef7b0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-03T00:00:16.842215"
        sha256 = "ba3ef7b0911ec524fb9e51ae7529024fda7371ee4bc0f786f828e45ea7535e89"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
