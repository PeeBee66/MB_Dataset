
rule MB_45d3ba05
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:49.076374"
        sha256 = "45d3ba05082377babed049f89ac2df6a5933ef383accfa8a5e2180a956e18733"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
