
rule MB_65bb489d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:50.787121"
        sha256 = "65bb489d2689e39a2f5ab4d4ba6c2df17c718d5fd415eeccac4bc85f6cf29a96"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
