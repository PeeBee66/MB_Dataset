
rule MB_bfc577ea
{
    meta:
        description = "Auto-generated rule for AhMyth"
        author = "MB-Collector"
        date = "2026-03-16T23:00:41.358904"
        sha256 = "bfc577ea1b9b326609d857e0c7ea4c7db5c382f86b3faeb92e9230da650b3af9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
