
rule MB_cd301491
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:48.019259"
        sha256 = "cd301491d5bb40f126d72ab157881de92b7790cdf01f65d2927e39623ad5ad46"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
