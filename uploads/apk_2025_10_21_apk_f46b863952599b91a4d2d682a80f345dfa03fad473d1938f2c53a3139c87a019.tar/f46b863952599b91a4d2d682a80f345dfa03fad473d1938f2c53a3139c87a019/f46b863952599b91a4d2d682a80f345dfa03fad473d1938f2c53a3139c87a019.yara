
rule MB_f46b8639
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:51:37.789833"
        sha256 = "f46b863952599b91a4d2d682a80f345dfa03fad473d1938f2c53a3139c87a019"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
