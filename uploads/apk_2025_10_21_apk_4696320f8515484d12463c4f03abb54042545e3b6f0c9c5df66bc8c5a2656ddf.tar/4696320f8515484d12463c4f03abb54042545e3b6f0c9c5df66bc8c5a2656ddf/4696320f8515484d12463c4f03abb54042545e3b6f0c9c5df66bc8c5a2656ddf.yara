
rule MB_4696320f
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:09:13.401090"
        sha256 = "4696320f8515484d12463c4f03abb54042545e3b6f0c9c5df66bc8c5a2656ddf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
