
rule MB_1d9110f0
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:26.391822"
        sha256 = "1d9110f04ce0817be45d88e83eeb0597ac52c793d8ae784652792e5352281c8d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
