
rule MB_21b6b9c7
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:00:40.894156"
        sha256 = "21b6b9c7262fe39d2f2ce49115c9c22f50d3e5b0b083a0f8c1ddd776c369ffd3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
