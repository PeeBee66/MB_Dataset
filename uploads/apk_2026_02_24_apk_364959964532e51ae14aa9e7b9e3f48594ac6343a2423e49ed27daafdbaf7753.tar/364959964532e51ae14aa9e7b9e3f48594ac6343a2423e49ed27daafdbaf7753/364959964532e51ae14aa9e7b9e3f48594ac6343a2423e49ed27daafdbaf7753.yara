
rule MB_36495996
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-02-23T23:00:22.725120"
        sha256 = "364959964532e51ae14aa9e7b9e3f48594ac6343a2423e49ed27daafdbaf7753"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
