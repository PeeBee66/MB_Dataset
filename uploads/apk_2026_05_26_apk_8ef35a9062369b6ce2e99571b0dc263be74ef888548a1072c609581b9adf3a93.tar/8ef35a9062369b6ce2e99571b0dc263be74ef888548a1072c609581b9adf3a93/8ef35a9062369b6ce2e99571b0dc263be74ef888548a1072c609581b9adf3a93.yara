
rule MB_8ef35a90
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-26T00:00:13.520101"
        sha256 = "8ef35a9062369b6ce2e99571b0dc263be74ef888548a1072c609581b9adf3a93"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
