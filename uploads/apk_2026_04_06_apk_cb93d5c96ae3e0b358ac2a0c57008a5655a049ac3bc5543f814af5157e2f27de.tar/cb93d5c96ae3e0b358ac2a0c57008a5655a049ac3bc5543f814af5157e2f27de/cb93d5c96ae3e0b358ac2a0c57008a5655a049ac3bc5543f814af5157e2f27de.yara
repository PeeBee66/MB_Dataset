
rule MB_cb93d5c9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-06T00:00:32.608509"
        sha256 = "cb93d5c96ae3e0b358ac2a0c57008a5655a049ac3bc5543f814af5157e2f27de"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
