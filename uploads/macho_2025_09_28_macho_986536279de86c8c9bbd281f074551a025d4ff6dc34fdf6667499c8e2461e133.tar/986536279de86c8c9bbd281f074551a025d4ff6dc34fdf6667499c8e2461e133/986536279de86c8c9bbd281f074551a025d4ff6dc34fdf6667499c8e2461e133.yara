
rule MB_98653627
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:24.509918"
        sha256 = "986536279de86c8c9bbd281f074551a025d4ff6dc34fdf6667499c8e2461e133"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
