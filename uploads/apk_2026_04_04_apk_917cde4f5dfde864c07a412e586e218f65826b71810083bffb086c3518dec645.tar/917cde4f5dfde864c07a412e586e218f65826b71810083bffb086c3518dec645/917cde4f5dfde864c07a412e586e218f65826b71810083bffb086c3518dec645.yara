
rule MB_917cde4f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-03T23:00:25.069672"
        sha256 = "917cde4f5dfde864c07a412e586e218f65826b71810083bffb086c3518dec645"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
