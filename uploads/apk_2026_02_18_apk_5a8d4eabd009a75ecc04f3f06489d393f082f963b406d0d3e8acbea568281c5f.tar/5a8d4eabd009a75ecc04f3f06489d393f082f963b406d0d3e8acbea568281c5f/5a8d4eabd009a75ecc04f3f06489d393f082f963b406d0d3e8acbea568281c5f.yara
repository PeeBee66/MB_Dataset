
rule MB_5a8d4eab
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-17T23:00:18.837461"
        sha256 = "5a8d4eabd009a75ecc04f3f06489d393f082f963b406d0d3e8acbea568281c5f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
