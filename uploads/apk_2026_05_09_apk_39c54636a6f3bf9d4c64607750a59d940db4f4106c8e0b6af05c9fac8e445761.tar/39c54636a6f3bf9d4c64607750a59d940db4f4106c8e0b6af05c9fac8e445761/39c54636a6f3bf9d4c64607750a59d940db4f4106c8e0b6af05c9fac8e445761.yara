
rule MB_39c54636
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:04.285808"
        sha256 = "39c54636a6f3bf9d4c64607750a59d940db4f4106c8e0b6af05c9fac8e445761"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
