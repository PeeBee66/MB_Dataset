
rule MB_fdad2f10
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-22T23:00:16.973118"
        sha256 = "fdad2f108dcefa145a1c04a3c87436af85a47696bd5c1dd1bf790bb57e3e5bbf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
