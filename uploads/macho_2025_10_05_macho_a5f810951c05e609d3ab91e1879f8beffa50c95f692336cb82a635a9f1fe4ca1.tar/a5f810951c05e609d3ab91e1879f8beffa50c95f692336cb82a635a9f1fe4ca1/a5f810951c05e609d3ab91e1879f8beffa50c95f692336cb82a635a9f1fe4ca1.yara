
rule MB_a5f81095
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:02.535527"
        sha256 = "a5f810951c05e609d3ab91e1879f8beffa50c95f692336cb82a635a9f1fe4ca1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
