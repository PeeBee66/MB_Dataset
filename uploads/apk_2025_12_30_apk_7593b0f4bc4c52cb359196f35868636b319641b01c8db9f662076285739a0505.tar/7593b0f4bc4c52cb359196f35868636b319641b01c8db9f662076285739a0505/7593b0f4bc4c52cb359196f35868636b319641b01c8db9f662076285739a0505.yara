
rule MB_7593b0f4
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-12-29T23:00:45.369135"
        sha256 = "7593b0f4bc4c52cb359196f35868636b319641b01c8db9f662076285739a0505"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
