
rule MB_7943027a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-27T23:00:23.301573"
        sha256 = "7943027a23fd3f9cc231f4ef8dd26ca05b262a3b5b53a698f48bdae2e693e144"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
