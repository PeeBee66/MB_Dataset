
rule MB_6a440dfa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:52.747085"
        sha256 = "6a440dfa5c59960575f07ab81e779e2066bb0f3541e58ce5c0ab319d34e19b56"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
