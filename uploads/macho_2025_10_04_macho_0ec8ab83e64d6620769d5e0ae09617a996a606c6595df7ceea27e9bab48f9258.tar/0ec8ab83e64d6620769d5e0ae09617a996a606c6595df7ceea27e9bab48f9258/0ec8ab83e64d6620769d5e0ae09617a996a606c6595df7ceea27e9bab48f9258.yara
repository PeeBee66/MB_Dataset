
rule MB_0ec8ab83
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:13.729666"
        sha256 = "0ec8ab83e64d6620769d5e0ae09617a996a606c6595df7ceea27e9bab48f9258"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
