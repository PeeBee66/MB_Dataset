
rule MB_61b603b3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-09T23:00:36.636569"
        sha256 = "61b603b382df05199967cbaf99a95dd177090c04f02dc96b99efbd7f0bf6412d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
