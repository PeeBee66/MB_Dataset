
rule MB_d566c64a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:21.278466"
        sha256 = "d566c64a41faf573349cf2c0ecb00f68dbe8b90bc1968d3317d3a20667ddad63"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
