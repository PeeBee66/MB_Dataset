
rule MB_801f9560
{
    meta:
        description = "Auto-generated rule for Crocodilus"
        author = "MB-Collector"
        date = "2025-10-20T11:52:23.463996"
        sha256 = "801f956057aa608c7393b2fcca9b731c610c6bd5e14f4f3c1d64e8f211828319"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
