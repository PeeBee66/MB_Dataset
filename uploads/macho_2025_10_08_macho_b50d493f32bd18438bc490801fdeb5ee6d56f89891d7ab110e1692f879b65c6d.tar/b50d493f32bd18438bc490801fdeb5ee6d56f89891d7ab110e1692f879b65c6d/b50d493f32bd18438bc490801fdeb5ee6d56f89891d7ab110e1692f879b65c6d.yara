
rule MB_b50d493f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:16.780405"
        sha256 = "b50d493f32bd18438bc490801fdeb5ee6d56f89891d7ab110e1692f879b65c6d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
