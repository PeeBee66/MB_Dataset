
rule MB_02c6b17b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:37.404833"
        sha256 = "02c6b17b841ac7c53ea61c0033246bc8ee11432ce5ed7372e0a63c0076315507"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
