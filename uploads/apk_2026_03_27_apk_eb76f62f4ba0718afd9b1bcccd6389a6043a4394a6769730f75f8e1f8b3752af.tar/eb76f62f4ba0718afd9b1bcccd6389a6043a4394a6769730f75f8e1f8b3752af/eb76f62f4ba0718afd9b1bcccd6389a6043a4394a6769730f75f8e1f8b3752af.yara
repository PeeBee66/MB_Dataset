
rule MB_eb76f62f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-26T23:00:24.763473"
        sha256 = "eb76f62f4ba0718afd9b1bcccd6389a6043a4394a6769730f75f8e1f8b3752af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
