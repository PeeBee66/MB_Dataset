
rule MB_2ef4c1b6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:02.776810"
        sha256 = "2ef4c1b6c6aab62efd903b9ee3c41a554e871eb9d1abd7e0ccc1f50a525a590e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
