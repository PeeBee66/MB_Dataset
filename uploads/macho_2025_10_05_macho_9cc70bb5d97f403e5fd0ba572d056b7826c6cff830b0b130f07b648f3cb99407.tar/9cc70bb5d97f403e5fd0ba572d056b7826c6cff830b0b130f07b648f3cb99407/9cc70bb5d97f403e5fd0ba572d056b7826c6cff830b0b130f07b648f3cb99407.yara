
rule MB_9cc70bb5
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:30.106212"
        sha256 = "9cc70bb5d97f403e5fd0ba572d056b7826c6cff830b0b130f07b648f3cb99407"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
