
rule MB_f81d01e7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-12T23:00:43.069034"
        sha256 = "f81d01e7361d276658306125e375453244f28d9ecca6c855e48e6fab88826267"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
