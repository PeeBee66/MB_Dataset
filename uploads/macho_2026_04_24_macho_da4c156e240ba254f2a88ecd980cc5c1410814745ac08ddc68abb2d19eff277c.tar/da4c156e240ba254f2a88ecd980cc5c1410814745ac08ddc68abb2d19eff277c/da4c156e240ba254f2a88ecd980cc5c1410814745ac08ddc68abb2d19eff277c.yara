
rule MB_da4c156e
{
    meta:
        description = "Auto-generated rule for Lazarus"
        author = "MB-Collector"
        date = "2026-04-24T00:03:05.860682"
        sha256 = "da4c156e240ba254f2a88ecd980cc5c1410814745ac08ddc68abb2d19eff277c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
