
rule MB_1c567bc5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:40.805113"
        sha256 = "1c567bc593e1cda8e6f470f911b743d7828f1458e18712901d6307235abe6b44"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
