
rule MB_ed0f8956
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:34.508405"
        sha256 = "ed0f89562e078fc45e5faf010b2a7d45fc90f9074234394e47b67f7e06bd5577"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
