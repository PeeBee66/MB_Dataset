
rule MB_6f0e8713
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:52.552294"
        sha256 = "6f0e8713ff4143f107aa610252aff265035220c2b10ce2023c942d9df7565bef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
