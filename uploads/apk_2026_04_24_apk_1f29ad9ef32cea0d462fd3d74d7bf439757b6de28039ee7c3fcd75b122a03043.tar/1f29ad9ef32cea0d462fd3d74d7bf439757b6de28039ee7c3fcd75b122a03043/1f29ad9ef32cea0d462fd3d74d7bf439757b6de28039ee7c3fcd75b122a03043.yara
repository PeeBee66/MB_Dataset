
rule MB_1f29ad9e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:02:18.592141"
        sha256 = "1f29ad9ef32cea0d462fd3d74d7bf439757b6de28039ee7c3fcd75b122a03043"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
