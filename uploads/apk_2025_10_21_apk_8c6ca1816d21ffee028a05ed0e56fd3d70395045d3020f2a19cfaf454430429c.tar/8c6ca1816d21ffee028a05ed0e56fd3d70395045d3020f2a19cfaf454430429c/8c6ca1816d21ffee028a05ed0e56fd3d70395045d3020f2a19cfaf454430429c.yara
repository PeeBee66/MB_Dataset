
rule MB_8c6ca181
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:46.431754"
        sha256 = "8c6ca1816d21ffee028a05ed0e56fd3d70395045d3020f2a19cfaf454430429c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
