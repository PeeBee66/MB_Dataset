
rule MB_595101d3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:22:03.390228"
        sha256 = "595101d359edb6c0ec1dfb6af54200948ec691ab9fd5df2997ca2d225a2ea043"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
