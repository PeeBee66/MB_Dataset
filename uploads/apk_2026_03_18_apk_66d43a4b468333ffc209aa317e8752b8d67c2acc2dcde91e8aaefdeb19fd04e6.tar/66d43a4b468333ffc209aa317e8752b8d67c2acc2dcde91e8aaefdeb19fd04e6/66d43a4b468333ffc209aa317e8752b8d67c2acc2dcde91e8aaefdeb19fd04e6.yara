
rule MB_66d43a4b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:00:31.927986"
        sha256 = "66d43a4b468333ffc209aa317e8752b8d67c2acc2dcde91e8aaefdeb19fd04e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
