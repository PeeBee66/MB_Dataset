
rule MB_a7c7a0a8
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T12:01:31.666227"
        sha256 = "a7c7a0a83a788c5497b94eb34ffe4e03edd062f490efbb33b7ed74f9410c30b0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
