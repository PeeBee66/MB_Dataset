
rule MB_899e510f
{
    meta:
        description = "Auto-generated rule for SMSEye"
        author = "MB-Collector"
        date = "2025-10-20T11:40:17.791087"
        sha256 = "899e510fa49b262220af000cbb6f2544dbce7abed05b4197954acfb530ab1c01"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
