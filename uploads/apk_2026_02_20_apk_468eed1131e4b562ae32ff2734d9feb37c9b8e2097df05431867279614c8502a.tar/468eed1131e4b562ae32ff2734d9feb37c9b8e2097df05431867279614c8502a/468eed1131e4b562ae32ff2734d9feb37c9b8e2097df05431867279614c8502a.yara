
rule MB_468eed11
{
    meta:
        description = "Auto-generated rule for PromptSpy"
        author = "MB-Collector"
        date = "2026-02-19T23:00:29.418606"
        sha256 = "468eed1131e4b562ae32ff2734d9feb37c9b8e2097df05431867279614c8502a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
