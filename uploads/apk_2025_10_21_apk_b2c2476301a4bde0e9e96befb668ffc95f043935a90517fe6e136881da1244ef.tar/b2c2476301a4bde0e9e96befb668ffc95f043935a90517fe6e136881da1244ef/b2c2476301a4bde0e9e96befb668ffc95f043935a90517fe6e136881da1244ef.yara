
rule MB_b2c24763
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:20.464293"
        sha256 = "b2c2476301a4bde0e9e96befb668ffc95f043935a90517fe6e136881da1244ef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
