
rule MB_22dd514e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:01:18.781196"
        sha256 = "22dd514e77f6f5a853e889471777a763c72316a4f68a612ea03a52121d17247d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
