
rule MB_236c0941
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:15.040330"
        sha256 = "236c09415f6f77ca40f7b4a9301fd7e9176cc29f8b3b7c02c3e5e9fff4b254dc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
