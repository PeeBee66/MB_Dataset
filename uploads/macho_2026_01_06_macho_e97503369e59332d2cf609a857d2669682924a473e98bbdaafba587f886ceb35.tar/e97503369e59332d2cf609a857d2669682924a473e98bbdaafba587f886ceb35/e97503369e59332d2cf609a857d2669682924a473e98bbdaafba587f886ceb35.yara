
rule MB_e9750336
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:59.643849"
        sha256 = "e97503369e59332d2cf609a857d2669682924a473e98bbdaafba587f886ceb35"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
