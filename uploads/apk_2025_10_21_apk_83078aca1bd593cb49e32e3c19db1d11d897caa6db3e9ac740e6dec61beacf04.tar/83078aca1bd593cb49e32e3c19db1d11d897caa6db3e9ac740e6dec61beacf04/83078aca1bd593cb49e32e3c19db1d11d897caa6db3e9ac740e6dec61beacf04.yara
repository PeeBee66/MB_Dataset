
rule MB_83078aca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:48.739789"
        sha256 = "83078aca1bd593cb49e32e3c19db1d11d897caa6db3e9ac740e6dec61beacf04"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
