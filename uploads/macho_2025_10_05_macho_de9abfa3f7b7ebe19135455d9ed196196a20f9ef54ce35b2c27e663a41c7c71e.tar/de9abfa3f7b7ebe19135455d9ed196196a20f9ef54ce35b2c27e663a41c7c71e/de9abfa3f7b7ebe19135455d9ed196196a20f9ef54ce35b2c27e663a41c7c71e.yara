
rule MB_de9abfa3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:14.307257"
        sha256 = "de9abfa3f7b7ebe19135455d9ed196196a20f9ef54ce35b2c27e663a41c7c71e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
