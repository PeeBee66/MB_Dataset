
rule MB_906c8cfc
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:45.593927"
        sha256 = "906c8cfc3888df604b7b60ba2fbadb350633ad96965b11b2e94a83bd28f038ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
