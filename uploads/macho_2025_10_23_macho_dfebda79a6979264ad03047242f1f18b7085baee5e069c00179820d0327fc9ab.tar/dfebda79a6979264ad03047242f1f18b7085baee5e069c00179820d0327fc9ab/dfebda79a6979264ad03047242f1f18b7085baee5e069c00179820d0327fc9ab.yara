
rule MB_dfebda79
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-22T23:00:23.361469"
        sha256 = "dfebda79a6979264ad03047242f1f18b7085baee5e069c00179820d0327fc9ab"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
