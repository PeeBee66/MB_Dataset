
rule MB_61bc7b5a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:35.718824"
        sha256 = "61bc7b5aed9f3c88d6db951ac8ada2b340f269562ce8c6b0963957d77b9e1840"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
