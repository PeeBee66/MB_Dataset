
rule MB_33c3f438
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:35.132849"
        sha256 = "33c3f43852f6ecadef74aef2dbb0d5a1215aa3cb23e4aaf76f202beed3aa8703"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
