
rule MB_f788b353
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:46:29.340179"
        sha256 = "f788b3536222942754f586169650c6b38f8d5a7d0d831fb104c913995d1b42ef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
