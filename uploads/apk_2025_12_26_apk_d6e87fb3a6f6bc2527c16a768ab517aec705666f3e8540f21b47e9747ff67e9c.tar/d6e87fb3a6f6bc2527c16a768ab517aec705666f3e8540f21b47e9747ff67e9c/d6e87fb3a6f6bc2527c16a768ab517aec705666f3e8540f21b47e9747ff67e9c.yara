
rule MB_d6e87fb3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-25T23:00:23.216759"
        sha256 = "d6e87fb3a6f6bc2527c16a768ab517aec705666f3e8540f21b47e9747ff67e9c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
