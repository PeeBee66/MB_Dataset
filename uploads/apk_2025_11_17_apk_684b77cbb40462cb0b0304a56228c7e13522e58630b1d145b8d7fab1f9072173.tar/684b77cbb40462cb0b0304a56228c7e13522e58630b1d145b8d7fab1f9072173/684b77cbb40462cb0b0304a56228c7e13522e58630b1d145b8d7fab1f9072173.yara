
rule MB_684b77cb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-16T23:00:31.164377"
        sha256 = "684b77cbb40462cb0b0304a56228c7e13522e58630b1d145b8d7fab1f9072173"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
