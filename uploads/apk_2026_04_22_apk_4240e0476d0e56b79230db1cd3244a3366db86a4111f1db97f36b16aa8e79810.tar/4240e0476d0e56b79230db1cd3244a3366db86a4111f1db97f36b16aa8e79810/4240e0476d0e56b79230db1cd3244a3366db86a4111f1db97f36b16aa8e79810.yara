
rule MB_4240e047
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-22T00:00:33.318865"
        sha256 = "4240e0476d0e56b79230db1cd3244a3366db86a4111f1db97f36b16aa8e79810"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
