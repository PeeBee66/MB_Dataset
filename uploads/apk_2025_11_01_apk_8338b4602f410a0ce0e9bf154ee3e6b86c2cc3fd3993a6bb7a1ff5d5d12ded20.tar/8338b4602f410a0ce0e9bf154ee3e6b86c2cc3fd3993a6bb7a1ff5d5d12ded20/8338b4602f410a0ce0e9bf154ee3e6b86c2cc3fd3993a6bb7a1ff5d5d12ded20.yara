
rule MB_8338b460
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:28.881726"
        sha256 = "8338b4602f410a0ce0e9bf154ee3e6b86c2cc3fd3993a6bb7a1ff5d5d12ded20"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
