
rule MB_c8613819
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-03-02T23:00:54.292472"
        sha256 = "c8613819cb4978591f4d98edd56bf3fdcc9f52245778416406d5b1e582a7024b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
