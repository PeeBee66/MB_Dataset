
rule MB_d921e4c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-25T23:00:27.354715"
        sha256 = "d921e4c59b048aa4085712054c1fa0cac28994f8857b519f27a297b8f2c5d77d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
