
rule MB_ab136320
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:00:30.605294"
        sha256 = "ab1363201d0897ab7c55dceb1f8664a58ac65fe4aee3c9600c5d7659f8ae58a9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
