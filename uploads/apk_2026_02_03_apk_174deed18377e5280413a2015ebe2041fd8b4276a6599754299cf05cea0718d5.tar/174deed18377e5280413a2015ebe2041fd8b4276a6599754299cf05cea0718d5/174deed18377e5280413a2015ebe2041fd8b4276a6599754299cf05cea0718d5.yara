
rule MB_174deed1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:27.177568"
        sha256 = "174deed18377e5280413a2015ebe2041fd8b4276a6599754299cf05cea0718d5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
