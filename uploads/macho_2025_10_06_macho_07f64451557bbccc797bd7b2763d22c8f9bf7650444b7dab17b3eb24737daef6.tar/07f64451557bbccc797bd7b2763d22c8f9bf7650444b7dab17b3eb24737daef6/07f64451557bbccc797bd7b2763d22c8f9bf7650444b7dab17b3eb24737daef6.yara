
rule MB_07f64451
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:32.312271"
        sha256 = "07f64451557bbccc797bd7b2763d22c8f9bf7650444b7dab17b3eb24737daef6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
