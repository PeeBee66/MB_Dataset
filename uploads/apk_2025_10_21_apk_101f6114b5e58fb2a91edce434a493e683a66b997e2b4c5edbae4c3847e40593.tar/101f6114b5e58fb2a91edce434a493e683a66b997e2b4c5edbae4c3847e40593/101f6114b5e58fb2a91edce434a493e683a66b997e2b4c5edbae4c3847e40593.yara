
rule MB_101f6114
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:41.308595"
        sha256 = "101f6114b5e58fb2a91edce434a493e683a66b997e2b4c5edbae4c3847e40593"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
