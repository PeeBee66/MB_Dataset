
rule MB_50b8638d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:39.434647"
        sha256 = "50b8638dde85a2667aabe9be84c4243f37a40945c82125a0d4e98104874a4541"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
