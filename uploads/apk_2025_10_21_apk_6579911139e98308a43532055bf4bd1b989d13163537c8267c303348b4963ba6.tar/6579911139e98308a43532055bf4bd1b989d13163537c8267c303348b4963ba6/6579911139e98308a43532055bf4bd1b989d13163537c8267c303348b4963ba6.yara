
rule MB_65799111
{
    meta:
        description = "Auto-generated rule for RefalRAT"
        author = "MB-Collector"
        date = "2025-10-20T11:10:36.405048"
        sha256 = "6579911139e98308a43532055bf4bd1b989d13163537c8267c303348b4963ba6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
