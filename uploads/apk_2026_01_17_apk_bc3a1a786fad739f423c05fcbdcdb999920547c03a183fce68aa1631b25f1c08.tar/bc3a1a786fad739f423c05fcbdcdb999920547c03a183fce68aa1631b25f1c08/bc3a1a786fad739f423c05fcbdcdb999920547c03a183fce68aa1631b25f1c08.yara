
rule MB_bc3a1a78
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-16T23:00:45.164770"
        sha256 = "bc3a1a786fad739f423c05fcbdcdb999920547c03a183fce68aa1631b25f1c08"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
