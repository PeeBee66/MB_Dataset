
rule MB_1d15f070
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:17.779210"
        sha256 = "1d15f0700a2dda228394bf37ad20ad2bd88c7813d6aca0199a6b40c704f80bc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
