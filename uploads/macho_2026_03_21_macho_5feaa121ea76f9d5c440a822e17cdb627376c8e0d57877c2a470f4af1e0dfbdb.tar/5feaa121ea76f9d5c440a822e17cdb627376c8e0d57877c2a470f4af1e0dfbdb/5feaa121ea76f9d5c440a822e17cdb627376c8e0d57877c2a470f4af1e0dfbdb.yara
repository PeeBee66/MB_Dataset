
rule MB_5feaa121
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:00:50.269277"
        sha256 = "5feaa121ea76f9d5c440a822e17cdb627376c8e0d57877c2a470f4af1e0dfbdb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
