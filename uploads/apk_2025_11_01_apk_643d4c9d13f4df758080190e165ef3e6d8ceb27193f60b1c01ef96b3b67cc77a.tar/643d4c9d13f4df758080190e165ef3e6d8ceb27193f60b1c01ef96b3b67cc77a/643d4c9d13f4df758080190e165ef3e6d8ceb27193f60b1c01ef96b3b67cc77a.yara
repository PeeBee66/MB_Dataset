
rule MB_643d4c9d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:13.627701"
        sha256 = "643d4c9d13f4df758080190e165ef3e6d8ceb27193f60b1c01ef96b3b67cc77a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
