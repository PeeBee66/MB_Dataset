
rule MB_fc27e112
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:04:19.968393"
        sha256 = "fc27e112786706f4caa3deae1a7db9a4e4f7366838135ab47a682185ce8db4a2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
