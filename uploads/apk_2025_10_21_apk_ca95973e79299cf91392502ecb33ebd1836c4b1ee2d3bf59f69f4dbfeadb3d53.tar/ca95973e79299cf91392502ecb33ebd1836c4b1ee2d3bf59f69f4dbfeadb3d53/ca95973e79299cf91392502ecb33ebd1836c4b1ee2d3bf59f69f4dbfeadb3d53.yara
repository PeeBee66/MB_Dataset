
rule MB_ca95973e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:50.265253"
        sha256 = "ca95973e79299cf91392502ecb33ebd1836c4b1ee2d3bf59f69f4dbfeadb3d53"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
