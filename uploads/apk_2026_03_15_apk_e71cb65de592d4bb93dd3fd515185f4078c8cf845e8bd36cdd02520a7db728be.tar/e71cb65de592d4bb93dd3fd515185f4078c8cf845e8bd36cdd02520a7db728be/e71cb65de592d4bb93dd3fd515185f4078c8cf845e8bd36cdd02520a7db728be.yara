
rule MB_e71cb65d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-14T23:00:34.105998"
        sha256 = "e71cb65de592d4bb93dd3fd515185f4078c8cf845e8bd36cdd02520a7db728be"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
