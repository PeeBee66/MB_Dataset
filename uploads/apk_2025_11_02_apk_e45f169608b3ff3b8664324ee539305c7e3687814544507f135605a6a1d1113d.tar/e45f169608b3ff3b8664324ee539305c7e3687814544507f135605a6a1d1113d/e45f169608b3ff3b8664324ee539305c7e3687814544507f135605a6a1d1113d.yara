
rule MB_e45f1696
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-01T23:00:28.937010"
        sha256 = "e45f169608b3ff3b8664324ee539305c7e3687814544507f135605a6a1d1113d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
