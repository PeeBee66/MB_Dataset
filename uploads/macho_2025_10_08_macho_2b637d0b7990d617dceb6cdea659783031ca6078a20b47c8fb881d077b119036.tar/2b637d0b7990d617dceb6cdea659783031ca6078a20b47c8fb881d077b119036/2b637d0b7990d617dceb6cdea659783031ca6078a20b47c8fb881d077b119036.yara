
rule MB_2b637d0b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:52.831291"
        sha256 = "2b637d0b7990d617dceb6cdea659783031ca6078a20b47c8fb881d077b119036"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
