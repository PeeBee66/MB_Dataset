
rule MB_5756dc04
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:22.059010"
        sha256 = "5756dc045742b39e7f51917b5c0ef039d72feedd76b98e42c0085943ae886164"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
