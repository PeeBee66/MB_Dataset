
rule MB_9b93951c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:07.964509"
        sha256 = "9b93951c9ace3818aa1fdd593d7c7be2a23a1fd5647dc1906f6ab57b90d76493"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
