
rule MB_a6ea793e
{
    meta:
        description = "Auto-generated rule for GhostGrab"
        author = "MB-Collector"
        date = "2026-05-07T00:00:23.901025"
        sha256 = "a6ea793e52823218041ededc61900c6ea273b50ec64d32c4d2a3ce722450705b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
