
rule MB_15fa6122
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:09.028319"
        sha256 = "15fa6122cae87f6f2015cded3c9d15d996a0826ae88ae8c882343a7987ca995c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
