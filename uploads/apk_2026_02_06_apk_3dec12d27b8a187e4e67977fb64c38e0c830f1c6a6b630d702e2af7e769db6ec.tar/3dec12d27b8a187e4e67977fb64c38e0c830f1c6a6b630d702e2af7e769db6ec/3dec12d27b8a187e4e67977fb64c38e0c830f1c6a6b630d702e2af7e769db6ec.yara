
rule MB_3dec12d2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:30.764599"
        sha256 = "3dec12d27b8a187e4e67977fb64c38e0c830f1c6a6b630d702e2af7e769db6ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
