
rule MB_c0f05be9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:00:20.714892"
        sha256 = "c0f05be91780c67dde68bfe1c0b6ba5d69a813cfa77672d42ff3367612fabcca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
