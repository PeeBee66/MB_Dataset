
rule MB_bc74da49
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:41.199960"
        sha256 = "bc74da49cf58d85b8ce8a49d2ac0fed574ef1634e67d92ef75440d7b24d0a3e4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
