
rule MB_4a187d1d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:01:04.378746"
        sha256 = "4a187d1d3dcc1e684a3a9e7bade340d032d6b77a7a232067eb55f85685c971ca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
