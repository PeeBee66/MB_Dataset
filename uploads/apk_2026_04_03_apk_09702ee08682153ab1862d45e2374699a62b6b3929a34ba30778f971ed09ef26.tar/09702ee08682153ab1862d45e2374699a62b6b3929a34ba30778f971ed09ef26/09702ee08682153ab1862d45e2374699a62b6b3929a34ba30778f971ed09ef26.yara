
rule MB_09702ee0
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-02T23:00:25.267412"
        sha256 = "09702ee08682153ab1862d45e2374699a62b6b3929a34ba30778f971ed09ef26"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
