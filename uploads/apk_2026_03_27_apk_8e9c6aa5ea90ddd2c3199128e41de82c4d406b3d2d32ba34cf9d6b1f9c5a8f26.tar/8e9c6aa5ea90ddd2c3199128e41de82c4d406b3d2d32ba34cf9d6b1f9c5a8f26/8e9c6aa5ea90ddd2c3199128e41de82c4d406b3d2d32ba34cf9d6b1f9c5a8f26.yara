
rule MB_8e9c6aa5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-26T23:00:21.277297"
        sha256 = "8e9c6aa5ea90ddd2c3199128e41de82c4d406b3d2d32ba34cf9d6b1f9c5a8f26"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
