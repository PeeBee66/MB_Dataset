
rule MB_2eda2c83
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:57.036246"
        sha256 = "2eda2c838ea696f6ab1e74d2a1fa3c265234a32416a666f0efa3d065d0185552"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
