
rule MB_97885efc
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:40.737275"
        sha256 = "97885efc01d75eec6a368d9f2dd7d684d13669101c8fb74b48de0d1f681e953e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
