
rule MB_399c4819
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:35.962346"
        sha256 = "399c4819af422e581639c9350dcba71b0ee00b87a4d37da11806db5e25a0adc5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
