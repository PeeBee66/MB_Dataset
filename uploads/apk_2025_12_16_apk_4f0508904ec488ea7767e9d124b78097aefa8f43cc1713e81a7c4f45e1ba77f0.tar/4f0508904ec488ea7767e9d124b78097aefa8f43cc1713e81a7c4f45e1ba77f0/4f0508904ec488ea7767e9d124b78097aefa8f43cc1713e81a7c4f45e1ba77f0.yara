
rule MB_4f050890
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-15T23:00:20.345924"
        sha256 = "4f0508904ec488ea7767e9d124b78097aefa8f43cc1713e81a7c4f45e1ba77f0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
