
rule MB_e07ee100
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:27.664134"
        sha256 = "e07ee100710fff0ada8d1f78e037b582f21ad8491b89c2a548be63174e2ba1cd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
