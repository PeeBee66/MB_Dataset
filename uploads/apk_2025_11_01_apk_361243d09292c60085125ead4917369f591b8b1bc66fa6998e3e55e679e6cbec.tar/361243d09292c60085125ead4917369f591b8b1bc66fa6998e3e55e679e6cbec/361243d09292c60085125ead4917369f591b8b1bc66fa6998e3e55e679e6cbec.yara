
rule MB_361243d0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:30.295228"
        sha256 = "361243d09292c60085125ead4917369f591b8b1bc66fa6998e3e55e679e6cbec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
