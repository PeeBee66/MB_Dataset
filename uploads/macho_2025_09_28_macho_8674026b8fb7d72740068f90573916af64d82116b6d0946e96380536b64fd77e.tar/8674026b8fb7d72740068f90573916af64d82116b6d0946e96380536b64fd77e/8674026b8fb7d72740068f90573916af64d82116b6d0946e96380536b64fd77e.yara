
rule MB_8674026b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:00:52.003147"
        sha256 = "8674026b8fb7d72740068f90573916af64d82116b6d0946e96380536b64fd77e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
