
rule MB_ef956469
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:18.397540"
        sha256 = "ef956469f47382f35ccf9ddd020bf1754e9f6ea709f8ca90455e3e984b63fb92"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
