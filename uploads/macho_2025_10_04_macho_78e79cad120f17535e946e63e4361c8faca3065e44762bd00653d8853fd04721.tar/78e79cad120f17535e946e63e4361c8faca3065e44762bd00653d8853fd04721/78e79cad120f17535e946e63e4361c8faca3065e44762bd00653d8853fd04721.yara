
rule MB_78e79cad
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:45.072405"
        sha256 = "78e79cad120f17535e946e63e4361c8faca3065e44762bd00653d8853fd04721"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
