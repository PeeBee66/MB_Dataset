
rule MB_cca961d7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:09.730464"
        sha256 = "cca961d71a3f16292bcfef99802d4f58a177d26239ec2c50edfe3a513b68418e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
