
rule MB_c38961f4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:00:25.105339"
        sha256 = "c38961f4493641448c71aabe8b46796c4ef0c6aaaed187be02ff06ed152ae1e9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
