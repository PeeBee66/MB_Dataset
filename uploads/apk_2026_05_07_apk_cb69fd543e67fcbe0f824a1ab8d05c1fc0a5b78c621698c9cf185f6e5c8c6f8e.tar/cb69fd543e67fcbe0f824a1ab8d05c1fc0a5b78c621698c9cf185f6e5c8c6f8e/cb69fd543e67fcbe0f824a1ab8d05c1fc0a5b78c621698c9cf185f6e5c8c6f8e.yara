
rule MB_cb69fd54
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:43.761598"
        sha256 = "cb69fd543e67fcbe0f824a1ab8d05c1fc0a5b78c621698c9cf185f6e5c8c6f8e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
