
rule MB_01e40d9f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:38.177933"
        sha256 = "01e40d9f1fc91eab41b7f4ce84f043c5b3297bf9011fa40a6ff32bbb3d4f5c9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
