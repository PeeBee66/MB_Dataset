
rule MB_2731b609
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-04T01:13:39.149744"
        sha256 = "2731b609ac26029c818b403b08e2ca0180b0654ca42b7ca168e677e557f01ce0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
