
rule MB_58ac130a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:53:40.251213"
        sha256 = "58ac130a8ebb09e37592ac69841483edc5695d1545b1f04f23d5b760ac17cd94"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
