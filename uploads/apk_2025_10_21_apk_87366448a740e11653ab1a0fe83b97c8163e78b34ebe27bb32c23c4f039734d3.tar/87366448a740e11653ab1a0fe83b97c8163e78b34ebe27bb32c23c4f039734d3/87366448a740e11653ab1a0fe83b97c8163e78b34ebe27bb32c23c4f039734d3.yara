
rule MB_87366448
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:00.429966"
        sha256 = "87366448a740e11653ab1a0fe83b97c8163e78b34ebe27bb32c23c4f039734d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
