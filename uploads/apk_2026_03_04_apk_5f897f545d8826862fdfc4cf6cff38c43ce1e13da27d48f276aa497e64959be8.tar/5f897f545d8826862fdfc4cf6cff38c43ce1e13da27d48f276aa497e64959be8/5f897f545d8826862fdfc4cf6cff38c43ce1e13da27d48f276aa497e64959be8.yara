
rule MB_5f897f54
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-03T23:00:16.110493"
        sha256 = "5f897f545d8826862fdfc4cf6cff38c43ce1e13da27d48f276aa497e64959be8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
