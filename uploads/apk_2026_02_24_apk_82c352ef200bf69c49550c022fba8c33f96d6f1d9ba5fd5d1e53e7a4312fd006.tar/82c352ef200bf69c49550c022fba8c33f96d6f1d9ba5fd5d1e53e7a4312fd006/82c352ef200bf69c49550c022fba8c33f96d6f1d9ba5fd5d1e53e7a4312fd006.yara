
rule MB_82c352ef
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:38.280956"
        sha256 = "82c352ef200bf69c49550c022fba8c33f96d6f1d9ba5fd5d1e53e7a4312fd006"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
