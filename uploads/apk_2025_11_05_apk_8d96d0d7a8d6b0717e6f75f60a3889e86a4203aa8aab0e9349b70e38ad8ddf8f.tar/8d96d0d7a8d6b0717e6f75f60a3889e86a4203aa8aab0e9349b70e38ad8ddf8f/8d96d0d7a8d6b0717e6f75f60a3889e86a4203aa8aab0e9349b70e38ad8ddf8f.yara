
rule MB_8d96d0d7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:43.119666"
        sha256 = "8d96d0d7a8d6b0717e6f75f60a3889e86a4203aa8aab0e9349b70e38ad8ddf8f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
