
rule MB_88829b2c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:00:40.985279"
        sha256 = "88829b2c3f9eb296ab664fc888ca062822784053a7fb733262c960d194f434a9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
