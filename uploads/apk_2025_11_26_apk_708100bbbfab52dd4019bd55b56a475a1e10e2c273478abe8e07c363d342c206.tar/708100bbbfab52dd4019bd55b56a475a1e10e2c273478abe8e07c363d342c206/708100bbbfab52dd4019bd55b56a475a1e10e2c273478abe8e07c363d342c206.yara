
rule MB_708100bb
{
    meta:
        description = "Auto-generated rule for ClayRAT"
        author = "MB-Collector"
        date = "2025-11-25T23:00:26.477623"
        sha256 = "708100bbbfab52dd4019bd55b56a475a1e10e2c273478abe8e07c363d342c206"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
