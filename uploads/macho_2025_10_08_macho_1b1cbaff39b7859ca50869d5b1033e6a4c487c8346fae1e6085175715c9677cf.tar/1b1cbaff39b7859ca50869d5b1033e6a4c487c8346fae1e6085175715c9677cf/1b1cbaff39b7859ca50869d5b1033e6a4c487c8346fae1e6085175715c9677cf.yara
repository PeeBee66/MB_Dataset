
rule MB_1b1cbaff
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:11.997250"
        sha256 = "1b1cbaff39b7859ca50869d5b1033e6a4c487c8346fae1e6085175715c9677cf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
