
rule MB_ce8cb74b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-02T23:00:29.520308"
        sha256 = "ce8cb74b3db1bac186ae57524e82d34d247104b43d0623c09712706938dc0642"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
