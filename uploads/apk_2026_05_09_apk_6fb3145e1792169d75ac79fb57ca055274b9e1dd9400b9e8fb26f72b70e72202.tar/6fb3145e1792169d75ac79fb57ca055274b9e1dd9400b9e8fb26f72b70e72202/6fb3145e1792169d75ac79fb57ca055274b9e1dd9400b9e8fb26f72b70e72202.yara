
rule MB_6fb3145e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:40.365357"
        sha256 = "6fb3145e1792169d75ac79fb57ca055274b9e1dd9400b9e8fb26f72b70e72202"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
