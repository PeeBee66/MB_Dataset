
rule MB_c2e98099
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:10.300127"
        sha256 = "c2e98099bf903557e14ec33070934b37620fe6f1de1f93d5ca49c6b1acd4d19b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
