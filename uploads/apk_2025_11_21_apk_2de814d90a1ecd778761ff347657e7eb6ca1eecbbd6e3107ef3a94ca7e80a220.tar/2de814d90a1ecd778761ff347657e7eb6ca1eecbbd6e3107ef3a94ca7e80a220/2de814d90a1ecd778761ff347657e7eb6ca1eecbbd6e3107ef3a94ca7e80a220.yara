
rule MB_2de814d9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:01:00.826191"
        sha256 = "2de814d90a1ecd778761ff347657e7eb6ca1eecbbd6e3107ef3a94ca7e80a220"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
