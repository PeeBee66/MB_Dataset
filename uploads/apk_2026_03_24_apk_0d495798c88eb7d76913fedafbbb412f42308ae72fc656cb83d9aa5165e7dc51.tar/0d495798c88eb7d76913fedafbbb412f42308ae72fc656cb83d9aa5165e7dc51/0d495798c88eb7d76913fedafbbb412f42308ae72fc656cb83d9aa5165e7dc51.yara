
rule MB_0d495798
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:19.396192"
        sha256 = "0d495798c88eb7d76913fedafbbb412f42308ae72fc656cb83d9aa5165e7dc51"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
