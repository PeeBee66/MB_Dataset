
rule MB_cefba3a5
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:07:45.759546"
        sha256 = "cefba3a5a6be2d9238b17f1f776507e2a5b109b6add59f7e55ef626288e867fa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
