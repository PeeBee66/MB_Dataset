
rule MB_3eaefcce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:00:14.073291"
        sha256 = "3eaefcceeee830ccbd4bce11477ccb5555b03a4402b129d0f0618b4937e3a765"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
