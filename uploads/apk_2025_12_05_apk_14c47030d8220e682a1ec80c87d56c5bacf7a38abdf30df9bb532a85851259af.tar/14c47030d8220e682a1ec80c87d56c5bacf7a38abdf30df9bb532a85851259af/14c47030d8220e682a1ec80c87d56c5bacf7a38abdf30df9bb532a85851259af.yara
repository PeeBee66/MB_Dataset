
rule MB_14c47030
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-04T23:00:21.223483"
        sha256 = "14c47030d8220e682a1ec80c87d56c5bacf7a38abdf30df9bb532a85851259af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
