
rule MB_fd7c0f6f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-19T00:00:34.810088"
        sha256 = "fd7c0f6fb3ce15e5e5f713147fd64365e9cdab0d2c23f89aed91005a3ae9e58c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
