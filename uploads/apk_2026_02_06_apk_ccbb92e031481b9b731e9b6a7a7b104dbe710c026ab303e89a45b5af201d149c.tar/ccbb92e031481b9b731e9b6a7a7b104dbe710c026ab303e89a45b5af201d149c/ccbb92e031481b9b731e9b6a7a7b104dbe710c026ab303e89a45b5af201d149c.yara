
rule MB_ccbb92e0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:46.391200"
        sha256 = "ccbb92e031481b9b731e9b6a7a7b104dbe710c026ab303e89a45b5af201d149c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
