
rule MB_5e337ada
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:24.135082"
        sha256 = "5e337adac38d09eb5121325da1cd6f6ddb1ead8f4a530d2206bcf145adcef921"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
