
rule MB_793b9d91
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-03T23:00:20.379072"
        sha256 = "793b9d915d2f412ad32d3aac486f17dd7b5014b86469b6a4540d559ee70a4d7b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
