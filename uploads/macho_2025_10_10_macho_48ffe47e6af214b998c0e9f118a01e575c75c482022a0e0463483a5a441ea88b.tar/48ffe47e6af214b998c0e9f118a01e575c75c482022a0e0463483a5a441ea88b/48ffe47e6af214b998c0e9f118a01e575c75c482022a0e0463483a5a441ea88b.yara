
rule MB_48ffe47e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:09.107613"
        sha256 = "48ffe47e6af214b998c0e9f118a01e575c75c482022a0e0463483a5a441ea88b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
