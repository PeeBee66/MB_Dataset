
rule MB_a81b8015
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:17.171799"
        sha256 = "a81b801522a1c72be91aefffa09b00256fad4ee9d47bb8d79b018b442ab4e78b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
