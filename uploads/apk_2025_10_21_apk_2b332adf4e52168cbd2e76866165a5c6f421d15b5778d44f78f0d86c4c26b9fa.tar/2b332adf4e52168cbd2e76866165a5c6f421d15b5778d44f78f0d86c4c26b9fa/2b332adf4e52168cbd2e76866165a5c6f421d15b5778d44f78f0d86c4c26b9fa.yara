
rule MB_2b332adf
{
    meta:
        description = "Auto-generated rule for Hook"
        author = "MB-Collector"
        date = "2025-10-20T11:53:11.409597"
        sha256 = "2b332adf4e52168cbd2e76866165a5c6f421d15b5778d44f78f0d86c4c26b9fa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
