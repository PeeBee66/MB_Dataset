
rule MB_e7ebac9b
{
    meta:
        description = "Auto-generated rule for RedHook"
        author = "MB-Collector"
        date = "2026-05-07T00:01:33.980319"
        sha256 = "e7ebac9ba2548db5e772f1a0d657acf0f61425e67cf326bea142a1f1c13a077d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
