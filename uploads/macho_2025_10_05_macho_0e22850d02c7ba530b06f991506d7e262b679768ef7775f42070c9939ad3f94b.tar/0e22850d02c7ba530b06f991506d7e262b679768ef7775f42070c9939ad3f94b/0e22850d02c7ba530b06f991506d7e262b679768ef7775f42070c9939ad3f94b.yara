
rule MB_0e22850d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:27.405790"
        sha256 = "0e22850d02c7ba530b06f991506d7e262b679768ef7775f42070c9939ad3f94b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
