
rule MB_63199098
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:04.327165"
        sha256 = "63199098198624ce045c019a8f54e11655ce5c4302657418b0c9240c36f554d1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
