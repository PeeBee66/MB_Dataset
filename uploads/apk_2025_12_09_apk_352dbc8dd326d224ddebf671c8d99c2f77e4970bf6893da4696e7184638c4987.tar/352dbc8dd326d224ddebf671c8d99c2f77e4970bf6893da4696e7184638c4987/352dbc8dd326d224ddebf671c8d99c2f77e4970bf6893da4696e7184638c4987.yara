
rule MB_352dbc8d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:20.615966"
        sha256 = "352dbc8dd326d224ddebf671c8d99c2f77e4970bf6893da4696e7184638c4987"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
