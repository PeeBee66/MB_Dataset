
rule MB_197d6197
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:14.373604"
        sha256 = "197d6197ebc9913c55c913c2a122cb47e5f10e76e29d7604df563807d822d443"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
