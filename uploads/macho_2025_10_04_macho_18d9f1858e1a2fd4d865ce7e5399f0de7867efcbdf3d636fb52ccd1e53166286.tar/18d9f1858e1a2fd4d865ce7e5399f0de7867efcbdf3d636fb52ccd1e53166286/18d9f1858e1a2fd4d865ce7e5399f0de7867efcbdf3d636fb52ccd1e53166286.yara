
rule MB_18d9f185
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:24.645576"
        sha256 = "18d9f1858e1a2fd4d865ce7e5399f0de7867efcbdf3d636fb52ccd1e53166286"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
