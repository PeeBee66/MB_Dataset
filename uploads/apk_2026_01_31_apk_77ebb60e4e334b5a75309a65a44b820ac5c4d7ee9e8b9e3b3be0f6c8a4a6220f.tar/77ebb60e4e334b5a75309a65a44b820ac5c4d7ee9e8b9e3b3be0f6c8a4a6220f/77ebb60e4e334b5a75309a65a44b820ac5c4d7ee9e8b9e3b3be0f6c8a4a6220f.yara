
rule MB_77ebb60e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-30T23:00:15.678960"
        sha256 = "77ebb60e4e334b5a75309a65a44b820ac5c4d7ee9e8b9e3b3be0f6c8a4a6220f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
