
rule MB_3a659f0e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-16T23:00:35.645237"
        sha256 = "3a659f0eea60ca2388eda4ea3989c15f8e5d29c54b51fc74efb599474ba943ea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
