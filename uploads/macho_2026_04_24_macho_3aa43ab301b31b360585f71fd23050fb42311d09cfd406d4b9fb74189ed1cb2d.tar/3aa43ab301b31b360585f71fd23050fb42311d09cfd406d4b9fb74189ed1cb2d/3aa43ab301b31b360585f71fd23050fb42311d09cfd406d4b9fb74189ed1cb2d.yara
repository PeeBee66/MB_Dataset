
rule MB_3aa43ab3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-04-24T00:03:00.375957"
        sha256 = "3aa43ab301b31b360585f71fd23050fb42311d09cfd406d4b9fb74189ed1cb2d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
