
rule MB_d79c24c7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:06:01.465657"
        sha256 = "d79c24c70a0806514ed9b228afe795723ec88a212c2042eb0dd764dd403c4ba9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
