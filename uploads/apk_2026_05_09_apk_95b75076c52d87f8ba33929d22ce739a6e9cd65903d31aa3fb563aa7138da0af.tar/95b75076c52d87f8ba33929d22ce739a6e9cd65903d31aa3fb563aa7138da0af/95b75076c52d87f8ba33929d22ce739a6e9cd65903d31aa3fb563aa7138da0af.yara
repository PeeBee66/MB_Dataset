
rule MB_95b75076
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:18.545084"
        sha256 = "95b75076c52d87f8ba33929d22ce739a6e9cd65903d31aa3fb563aa7138da0af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
