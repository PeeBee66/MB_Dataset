
rule MB_9185cda6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:17.286025"
        sha256 = "9185cda615670b1928acc5419dd309c27eeb42f706c549b058dd48c6c877b0f5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
