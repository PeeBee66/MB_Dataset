
rule MB_bc4c1cd3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:01:10.140829"
        sha256 = "bc4c1cd39d60c29959a4909a5ff71db566a06d62d75405a37e710daca2d4771f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
