
rule MB_4d6be696
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:09.178841"
        sha256 = "4d6be6969ecc7b2d7247fe1fe4ca02d8621363a91905f8ddad6a44f0289219d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
