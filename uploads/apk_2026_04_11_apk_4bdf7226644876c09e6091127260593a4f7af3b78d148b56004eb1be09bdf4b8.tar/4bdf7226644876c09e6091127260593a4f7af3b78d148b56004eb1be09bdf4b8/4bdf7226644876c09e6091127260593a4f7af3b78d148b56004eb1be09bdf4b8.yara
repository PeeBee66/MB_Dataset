
rule MB_4bdf7226
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:01:06.639099"
        sha256 = "4bdf7226644876c09e6091127260593a4f7af3b78d148b56004eb1be09bdf4b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
