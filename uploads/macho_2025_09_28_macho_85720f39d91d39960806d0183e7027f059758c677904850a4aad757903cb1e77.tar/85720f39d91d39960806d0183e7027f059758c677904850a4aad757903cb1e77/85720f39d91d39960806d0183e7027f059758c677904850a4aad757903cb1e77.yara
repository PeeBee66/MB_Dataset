
rule MB_85720f39
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:32.462534"
        sha256 = "85720f39d91d39960806d0183e7027f059758c677904850a4aad757903cb1e77"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
