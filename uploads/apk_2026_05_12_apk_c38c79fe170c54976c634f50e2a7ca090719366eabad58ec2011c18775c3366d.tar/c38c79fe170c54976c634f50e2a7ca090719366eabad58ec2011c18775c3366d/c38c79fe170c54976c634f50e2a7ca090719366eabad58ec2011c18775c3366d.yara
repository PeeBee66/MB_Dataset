
rule MB_c38c79fe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-12T00:00:12.273771"
        sha256 = "c38c79fe170c54976c634f50e2a7ca090719366eabad58ec2011c18775c3366d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
