
rule MB_778b27d0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:53.716427"
        sha256 = "778b27d0fdbf433472461553f3b0ae108551502b646a15bf4b066c6b60947ede"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
