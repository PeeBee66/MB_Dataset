
rule MB_b1a8a189
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-17T23:00:26.224852"
        sha256 = "b1a8a189a95dfe33683141ba24f022357b2e60e5a811f5559b3119fe67c17bdc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
