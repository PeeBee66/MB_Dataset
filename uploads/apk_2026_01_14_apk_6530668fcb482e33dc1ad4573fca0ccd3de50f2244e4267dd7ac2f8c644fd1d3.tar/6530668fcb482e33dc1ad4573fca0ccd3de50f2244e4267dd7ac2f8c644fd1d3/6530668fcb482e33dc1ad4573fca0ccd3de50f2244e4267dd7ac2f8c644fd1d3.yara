
rule MB_6530668f
{
    meta:
        description = "Auto-generated rule for Datzbro"
        author = "MB-Collector"
        date = "2026-01-13T23:00:17.050994"
        sha256 = "6530668fcb482e33dc1ad4573fca0ccd3de50f2244e4267dd7ac2f8c644fd1d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
