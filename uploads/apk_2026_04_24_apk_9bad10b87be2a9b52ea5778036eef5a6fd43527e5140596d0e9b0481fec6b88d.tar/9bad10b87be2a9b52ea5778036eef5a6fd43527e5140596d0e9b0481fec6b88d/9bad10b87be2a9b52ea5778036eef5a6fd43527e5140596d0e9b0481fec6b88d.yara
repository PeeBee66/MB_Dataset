
rule MB_9bad10b8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:23.956513"
        sha256 = "9bad10b87be2a9b52ea5778036eef5a6fd43527e5140596d0e9b0481fec6b88d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
