
rule MB_d60603ab
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:30.439283"
        sha256 = "d60603ab5e7b408202a56911f1ad64e34e43730a16759a5b08a14644309a9d57"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
