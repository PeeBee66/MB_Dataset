
rule MB_1ac8b0b1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:07.230207"
        sha256 = "1ac8b0b1b54f8b41641d05333ac3473d9f795beaf86f346e88abad0914849945"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
