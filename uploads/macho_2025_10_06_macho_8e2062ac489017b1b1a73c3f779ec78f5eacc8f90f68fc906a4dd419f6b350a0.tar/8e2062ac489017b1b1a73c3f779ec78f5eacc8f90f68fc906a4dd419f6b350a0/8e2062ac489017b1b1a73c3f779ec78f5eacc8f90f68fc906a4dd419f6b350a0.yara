
rule MB_8e2062ac
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:11.736253"
        sha256 = "8e2062ac489017b1b1a73c3f779ec78f5eacc8f90f68fc906a4dd419f6b350a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
