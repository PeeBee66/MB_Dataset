
rule MB_70db40bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:35:23.561652"
        sha256 = "70db40bbe0fd718aefbbf6a9a361bbd909372b3c631a9f929acb7f2d2b42edf2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
