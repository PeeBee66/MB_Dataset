
rule MB_7fe63d72
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:36.820710"
        sha256 = "7fe63d72d188ca85b1bc67a06a012c982f2e905d761d76c57d2be23ec851c7e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
