
rule MB_46326534
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:00:56.643345"
        sha256 = "46326534553b3c5307d4c0347c12919b93b2699f9670593885cf52182a28180f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
