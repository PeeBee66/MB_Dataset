
rule MB_96c6a228
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:01:02.281053"
        sha256 = "96c6a228d7fb56f609d8f05086126557ffe8ba5b016e7bb6aedc0e9cc3bbeca8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
