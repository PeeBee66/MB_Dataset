
rule MB_db30e3f8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-20T00:00:19.879241"
        sha256 = "db30e3f8c09d36e8b9e1d8093b700f97f6a6061484e4db673e78d6a5e88d43bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
