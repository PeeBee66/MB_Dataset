
rule MB_f5bd5070
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-04T23:00:41.793374"
        sha256 = "f5bd5070852baf016192d752f58f631020be07560736e7826746b07a15657607"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
