
rule MB_ecc15c35
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-04T23:00:40.425989"
        sha256 = "ecc15c35c1f6e04c049023a664b23a3369dfeddb155408601f660c295b6bfa33"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
