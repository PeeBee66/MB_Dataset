
rule MB_55e4a842
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:01:08.141964"
        sha256 = "55e4a8425387a5ad4d63be81b36e39199d38ae6270828979440836708af1252c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
