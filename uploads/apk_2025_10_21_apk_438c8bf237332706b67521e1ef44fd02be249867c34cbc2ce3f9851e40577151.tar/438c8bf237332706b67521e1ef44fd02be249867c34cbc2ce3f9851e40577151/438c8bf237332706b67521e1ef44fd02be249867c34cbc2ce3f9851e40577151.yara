
rule MB_438c8bf2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:58.435347"
        sha256 = "438c8bf237332706b67521e1ef44fd02be249867c34cbc2ce3f9851e40577151"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
