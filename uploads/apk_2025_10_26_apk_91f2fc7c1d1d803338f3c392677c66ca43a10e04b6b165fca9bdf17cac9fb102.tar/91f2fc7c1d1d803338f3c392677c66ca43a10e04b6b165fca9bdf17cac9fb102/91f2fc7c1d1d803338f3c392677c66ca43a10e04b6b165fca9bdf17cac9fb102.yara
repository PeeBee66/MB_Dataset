
rule MB_91f2fc7c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-25T23:00:14.655172"
        sha256 = "91f2fc7c1d1d803338f3c392677c66ca43a10e04b6b165fca9bdf17cac9fb102"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
