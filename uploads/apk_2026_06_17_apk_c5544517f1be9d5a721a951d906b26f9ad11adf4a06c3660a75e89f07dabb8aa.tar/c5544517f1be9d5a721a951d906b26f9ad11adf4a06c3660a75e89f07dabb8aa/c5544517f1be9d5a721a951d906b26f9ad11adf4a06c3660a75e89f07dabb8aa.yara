
rule MB_c5544517
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-17T00:00:14.509240"
        sha256 = "c5544517f1be9d5a721a951d906b26f9ad11adf4a06c3660a75e89f07dabb8aa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
