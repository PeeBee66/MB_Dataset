
rule MB_2ca2abcb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:36.497171"
        sha256 = "2ca2abcb1f1896793ba434f37bf4c24535f5dee1c81f3fe118b15cbd045614b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
