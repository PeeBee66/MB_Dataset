
rule MB_4e4acc0a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:49.231566"
        sha256 = "4e4acc0a6bb61cf07705aac7bb86ec5a014f68771566cfa9400e702561c645f9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
