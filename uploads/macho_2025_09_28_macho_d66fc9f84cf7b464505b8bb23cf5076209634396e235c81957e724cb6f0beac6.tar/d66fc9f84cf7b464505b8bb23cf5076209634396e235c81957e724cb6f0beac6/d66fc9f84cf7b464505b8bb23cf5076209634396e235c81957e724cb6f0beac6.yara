
rule MB_d66fc9f8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:03.454578"
        sha256 = "d66fc9f84cf7b464505b8bb23cf5076209634396e235c81957e724cb6f0beac6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
