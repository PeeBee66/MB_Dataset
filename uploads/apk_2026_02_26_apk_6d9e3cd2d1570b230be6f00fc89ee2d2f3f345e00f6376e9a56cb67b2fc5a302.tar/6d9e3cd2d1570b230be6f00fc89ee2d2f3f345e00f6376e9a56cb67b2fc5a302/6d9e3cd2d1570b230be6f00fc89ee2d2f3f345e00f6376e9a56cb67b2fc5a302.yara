
rule MB_6d9e3cd2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-25T23:00:33.193840"
        sha256 = "6d9e3cd2d1570b230be6f00fc89ee2d2f3f345e00f6376e9a56cb67b2fc5a302"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
