
rule MB_0dc22b4c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:19:52.159484"
        sha256 = "0dc22b4cb9aca70b5982a789c6342656331063795991ca84838b2cf5fe5d960a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
