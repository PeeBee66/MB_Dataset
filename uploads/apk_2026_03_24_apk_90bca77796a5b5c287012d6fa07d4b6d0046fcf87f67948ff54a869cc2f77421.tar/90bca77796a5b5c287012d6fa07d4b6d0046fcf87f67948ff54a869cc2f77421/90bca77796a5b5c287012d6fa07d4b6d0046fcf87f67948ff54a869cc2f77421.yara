
rule MB_90bca777
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:49.742283"
        sha256 = "90bca77796a5b5c287012d6fa07d4b6d0046fcf87f67948ff54a869cc2f77421"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
