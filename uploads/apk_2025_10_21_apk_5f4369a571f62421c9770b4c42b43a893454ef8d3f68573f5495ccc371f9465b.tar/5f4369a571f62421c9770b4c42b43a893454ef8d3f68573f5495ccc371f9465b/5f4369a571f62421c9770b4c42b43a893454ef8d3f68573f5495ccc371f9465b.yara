
rule MB_5f4369a5
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:29:39.522689"
        sha256 = "5f4369a571f62421c9770b4c42b43a893454ef8d3f68573f5495ccc371f9465b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
