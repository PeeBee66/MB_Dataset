
rule MB_0acce528
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:28.654134"
        sha256 = "0acce52848feedf7f1bd774ee19a7c29820f9d48de1766b8e7c0f52dd88513bc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
