
rule MB_a0229136
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:20:04.147629"
        sha256 = "a022913613f86b2e2a8e625c3550bbd9eaab3e05eeaf2576b90a2e793ac795f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
