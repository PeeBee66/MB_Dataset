
rule MB_04cb1225
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-20T11:22:12.539823"
        sha256 = "04cb1225b4a5a0c256234a9b027408994c45911041766fe0b7e691c44a29389d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
