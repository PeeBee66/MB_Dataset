
rule MB_f3d31920
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:21.205666"
        sha256 = "f3d31920a345a40062c95c29f5a1da663365a93464e4e27f1cf5faa3ec5dc6c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
