
rule MB_ed93294a
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:17.345469"
        sha256 = "ed93294a4e5d3cf5b548ab0fa6427ceff210b859f107d1dfda2227ad3b65a778"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
