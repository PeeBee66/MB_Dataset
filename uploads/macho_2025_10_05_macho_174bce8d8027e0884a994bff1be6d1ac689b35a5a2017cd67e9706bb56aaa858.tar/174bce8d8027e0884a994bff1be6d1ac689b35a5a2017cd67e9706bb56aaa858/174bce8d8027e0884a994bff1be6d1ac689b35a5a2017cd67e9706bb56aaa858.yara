
rule MB_174bce8d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:16.990200"
        sha256 = "174bce8d8027e0884a994bff1be6d1ac689b35a5a2017cd67e9706bb56aaa858"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
