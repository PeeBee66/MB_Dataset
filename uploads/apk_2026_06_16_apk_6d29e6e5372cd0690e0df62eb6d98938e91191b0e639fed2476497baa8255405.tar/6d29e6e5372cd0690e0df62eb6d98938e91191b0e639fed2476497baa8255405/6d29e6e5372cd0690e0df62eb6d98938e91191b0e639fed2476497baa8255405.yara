
rule MB_6d29e6e5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:26.783313"
        sha256 = "6d29e6e5372cd0690e0df62eb6d98938e91191b0e639fed2476497baa8255405"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
