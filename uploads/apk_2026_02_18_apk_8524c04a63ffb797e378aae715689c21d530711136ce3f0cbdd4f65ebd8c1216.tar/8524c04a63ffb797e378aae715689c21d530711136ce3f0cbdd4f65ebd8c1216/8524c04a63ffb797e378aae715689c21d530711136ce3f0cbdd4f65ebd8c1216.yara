
rule MB_8524c04a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-17T23:00:24.794490"
        sha256 = "8524c04a63ffb797e378aae715689c21d530711136ce3f0cbdd4f65ebd8c1216"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
