
rule MB_381c41b3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:44.909277"
        sha256 = "381c41b3253ec42e5b2ea44c52b357cc8a3c11d11bd43a38239995eb925234e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
