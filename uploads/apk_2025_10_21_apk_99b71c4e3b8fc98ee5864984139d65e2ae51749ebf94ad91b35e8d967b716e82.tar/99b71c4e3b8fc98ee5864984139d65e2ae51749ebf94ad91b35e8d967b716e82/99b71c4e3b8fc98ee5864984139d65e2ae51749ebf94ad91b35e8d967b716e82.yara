
rule MB_99b71c4e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:27:54.776337"
        sha256 = "99b71c4e3b8fc98ee5864984139d65e2ae51749ebf94ad91b35e8d967b716e82"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
