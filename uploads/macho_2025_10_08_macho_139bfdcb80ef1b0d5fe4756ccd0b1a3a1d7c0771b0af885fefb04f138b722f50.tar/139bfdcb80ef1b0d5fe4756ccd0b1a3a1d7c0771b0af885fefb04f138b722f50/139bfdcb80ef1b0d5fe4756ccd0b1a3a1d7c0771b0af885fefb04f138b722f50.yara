
rule MB_139bfdcb
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:09.610829"
        sha256 = "139bfdcb80ef1b0d5fe4756ccd0b1a3a1d7c0771b0af885fefb04f138b722f50"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
