
rule MB_5786b5ec
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:00:58.097194"
        sha256 = "5786b5eca3045d0bc95e19469b852cc10a454f94302c528e336f183bc25bacd4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
