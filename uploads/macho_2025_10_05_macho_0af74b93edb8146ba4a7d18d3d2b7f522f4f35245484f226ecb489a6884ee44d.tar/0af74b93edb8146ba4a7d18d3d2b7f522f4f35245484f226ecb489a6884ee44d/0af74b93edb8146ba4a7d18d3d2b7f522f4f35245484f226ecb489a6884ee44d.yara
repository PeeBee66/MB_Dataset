
rule MB_0af74b93
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:38.425377"
        sha256 = "0af74b93edb8146ba4a7d18d3d2b7f522f4f35245484f226ecb489a6884ee44d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
