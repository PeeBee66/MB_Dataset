
rule MB_97936d78
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-11T00:00:21.556904"
        sha256 = "97936d7873348f905d119dd9399261374aae494296e1b5fb3df521ef3cc76405"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
