
rule MB_10d7b9cf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:34.320279"
        sha256 = "10d7b9cf51583b5b53ae1b94df3a9aa2657f403a08458b49218a681ed94284a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
