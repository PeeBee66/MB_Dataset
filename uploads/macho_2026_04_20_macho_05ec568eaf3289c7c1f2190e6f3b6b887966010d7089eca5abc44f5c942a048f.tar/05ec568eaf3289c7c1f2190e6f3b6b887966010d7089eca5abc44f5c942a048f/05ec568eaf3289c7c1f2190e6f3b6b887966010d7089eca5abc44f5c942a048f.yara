
rule MB_05ec568e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-20T00:01:02.322015"
        sha256 = "05ec568eaf3289c7c1f2190e6f3b6b887966010d7089eca5abc44f5c942a048f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
