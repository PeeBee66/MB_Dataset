
rule MB_45bba768
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:45:50.374114"
        sha256 = "45bba7681e5a2c3512e6337baed739d3af30af5bfc9ffe0ae18e211e068274a1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
