
rule MB_0d1e3a9e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-03T23:00:47.356422"
        sha256 = "0d1e3a9e6f3211b7e3072d736e9a2e6be363fc7c100b90bf7e1e9bee121e30df"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
