
rule MB_b420b96e
{
    meta:
        description = "Auto-generated rule for PromptSpy"
        author = "MB-Collector"
        date = "2026-02-19T23:00:45.514155"
        sha256 = "b420b96e0d76702f51ba0e3364da881aaf766e00538059e58fec6b7676a68e6c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
