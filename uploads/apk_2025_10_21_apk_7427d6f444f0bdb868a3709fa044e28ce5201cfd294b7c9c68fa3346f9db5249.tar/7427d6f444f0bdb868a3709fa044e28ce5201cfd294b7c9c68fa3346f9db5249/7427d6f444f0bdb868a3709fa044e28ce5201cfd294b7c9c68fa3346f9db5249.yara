
rule MB_7427d6f4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:56.282182"
        sha256 = "7427d6f444f0bdb868a3709fa044e28ce5201cfd294b7c9c68fa3346f9db5249"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
