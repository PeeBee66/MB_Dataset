
rule MB_283ff3ab
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:34.708125"
        sha256 = "283ff3ab6a65e1690fdb131c0353f4978b2f238fa25936ca775a27b5bba11a83"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
