
rule MB_3c81526b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:20.720292"
        sha256 = "3c81526bcb801d7dcfaea7f379528471d745a36e3c1bdc41877b4bed34b5dce6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
