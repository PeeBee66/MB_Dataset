
rule MB_998c38b4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:16.696590"
        sha256 = "998c38b430097479b015a68d9435dc5b98684119739572a4dff11e085881187e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
