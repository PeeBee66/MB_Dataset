
rule MB_fa1b8ce8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:05.896570"
        sha256 = "fa1b8ce8ba1016cfd7bb81033483be7e9e07fc2b4b511fbfb126387c07a6c9aa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
