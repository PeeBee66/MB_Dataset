
rule MB_b8ca6e97
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:43.011686"
        sha256 = "b8ca6e9722532acffe1d51a5a311a5c5c0af0ff390b499237b9ea0879a2b1b5e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
