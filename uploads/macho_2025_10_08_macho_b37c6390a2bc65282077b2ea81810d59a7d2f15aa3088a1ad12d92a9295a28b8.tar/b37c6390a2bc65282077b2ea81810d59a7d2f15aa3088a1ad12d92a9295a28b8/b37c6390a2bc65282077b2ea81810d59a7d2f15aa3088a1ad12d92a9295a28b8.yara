
rule MB_b37c6390
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:45.655496"
        sha256 = "b37c6390a2bc65282077b2ea81810d59a7d2f15aa3088a1ad12d92a9295a28b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
