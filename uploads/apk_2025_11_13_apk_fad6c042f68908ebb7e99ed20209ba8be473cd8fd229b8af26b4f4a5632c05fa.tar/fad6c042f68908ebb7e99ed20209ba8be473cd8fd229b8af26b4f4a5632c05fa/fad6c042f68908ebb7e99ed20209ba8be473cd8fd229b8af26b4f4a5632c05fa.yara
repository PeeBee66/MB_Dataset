
rule MB_fad6c042
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:01:03.413185"
        sha256 = "fad6c042f68908ebb7e99ed20209ba8be473cd8fd229b8af26b4f4a5632c05fa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
