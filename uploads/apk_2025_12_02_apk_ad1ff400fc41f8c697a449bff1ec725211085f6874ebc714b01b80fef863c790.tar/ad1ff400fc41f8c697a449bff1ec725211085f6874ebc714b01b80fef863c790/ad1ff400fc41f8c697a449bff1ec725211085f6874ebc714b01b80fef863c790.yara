
rule MB_ad1ff400
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:01:19.155955"
        sha256 = "ad1ff400fc41f8c697a449bff1ec725211085f6874ebc714b01b80fef863c790"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
