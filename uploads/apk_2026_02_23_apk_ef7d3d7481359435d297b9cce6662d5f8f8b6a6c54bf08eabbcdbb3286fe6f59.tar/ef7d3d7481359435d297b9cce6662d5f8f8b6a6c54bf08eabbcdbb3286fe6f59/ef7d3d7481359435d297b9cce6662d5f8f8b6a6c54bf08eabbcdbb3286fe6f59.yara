
rule MB_ef7d3d74
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-22T23:00:16.730702"
        sha256 = "ef7d3d7481359435d297b9cce6662d5f8f8b6a6c54bf08eabbcdbb3286fe6f59"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
