
rule MB_3df1399f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:17.189285"
        sha256 = "3df1399f9b07fa9794d041e43f83fb65ea7052cd3d66c503bec55ab3d8d415fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
