
rule MB_ea54bf55
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:46.737044"
        sha256 = "ea54bf556a12a654b7012f38edfcb5bb758af2d3a420c570c17c3e8027178597"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
