
rule MB_ca873d13
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:30.851770"
        sha256 = "ca873d13599da78a97064cda743b4a34ecb3406588905ae4f14dc9af0466ac7a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
