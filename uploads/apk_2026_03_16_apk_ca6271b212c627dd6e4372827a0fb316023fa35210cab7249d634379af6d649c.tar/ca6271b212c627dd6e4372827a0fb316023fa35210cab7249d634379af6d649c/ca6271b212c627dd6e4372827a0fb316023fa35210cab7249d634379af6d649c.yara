
rule MB_ca6271b2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:00:48.521997"
        sha256 = "ca6271b212c627dd6e4372827a0fb316023fa35210cab7249d634379af6d649c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
