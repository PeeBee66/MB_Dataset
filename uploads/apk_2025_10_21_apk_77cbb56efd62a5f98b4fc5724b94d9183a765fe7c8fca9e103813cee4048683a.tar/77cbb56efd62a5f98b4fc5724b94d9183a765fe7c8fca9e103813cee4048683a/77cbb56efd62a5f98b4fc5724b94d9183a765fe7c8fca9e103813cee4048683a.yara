
rule MB_77cbb56e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:31.976491"
        sha256 = "77cbb56efd62a5f98b4fc5724b94d9183a765fe7c8fca9e103813cee4048683a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
