
rule MB_c3c107ff
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-03T23:00:30.639620"
        sha256 = "c3c107ff3419beb378d3e26727aad8089c42bc688b3c79fa981260e93b66ca73"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
