
rule MB_e15ebe6b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-19T23:00:28.434699"
        sha256 = "e15ebe6b60173a80a7fc6b421ad5bc59d72404eae2e71ff1b0cf530b20c1d886"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
