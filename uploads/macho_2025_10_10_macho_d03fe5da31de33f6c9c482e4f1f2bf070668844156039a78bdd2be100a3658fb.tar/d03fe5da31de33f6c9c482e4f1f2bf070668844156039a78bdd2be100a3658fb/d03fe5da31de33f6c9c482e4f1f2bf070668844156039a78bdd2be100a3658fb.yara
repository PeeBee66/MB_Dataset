
rule MB_d03fe5da
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:25.999575"
        sha256 = "d03fe5da31de33f6c9c482e4f1f2bf070668844156039a78bdd2be100a3658fb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
