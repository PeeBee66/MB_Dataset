
rule MB_f73771a1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:43.847406"
        sha256 = "f73771a1b9887ebe85ce70b6dc459e0ce05ff6f71ba5833b5385a9e0a81af3df"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
