
rule MB_1aeae34c
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:01:21.443278"
        sha256 = "1aeae34c264bbfbd4eed6d92a94ac788bfb9b050a54032fde811402d63f18bf8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
