
rule MB_54a3e468
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:47.380365"
        sha256 = "54a3e468ad1f84a4ce28a69b77578712cfef62dea2b99f509d3a1f22235e5af3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
