
rule MB_3bf85d89
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:01:28.961251"
        sha256 = "3bf85d89ea0f5f29c3adbc1af46fafb2fbd2147102659709cd1bd90273b44d27"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
