
rule MB_88e08472
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:15.159837"
        sha256 = "88e08472199a41416bc19e0f2bb4a87d40e63e44e064515666bf2e62588ee5db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
