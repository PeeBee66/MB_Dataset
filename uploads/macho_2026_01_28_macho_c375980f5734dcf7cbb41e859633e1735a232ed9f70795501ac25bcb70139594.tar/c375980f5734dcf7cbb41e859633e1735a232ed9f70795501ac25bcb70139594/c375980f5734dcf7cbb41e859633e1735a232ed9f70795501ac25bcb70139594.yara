
rule MB_c375980f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-27T23:00:19.708369"
        sha256 = "c375980f5734dcf7cbb41e859633e1735a232ed9f70795501ac25bcb70139594"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
