
rule MB_de23cdf0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:49.723574"
        sha256 = "de23cdf0fd8dd42c61036e7735ed2b380203986398103a57a31e02940a69d819"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
