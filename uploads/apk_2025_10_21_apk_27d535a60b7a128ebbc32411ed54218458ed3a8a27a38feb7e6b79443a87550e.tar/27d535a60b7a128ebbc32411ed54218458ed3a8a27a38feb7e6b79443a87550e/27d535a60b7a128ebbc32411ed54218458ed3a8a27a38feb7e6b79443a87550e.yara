
rule MB_27d535a6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:27:45.769683"
        sha256 = "27d535a60b7a128ebbc32411ed54218458ed3a8a27a38feb7e6b79443a87550e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
