
rule MB_25ed3d37
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:26.240388"
        sha256 = "25ed3d37f5fcf96e0c487b9043ccbc82c1d7986fea4b1d21f08d763756ce1a3e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
