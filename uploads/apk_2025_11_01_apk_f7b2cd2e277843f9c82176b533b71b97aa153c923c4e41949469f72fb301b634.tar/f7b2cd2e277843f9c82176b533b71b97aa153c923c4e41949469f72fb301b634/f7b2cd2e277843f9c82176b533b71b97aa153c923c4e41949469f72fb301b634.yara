
rule MB_f7b2cd2e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:59.925297"
        sha256 = "f7b2cd2e277843f9c82176b533b71b97aa153c923c4e41949469f72fb301b634"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
