
rule MB_4a6250d7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:01:06.231683"
        sha256 = "4a6250d7dab7d82255cc526f6b857af8f53378c186700dd8682408180b92cb6a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
