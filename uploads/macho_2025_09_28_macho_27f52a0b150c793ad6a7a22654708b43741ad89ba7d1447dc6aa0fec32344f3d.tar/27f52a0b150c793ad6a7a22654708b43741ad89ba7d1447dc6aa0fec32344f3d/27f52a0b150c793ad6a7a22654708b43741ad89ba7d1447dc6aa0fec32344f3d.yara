
rule MB_27f52a0b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:29.602093"
        sha256 = "27f52a0b150c793ad6a7a22654708b43741ad89ba7d1447dc6aa0fec32344f3d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
