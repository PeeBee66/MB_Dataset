
rule MB_bc7c3a3f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-15T23:00:16.435265"
        sha256 = "bc7c3a3f2b617a7bec37ae806fad0d53a0763f0b2cc905050a5b93ecc486e3f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
