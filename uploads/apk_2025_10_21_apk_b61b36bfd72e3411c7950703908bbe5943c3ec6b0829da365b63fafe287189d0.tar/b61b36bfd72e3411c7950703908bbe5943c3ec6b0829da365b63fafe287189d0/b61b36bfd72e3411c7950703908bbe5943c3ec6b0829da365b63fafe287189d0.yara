
rule MB_b61b36bf
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T11:35:58.491314"
        sha256 = "b61b36bfd72e3411c7950703908bbe5943c3ec6b0829da365b63fafe287189d0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
