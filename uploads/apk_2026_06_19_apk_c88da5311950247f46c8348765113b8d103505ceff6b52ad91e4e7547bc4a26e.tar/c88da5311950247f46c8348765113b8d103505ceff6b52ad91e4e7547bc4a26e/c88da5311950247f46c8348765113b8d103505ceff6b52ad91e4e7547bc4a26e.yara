
rule MB_c88da531
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-19T00:00:17.659920"
        sha256 = "c88da5311950247f46c8348765113b8d103505ceff6b52ad91e4e7547bc4a26e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
