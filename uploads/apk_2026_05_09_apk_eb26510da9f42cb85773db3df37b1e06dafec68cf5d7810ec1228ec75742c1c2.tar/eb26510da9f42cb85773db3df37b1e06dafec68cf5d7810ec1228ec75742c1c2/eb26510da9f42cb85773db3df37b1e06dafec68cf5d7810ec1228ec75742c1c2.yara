
rule MB_eb26510d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:28.021614"
        sha256 = "eb26510da9f42cb85773db3df37b1e06dafec68cf5d7810ec1228ec75742c1c2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
