
rule MB_28204f81
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:20.913077"
        sha256 = "28204f81586457f3f835a64aed3ec82eb8b100b4c3a6446bb2f9f50cf06cbe20"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
