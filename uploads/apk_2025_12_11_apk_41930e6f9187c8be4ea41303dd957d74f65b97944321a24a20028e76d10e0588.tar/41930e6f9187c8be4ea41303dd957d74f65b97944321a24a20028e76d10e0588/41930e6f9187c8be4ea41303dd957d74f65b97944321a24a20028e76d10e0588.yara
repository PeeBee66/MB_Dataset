
rule MB_41930e6f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-10T23:00:39.285413"
        sha256 = "41930e6f9187c8be4ea41303dd957d74f65b97944321a24a20028e76d10e0588"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
