
rule MB_16e94da7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:50.932403"
        sha256 = "16e94da7377e34cbf9f40500cc593404520f18ddfe9691206fb98d874ba7ed49"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
