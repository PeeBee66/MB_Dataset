
rule MB_64e86716
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:01:49.578769"
        sha256 = "64e86716d6ab49271201dfe9c9fe9a8d7be8ac97a8c641eb712f987c5945d26b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
