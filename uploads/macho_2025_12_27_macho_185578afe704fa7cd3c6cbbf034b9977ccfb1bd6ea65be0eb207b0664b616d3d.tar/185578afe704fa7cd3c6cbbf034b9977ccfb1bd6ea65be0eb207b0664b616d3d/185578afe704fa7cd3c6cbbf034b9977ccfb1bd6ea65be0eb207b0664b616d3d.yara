
rule MB_185578af
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-26T23:00:18.487505"
        sha256 = "185578afe704fa7cd3c6cbbf034b9977ccfb1bd6ea65be0eb207b0664b616d3d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
