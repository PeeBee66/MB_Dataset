
rule MB_ba9e4a86
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:30.551050"
        sha256 = "ba9e4a86cca3bce50c5a87b4bdf15950545173f0ac5bd23dd095ce934e07dca0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
