
rule MB_4e93396d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:20.488323"
        sha256 = "4e93396db22b92f46009e49fb802d0cf05d264a64c8810a3a486bb4bc36d4b88"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
