
rule MB_4eb2ac59
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:22.476444"
        sha256 = "4eb2ac595b1a17ddde607d55dc41d93896eeca3a01cd440b8953159bca3a418d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
