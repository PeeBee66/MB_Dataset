
rule MB_7bdf54b8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:23.516502"
        sha256 = "7bdf54b8fb0edd3ea175534dc17c7749177fbd00660bfcc622ff405931f565dc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
