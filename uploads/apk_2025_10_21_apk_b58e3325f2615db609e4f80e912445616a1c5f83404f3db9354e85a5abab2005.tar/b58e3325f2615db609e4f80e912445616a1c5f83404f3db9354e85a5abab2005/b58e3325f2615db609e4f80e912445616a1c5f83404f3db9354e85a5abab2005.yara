
rule MB_b58e3325
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:24.016150"
        sha256 = "b58e3325f2615db609e4f80e912445616a1c5f83404f3db9354e85a5abab2005"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
