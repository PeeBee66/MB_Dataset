
rule MB_774af642
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:01:15.727074"
        sha256 = "774af64259ad726296fb4fc56ca91897c7da9acb3a10ad49325ead714f6562c4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
