
rule MB_1602e827
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:44.690669"
        sha256 = "1602e827dcc914587dc22d55e49d26260c14c6ba86bd51f78b8ff95941ce290f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
