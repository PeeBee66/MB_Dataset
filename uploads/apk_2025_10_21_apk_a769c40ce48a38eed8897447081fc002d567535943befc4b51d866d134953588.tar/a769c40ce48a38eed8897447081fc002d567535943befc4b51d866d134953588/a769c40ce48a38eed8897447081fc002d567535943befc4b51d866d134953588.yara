
rule MB_a769c40c
{
    meta:
        description = "Auto-generated rule for BingoMod"
        author = "MB-Collector"
        date = "2025-10-20T11:38:53.572069"
        sha256 = "a769c40ce48a38eed8897447081fc002d567535943befc4b51d866d134953588"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
