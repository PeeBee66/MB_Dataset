
rule MB_9da55ad0
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:35:06.771640"
        sha256 = "9da55ad04e480fa1fd3b45a5f245e6511dfc45d44123000e1cc2d1e10c65e8b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
