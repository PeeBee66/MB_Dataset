
rule MB_adefc2f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:36.533118"
        sha256 = "adefc2f666aa936763b18300444995e1d2a4c1950ef00577de7a88381b825c1f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
