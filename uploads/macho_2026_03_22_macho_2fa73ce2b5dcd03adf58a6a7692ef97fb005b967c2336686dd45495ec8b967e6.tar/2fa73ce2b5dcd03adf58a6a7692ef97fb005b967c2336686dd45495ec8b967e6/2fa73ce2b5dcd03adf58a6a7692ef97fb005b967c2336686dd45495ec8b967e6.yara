
rule MB_2fa73ce2
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:01:59.170036"
        sha256 = "2fa73ce2b5dcd03adf58a6a7692ef97fb005b967c2336686dd45495ec8b967e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
