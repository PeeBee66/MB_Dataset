
rule MB_759eed82
{
    meta:
        description = "Auto-generated rule for Mirax"
        author = "MB-Collector"
        date = "2026-04-16T00:02:50.126723"
        sha256 = "759eed82699b86b6a792a63ccc76c2fa5ed71720b89132abdead9753f5d7bd11"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
