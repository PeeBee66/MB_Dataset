
rule MB_f19a8bd4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:00:45.226600"
        sha256 = "f19a8bd4ebd1ef6c60f3e83d04638beb5ef4a51b01fa6d5a68d565bdf0b46219"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
