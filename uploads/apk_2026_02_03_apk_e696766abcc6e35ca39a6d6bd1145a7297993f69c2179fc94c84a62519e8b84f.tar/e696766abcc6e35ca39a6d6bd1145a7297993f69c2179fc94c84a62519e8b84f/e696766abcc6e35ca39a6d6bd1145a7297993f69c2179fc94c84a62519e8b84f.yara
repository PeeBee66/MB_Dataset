
rule MB_e696766a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:06.566555"
        sha256 = "e696766abcc6e35ca39a6d6bd1145a7297993f69c2179fc94c84a62519e8b84f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
