
rule MB_2c3fe15a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:56.048167"
        sha256 = "2c3fe15a3a811d46dd53817bb55b090a706a3fb4e3c8ccd038f3353e8a7ed223"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
