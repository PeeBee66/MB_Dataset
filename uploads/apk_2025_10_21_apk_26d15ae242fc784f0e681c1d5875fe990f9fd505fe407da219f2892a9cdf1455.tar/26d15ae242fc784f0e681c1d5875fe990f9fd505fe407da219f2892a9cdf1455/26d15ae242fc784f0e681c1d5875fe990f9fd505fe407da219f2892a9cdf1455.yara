
rule MB_26d15ae2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:27.805672"
        sha256 = "26d15ae242fc784f0e681c1d5875fe990f9fd505fe407da219f2892a9cdf1455"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
