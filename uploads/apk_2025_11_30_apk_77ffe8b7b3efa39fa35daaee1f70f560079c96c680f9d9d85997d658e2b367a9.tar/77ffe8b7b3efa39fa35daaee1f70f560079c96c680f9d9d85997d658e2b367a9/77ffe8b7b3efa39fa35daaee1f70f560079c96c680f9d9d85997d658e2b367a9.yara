
rule MB_77ffe8b7
{
    meta:
        description = "Auto-generated rule for Metasploit"
        author = "MB-Collector"
        date = "2025-11-29T23:00:12.263795"
        sha256 = "77ffe8b7b3efa39fa35daaee1f70f560079c96c680f9d9d85997d658e2b367a9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
