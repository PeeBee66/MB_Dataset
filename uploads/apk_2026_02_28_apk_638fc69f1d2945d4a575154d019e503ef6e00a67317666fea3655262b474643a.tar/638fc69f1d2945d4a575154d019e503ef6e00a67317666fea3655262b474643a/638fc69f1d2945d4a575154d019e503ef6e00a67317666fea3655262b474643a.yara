
rule MB_638fc69f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-27T23:00:12.786891"
        sha256 = "638fc69f1d2945d4a575154d019e503ef6e00a67317666fea3655262b474643a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
