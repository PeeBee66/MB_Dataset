
rule MB_09281e74
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:01:02.948291"
        sha256 = "09281e74d9d4eeffcf9b39bd524625ffadf96d1dedbe2540a0f3286f183feaac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
