
rule MB_5c28134d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:08.471373"
        sha256 = "5c28134dee20ddff2f35385867cb77727da73183b0aea42ac42a5e32007625e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
