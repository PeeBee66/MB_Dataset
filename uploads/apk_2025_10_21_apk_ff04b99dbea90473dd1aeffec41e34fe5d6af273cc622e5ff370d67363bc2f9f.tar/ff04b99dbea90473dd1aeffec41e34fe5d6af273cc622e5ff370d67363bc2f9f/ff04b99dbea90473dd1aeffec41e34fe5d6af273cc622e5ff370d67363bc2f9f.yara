
rule MB_ff04b99d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:36.098973"
        sha256 = "ff04b99dbea90473dd1aeffec41e34fe5d6af273cc622e5ff370d67363bc2f9f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
