
rule MB_204edbbd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-23T23:01:03.990714"
        sha256 = "204edbbd9ab906160ea75c77681a47a21f018f18eca0927a901df6fe24fbd532"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
