
rule MB_5dad07b0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:54.732338"
        sha256 = "5dad07b06415deca06f91629545af6cf5ef7852c315f44732d97541c0d07a0b5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
