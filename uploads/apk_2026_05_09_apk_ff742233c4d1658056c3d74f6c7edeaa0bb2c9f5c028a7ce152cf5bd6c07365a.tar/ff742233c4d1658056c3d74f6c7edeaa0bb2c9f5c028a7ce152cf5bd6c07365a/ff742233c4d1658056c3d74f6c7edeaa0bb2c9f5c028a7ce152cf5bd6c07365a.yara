
rule MB_ff742233
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:00:52.792292"
        sha256 = "ff742233c4d1658056c3d74f6c7edeaa0bb2c9f5c028a7ce152cf5bd6c07365a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
