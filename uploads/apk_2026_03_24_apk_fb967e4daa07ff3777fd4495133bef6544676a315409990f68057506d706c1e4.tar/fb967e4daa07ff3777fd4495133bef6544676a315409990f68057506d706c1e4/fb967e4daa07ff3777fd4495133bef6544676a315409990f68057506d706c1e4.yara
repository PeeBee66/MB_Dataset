
rule MB_fb967e4d
{
    meta:
        description = "Auto-generated rule for Mirai"
        author = "MB-Collector"
        date = "2026-03-23T23:00:35.889332"
        sha256 = "fb967e4daa07ff3777fd4495133bef6544676a315409990f68057506d706c1e4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
