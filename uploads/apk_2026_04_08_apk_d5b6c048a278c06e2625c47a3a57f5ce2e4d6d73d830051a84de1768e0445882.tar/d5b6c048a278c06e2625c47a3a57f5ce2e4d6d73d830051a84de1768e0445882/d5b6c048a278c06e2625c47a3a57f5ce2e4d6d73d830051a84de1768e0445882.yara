
rule MB_d5b6c048
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-08T00:00:22.022543"
        sha256 = "d5b6c048a278c06e2625c47a3a57f5ce2e4d6d73d830051a84de1768e0445882"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
