
rule MB_17b55534
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-12T23:00:27.900454"
        sha256 = "17b5553458d022f27f2e5895b303bab036a0912e3a0d8b1c0138f4d7900bc2c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
