
rule MB_85c1e56d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-06T23:00:12.608682"
        sha256 = "85c1e56dcd1f6228915262b55ac29c9d5ec83542b0e7ac66fedee6be5f689be1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
