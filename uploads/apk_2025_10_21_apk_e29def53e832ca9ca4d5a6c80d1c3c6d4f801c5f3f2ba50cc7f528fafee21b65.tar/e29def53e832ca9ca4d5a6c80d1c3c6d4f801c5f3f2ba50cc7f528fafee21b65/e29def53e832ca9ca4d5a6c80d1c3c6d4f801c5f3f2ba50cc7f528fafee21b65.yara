
rule MB_e29def53
{
    meta:
        description = "Auto-generated rule for Hook"
        author = "MB-Collector"
        date = "2025-10-20T11:53:19.326439"
        sha256 = "e29def53e832ca9ca4d5a6c80d1c3c6d4f801c5f3f2ba50cc7f528fafee21b65"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
