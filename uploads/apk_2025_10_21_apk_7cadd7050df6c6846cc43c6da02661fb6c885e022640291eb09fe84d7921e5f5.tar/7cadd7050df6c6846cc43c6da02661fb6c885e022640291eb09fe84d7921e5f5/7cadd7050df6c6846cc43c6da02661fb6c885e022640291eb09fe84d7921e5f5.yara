
rule MB_7cadd705
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:33.832155"
        sha256 = "7cadd7050df6c6846cc43c6da02661fb6c885e022640291eb09fe84d7921e5f5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
