
rule MB_3dc24332
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:36.711737"
        sha256 = "3dc24332f897ef758c38e4959624606236a3c63a1ba2e0b3d268ed6ce40b5c1a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
