
rule MB_cb00aa25
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:55.052418"
        sha256 = "cb00aa2550645729c93bfc2bcbe9411ab7f8b14c41f80ced6313e51f1b8b19e1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
