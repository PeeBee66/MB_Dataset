
rule MB_a3abf59a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:48.534396"
        sha256 = "a3abf59afe735fec1b2b1599ea411906674a58df563d8ebc779e8127a1b05795"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
