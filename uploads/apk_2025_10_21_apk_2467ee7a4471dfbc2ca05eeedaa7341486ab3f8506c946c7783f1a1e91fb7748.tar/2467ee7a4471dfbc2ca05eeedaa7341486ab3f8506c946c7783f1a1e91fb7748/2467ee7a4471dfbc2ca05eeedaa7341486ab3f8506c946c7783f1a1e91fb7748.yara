
rule MB_2467ee7a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:44.201941"
        sha256 = "2467ee7a4471dfbc2ca05eeedaa7341486ab3f8506c946c7783f1a1e91fb7748"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
