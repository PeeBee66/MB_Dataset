
rule MB_09cd824f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:46.075752"
        sha256 = "09cd824f91c6dd4ca852ddf4f80aed469c71ab748565b6598f3ffb62d841f9c6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
