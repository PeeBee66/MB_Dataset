
rule MB_faeb83e7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:28.615712"
        sha256 = "faeb83e77a383e529cee0ae689fec98970099fa58758ba4526da1adadaefbe8a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
