
rule MB_918b846b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-01T23:01:06.500165"
        sha256 = "918b846b21167686b9d121e182c9dfec18e66b53fd1c33af1cdd1d0907e5fb12"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
