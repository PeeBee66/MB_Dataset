
rule MB_c2e5bc2e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:56.114645"
        sha256 = "c2e5bc2e42d0856253aaa196d18f4c80aa59af29ad565386b590718c88030a30"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
