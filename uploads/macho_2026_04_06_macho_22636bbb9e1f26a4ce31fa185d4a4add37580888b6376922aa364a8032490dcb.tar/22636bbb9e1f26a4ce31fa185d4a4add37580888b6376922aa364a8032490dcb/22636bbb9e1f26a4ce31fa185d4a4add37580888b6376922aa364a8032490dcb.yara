
rule MB_22636bbb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-06T00:00:45.557998"
        sha256 = "22636bbb9e1f26a4ce31fa185d4a4add37580888b6376922aa364a8032490dcb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
