
rule MB_b75757e3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:23.476731"
        sha256 = "b75757e3f7f4b7b7e362ca42756869a310f0f32da06790466e68518f6622efb8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
