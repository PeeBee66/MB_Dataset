
rule MB_aa594e90
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:01:23.042965"
        sha256 = "aa594e90a88687010a00fa07bd055454b89e07929b21623cc5b3f0bc0108548f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
