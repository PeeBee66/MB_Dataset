
rule MB_600077be
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:04:02.941417"
        sha256 = "600077bee4cc917db6914d23c8c76b9356af8db272c9475feb5f331b9c293032"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
