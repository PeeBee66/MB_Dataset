
rule MB_f9f87377
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:28.673494"
        sha256 = "f9f8737746415f4a0976abe2774815732b4a2a0e39cdc1cd6d1f7a70e55a7d62"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
