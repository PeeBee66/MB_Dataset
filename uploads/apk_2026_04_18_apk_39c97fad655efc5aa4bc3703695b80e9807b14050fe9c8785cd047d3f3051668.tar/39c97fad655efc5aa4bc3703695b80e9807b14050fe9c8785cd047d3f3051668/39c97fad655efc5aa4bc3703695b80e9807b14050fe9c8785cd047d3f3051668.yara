
rule MB_39c97fad
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:41.052632"
        sha256 = "39c97fad655efc5aa4bc3703695b80e9807b14050fe9c8785cd047d3f3051668"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
