
rule MB_c02c3e4f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:59.050244"
        sha256 = "c02c3e4ff75e6d28b485ce1e848307db81ff2a291f38d65395f1993539ead072"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
