
rule MB_0a789251
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:30.539283"
        sha256 = "0a7892513f7ed540529df130d9f51a8e39ddd562b08ec462d6bf07b89eca6169"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
