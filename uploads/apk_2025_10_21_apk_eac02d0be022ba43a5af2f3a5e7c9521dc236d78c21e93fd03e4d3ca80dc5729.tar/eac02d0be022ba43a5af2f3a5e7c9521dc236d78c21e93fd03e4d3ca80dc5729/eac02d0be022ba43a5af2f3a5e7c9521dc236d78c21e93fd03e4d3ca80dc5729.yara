
rule MB_eac02d0b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:04.870765"
        sha256 = "eac02d0be022ba43a5af2f3a5e7c9521dc236d78c21e93fd03e4d3ca80dc5729"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
