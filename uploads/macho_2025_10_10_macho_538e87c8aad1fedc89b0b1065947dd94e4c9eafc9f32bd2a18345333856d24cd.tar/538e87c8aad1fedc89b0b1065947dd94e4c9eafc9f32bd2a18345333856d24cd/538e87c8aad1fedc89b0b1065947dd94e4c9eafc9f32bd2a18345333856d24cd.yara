
rule MB_538e87c8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:57.772509"
        sha256 = "538e87c8aad1fedc89b0b1065947dd94e4c9eafc9f32bd2a18345333856d24cd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
