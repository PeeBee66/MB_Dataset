
rule MB_9035d9d6
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:07.861127"
        sha256 = "9035d9d6a4da8b5d63873c23e2f2d61f0a31bf7f0a629c21588ad2a1051008d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
