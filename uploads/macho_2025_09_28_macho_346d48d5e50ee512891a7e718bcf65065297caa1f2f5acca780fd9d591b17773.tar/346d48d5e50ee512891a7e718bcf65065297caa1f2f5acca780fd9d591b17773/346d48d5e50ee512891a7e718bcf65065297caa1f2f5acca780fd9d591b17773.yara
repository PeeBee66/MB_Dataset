
rule MB_346d48d5
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:38.801678"
        sha256 = "346d48d5e50ee512891a7e718bcf65065297caa1f2f5acca780fd9d591b17773"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
