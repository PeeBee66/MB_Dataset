
rule MB_e9630dd6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:00:24.723135"
        sha256 = "e9630dd62cb4a53f759d620884205b2c6a1fec90cb65f2c34334488cc826ee9d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
