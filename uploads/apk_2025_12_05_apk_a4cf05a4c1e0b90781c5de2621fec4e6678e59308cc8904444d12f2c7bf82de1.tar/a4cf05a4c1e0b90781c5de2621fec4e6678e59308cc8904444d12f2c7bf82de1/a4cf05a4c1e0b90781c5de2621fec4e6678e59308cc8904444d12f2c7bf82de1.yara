
rule MB_a4cf05a4
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-12-04T23:01:18.858306"
        sha256 = "a4cf05a4c1e0b90781c5de2621fec4e6678e59308cc8904444d12f2c7bf82de1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
