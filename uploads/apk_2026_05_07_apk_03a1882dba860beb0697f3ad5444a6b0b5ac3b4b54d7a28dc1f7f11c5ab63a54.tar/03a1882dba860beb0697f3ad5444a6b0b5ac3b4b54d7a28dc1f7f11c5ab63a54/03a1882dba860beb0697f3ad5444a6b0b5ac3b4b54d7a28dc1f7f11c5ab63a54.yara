
rule MB_03a1882d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:54.068745"
        sha256 = "03a1882dba860beb0697f3ad5444a6b0b5ac3b4b54d7a28dc1f7f11c5ab63a54"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
