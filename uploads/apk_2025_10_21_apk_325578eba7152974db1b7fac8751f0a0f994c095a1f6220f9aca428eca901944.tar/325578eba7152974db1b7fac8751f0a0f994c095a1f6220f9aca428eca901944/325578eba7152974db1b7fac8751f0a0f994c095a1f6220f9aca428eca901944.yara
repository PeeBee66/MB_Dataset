
rule MB_325578eb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:37:38.864599"
        sha256 = "325578eba7152974db1b7fac8751f0a0f994c095a1f6220f9aca428eca901944"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
