
rule MB_164ffa8b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:19.325829"
        sha256 = "164ffa8bca5586591220839da10d14a669e4d2f61624ca287fb29f039aafba9e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
