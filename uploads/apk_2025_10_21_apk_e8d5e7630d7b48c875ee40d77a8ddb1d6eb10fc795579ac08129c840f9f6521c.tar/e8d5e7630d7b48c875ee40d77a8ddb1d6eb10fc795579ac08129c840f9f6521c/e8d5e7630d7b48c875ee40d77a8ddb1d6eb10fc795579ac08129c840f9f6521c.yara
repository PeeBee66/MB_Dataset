
rule MB_e8d5e763
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:08.895554"
        sha256 = "e8d5e7630d7b48c875ee40d77a8ddb1d6eb10fc795579ac08129c840f9f6521c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
