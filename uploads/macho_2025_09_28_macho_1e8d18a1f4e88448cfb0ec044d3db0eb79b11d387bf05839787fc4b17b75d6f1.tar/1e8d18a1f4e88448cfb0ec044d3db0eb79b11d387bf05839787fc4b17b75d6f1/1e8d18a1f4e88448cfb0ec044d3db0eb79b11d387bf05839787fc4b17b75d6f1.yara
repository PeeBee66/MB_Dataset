
rule MB_1e8d18a1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:19.674946"
        sha256 = "1e8d18a1f4e88448cfb0ec044d3db0eb79b11d387bf05839787fc4b17b75d6f1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
