
rule MB_85d8f504
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:01:25.691969"
        sha256 = "85d8f504cadb55851a393a13a026f1833ed6db32cb07882415e029e709ae0750"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
