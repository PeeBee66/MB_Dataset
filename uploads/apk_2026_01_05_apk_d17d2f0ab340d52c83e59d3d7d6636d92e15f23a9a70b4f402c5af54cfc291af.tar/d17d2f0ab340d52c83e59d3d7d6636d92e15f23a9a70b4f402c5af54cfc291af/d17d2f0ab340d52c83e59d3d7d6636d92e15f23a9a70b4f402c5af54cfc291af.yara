
rule MB_d17d2f0a
{
    meta:
        description = "Auto-generated rule for Anubis"
        author = "MB-Collector"
        date = "2026-01-04T23:00:26.617447"
        sha256 = "d17d2f0ab340d52c83e59d3d7d6636d92e15f23a9a70b4f402c5af54cfc291af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
