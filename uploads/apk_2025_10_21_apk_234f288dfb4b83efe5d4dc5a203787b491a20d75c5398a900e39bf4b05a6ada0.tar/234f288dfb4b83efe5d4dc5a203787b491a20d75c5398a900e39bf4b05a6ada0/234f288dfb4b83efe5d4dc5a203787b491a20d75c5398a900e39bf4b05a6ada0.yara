
rule MB_234f288d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:29:53.200010"
        sha256 = "234f288dfb4b83efe5d4dc5a203787b491a20d75c5398a900e39bf4b05a6ada0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
