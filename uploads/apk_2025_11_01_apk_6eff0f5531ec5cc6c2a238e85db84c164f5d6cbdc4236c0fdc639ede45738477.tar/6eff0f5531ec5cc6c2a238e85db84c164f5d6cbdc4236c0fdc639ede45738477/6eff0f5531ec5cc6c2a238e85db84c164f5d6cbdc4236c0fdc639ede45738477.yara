
rule MB_6eff0f55
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:18.222257"
        sha256 = "6eff0f5531ec5cc6c2a238e85db84c164f5d6cbdc4236c0fdc639ede45738477"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
