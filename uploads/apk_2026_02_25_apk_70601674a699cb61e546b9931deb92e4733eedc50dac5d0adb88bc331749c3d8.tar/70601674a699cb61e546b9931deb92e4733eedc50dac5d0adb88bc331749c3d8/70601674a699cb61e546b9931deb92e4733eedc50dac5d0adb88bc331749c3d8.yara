
rule MB_70601674
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-24T23:00:35.028841"
        sha256 = "70601674a699cb61e546b9931deb92e4733eedc50dac5d0adb88bc331749c3d8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
