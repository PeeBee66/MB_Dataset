
rule MB_e27579b9
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:09:18.202618"
        sha256 = "e27579b92fcad2f4fe96db7b5e7a7cdc41754a7cd126fcaf598d3f8d8c21c0f5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
