
rule MB_ddaa1d7e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:55.941394"
        sha256 = "ddaa1d7ef016ea2009267dfcfffe13129033e80c6a0bb38f6f1fc235cb96a237"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
