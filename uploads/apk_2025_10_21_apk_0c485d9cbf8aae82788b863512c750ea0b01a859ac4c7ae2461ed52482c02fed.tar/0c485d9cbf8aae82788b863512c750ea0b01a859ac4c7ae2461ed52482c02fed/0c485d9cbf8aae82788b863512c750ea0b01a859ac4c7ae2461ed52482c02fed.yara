
rule MB_0c485d9c
{
    meta:
        description = "Auto-generated rule for Ahmyth"
        author = "MB-Collector"
        date = "2025-10-20T11:16:14.391395"
        sha256 = "0c485d9cbf8aae82788b863512c750ea0b01a859ac4c7ae2461ed52482c02fed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
