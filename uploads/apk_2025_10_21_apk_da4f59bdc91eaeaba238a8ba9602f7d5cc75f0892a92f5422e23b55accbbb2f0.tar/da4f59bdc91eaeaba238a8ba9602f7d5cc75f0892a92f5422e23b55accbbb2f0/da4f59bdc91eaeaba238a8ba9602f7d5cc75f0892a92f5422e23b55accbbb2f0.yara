
rule MB_da4f59bd
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:10:58.867212"
        sha256 = "da4f59bdc91eaeaba238a8ba9602f7d5cc75f0892a92f5422e23b55accbbb2f0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
