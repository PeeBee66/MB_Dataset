
rule MB_44b5086d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:48.921127"
        sha256 = "44b5086d35b879afb9278392c230cdd0d16ac9b830cd44e75ece6ccf0fd4952c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
