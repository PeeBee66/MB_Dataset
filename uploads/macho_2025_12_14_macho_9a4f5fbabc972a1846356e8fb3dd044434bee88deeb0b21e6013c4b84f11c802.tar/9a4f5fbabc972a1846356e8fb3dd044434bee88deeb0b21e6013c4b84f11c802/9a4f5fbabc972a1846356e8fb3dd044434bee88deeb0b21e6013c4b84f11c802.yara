
rule MB_9a4f5fba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:58.426774"
        sha256 = "9a4f5fbabc972a1846356e8fb3dd044434bee88deeb0b21e6013c4b84f11c802"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
