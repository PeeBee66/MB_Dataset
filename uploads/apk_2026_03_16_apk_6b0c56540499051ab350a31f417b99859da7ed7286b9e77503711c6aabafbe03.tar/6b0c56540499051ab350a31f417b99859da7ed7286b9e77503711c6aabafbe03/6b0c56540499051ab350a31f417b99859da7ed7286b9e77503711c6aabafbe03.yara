
rule MB_6b0c5654
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:02:03.492455"
        sha256 = "6b0c56540499051ab350a31f417b99859da7ed7286b9e77503711c6aabafbe03"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
