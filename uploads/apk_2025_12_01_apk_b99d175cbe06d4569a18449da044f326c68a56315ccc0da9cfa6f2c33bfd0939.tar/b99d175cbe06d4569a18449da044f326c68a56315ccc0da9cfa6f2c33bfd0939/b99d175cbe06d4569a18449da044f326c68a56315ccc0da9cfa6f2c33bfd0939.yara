
rule MB_b99d175c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-30T23:00:44.578753"
        sha256 = "b99d175cbe06d4569a18449da044f326c68a56315ccc0da9cfa6f2c33bfd0939"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
