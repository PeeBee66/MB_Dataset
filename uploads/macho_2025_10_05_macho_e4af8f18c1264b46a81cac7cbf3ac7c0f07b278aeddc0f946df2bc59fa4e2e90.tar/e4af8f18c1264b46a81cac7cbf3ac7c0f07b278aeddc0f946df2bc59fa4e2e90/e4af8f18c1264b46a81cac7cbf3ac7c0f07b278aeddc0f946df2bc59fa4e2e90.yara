
rule MB_e4af8f18
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:14.447298"
        sha256 = "e4af8f18c1264b46a81cac7cbf3ac7c0f07b278aeddc0f946df2bc59fa4e2e90"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
