
rule MB_ec033c13
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-18T23:00:18.045979"
        sha256 = "ec033c13f06bcccb3d35b46c56003a60516339419ccc75a3738bbcf7f83e52b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
