
rule MB_d076268a
{
    meta:
        description = "Auto-generated rule for PromptSpy"
        author = "MB-Collector"
        date = "2026-02-19T23:00:24.019667"
        sha256 = "d076268a34eb62ba17aaf3cfb244998bd3a1a9a4c1ca98d21944d94da30f42a8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
