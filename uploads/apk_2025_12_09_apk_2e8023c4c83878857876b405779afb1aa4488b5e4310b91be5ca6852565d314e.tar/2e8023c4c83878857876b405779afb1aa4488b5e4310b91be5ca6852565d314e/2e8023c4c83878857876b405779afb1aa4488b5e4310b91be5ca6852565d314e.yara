
rule MB_2e8023c4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:15.335786"
        sha256 = "2e8023c4c83878857876b405779afb1aa4488b5e4310b91be5ca6852565d314e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
