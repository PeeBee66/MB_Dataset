
rule MB_de1d599d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:00:59.688440"
        sha256 = "de1d599dce6596fb6b5ed9aea4654e98e477877d6029e173a39a0dbd9db86f5c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
