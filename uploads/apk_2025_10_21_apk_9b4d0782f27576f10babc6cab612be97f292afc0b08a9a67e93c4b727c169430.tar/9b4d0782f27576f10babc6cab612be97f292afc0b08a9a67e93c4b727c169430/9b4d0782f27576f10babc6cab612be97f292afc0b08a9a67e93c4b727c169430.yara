
rule MB_9b4d0782
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:28:28.632317"
        sha256 = "9b4d0782f27576f10babc6cab612be97f292afc0b08a9a67e93c4b727c169430"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
