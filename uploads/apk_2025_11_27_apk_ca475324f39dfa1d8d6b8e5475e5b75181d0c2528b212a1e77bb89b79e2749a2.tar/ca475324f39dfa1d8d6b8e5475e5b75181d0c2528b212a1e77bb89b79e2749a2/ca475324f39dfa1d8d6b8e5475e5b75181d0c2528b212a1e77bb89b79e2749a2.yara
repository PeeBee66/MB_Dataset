
rule MB_ca475324
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:00:46.062118"
        sha256 = "ca475324f39dfa1d8d6b8e5475e5b75181d0c2528b212a1e77bb89b79e2749a2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
