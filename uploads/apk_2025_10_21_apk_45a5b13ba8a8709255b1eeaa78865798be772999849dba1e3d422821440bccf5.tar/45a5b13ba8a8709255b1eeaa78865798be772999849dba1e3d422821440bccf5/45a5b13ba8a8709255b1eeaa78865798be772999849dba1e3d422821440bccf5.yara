
rule MB_45a5b13b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:20.545121"
        sha256 = "45a5b13ba8a8709255b1eeaa78865798be772999849dba1e3d422821440bccf5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
