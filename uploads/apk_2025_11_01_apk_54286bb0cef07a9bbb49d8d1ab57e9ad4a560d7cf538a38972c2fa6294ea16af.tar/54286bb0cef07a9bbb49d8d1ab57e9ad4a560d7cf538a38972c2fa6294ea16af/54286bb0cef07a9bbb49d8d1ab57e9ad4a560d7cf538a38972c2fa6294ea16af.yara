
rule MB_54286bb0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:44.386539"
        sha256 = "54286bb0cef07a9bbb49d8d1ab57e9ad4a560d7cf538a38972c2fa6294ea16af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
