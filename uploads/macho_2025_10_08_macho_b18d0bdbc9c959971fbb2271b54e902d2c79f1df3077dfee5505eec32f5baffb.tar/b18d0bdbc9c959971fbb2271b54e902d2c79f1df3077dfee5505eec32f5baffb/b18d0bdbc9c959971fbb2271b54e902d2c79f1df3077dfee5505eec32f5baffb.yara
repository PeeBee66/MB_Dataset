
rule MB_b18d0bdb
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:12.024371"
        sha256 = "b18d0bdbc9c959971fbb2271b54e902d2c79f1df3077dfee5505eec32f5baffb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
