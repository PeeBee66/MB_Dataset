
rule MB_bea59ffd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:28.130500"
        sha256 = "bea59ffda9b0e4f6cb4842bac1ca1a16320631a8fec5a6ab0a9904f327cd0e0e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
