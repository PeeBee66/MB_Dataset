
rule MB_adeb8220
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-04T23:00:22.702078"
        sha256 = "adeb8220393a3d895f0991ee1663a677ee3fd906ad3e0702fabcb5c52507de3c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
