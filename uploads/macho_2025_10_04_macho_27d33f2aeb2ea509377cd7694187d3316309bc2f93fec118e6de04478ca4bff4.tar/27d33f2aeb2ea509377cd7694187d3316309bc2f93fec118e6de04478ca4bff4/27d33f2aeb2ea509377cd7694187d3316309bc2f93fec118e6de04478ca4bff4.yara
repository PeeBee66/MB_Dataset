
rule MB_27d33f2a
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:29.753403"
        sha256 = "27d33f2aeb2ea509377cd7694187d3316309bc2f93fec118e6de04478ca4bff4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
