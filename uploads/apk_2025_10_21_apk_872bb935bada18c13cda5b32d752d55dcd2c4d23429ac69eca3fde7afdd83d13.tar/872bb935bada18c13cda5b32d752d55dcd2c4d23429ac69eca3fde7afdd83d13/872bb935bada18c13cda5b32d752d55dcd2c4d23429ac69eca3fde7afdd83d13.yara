
rule MB_872bb935
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:04.154446"
        sha256 = "872bb935bada18c13cda5b32d752d55dcd2c4d23429ac69eca3fde7afdd83d13"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
