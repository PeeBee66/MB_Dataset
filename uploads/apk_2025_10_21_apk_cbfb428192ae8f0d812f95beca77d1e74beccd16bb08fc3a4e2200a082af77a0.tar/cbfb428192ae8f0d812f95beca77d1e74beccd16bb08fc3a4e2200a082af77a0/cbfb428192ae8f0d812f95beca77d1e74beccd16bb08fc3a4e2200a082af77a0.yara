
rule MB_cbfb4281
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:18.751323"
        sha256 = "cbfb428192ae8f0d812f95beca77d1e74beccd16bb08fc3a4e2200a082af77a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
