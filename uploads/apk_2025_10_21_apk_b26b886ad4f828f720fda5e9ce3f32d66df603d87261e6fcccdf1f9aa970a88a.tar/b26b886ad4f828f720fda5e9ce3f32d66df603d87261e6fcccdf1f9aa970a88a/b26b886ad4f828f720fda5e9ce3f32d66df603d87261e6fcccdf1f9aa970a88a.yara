
rule MB_b26b886a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:47:34.568067"
        sha256 = "b26b886ad4f828f720fda5e9ce3f32d66df603d87261e6fcccdf1f9aa970a88a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
