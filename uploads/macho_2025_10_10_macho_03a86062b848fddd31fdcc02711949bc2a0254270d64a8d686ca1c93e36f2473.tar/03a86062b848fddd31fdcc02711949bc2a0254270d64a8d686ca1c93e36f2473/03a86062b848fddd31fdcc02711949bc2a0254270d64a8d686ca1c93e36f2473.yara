
rule MB_03a86062
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:04.326379"
        sha256 = "03a86062b848fddd31fdcc02711949bc2a0254270d64a8d686ca1c93e36f2473"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
