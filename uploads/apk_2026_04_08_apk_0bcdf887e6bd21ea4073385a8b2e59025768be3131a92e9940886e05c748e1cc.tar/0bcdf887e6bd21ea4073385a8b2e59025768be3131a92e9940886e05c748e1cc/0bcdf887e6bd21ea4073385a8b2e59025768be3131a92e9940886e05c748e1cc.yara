
rule MB_0bcdf887
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-08T00:00:28.164421"
        sha256 = "0bcdf887e6bd21ea4073385a8b2e59025768be3131a92e9940886e05c748e1cc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
