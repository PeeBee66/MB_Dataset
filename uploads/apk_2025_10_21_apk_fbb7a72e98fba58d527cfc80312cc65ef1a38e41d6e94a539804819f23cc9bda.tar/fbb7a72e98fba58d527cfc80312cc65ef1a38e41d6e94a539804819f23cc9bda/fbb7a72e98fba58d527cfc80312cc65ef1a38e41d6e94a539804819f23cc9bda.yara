
rule MB_fbb7a72e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:31.110204"
        sha256 = "fbb7a72e98fba58d527cfc80312cc65ef1a38e41d6e94a539804819f23cc9bda"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
