
rule MB_c00e7394
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:00:22.385432"
        sha256 = "c00e739417750ad766dba107559427781ce2ef5f16dda255d48309a51e4c0248"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
