
rule MB_e4f16c25
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:29:05.942111"
        sha256 = "e4f16c2584f7d31b0a1720171e5e5b5b938d12b3728d83378f2af0c553e70307"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
