
rule MB_dbd4e7f1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:38.275074"
        sha256 = "dbd4e7f10579f00acfd714453ccecef4458769103633be4c88d4eb615c0741a7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
