
rule MB_47ae095f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:00:53.493411"
        sha256 = "47ae095fd9e5143798a70805a23eb294fc072170dac19c1fa112beca186d844a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
