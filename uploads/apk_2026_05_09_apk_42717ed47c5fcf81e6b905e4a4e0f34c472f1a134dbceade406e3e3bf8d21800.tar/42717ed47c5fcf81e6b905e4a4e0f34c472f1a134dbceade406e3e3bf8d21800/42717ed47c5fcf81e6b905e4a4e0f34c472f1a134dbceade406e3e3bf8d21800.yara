
rule MB_42717ed4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:09.274527"
        sha256 = "42717ed47c5fcf81e6b905e4a4e0f34c472f1a134dbceade406e3e3bf8d21800"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
