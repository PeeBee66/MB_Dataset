
rule MB_2a62c5a7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:42.169616"
        sha256 = "2a62c5a7eaf2ba4a52a49998771e1a62073f299d4dab5fff23a6e121d2641079"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
