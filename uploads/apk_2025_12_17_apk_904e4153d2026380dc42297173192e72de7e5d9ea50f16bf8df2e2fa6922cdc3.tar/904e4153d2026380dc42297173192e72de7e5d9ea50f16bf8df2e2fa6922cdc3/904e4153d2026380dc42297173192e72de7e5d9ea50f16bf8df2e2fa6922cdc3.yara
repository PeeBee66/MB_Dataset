
rule MB_904e4153
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-16T23:00:36.125112"
        sha256 = "904e4153d2026380dc42297173192e72de7e5d9ea50f16bf8df2e2fa6922cdc3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
