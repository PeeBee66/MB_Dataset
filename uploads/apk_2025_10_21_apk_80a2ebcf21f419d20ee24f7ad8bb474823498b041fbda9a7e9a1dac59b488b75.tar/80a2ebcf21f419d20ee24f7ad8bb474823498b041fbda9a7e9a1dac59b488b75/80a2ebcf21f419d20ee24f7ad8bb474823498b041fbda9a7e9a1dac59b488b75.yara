
rule MB_80a2ebcf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:53.860574"
        sha256 = "80a2ebcf21f419d20ee24f7ad8bb474823498b041fbda9a7e9a1dac59b488b75"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
