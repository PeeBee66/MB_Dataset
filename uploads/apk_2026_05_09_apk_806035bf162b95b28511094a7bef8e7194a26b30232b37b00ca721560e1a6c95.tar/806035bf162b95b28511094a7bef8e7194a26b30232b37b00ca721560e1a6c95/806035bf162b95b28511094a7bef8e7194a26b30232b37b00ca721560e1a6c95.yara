
rule MB_806035bf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:50.039268"
        sha256 = "806035bf162b95b28511094a7bef8e7194a26b30232b37b00ca721560e1a6c95"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
