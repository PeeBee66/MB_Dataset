
rule MB_e327a48b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:39.083788"
        sha256 = "e327a48be7c897ac84a3f6e3fcc577f2fdcac033ab13717c105ca3b9b8258082"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
