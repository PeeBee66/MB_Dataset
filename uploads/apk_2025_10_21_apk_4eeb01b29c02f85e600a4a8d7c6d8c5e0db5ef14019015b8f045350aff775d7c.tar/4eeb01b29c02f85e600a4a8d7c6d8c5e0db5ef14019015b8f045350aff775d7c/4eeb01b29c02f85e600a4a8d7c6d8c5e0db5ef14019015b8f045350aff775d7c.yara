
rule MB_4eeb01b2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:00.472364"
        sha256 = "4eeb01b29c02f85e600a4a8d7c6d8c5e0db5ef14019015b8f045350aff775d7c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
