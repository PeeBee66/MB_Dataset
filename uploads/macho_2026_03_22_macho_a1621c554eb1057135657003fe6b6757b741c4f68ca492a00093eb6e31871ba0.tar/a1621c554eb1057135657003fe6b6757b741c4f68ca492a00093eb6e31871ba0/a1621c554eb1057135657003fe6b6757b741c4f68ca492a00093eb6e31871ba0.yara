
rule MB_a1621c55
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:01:18.793367"
        sha256 = "a1621c554eb1057135657003fe6b6757b741c4f68ca492a00093eb6e31871ba0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
