
rule MB_957da224
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:19.895710"
        sha256 = "957da2245cf32478e9b9b9910bc16e3875e4d32fc7d16a4d745ef96b7a021914"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
