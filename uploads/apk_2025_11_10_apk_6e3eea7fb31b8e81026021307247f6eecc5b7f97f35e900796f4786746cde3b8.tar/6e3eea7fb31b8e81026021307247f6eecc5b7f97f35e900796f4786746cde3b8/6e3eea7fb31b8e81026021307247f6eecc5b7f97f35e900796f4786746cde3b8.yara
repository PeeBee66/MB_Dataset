
rule MB_6e3eea7f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:49.657666"
        sha256 = "6e3eea7fb31b8e81026021307247f6eecc5b7f97f35e900796f4786746cde3b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
