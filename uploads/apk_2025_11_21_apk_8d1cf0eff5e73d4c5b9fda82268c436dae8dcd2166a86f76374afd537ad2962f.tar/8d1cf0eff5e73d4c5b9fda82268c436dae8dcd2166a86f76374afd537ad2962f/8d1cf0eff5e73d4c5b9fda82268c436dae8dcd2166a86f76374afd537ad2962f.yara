
rule MB_8d1cf0ef
{
    meta:
        description = "Auto-generated rule for Datzbro"
        author = "MB-Collector"
        date = "2025-11-20T23:00:51.145651"
        sha256 = "8d1cf0eff5e73d4c5b9fda82268c436dae8dcd2166a86f76374afd537ad2962f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
