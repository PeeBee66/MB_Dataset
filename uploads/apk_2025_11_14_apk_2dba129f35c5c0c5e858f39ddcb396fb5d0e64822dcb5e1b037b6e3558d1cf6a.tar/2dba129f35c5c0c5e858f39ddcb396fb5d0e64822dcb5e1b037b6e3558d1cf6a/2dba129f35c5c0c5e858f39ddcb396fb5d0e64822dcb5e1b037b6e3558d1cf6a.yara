
rule MB_2dba129f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:34.028275"
        sha256 = "2dba129f35c5c0c5e858f39ddcb396fb5d0e64822dcb5e1b037b6e3558d1cf6a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
