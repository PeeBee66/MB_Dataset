
rule MB_e93ff09e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:11.842532"
        sha256 = "e93ff09ee9325d4b34f9cff330f1455ea013915c29d7323a7bac1bdffdb2e80d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
