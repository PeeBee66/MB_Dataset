
rule MB_cb147e7c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:23.509387"
        sha256 = "cb147e7ce69723523f604da875d78ca4738e5f416d2297910ee179a5067e79fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
