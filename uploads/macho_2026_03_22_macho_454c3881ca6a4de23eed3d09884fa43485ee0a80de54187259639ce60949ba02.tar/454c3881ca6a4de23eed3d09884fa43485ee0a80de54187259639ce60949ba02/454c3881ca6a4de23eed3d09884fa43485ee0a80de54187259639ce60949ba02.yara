
rule MB_454c3881
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:01:52.231399"
        sha256 = "454c3881ca6a4de23eed3d09884fa43485ee0a80de54187259639ce60949ba02"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
