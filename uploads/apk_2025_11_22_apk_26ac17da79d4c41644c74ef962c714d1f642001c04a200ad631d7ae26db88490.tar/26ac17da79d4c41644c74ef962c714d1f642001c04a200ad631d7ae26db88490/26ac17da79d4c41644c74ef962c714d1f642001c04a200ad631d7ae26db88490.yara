
rule MB_26ac17da
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:00:30.355325"
        sha256 = "26ac17da79d4c41644c74ef962c714d1f642001c04a200ad631d7ae26db88490"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
