
rule MB_d41a27ee
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-31T23:00:23.820034"
        sha256 = "d41a27ee5d4b12f6c94e73cc453c69b20ff92ce29823b0ff5bcc50c0d61f826e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
