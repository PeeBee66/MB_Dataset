
rule MB_bd8d876a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:02:03.893559"
        sha256 = "bd8d876a63c55a252a600f565c9ccc0f9d2375a0a341b84f5821b07d85f111de"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
