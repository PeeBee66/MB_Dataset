
rule MB_225835bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:49.355469"
        sha256 = "225835bb477eac973330d1d3c48ad14b2f081357817402595e0bcfcbe8ad8bca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
