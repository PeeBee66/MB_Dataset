
rule MB_1550a867
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-12-27T23:00:14.709043"
        sha256 = "1550a86714f756fa4342cb995d5a92f94c8409a59c1638528991dd0823068e79"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
