
rule MB_e2cfd142
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:28.467947"
        sha256 = "e2cfd14230a2b970f51b4e0ec5062a98591dadba2a05960ac8caa557384e6211"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
