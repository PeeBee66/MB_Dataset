
rule MB_cc295a67
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:24.357968"
        sha256 = "cc295a676a7f6b139c15946c895451cebbbeb82db47340ab523a013ea7efa4ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
