
rule MB_3ec27614
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-03T23:00:24.554826"
        sha256 = "3ec2761441202ccc6bc7f2628cafd9582ecd68af9350ac783212ad9d830dd66c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
