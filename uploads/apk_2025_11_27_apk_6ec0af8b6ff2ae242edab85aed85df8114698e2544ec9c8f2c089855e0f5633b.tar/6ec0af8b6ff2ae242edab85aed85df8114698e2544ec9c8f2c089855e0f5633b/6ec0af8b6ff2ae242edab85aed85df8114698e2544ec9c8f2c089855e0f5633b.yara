
rule MB_6ec0af8b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:01:25.144067"
        sha256 = "6ec0af8b6ff2ae242edab85aed85df8114698e2544ec9c8f2c089855e0f5633b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
