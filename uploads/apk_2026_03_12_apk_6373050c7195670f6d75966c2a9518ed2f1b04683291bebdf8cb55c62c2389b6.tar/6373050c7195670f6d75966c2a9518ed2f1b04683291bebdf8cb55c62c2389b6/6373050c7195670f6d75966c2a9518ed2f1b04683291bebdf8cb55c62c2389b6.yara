
rule MB_6373050c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-11T23:00:35.650084"
        sha256 = "6373050c7195670f6d75966c2a9518ed2f1b04683291bebdf8cb55c62c2389b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
