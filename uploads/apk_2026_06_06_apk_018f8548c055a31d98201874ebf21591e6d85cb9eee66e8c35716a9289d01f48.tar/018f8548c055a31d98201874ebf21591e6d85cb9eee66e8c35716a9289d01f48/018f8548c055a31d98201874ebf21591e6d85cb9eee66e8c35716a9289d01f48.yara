
rule MB_018f8548
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-06T00:00:14.442001"
        sha256 = "018f8548c055a31d98201874ebf21591e6d85cb9eee66e8c35716a9289d01f48"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
