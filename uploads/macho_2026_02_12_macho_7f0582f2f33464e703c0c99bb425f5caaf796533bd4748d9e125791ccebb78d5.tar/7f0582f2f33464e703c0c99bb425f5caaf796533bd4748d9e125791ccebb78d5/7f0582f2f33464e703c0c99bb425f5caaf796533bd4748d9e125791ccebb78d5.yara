
rule MB_7f0582f2
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:42.159981"
        sha256 = "7f0582f2f33464e703c0c99bb425f5caaf796533bd4748d9e125791ccebb78d5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
