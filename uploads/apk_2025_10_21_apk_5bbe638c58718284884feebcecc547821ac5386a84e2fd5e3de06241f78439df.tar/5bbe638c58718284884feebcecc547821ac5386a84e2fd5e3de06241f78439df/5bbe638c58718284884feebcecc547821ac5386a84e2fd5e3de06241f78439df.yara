
rule MB_5bbe638c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:13.905717"
        sha256 = "5bbe638c58718284884feebcecc547821ac5386a84e2fd5e3de06241f78439df"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
