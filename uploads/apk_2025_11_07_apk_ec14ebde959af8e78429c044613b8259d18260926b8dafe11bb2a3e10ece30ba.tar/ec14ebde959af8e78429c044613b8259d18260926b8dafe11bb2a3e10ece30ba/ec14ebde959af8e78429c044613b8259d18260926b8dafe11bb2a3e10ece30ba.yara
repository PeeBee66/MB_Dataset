
rule MB_ec14ebde
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:00:44.572116"
        sha256 = "ec14ebde959af8e78429c044613b8259d18260926b8dafe11bb2a3e10ece30ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
