
rule MB_f4a9564d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:26.582721"
        sha256 = "f4a9564ddd75c3d681499c77927a014dce917151e15ddeea41325954b9331fe4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
