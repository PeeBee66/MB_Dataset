
rule MB_ba71c7e5
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-31T23:00:26.095140"
        sha256 = "ba71c7e507e1b0d8202447f9f86f585286b4ab01b58c7e32bb4f495381ef5004"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
