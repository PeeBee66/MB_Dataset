
rule MB_db64f319
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:24.252343"
        sha256 = "db64f31937f624668b0a0c488aa3c5a85062a526ab76861d5d8d79122c1347c6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
