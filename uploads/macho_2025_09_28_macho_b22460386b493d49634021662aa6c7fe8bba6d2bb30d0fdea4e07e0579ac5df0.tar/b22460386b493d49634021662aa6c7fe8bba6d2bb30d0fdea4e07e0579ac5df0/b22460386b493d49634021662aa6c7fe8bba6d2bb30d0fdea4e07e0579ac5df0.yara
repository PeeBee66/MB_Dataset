
rule MB_b2246038
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:38.249166"
        sha256 = "b22460386b493d49634021662aa6c7fe8bba6d2bb30d0fdea4e07e0579ac5df0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
