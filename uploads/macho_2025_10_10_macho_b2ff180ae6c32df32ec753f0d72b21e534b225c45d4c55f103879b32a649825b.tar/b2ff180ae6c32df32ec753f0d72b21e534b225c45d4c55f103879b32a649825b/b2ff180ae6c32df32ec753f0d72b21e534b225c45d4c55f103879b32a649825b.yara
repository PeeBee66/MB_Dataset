
rule MB_b2ff180a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:33.263140"
        sha256 = "b2ff180ae6c32df32ec753f0d72b21e534b225c45d4c55f103879b32a649825b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
