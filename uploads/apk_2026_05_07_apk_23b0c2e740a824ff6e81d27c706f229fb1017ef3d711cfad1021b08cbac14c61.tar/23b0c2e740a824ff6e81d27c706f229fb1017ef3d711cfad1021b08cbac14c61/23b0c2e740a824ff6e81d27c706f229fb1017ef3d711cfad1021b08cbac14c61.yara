
rule MB_23b0c2e7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:07.003935"
        sha256 = "23b0c2e740a824ff6e81d27c706f229fb1017ef3d711cfad1021b08cbac14c61"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
