
rule MB_49efcc4f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:21.902601"
        sha256 = "49efcc4fb597c78b34da69a5ffd675fbf0aa25c1b3dd3284dc998a80d2317509"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
