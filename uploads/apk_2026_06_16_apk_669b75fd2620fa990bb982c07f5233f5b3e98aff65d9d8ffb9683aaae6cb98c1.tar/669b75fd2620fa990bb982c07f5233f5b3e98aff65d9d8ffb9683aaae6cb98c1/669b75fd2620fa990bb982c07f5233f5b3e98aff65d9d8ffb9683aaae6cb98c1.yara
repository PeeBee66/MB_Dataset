
rule MB_669b75fd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:58.303045"
        sha256 = "669b75fd2620fa990bb982c07f5233f5b3e98aff65d9d8ffb9683aaae6cb98c1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
