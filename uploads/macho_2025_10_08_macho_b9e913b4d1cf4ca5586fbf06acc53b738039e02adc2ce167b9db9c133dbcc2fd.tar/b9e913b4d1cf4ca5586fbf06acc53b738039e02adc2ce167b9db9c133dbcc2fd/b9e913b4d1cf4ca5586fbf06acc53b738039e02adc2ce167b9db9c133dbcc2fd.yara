
rule MB_b9e913b4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:57.683593"
        sha256 = "b9e913b4d1cf4ca5586fbf06acc53b738039e02adc2ce167b9db9c133dbcc2fd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
