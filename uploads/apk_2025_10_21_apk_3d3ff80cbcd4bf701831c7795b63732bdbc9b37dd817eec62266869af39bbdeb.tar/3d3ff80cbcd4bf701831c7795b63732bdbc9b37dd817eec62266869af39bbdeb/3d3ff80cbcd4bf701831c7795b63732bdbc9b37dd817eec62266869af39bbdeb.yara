
rule MB_3d3ff80c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:37:07.793789"
        sha256 = "3d3ff80cbcd4bf701831c7795b63732bdbc9b37dd817eec62266869af39bbdeb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
