
rule MB_bf06df82
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-05-09T00:04:47.444020"
        sha256 = "bf06df823a0a0b1b4618ee736f5f0bd508b315ea3c6b96a16d2a0d0e58906346"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
