
rule MB_8788fd79
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:39.785353"
        sha256 = "8788fd79a123e566f434293b7bf3ad3f5663bb4ed8b229e6f8ebc283cd8d4e1c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
