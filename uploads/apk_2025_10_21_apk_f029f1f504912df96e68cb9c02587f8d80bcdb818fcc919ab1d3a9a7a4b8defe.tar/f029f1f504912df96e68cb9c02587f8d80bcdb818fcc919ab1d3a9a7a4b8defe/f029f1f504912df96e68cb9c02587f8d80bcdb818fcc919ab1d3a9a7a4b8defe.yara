
rule MB_f029f1f5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:20.617580"
        sha256 = "f029f1f504912df96e68cb9c02587f8d80bcdb818fcc919ab1d3a9a7a4b8defe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
