
rule MB_64a92631
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-20T00:00:17.953280"
        sha256 = "64a9263148d49bbabaf13b68fc461c93275d5d7f852288ccf00d1b25e39069d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
