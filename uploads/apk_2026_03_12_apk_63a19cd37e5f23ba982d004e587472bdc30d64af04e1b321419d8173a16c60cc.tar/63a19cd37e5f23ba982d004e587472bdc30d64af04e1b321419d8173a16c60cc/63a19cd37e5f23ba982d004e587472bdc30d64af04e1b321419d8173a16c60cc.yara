
rule MB_63a19cd3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-11T23:00:16.599352"
        sha256 = "63a19cd37e5f23ba982d004e587472bdc30d64af04e1b321419d8173a16c60cc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
