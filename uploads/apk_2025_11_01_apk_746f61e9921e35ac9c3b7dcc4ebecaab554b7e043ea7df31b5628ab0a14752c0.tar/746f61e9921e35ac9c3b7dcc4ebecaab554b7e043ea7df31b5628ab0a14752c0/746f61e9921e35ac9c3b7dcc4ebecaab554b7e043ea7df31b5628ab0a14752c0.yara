
rule MB_746f61e9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:34.820347"
        sha256 = "746f61e9921e35ac9c3b7dcc4ebecaab554b7e043ea7df31b5628ab0a14752c0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
