
rule MB_666ed808
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:00:44.207105"
        sha256 = "666ed8080e6a23444c8be3691110c780742df286936a19cfc8b2b8c2288e2be1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
