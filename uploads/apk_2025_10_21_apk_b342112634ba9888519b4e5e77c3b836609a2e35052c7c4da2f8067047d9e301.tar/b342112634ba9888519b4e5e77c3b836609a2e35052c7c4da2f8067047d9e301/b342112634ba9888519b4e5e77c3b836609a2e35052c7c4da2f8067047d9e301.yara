
rule MB_b3421126
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:42.182112"
        sha256 = "b342112634ba9888519b4e5e77c3b836609a2e35052c7c4da2f8067047d9e301"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
