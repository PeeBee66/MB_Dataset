
rule MB_cbd1db1d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:06.240342"
        sha256 = "cbd1db1d117054fc747b0ce39a7ca8f260824c408a30d8a27ac36c8d0b6b18de"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
