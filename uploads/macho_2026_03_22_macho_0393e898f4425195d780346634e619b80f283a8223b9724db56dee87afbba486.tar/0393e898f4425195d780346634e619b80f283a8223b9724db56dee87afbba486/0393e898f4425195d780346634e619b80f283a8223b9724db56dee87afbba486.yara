
rule MB_0393e898
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:01:10.810148"
        sha256 = "0393e898f4425195d780346634e619b80f283a8223b9724db56dee87afbba486"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
