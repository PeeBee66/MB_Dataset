
rule MB_b3c86606
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:34.961042"
        sha256 = "b3c86606b1410cc558acef06d55c2a03d41ad85cb2b04e904640f58b23185db3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
