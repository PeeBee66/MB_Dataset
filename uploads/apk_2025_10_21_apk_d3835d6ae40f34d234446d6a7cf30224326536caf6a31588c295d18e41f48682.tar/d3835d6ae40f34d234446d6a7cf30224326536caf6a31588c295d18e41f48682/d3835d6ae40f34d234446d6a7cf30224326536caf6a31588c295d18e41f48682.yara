
rule MB_d3835d6a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:04.711849"
        sha256 = "d3835d6ae40f34d234446d6a7cf30224326536caf6a31588c295d18e41f48682"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
