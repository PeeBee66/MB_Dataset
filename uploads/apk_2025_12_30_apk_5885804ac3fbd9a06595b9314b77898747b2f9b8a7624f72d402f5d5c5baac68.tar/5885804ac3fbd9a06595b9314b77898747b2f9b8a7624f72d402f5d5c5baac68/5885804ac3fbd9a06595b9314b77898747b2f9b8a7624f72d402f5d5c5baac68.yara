
rule MB_5885804a
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-12-29T23:00:53.818954"
        sha256 = "5885804ac3fbd9a06595b9314b77898747b2f9b8a7624f72d402f5d5c5baac68"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
