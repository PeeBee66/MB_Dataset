
rule MB_7982c897
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:38.916731"
        sha256 = "7982c897c5bc8f3b31fc610b9cada477c8a8b66138aa5dba47ea6526152318ac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
