
rule MB_f4624068
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:41.298719"
        sha256 = "f4624068f4f20e06a151cecd5c093bec98170c89c4b7e61b920024af8b14cf02"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
