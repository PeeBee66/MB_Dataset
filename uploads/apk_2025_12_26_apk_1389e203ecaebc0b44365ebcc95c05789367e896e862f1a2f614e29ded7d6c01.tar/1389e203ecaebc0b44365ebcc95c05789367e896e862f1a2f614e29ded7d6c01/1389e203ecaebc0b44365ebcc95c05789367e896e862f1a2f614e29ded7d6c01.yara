
rule MB_1389e203
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-25T23:00:27.069188"
        sha256 = "1389e203ecaebc0b44365ebcc95c05789367e896e862f1a2f614e29ded7d6c01"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
