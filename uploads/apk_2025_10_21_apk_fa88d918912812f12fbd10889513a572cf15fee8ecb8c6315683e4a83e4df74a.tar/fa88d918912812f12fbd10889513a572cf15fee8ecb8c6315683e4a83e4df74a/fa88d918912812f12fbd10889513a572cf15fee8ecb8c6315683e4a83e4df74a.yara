
rule MB_fa88d918
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:54.566172"
        sha256 = "fa88d918912812f12fbd10889513a572cf15fee8ecb8c6315683e4a83e4df74a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
