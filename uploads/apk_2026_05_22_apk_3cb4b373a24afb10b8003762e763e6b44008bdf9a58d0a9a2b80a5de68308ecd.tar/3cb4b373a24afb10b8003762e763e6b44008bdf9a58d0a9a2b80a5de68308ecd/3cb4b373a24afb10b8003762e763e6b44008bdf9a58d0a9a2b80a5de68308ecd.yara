
rule MB_3cb4b373
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:17.365895"
        sha256 = "3cb4b373a24afb10b8003762e763e6b44008bdf9a58d0a9a2b80a5de68308ecd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
