
rule MB_ed3c5f91
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:14.928304"
        sha256 = "ed3c5f9175f6169296de0d7c1669dfea12b2b7143c8720c0649b3180dfd5c0bd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
