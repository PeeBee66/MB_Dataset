
rule MB_bc02322a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:15.724303"
        sha256 = "bc02322aaf96fa1841101636dc4c8011da3bcc5571a6f0278813884ce54b5b3f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
