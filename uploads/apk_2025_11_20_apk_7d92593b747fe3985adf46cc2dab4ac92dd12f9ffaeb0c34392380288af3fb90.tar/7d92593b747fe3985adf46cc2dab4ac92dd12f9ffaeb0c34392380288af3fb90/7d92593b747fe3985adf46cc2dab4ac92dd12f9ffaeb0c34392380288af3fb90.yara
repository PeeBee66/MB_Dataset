
rule MB_7d92593b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:01:13.560358"
        sha256 = "7d92593b747fe3985adf46cc2dab4ac92dd12f9ffaeb0c34392380288af3fb90"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
