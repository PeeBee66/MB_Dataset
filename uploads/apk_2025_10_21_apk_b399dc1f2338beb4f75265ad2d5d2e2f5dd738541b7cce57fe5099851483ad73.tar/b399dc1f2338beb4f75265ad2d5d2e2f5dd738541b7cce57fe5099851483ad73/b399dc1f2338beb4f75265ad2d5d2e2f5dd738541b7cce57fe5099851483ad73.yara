
rule MB_b399dc1f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:49.778203"
        sha256 = "b399dc1f2338beb4f75265ad2d5d2e2f5dd738541b7cce57fe5099851483ad73"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
