
rule MB_48aa566c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-25T00:01:02.555626"
        sha256 = "48aa566cea7a48a0951d7ba5efbe5b9ea0b0991a0a11fbc9ef19707bb1789fd7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
