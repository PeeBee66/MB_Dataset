
rule MB_6dbc6063
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:43.006974"
        sha256 = "6dbc6063e24d4273addf0f661b4bb275b18c39c11a0dbe7f662f4e523003eb2c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
