
rule MB_de2cf1f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:09.169232"
        sha256 = "de2cf1f6dc8c96cbfca5ac97628ad9068a161a863436d7bc0362f609bb2272db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
