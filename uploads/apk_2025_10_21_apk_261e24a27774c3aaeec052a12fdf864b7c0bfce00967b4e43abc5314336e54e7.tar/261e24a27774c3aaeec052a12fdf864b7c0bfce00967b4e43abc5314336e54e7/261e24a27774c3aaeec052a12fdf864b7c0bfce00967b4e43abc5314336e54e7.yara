
rule MB_261e24a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:09.375802"
        sha256 = "261e24a27774c3aaeec052a12fdf864b7c0bfce00967b4e43abc5314336e54e7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
