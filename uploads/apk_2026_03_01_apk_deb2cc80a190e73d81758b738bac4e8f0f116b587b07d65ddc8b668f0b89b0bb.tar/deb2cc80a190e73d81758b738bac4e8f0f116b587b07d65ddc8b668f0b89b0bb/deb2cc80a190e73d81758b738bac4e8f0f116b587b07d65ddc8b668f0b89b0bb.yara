
rule MB_deb2cc80
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-28T23:00:24.309824"
        sha256 = "deb2cc80a190e73d81758b738bac4e8f0f116b587b07d65ddc8b668f0b89b0bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
