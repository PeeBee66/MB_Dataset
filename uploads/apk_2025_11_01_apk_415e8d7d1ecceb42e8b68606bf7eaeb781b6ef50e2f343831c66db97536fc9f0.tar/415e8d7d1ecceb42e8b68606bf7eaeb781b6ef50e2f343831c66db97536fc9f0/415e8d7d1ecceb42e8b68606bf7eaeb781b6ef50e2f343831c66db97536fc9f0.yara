
rule MB_415e8d7d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:46.383076"
        sha256 = "415e8d7d1ecceb42e8b68606bf7eaeb781b6ef50e2f343831c66db97536fc9f0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
