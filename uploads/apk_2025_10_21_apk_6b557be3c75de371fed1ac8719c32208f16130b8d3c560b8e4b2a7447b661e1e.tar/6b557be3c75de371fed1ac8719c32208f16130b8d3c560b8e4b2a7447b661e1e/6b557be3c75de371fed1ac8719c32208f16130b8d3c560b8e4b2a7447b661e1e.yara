
rule MB_6b557be3
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:49:22.099324"
        sha256 = "6b557be3c75de371fed1ac8719c32208f16130b8d3c560b8e4b2a7447b661e1e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
