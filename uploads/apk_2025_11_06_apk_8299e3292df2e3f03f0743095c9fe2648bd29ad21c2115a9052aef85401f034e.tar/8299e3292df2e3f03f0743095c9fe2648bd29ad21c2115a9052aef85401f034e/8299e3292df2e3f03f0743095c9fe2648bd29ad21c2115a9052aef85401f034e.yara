
rule MB_8299e329
{
    meta:
        description = "Auto-generated rule for ClayRAT"
        author = "MB-Collector"
        date = "2025-11-05T23:00:17.291297"
        sha256 = "8299e3292df2e3f03f0743095c9fe2648bd29ad21c2115a9052aef85401f034e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
