
rule MB_d539ccf3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:30.677431"
        sha256 = "d539ccf3d622e91fe6e733a82bf43da4835ee9cd3ae08e8dc188248d2514c207"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
