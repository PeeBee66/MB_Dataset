
rule MB_e8f780e2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:55.146396"
        sha256 = "e8f780e2835e2a072b45219823b8c018a09c4971c754e10c264eac9eb04b884d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
