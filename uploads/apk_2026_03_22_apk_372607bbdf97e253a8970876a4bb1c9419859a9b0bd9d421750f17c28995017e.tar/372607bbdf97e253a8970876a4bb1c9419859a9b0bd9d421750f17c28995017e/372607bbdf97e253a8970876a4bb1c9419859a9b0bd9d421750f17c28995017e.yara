
rule MB_372607bb
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-21T23:00:18.080757"
        sha256 = "372607bbdf97e253a8970876a4bb1c9419859a9b0bd9d421750f17c28995017e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
