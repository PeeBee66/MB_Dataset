
rule MB_c8dcf4ee
{
    meta:
        description = "Auto-generated rule for Crocodilus"
        author = "MB-Collector"
        date = "2025-10-20T11:52:34.596202"
        sha256 = "c8dcf4ee90bbfbd52c182aa80974381871fbc2f9b34b4e81dbcc4eed9777212e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
