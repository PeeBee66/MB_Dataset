
rule MB_ced78925
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:00:42.946455"
        sha256 = "ced78925e9812c49be0a29bca1f03bcc4a6d7360faa965343737ce681c91003b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
