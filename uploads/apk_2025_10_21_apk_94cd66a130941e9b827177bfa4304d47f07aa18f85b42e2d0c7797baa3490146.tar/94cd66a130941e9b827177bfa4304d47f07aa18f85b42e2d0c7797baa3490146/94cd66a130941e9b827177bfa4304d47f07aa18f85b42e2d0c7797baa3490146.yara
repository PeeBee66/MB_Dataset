
rule MB_94cd66a1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:05.272193"
        sha256 = "94cd66a130941e9b827177bfa4304d47f07aa18f85b42e2d0c7797baa3490146"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
