
rule MB_30bae51e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:47.341696"
        sha256 = "30bae51ea96278d1f9ec292ad8034abb384b25ca98bb71f870d9174f94259aa1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
