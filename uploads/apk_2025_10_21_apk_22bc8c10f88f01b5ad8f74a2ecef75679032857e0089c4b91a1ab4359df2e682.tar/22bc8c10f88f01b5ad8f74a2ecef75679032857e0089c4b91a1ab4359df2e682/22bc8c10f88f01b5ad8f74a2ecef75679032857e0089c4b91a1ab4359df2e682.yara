
rule MB_22bc8c10
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:37:47.069035"
        sha256 = "22bc8c10f88f01b5ad8f74a2ecef75679032857e0089c4b91a1ab4359df2e682"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
