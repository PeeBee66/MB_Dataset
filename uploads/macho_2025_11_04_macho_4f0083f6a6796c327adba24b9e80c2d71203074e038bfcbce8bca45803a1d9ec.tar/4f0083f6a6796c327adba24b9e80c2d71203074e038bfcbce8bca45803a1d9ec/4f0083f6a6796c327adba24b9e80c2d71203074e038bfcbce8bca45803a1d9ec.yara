
rule MB_4f0083f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-03T23:00:51.385442"
        sha256 = "4f0083f6a6796c327adba24b9e80c2d71203074e038bfcbce8bca45803a1d9ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
