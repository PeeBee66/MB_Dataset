
rule MB_fe0b56ed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-16T23:00:13.744349"
        sha256 = "fe0b56ed55243e25dd8d7d4512aeed3a3981257e187a139549333868391fdac0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
