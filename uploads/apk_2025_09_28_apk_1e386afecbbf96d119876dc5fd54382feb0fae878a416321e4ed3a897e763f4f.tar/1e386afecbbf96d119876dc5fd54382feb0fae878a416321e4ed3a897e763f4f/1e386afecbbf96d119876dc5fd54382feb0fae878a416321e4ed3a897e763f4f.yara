
rule MB_1e386afe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:24.199833"
        sha256 = "1e386afecbbf96d119876dc5fd54382feb0fae878a416321e4ed3a897e763f4f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
