
rule MB_e45adf16
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:19.857497"
        sha256 = "e45adf165cc83b395fefa21009761bfd35b8a8dea47f51ffa25c191d578ac8cd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
