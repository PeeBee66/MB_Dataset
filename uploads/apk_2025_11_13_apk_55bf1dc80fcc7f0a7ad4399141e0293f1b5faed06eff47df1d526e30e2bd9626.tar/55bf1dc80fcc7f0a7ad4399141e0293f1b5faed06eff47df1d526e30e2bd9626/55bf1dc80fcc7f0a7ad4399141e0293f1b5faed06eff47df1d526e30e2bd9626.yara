
rule MB_55bf1dc8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:59.264285"
        sha256 = "55bf1dc80fcc7f0a7ad4399141e0293f1b5faed06eff47df1d526e30e2bd9626"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
