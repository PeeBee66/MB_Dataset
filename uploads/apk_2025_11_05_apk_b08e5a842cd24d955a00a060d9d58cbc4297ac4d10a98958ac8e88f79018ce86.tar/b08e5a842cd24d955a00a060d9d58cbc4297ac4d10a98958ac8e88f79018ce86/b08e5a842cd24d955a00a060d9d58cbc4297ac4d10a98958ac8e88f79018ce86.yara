
rule MB_b08e5a84
{
    meta:
        description = "Auto-generated rule for ClayRAT"
        author = "MB-Collector"
        date = "2025-11-04T23:00:34.620833"
        sha256 = "b08e5a842cd24d955a00a060d9d58cbc4297ac4d10a98958ac8e88f79018ce86"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
