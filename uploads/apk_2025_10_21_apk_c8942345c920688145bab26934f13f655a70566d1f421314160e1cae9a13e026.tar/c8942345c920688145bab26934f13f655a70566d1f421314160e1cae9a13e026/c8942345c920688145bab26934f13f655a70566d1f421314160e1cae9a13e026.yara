
rule MB_c8942345
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:33.123532"
        sha256 = "c8942345c920688145bab26934f13f655a70566d1f421314160e1cae9a13e026"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
