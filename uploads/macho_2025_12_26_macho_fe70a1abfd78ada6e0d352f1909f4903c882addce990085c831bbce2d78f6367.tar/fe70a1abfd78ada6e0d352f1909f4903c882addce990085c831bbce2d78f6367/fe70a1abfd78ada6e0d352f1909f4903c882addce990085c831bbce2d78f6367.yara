
rule MB_fe70a1ab
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-12-25T23:00:34.318408"
        sha256 = "fe70a1abfd78ada6e0d352f1909f4903c882addce990085c831bbce2d78f6367"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
