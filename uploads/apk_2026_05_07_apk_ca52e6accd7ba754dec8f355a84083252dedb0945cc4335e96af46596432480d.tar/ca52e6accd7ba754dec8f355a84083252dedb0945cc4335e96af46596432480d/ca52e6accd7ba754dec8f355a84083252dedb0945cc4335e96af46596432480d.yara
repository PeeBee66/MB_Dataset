
rule MB_ca52e6ac
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:25.169999"
        sha256 = "ca52e6accd7ba754dec8f355a84083252dedb0945cc4335e96af46596432480d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
