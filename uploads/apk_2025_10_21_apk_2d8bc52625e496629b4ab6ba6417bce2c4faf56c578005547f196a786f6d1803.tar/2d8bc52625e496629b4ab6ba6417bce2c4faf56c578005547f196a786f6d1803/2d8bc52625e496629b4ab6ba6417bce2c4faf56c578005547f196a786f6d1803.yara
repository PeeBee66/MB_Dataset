
rule MB_2d8bc526
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:53.627842"
        sha256 = "2d8bc52625e496629b4ab6ba6417bce2c4faf56c578005547f196a786f6d1803"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
