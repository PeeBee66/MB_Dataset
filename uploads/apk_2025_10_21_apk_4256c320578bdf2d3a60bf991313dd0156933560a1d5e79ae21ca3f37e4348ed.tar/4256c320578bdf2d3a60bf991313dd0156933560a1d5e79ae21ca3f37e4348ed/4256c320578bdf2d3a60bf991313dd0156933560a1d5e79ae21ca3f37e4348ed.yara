
rule MB_4256c320
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T11:05:37.548346"
        sha256 = "4256c320578bdf2d3a60bf991313dd0156933560a1d5e79ae21ca3f37e4348ed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
