
rule MB_e93d2128
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:01:09.523849"
        sha256 = "e93d21282e2da4cd478c2db2ff11f7d929a2f2c41136bd70d554107437cd49bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
