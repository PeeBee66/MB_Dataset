
rule MB_73651902
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-07T00:00:20.677076"
        sha256 = "7365190230042fa2f8aba13d39cfecaa52b029750331760bcd114bafb01cb6db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
