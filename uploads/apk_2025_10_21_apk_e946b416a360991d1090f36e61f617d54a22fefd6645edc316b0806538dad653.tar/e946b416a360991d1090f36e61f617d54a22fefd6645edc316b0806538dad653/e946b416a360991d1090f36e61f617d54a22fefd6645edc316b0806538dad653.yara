
rule MB_e946b416
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:06:00.233794"
        sha256 = "e946b416a360991d1090f36e61f617d54a22fefd6645edc316b0806538dad653"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
