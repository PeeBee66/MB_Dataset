
rule MB_614ee90d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:27.553366"
        sha256 = "614ee90dc91a1bf0f45552b97c99e33d6830f320e5a09c7182eddcb09277f1d6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
