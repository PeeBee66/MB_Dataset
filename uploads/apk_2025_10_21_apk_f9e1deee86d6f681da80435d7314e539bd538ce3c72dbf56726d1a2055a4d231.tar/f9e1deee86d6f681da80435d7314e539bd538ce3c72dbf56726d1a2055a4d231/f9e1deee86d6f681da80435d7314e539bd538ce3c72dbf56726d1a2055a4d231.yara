
rule MB_f9e1deee
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:52:57.073964"
        sha256 = "f9e1deee86d6f681da80435d7314e539bd538ce3c72dbf56726d1a2055a4d231"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
