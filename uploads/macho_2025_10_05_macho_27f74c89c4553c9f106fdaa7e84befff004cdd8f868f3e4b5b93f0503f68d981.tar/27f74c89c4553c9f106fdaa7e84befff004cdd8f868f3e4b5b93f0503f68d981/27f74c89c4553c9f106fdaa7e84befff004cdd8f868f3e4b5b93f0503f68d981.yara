
rule MB_27f74c89
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:05.419274"
        sha256 = "27f74c89c4553c9f106fdaa7e84befff004cdd8f868f3e4b5b93f0503f68d981"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
