
rule MB_479e9dcc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:57.656148"
        sha256 = "479e9dccf1f3184c4e5c4a9a3ec393dd5eb0cdc6b0bf069ecb47763f2e14af82"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
