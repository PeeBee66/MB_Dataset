
rule MB_7b167d36
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-09T23:00:33.338893"
        sha256 = "7b167d362a9282adb176095be2e5bd4692b4158b7bdf4c6c20870daed5b04665"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
