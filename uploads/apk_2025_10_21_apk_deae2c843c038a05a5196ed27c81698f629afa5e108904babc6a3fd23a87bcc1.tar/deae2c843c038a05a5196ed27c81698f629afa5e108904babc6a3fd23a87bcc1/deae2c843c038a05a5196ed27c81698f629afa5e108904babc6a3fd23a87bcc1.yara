
rule MB_deae2c84
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:28:33.239610"
        sha256 = "deae2c843c038a05a5196ed27c81698f629afa5e108904babc6a3fd23a87bcc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
