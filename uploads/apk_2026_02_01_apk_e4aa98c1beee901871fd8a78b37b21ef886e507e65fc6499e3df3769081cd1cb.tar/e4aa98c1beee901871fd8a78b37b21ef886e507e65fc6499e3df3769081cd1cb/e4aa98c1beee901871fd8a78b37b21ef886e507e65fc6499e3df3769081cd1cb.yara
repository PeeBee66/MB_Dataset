
rule MB_e4aa98c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-31T23:00:17.161510"
        sha256 = "e4aa98c1beee901871fd8a78b37b21ef886e507e65fc6499e3df3769081cd1cb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
