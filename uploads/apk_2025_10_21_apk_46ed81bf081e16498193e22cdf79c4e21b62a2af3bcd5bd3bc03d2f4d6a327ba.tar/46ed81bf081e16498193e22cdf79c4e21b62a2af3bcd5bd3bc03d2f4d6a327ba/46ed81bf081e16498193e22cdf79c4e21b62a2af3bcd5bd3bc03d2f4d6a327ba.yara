
rule MB_46ed81bf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:48.874088"
        sha256 = "46ed81bf081e16498193e22cdf79c4e21b62a2af3bcd5bd3bc03d2f4d6a327ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
