
rule MB_1ba56b3e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:22.452417"
        sha256 = "1ba56b3ec2cee4c46d23f7d2fc960fa0a384fb2d71702823fd508478b452114c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
