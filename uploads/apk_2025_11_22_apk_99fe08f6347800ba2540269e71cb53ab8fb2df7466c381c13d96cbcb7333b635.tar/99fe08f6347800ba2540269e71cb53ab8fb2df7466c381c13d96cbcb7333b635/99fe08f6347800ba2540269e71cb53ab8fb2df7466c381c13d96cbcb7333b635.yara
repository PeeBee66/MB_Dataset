
rule MB_99fe08f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:00:49.843736"
        sha256 = "99fe08f6347800ba2540269e71cb53ab8fb2df7466c381c13d96cbcb7333b635"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
