
rule MB_d92b99f1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:58.492413"
        sha256 = "d92b99f1f08b5c557ec9e04cb7712d2f81c300714a81b21573dce7f8b6df0c23"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
