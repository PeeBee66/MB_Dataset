
rule MB_30d70377
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:19.194206"
        sha256 = "30d703770a97a1ad5f54719c1986f0faf3b2875807fe5d8cf8e9308ba4ba5990"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
