
rule MB_8360ffa4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:53.734792"
        sha256 = "8360ffa40cf66d481b18c65b5172af4aec2cd4e7cd97d3b93a00241417761e8f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
