
rule MB_153279a6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:21.771092"
        sha256 = "153279a6d6d3633df1ec425b9532ff3b525a0b955536fc5ca2a0e49ea3563064"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
