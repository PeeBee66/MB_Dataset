
rule MB_b11f1a15
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:37.916805"
        sha256 = "b11f1a152ae645946926bd251e6153ca1c7e15dbb87e379b6238081b6c92143f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
