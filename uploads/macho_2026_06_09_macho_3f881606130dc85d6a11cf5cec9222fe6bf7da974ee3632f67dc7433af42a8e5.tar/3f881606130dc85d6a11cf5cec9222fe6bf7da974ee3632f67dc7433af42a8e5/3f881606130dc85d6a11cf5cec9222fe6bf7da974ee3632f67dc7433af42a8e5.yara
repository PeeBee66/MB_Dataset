
rule MB_3f881606
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-09T00:00:52.756791"
        sha256 = "3f881606130dc85d6a11cf5cec9222fe6bf7da974ee3632f67dc7433af42a8e5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
