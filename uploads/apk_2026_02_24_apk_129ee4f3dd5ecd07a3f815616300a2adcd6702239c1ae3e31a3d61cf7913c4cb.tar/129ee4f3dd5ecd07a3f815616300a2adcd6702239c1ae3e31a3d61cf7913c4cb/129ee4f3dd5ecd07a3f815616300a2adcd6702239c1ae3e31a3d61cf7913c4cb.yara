
rule MB_129ee4f3
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:24.274698"
        sha256 = "129ee4f3dd5ecd07a3f815616300a2adcd6702239c1ae3e31a3d61cf7913c4cb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
