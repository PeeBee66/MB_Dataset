
rule MB_67a50b51
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:00:50.655677"
        sha256 = "67a50b514fe97e33015569e0d93b024b6ecc4700c6f92b17f2c128cf332a7004"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
