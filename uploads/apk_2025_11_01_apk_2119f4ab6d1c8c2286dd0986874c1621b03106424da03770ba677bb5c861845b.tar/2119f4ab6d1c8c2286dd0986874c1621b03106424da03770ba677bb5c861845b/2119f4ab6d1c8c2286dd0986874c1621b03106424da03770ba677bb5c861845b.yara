
rule MB_2119f4ab
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:20.897643"
        sha256 = "2119f4ab6d1c8c2286dd0986874c1621b03106424da03770ba677bb5c861845b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
