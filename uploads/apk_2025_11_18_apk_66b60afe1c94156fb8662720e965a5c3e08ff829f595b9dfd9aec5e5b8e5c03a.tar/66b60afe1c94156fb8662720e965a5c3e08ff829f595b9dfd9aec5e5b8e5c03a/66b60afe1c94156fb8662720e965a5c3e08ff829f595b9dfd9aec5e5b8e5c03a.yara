
rule MB_66b60afe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:27.286631"
        sha256 = "66b60afe1c94156fb8662720e965a5c3e08ff829f595b9dfd9aec5e5b8e5c03a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
