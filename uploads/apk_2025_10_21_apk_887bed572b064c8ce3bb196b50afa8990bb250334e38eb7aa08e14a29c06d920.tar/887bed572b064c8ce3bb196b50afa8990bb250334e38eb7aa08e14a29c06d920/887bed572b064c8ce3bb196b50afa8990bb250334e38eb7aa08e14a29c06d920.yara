
rule MB_887bed57
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:11:32.904658"
        sha256 = "887bed572b064c8ce3bb196b50afa8990bb250334e38eb7aa08e14a29c06d920"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
