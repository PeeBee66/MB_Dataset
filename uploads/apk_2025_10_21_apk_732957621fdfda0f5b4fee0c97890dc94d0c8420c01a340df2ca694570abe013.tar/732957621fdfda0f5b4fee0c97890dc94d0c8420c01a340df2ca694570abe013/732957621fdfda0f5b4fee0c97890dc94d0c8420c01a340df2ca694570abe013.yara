
rule MB_73295762
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:03.866502"
        sha256 = "732957621fdfda0f5b4fee0c97890dc94d0c8420c01a340df2ca694570abe013"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
