
rule MB_a67be79b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:42.167448"
        sha256 = "a67be79ba8a6d22b39921cfd16c5be8e037271f617849a61c5c7adc73006fa97"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
