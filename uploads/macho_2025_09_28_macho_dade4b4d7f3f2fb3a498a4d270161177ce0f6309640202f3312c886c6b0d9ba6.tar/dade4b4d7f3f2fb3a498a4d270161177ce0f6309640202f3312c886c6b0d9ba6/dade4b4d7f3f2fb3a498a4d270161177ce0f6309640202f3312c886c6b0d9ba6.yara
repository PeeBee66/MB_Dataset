
rule MB_dade4b4d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:40.251486"
        sha256 = "dade4b4d7f3f2fb3a498a4d270161177ce0f6309640202f3312c886c6b0d9ba6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
