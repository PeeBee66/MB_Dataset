
rule MB_5c9f0295
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:54.623461"
        sha256 = "5c9f0295246648725cf6c9d05de63fc823978ef73baf78c6193803f76d90f0d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
