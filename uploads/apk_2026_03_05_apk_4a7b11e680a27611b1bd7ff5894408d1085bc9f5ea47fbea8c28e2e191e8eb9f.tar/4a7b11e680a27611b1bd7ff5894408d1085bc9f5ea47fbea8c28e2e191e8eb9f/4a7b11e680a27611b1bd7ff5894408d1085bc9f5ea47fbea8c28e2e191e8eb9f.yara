
rule MB_4a7b11e6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:23.487188"
        sha256 = "4a7b11e680a27611b1bd7ff5894408d1085bc9f5ea47fbea8c28e2e191e8eb9f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
