
rule MB_ff7f0c39
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-21T23:00:37.484822"
        sha256 = "ff7f0c39aa90ed8f4ce24658a347e7871bb5f6a607eaedf2cf2859a1fb5782a9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
