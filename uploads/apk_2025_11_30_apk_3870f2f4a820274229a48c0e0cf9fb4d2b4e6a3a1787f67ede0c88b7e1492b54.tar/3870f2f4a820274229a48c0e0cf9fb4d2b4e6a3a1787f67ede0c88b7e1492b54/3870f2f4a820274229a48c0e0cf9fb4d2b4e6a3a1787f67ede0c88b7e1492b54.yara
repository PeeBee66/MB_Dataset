
rule MB_3870f2f4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:42.547295"
        sha256 = "3870f2f4a820274229a48c0e0cf9fb4d2b4e6a3a1787f67ede0c88b7e1492b54"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
