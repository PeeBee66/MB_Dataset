
rule MB_e4d9c44d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:08.547503"
        sha256 = "e4d9c44d7a2577a8a0a241923d7d74cbd66ad8a8c2ce62b13ceee576d6977acd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
