
rule MB_da986b5d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-03T23:00:28.552439"
        sha256 = "da986b5d8520091c9e9afac6ddd00ef19fc302a378ce9b0e5414c0b2047312a1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
