
rule MB_958fe0ad
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-10T23:00:13.883504"
        sha256 = "958fe0ad35fd2e1574e458084e26d790c57356cbcc13057855e36b71b00c4198"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
