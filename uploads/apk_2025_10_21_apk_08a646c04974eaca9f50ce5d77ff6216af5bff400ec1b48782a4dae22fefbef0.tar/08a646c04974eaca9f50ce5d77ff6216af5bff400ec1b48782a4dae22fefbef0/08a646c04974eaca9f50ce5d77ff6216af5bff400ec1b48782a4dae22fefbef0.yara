
rule MB_08a646c0
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:47:42.185761"
        sha256 = "08a646c04974eaca9f50ce5d77ff6216af5bff400ec1b48782a4dae22fefbef0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
