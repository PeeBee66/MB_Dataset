
rule MB_7748ca5b
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:17:56.773816"
        sha256 = "7748ca5b385db3fda3e07000b1552ca05405333083b33c4f470dd3ae4f0e3a5f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
