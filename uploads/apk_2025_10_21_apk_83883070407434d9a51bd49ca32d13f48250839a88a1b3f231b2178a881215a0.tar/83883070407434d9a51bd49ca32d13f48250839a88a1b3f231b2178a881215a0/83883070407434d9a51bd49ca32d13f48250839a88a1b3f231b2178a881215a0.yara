
rule MB_83883070
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:26.134780"
        sha256 = "83883070407434d9a51bd49ca32d13f48250839a88a1b3f231b2178a881215a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
