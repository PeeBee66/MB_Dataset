
rule MB_7f2505b9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:12.484313"
        sha256 = "7f2505b9149129fed29e28003dac3b8ab5e6e9d8d71489ea3c89bb2a1c810139"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
