
rule MB_261305cc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:02:23.344875"
        sha256 = "261305ccbee49fc67c13d275e5788fdc3db8b6a85ec99de16130be93130bcb19"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
