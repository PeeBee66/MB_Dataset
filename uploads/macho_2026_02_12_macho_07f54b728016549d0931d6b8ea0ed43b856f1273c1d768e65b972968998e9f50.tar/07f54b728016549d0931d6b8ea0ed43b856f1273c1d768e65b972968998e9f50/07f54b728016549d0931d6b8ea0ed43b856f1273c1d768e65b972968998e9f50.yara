
rule MB_07f54b72
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:43.660688"
        sha256 = "07f54b728016549d0931d6b8ea0ed43b856f1273c1d768e65b972968998e9f50"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
