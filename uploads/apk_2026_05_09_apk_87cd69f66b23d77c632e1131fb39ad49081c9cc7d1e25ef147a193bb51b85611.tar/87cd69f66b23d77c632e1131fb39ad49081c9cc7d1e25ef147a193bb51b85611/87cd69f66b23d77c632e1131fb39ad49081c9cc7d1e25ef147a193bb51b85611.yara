
rule MB_87cd69f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:33.068205"
        sha256 = "87cd69f66b23d77c632e1131fb39ad49081c9cc7d1e25ef147a193bb51b85611"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
