
rule MB_670ea448
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-15T23:00:31.513221"
        sha256 = "670ea4487f9bfdfa4dba45eb5373f2c4202db54e21d237725ad4432903c07364"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
