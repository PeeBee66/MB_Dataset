
rule MB_5fbbca2d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:41.571681"
        sha256 = "5fbbca2d72840feb86b6ef8a1abb4fe2f225d84228a714391673be2719c73ac7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
