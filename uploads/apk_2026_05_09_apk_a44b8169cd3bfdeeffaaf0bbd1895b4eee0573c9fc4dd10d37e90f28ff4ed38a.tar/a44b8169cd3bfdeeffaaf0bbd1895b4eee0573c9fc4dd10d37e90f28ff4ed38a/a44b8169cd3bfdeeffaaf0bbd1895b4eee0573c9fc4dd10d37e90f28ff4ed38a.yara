
rule MB_a44b8169
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:39.377950"
        sha256 = "a44b8169cd3bfdeeffaaf0bbd1895b4eee0573c9fc4dd10d37e90f28ff4ed38a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
