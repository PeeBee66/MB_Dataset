
rule MB_0cec2323
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:51.734202"
        sha256 = "0cec2323ab036866f453110ca1497f4f7329d5e787d52209dcf82dfc2ea03cf8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
