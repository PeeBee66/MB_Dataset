
rule MB_1f2290b1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:34.742753"
        sha256 = "1f2290b11e9216a21dacbb720db2ef924c224f0f55af8ed74a3e63a61e0c02fc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
