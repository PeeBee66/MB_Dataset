
rule MB_bd9e2e06
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:13.759877"
        sha256 = "bd9e2e06b9816ca1e432f89dab95dde143d27e07d79c959aad13c2415809fbe1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
