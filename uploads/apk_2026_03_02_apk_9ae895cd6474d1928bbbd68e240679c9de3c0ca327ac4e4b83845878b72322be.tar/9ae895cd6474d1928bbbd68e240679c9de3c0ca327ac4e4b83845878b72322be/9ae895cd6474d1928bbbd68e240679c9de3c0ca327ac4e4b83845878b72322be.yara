
rule MB_9ae895cd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-01T23:00:18.513528"
        sha256 = "9ae895cd6474d1928bbbd68e240679c9de3c0ca327ac4e4b83845878b72322be"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
