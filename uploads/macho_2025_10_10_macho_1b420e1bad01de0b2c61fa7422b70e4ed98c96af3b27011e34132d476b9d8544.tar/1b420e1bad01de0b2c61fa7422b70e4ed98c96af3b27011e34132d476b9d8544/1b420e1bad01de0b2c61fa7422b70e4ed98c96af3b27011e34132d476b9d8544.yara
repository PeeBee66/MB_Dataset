
rule MB_1b420e1b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:02:00.063814"
        sha256 = "1b420e1bad01de0b2c61fa7422b70e4ed98c96af3b27011e34132d476b9d8544"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
