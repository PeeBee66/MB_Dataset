
rule MB_85f9dcf4
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:17:22.598216"
        sha256 = "85f9dcf4e31a43ac871c044ae1c209dc26ef2499a02edfe7225b885e0c312036"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
