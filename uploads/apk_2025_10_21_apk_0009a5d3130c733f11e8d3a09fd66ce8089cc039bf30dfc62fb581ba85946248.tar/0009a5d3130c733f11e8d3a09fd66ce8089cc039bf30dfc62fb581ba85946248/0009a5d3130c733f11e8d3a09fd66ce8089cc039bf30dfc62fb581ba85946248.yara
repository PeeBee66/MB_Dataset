
rule MB_0009a5d3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:25.806099"
        sha256 = "0009a5d3130c733f11e8d3a09fd66ce8089cc039bf30dfc62fb581ba85946248"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
