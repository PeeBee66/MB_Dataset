
rule MB_8ef62bef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:01:17.194263"
        sha256 = "8ef62bef2f33e486fe2a962a863dc2f621dd2369f24398817e9c4795f970c012"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
