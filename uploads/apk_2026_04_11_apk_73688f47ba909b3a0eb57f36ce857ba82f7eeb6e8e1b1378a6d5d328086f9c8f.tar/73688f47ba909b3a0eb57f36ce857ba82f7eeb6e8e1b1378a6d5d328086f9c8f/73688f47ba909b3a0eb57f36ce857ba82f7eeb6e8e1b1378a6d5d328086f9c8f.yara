
rule MB_73688f47
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:01:11.937104"
        sha256 = "73688f47ba909b3a0eb57f36ce857ba82f7eeb6e8e1b1378a6d5d328086f9c8f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
