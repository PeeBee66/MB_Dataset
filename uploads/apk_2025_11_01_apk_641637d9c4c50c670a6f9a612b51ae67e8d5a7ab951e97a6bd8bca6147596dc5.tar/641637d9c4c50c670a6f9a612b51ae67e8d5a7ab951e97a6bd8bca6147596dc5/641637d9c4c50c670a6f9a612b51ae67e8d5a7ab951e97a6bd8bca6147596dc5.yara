
rule MB_641637d9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:23.087007"
        sha256 = "641637d9c4c50c670a6f9a612b51ae67e8d5a7ab951e97a6bd8bca6147596dc5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
