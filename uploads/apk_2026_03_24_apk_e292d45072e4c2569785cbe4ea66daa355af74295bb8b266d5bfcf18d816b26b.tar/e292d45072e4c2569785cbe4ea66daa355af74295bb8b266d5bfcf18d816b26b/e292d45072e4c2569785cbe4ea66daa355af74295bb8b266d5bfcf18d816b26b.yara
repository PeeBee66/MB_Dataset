
rule MB_e292d450
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-23T23:00:30.542196"
        sha256 = "e292d45072e4c2569785cbe4ea66daa355af74295bb8b266d5bfcf18d816b26b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
