
rule MB_6399d775
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:17.435118"
        sha256 = "6399d775a1ef86e7b090630e49aefbe842c94fa925221420a743eb82aa46afa8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
