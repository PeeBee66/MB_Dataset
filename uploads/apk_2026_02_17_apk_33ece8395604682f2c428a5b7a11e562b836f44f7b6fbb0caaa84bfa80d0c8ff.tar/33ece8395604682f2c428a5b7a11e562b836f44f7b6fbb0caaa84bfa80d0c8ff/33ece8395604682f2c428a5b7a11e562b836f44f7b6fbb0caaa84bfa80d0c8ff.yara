
rule MB_33ece839
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2026-02-16T23:00:19.634783"
        sha256 = "33ece8395604682f2c428a5b7a11e562b836f44f7b6fbb0caaa84bfa80d0c8ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
