
rule MB_0fad716d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:11.666127"
        sha256 = "0fad716dfb636e95feaf6b54f018d3b3337542970da77f7ef63de473fceaaf96"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
