
rule MB_0245f09e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:15.849169"
        sha256 = "0245f09eaaf22ed607f02e845f78619d037221d04024c02ae92d6944c627981a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
