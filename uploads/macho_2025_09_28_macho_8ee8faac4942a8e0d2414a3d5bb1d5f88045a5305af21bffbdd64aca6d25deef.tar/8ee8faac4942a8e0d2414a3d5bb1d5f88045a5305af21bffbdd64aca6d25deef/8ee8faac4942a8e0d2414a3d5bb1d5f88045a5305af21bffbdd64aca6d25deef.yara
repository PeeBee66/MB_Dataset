
rule MB_8ee8faac
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:42.705956"
        sha256 = "8ee8faac4942a8e0d2414a3d5bb1d5f88045a5305af21bffbdd64aca6d25deef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
