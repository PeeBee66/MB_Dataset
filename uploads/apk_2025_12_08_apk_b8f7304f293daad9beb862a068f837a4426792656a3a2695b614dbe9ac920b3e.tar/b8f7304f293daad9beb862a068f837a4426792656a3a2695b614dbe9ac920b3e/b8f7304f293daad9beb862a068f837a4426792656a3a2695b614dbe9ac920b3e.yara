
rule MB_b8f7304f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:12.309202"
        sha256 = "b8f7304f293daad9beb862a068f837a4426792656a3a2695b614dbe9ac920b3e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
