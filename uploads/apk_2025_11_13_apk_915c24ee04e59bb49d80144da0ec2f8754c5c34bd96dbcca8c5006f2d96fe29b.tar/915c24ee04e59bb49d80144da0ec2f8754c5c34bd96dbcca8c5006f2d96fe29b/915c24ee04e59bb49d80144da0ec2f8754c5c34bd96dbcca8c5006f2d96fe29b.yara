
rule MB_915c24ee
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:01:22.843151"
        sha256 = "915c24ee04e59bb49d80144da0ec2f8754c5c34bd96dbcca8c5006f2d96fe29b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
