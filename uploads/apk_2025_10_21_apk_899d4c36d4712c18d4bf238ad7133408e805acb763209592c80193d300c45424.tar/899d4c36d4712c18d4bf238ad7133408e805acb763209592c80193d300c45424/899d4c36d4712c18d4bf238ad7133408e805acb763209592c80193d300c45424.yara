
rule MB_899d4c36
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:18.015112"
        sha256 = "899d4c36d4712c18d4bf238ad7133408e805acb763209592c80193d300c45424"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
