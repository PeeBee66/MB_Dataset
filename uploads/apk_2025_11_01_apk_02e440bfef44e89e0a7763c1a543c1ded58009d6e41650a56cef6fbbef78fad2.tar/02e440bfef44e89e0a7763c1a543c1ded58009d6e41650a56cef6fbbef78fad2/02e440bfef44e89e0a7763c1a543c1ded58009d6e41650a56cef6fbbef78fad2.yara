
rule MB_02e440bf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:20.667477"
        sha256 = "02e440bfef44e89e0a7763c1a543c1ded58009d6e41650a56cef6fbbef78fad2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
