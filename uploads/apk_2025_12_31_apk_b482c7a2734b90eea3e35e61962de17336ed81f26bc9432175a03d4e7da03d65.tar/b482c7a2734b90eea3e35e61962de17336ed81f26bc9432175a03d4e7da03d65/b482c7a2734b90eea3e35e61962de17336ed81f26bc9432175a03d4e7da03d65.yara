
rule MB_b482c7a2
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-12-30T23:00:18.694401"
        sha256 = "b482c7a2734b90eea3e35e61962de17336ed81f26bc9432175a03d4e7da03d65"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
