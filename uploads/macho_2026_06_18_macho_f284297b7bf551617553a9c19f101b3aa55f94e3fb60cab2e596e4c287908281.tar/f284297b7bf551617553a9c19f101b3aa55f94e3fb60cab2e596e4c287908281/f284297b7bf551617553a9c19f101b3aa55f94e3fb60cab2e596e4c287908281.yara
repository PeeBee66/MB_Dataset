
rule MB_f284297b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-06-18T00:01:35.797413"
        sha256 = "f284297b7bf551617553a9c19f101b3aa55f94e3fb60cab2e596e4c287908281"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
