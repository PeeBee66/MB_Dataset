
rule MB_246bdb0a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:12.564611"
        sha256 = "246bdb0a9e7698e37ec7b906551ceed302d0445c9572bb3cdc02a68862fd2d2a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
