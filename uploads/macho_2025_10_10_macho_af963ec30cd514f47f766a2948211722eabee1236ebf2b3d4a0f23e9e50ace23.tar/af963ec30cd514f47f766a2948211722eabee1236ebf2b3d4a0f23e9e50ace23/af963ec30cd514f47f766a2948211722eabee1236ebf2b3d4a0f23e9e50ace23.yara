
rule MB_af963ec3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:18.803273"
        sha256 = "af963ec30cd514f47f766a2948211722eabee1236ebf2b3d4a0f23e9e50ace23"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
