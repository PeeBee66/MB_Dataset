
rule MB_807d8ffb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:41.706129"
        sha256 = "807d8ffb7975d525386036b10563485033155f62d4355a83e372b08b370c3850"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
