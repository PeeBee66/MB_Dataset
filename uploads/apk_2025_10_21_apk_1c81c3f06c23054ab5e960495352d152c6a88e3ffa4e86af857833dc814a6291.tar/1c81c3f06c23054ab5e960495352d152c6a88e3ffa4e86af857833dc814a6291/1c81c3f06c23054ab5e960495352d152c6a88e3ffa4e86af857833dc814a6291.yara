
rule MB_1c81c3f0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:39:27.445264"
        sha256 = "1c81c3f06c23054ab5e960495352d152c6a88e3ffa4e86af857833dc814a6291"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
