
rule MB_8c969efe
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:03:42.290888"
        sha256 = "8c969efed52d0710a6986d01ecd9d8f7a2483bb96ab6f94e7c6d122b98617352"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
