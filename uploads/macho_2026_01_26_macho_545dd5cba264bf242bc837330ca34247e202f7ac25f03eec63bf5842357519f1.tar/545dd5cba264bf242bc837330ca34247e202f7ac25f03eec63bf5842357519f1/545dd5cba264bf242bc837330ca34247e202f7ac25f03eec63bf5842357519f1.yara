
rule MB_545dd5cb
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-01-25T23:00:16.652339"
        sha256 = "545dd5cba264bf242bc837330ca34247e202f7ac25f03eec63bf5842357519f1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
