
rule MB_7d5ee754
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:35.707392"
        sha256 = "7d5ee754752d75ba0cd7c640c12f459bf8dee4b0d3411587e5b37dfedf9532fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
