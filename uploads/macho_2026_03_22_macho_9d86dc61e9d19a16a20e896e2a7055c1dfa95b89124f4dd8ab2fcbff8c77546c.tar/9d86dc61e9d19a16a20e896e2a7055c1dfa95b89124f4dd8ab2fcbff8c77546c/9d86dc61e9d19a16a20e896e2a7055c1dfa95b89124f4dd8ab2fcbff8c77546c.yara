
rule MB_9d86dc61
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:03:03.867999"
        sha256 = "9d86dc61e9d19a16a20e896e2a7055c1dfa95b89124f4dd8ab2fcbff8c77546c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
