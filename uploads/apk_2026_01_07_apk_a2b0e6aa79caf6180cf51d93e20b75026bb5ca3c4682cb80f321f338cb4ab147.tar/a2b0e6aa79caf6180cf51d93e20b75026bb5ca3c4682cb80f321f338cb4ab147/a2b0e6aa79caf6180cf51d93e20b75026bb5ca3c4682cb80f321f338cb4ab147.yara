
rule MB_a2b0e6aa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-06T23:00:23.308103"
        sha256 = "a2b0e6aa79caf6180cf51d93e20b75026bb5ca3c4682cb80f321f338cb4ab147"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
