
rule MB_b80c00bc
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-20T11:22:08.170990"
        sha256 = "b80c00bc987ea9acacec57eeaf299421da8e083f611084816bf0c015c7088ded"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
