
rule MB_d3f86375
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:16:54.944414"
        sha256 = "d3f863757e946d117ee7c7b50e480264a2ff1a08e7925bd2de3e6c43182868ed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
