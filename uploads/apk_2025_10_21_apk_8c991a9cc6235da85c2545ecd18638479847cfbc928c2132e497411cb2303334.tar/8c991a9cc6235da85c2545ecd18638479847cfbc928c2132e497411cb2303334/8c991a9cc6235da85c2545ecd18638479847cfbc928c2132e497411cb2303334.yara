
rule MB_8c991a9c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:35:29.360383"
        sha256 = "8c991a9cc6235da85c2545ecd18638479847cfbc928c2132e497411cb2303334"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
