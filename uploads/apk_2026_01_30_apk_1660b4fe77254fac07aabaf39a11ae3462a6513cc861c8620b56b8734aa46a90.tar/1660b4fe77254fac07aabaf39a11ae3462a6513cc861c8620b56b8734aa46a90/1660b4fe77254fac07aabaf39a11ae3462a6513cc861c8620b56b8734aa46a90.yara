
rule MB_1660b4fe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:36.531376"
        sha256 = "1660b4fe77254fac07aabaf39a11ae3462a6513cc861c8620b56b8734aa46a90"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
