
rule MB_65320181
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-22T23:00:12.954311"
        sha256 = "653201819cb651d397c8c01f36036cd317e53dd1eb61a337051f246a3008a11f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
