
rule MB_9b84104f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-27T23:00:36.536489"
        sha256 = "9b84104fa889a7279eb07bcf5952b5054d8502f7fba2f09bf2f8211bec84ff90"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
