
rule MB_f5471a00
{
    meta:
        description = "Auto-generated rule for MacSync"
        author = "MB-Collector"
        date = "2026-04-16T00:03:22.552026"
        sha256 = "f5471a00bb6cdaf01e44311c04de2e66c6f92ccc4b8e42bbb1bcb4e48f86ef3e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
