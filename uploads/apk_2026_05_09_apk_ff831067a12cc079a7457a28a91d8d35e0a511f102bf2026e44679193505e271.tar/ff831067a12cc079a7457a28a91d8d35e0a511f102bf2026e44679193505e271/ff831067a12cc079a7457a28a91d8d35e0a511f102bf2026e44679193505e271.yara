
rule MB_ff831067
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:50.726035"
        sha256 = "ff831067a12cc079a7457a28a91d8d35e0a511f102bf2026e44679193505e271"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
