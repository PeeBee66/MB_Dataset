
rule MB_c11f178e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:11.113304"
        sha256 = "c11f178e5090f36f97758fbaca79ec460f890cf14bf71e5a68077c8e43edd0e3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
