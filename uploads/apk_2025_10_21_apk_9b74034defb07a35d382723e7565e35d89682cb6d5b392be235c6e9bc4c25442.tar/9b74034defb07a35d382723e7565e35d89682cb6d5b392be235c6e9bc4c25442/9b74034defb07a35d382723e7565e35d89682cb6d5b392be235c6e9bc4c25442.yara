
rule MB_9b74034d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:46.561613"
        sha256 = "9b74034defb07a35d382723e7565e35d89682cb6d5b392be235c6e9bc4c25442"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
