
rule MB_719b3369
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:44.607357"
        sha256 = "719b3369831ad7d500faa91ae023b8b24d3df151e72b0ad06a47ff1deb1a48e1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
