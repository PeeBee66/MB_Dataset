
rule MB_9995eac0
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:37:34.266601"
        sha256 = "9995eac0e17eb54f3b5bacc8499d9be6cbfdb8d9fc9d2cd150c292c789bec34e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
