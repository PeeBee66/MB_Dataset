
rule MB_ecdc2734
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:11.004355"
        sha256 = "ecdc273481d909d46d88c636a831f4bffda1466836c44aba7e711822e72326bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
