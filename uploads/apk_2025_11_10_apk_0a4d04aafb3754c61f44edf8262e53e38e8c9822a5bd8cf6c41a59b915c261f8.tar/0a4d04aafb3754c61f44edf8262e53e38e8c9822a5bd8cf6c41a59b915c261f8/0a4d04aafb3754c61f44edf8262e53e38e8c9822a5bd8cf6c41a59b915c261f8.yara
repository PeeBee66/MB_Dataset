
rule MB_0a4d04aa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:23.345126"
        sha256 = "0a4d04aafb3754c61f44edf8262e53e38e8c9822a5bd8cf6c41a59b915c261f8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
