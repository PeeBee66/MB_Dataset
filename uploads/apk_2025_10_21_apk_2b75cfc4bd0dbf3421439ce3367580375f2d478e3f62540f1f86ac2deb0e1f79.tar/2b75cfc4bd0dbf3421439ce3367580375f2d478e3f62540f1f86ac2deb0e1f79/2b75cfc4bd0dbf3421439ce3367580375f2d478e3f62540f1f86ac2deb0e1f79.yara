
rule MB_2b75cfc4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:43.169257"
        sha256 = "2b75cfc4bd0dbf3421439ce3367580375f2d478e3f62540f1f86ac2deb0e1f79"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
