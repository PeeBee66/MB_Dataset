
rule MB_bc098ad6
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:19.195380"
        sha256 = "bc098ad6041cb7d9479709e5c76a73faa4f57d627657648d776d0ac596b84015"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
