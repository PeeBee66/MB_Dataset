
rule MB_50183f26
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:22.463413"
        sha256 = "50183f261f0685c68b3a11c710b3505afa7a93a360437aeea0412adf73055eba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
