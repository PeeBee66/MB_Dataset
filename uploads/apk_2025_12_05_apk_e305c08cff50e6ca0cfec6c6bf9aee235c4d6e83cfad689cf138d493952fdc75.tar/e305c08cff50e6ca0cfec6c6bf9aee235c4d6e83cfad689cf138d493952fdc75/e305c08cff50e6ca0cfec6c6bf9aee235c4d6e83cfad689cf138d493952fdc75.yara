
rule MB_e305c08c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:14.294710"
        sha256 = "e305c08cff50e6ca0cfec6c6bf9aee235c4d6e83cfad689cf138d493952fdc75"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
