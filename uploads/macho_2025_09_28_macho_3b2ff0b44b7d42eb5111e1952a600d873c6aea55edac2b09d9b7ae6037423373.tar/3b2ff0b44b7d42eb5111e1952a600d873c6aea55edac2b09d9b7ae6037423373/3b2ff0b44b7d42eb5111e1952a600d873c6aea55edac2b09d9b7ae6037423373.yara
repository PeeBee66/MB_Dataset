
rule MB_3b2ff0b4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:12.506530"
        sha256 = "3b2ff0b44b7d42eb5111e1952a600d873c6aea55edac2b09d9b7ae6037423373"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
