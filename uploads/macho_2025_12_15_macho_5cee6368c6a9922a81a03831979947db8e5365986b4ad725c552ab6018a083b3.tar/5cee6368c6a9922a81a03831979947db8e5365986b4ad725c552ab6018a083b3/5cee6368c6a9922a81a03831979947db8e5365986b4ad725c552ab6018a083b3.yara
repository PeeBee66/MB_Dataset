
rule MB_5cee6368
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-14T23:00:21.939009"
        sha256 = "5cee6368c6a9922a81a03831979947db8e5365986b4ad725c552ab6018a083b3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
