
rule MB_47cefad3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:40.870779"
        sha256 = "47cefad32fe7dd83811090aebdf402d2a763c0076ea05784f407883db8d9ded8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
