
rule MB_7959e522
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:36.792550"
        sha256 = "7959e5225990a6dd0c866f77e302a3541716e0dd9e1f6477b54ba3051d63501a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
