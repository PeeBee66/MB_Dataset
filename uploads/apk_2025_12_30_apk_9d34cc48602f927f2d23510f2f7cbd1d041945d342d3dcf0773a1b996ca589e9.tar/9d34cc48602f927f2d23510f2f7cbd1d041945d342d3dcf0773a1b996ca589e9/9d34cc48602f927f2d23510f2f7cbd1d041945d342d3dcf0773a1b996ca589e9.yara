
rule MB_9d34cc48
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-29T23:00:36.043612"
        sha256 = "9d34cc48602f927f2d23510f2f7cbd1d041945d342d3dcf0773a1b996ca589e9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
