
rule MB_0e69f3d1
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2026-01-07T23:00:18.143268"
        sha256 = "0e69f3d10ba88974c47a9ce83a095a29e9ac3de66b0441db60624fbe0772f6c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
