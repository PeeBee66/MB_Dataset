
rule MB_693e0c43
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:37.527531"
        sha256 = "693e0c43650ae82f3450b6fa293d91eab23614f71e90994390190cec536f1c52"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
