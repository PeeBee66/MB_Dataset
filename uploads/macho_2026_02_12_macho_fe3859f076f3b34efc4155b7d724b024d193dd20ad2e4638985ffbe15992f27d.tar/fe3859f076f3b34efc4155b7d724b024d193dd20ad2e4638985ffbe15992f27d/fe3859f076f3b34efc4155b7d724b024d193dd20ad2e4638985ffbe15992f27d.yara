
rule MB_fe3859f0
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:18.691205"
        sha256 = "fe3859f076f3b34efc4155b7d724b024d193dd20ad2e4638985ffbe15992f27d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
