
rule MB_5294f5ff
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:46.682491"
        sha256 = "5294f5ff8d2190157b8a2c0863ee395764ad520ae397929f60756a6c810fb9ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
