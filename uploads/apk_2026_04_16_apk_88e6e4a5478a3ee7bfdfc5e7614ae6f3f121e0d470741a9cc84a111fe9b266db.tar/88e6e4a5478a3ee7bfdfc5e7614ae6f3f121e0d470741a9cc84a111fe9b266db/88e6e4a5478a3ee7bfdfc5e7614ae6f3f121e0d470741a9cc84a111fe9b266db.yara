
rule MB_88e6e4a5
{
    meta:
        description = "Auto-generated rule for Mirax"
        author = "MB-Collector"
        date = "2026-04-16T00:02:42.360818"
        sha256 = "88e6e4a5478a3ee7bfdfc5e7614ae6f3f121e0d470741a9cc84a111fe9b266db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
