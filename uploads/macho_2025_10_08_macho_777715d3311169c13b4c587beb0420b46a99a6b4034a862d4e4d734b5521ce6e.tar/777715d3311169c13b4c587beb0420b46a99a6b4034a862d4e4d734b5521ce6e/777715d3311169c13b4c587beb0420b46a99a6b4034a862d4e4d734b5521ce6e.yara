
rule MB_777715d3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:50.483247"
        sha256 = "777715d3311169c13b4c587beb0420b46a99a6b4034a862d4e4d734b5521ce6e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
