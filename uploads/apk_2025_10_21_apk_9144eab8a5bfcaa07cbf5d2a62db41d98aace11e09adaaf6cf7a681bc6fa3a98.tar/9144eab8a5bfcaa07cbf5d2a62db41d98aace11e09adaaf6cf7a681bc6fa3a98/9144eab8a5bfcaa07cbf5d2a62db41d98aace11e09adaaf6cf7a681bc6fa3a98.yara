
rule MB_9144eab8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T10:59:59.033445"
        sha256 = "9144eab8a5bfcaa07cbf5d2a62db41d98aace11e09adaaf6cf7a681bc6fa3a98"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
