
rule MB_ff2e46ba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:12.461180"
        sha256 = "ff2e46babb66a7a24b36960e20b26e2b6b329d5db1499dba3aebc4c95f5fb5e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
