
rule MB_4064f42a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:01:15.870235"
        sha256 = "4064f42a30b85220545e4a43672e374ba879b36b3d79c4a5e2324a3ca1f6df8a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
