
rule MB_1e6d4b05
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-11T23:00:24.921972"
        sha256 = "1e6d4b0538558429422b71d1f4d724c8ce31be92d299df33a8339e32316e2298"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
