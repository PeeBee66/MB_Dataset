
rule MB_0d5c59fb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-23T23:00:28.596001"
        sha256 = "0d5c59fb86a094f4b2d5c170e9fa4a8c401de6267b6d6cd12af45003690aba0b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
