
rule MB_c62f3e8c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:25.421453"
        sha256 = "c62f3e8c3872e0e3e4667e0291d827f54febac35836cc56ef807a2880e8ac805"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
