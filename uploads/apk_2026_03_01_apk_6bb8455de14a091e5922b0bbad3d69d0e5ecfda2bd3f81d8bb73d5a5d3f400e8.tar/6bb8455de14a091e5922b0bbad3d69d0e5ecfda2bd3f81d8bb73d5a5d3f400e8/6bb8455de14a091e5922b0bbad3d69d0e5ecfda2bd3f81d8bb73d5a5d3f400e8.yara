
rule MB_6bb8455d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-28T23:00:19.703999"
        sha256 = "6bb8455de14a091e5922b0bbad3d69d0e5ecfda2bd3f81d8bb73d5a5d3f400e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
