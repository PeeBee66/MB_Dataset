
rule MB_f466c7fe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:04.231830"
        sha256 = "f466c7fe6b2c58489f85078f19b9b69b3835ad4c9eb425820f5abe8a164ef994"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
