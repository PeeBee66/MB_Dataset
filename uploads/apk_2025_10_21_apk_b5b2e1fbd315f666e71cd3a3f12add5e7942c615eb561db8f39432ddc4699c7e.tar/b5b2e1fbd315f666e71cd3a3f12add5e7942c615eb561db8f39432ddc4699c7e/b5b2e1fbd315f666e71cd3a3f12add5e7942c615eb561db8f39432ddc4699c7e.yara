
rule MB_b5b2e1fb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:32.546553"
        sha256 = "b5b2e1fbd315f666e71cd3a3f12add5e7942c615eb561db8f39432ddc4699c7e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
