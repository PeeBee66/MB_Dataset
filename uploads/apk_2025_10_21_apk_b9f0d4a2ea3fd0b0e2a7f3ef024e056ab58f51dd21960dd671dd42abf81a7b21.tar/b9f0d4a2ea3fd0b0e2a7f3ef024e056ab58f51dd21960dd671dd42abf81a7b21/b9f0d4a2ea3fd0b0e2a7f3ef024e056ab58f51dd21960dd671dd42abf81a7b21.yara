
rule MB_b9f0d4a2
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-20T11:51:22.101777"
        sha256 = "b9f0d4a2ea3fd0b0e2a7f3ef024e056ab58f51dd21960dd671dd42abf81a7b21"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
