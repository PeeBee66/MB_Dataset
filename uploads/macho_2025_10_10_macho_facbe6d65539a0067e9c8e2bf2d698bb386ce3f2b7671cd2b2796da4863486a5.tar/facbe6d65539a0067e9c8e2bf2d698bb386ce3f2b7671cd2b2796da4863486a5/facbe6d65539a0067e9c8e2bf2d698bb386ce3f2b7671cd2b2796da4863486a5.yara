
rule MB_facbe6d6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:59.563617"
        sha256 = "facbe6d65539a0067e9c8e2bf2d698bb386ce3f2b7671cd2b2796da4863486a5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
