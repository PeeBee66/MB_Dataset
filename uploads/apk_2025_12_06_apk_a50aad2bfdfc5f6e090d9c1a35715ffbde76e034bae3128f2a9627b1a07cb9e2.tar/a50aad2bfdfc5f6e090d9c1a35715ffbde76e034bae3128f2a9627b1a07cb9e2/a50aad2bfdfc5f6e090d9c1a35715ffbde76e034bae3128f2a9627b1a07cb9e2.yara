
rule MB_a50aad2b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-05T23:00:13.927176"
        sha256 = "a50aad2bfdfc5f6e090d9c1a35715ffbde76e034bae3128f2a9627b1a07cb9e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
