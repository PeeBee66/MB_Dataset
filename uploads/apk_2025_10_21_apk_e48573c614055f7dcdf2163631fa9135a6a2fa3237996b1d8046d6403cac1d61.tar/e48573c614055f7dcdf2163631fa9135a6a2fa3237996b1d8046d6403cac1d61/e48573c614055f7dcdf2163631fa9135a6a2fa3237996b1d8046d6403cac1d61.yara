
rule MB_e48573c6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:35.316158"
        sha256 = "e48573c614055f7dcdf2163631fa9135a6a2fa3237996b1d8046d6403cac1d61"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
