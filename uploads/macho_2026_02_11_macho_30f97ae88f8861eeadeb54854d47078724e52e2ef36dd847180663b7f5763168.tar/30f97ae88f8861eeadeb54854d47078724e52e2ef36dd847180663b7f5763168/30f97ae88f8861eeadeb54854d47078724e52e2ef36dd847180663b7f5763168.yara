
rule MB_30f97ae8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-10T23:00:18.000001"
        sha256 = "30f97ae88f8861eeadeb54854d47078724e52e2ef36dd847180663b7f5763168"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
