
rule MB_72fa32a3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:03.182784"
        sha256 = "72fa32a3063786ec9a479e455e99d311ef2961a51e07c54b55e5f74540b392d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
