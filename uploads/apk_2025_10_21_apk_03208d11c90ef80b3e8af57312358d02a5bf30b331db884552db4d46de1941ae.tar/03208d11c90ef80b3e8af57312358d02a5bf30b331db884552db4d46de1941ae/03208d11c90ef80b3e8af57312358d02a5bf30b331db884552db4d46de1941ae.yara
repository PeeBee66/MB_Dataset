
rule MB_03208d11
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:40.846183"
        sha256 = "03208d11c90ef80b3e8af57312358d02a5bf30b331db884552db4d46de1941ae"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
