
rule MB_b52decfd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:02.359803"
        sha256 = "b52decfd3c611faed8a4827de64425492dc2135f110eaab53eef142059b3487a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
