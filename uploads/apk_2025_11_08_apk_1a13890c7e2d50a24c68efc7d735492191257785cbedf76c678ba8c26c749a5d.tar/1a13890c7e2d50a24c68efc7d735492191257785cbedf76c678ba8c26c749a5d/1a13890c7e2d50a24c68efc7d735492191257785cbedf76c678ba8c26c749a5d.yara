
rule MB_1a13890c
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-11-07T23:01:08.183726"
        sha256 = "1a13890c7e2d50a24c68efc7d735492191257785cbedf76c678ba8c26c749a5d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
