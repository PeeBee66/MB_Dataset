
rule MB_5a6eda5a
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:09.418766"
        sha256 = "5a6eda5a51b8330bea4f79652927cefbb2aed857d60f71ea3b14e63db06dc1ad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
