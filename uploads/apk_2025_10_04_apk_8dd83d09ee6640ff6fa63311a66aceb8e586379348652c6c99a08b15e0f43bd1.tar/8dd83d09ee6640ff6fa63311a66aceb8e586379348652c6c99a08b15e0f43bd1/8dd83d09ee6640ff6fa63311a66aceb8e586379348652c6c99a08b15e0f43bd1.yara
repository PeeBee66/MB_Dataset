
rule MB_8dd83d09
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-04T01:13:34.757507"
        sha256 = "8dd83d09ee6640ff6fa63311a66aceb8e586379348652c6c99a08b15e0f43bd1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
