
rule MB_f5748dfb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:00:21.054424"
        sha256 = "f5748dfb71ebd394c5e2ebdc301703e9037839c9fab2b80d5a5322459d8fb9c2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
