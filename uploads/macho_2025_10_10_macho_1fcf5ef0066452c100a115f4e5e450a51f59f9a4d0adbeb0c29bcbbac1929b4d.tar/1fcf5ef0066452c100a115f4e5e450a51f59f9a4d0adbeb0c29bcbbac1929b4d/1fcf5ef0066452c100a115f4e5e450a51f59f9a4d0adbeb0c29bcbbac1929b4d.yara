
rule MB_1fcf5ef0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:50.552612"
        sha256 = "1fcf5ef0066452c100a115f4e5e450a51f59f9a4d0adbeb0c29bcbbac1929b4d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
