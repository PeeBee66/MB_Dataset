
rule MB_363bccfd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:19.758674"
        sha256 = "363bccfdc1f586f9b13ad8c7774306d875f336787a0f1806847118cfc2485350"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
