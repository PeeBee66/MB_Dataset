
rule MB_7f587f68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:06.700846"
        sha256 = "7f587f6845b47487a7e8679f9ff5286b586ef57198e7e8cb7522be20e8506a18"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
