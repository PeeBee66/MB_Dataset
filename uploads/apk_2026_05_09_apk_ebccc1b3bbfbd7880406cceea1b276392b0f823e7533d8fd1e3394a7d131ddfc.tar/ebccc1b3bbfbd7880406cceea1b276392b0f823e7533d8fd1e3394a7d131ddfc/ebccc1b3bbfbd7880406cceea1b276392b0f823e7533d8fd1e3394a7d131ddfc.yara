
rule MB_ebccc1b3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:56.760067"
        sha256 = "ebccc1b3bbfbd7880406cceea1b276392b0f823e7533d8fd1e3394a7d131ddfc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
