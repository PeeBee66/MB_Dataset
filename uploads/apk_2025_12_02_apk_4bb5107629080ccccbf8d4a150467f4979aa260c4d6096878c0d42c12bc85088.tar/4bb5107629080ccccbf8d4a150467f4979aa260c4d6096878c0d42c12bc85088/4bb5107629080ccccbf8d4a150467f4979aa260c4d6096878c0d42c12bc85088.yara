
rule MB_4bb51076
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:00:14.953876"
        sha256 = "4bb5107629080ccccbf8d4a150467f4979aa260c4d6096878c0d42c12bc85088"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
