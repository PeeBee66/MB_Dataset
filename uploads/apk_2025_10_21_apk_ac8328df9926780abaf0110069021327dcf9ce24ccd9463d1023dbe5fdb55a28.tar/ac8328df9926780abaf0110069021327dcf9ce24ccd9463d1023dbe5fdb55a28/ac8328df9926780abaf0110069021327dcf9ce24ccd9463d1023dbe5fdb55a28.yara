
rule MB_ac8328df
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:09.878750"
        sha256 = "ac8328df9926780abaf0110069021327dcf9ce24ccd9463d1023dbe5fdb55a28"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
