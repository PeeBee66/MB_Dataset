
rule MB_f4400099
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:08.685299"
        sha256 = "f440009950ba976b0c72699807b58b7047ea69cc012068cc3bdf2edbdcdb61f9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
