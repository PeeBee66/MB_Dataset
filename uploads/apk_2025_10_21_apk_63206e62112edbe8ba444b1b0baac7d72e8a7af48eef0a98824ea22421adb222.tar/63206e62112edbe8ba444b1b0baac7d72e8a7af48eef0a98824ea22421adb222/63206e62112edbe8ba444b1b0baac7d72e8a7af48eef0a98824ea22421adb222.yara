
rule MB_63206e62
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:02.731631"
        sha256 = "63206e62112edbe8ba444b1b0baac7d72e8a7af48eef0a98824ea22421adb222"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
