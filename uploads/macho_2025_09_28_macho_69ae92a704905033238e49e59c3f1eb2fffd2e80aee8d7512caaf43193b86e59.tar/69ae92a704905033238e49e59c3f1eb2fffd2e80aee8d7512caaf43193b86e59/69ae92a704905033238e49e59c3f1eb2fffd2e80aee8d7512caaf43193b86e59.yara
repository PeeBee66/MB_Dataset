
rule MB_69ae92a7
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:58.650600"
        sha256 = "69ae92a704905033238e49e59c3f1eb2fffd2e80aee8d7512caaf43193b86e59"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
