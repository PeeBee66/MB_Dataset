
rule MB_e493fb5d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:00:38.313803"
        sha256 = "e493fb5dd552583243a53616c5d145f3e0e560b983e3eec034b546b066bba85c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
