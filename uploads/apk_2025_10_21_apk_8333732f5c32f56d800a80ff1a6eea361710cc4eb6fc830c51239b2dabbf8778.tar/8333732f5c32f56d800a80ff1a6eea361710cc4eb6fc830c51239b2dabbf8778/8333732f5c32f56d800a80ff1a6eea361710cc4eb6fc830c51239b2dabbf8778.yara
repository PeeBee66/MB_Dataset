
rule MB_8333732f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:43.190514"
        sha256 = "8333732f5c32f56d800a80ff1a6eea361710cc4eb6fc830c51239b2dabbf8778"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
