
rule MB_b42abc66
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:37.991464"
        sha256 = "b42abc669f0b512553c70a390ac28797385467147be91ec3dc222557dc09395c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
