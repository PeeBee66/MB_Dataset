
rule MB_d4260c77
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:00:59.629740"
        sha256 = "d4260c77a075c50ef7a740768331a7f83aac07c9b2737ba0c02c5e4dc469c5ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
