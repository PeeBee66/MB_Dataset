
rule MB_d8219ff7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-04T00:00:24.001049"
        sha256 = "d8219ff7bb309b660a61008793f8250aeff1133be9be3a7747fba28500b0362c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
