
rule MB_e53e38d1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:06.219573"
        sha256 = "e53e38d1e1edefc7ca3a6a96a876162e577dfc24c05d980bf18ab00efc3b81d8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
