
rule MB_a26450e9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:50.391273"
        sha256 = "a26450e92ddb8b3da643c35aa39dc4b29509598485000b56caa30c881daa9099"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
