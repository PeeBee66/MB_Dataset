
rule MB_75cd6f16
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:23.233115"
        sha256 = "75cd6f164dee674a18edc5154ef0d48633eb581b73d77aef047af0a5856420cc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
