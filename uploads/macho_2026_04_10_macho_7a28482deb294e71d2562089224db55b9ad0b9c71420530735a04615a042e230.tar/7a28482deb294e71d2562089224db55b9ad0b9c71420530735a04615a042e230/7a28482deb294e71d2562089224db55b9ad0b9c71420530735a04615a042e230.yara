
rule MB_7a28482d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-10T00:00:56.190094"
        sha256 = "7a28482deb294e71d2562089224db55b9ad0b9c71420530735a04615a042e230"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
