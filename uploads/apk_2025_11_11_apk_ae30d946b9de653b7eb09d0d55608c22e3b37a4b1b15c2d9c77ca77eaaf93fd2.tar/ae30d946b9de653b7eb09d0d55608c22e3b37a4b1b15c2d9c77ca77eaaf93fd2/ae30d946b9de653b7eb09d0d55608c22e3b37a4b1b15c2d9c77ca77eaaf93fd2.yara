
rule MB_ae30d946
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:00:54.173755"
        sha256 = "ae30d946b9de653b7eb09d0d55608c22e3b37a4b1b15c2d9c77ca77eaaf93fd2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
