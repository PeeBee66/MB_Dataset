
rule MB_a305170f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-18T23:00:14.699831"
        sha256 = "a305170fc890a43d4267699959ee91d4c9fe32f3ddaa0c1342918b8a87ab1d1c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
