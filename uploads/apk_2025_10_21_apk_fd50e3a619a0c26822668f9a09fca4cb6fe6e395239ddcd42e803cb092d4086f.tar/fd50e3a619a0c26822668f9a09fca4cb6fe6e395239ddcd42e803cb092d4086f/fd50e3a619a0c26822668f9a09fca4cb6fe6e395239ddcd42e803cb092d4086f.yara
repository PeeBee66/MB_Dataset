
rule MB_fd50e3a6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:35.002223"
        sha256 = "fd50e3a619a0c26822668f9a09fca4cb6fe6e395239ddcd42e803cb092d4086f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
