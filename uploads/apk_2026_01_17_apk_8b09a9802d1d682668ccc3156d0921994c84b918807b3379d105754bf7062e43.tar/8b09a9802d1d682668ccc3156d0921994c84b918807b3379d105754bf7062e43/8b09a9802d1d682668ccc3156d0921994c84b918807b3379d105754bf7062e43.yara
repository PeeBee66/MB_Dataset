
rule MB_8b09a980
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-16T23:00:21.810949"
        sha256 = "8b09a9802d1d682668ccc3156d0921994c84b918807b3379d105754bf7062e43"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
