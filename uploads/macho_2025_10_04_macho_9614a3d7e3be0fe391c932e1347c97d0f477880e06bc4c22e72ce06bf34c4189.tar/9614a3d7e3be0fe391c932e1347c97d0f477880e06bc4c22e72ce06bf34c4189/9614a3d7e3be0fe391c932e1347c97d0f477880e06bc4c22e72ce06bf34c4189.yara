
rule MB_9614a3d7
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:21.990717"
        sha256 = "9614a3d7e3be0fe391c932e1347c97d0f477880e06bc4c22e72ce06bf34c4189"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
