
rule MB_7a449a29
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:31.764055"
        sha256 = "7a449a292f2498734e22aa7f43857fda0d34f81910ffb8a85cd679eb9c3694de"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
