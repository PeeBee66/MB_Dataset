
rule MB_3d59b82e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:01:02.057095"
        sha256 = "3d59b82e74724ebebab1631d58e5d07da265836467730ae601bcd308bd3b3d32"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
