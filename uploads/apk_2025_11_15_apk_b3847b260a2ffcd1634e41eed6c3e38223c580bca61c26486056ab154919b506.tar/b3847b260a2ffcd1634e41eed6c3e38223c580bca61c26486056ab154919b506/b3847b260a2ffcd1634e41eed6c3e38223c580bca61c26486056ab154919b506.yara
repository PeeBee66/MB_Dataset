
rule MB_b3847b26
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-14T23:00:46.471919"
        sha256 = "b3847b260a2ffcd1634e41eed6c3e38223c580bca61c26486056ab154919b506"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
