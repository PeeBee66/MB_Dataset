
rule MB_2b7af4d5
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-21T23:00:15.033945"
        sha256 = "2b7af4d5fd24ce4daaa2aada2db239d0ec17510d17a55beb214b70b8edc54fb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
