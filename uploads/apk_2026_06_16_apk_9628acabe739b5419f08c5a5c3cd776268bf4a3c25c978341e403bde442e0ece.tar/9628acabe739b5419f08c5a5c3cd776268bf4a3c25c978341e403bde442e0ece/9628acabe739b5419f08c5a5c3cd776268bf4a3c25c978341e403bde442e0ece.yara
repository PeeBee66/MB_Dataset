
rule MB_9628acab
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:40.124383"
        sha256 = "9628acabe739b5419f08c5a5c3cd776268bf4a3c25c978341e403bde442e0ece"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
