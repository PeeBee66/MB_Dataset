
rule MB_4d66b097
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:58:56.493854"
        sha256 = "4d66b097cc900cde8ab5d22f3ab915f5879c6ea2eef9f85196ddff149315eefe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
