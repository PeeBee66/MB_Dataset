
rule MB_d79143cc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:49.416630"
        sha256 = "d79143ccf52e83edf2ab47621a205d447f9453a6ce371e45568548bb313e2f13"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
