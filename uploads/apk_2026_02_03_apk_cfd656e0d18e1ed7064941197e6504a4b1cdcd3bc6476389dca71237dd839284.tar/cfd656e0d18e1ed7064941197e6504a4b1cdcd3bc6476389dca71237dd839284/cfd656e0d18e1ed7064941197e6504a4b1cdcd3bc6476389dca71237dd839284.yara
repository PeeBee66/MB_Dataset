
rule MB_cfd656e0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:45.430252"
        sha256 = "cfd656e0d18e1ed7064941197e6504a4b1cdcd3bc6476389dca71237dd839284"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
