
rule MB_ca2e505a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:29.635822"
        sha256 = "ca2e505a14391d0455ea1e007531a7c9c4c56dada2e1e185257a0be843e1745b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
