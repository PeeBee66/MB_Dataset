
rule MB_4825baa9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:32.213163"
        sha256 = "4825baa9d273e531f80be5eb5d9dc5f4a1f470f95e89624528cc2838040e581f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
