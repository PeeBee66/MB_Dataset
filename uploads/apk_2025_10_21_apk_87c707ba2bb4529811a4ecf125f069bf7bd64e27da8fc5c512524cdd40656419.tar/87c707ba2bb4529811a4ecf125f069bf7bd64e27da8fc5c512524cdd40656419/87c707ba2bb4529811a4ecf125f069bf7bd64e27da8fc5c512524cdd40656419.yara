
rule MB_87c707ba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:35.487769"
        sha256 = "87c707ba2bb4529811a4ecf125f069bf7bd64e27da8fc5c512524cdd40656419"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
