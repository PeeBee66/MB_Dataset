
rule MB_b1a5a668
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:37.992584"
        sha256 = "b1a5a668aeb753dd22c8e757a09b81250fb04b1bdb378f8d7faaeb114336826e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
