
rule MB_40706787
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-13T00:00:27.274623"
        sha256 = "4070678717cf011417c9e4307c9ecb4d481563db4758ffaada5fa6870e06a4ac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
