
rule MB_37aea8c8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:00:49.633598"
        sha256 = "37aea8c8ed8ea55d23da37d997e82e6cc34bf80bce891378be7543adf6678ea1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
