
rule MB_357b0de5
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:54.543744"
        sha256 = "357b0de53b2a47b4e0b3ebc87c63342b5e1e7e99ce3273ad1495c7e928bf7a73"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
