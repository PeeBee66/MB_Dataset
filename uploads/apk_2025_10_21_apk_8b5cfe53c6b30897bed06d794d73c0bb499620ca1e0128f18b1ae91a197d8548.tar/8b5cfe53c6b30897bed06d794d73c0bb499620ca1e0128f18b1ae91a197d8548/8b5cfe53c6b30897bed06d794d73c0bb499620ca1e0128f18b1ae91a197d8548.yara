
rule MB_8b5cfe53
{
    meta:
        description = "Auto-generated rule for Ajina"
        author = "MB-Collector"
        date = "2025-10-20T11:39:46.926249"
        sha256 = "8b5cfe53c6b30897bed06d794d73c0bb499620ca1e0128f18b1ae91a197d8548"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
