
rule MB_6dd19edd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:23.420924"
        sha256 = "6dd19edd60ed2025afc6b661e85f146c925f2137e51ae49c5d1dce955ac43aaf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
