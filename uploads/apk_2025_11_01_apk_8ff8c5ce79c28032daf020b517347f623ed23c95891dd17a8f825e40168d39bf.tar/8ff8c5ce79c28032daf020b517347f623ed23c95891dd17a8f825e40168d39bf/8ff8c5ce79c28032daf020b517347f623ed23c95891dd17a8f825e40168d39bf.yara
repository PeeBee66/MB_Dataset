
rule MB_8ff8c5ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:44.996809"
        sha256 = "8ff8c5ce79c28032daf020b517347f623ed23c95891dd17a8f825e40168d39bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
