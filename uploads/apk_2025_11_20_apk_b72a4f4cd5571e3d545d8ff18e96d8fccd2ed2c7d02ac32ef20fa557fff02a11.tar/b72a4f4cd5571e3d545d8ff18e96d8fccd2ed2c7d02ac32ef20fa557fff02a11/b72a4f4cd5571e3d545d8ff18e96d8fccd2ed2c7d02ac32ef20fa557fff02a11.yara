
rule MB_b72a4f4c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:25.854213"
        sha256 = "b72a4f4cd5571e3d545d8ff18e96d8fccd2ed2c7d02ac32ef20fa557fff02a11"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
