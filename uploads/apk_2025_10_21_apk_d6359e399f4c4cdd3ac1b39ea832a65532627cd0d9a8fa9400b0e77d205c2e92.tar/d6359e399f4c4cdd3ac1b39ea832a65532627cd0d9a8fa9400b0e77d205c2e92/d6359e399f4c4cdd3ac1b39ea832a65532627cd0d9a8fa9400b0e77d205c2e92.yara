
rule MB_d6359e39
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:19.624923"
        sha256 = "d6359e399f4c4cdd3ac1b39ea832a65532627cd0d9a8fa9400b0e77d205c2e92"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
