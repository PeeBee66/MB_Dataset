
rule MB_3aea0345
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:01:14.674179"
        sha256 = "3aea0345c88f069d3a079c82571086adafb585137a86e277f4e5c9fb1b2190e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
