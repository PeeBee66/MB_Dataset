
rule MB_9190e034
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:51.184484"
        sha256 = "9190e03467a830461a83ca5b2cf51a1c21a5ffe6c823e25c09973948e4f29900"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
