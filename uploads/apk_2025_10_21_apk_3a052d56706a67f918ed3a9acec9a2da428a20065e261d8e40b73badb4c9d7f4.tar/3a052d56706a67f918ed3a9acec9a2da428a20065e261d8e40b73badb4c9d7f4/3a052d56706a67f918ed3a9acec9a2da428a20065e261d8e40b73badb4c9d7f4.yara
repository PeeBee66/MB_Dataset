
rule MB_3a052d56
{
    meta:
        description = "Auto-generated rule for DCHSpy"
        author = "MB-Collector"
        date = "2025-10-20T11:31:21.176281"
        sha256 = "3a052d56706a67f918ed3a9acec9a2da428a20065e261d8e40b73badb4c9d7f4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
