
rule MB_51825d21
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:52:42.923231"
        sha256 = "51825d216e60d51e8c73c7fb323347737288b917b656ed921eefc9f3cd80106c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
