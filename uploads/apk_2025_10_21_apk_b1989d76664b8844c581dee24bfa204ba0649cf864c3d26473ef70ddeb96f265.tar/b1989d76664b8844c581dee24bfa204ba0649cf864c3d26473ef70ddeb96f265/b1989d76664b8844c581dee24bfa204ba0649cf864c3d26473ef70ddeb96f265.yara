
rule MB_b1989d76
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:12.203096"
        sha256 = "b1989d76664b8844c581dee24bfa204ba0649cf864c3d26473ef70ddeb96f265"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
