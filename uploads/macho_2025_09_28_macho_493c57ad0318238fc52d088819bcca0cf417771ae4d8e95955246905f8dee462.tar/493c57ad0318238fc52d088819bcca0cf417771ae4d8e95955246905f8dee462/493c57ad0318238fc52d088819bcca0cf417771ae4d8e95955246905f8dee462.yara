
rule MB_493c57ad
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:14.720267"
        sha256 = "493c57ad0318238fc52d088819bcca0cf417771ae4d8e95955246905f8dee462"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
