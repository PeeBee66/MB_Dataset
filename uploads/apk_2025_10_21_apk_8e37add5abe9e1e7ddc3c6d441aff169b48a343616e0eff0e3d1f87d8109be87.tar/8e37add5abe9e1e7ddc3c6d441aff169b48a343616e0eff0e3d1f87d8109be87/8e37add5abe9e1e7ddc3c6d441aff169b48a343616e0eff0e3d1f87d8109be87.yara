
rule MB_8e37add5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:13.694743"
        sha256 = "8e37add5abe9e1e7ddc3c6d441aff169b48a343616e0eff0e3d1f87d8109be87"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
