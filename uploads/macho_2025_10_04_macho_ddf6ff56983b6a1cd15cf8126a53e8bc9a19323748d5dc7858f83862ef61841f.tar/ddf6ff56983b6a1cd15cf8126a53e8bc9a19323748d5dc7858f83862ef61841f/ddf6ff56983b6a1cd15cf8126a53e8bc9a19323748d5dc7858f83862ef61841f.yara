
rule MB_ddf6ff56
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:25.000246"
        sha256 = "ddf6ff56983b6a1cd15cf8126a53e8bc9a19323748d5dc7858f83862ef61841f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
