
rule MB_7fb836c0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:30.273699"
        sha256 = "7fb836c08ff527443b06d1c20afb6a4b0f51eb373013f211e0d3200bf26527b7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
