
rule MB_a26c07ad
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-03-25T23:00:18.385964"
        sha256 = "a26c07ad66b966d3c610ff11ee594dd0b14c332a57f66ce3d32610191176ceb0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
