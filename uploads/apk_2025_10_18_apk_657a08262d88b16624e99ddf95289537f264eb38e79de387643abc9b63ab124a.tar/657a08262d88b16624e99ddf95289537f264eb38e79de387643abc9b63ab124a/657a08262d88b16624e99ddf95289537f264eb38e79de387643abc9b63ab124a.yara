
rule MB_657a0826
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-17T23:00:17.926780"
        sha256 = "657a08262d88b16624e99ddf95289537f264eb38e79de387643abc9b63ab124a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
