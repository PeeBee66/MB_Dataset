
rule MB_21a5b4ad
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:21:07.486011"
        sha256 = "21a5b4ad0fcaeefaa8ad617f2aa889ed6f28a1bf96d88ad68aadcedbc7255f75"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
