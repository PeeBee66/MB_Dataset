
rule MB_7e631e9f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:33.248973"
        sha256 = "7e631e9f7791f4648f776419c020ce6c33071c3e195669dd473f1423f098d39d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
