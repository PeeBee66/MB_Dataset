
rule MB_98f7e90c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:52.763826"
        sha256 = "98f7e90ca87cc54ef14c3e21569977d4d9cb1b8e49e978f61865628137079f60"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
