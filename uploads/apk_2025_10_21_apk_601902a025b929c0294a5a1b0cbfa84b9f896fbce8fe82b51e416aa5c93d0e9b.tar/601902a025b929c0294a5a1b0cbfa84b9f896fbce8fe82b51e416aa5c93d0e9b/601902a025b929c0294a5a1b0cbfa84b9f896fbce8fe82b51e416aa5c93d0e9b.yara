
rule MB_601902a0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:37.710750"
        sha256 = "601902a025b929c0294a5a1b0cbfa84b9f896fbce8fe82b51e416aa5c93d0e9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
