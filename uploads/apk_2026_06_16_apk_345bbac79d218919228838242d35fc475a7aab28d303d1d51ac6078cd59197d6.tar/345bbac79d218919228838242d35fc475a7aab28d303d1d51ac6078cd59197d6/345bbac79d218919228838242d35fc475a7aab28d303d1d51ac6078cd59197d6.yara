
rule MB_345bbac7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:17.333502"
        sha256 = "345bbac79d218919228838242d35fc475a7aab28d303d1d51ac6078cd59197d6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
