
rule MB_ab2b6abb
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:07:59.993169"
        sha256 = "ab2b6abb87a3438ecc2f8cdd619ea301414f70a0e466a733a3d2598d71c94a4d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
