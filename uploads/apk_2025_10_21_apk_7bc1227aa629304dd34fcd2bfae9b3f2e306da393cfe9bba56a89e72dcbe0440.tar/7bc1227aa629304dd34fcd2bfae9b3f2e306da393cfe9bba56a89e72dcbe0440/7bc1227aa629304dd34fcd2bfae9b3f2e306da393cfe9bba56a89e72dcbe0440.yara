
rule MB_7bc1227a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:31.811137"
        sha256 = "7bc1227aa629304dd34fcd2bfae9b3f2e306da393cfe9bba56a89e72dcbe0440"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
