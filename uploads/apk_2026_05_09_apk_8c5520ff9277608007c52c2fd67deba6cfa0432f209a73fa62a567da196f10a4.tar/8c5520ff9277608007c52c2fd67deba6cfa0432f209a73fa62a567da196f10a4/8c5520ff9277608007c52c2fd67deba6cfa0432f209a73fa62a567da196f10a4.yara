
rule MB_8c5520ff
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:05.393716"
        sha256 = "8c5520ff9277608007c52c2fd67deba6cfa0432f209a73fa62a567da196f10a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
