
rule MB_a9562ab6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-22T00:00:56.796094"
        sha256 = "a9562ab6bce06e92d4e428088eacc1e990e67ceae6f6940047360261b5599614"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
