
rule MB_8c4f8053
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:32.140463"
        sha256 = "8c4f8053881899f844a2e6dea8ce119124acac2b34750a47650e368c27bf7a3b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
