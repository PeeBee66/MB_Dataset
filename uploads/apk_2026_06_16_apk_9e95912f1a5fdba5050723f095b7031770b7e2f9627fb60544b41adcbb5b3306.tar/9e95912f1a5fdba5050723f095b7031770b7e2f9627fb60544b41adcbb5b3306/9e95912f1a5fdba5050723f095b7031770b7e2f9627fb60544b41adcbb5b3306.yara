
rule MB_9e95912f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:50.049997"
        sha256 = "9e95912f1a5fdba5050723f095b7031770b7e2f9627fb60544b41adcbb5b3306"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
