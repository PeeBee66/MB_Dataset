
rule MB_39ff96df
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:23.831732"
        sha256 = "39ff96df1f5894bc094b1efca76a8418d264022f049ad473a3adffcaa3ceb84e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
