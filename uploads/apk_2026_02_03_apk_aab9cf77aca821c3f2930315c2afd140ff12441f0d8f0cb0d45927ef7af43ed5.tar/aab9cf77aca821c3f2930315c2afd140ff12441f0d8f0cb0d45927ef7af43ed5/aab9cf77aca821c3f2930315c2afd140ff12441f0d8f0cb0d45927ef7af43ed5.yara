
rule MB_aab9cf77
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:55.662200"
        sha256 = "aab9cf77aca821c3f2930315c2afd140ff12441f0d8f0cb0d45927ef7af43ed5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
