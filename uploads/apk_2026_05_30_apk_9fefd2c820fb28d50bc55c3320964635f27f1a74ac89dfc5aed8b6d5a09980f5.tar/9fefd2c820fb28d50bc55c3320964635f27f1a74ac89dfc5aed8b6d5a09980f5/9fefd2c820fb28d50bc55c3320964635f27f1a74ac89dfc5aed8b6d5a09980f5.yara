
rule MB_9fefd2c8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-30T00:00:15.523078"
        sha256 = "9fefd2c820fb28d50bc55c3320964635f27f1a74ac89dfc5aed8b6d5a09980f5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
