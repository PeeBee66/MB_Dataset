
rule MB_6f58b07b
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-12-29T23:00:49.170955"
        sha256 = "6f58b07b5ddabc29c9c7e7165349edbd2bee923446514044d67040de2f36664a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
