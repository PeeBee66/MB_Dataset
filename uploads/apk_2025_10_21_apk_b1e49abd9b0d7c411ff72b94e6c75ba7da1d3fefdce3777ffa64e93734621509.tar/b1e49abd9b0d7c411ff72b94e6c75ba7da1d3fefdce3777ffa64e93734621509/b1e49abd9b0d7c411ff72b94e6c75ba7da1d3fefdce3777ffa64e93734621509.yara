
rule MB_b1e49abd
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:45:03.164295"
        sha256 = "b1e49abd9b0d7c411ff72b94e6c75ba7da1d3fefdce3777ffa64e93734621509"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
