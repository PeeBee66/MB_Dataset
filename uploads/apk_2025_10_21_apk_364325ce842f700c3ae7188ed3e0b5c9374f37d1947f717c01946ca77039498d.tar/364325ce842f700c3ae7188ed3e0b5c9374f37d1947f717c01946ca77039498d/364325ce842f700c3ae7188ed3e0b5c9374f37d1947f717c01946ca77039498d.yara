
rule MB_364325ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:35.444558"
        sha256 = "364325ce842f700c3ae7188ed3e0b5c9374f37d1947f717c01946ca77039498d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
