
rule MB_d1fec0ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-30T23:00:20.053141"
        sha256 = "d1fec0ce2be2097357d307e835783380ac010c7d55f3e72fa3906f0d0edd7a6a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
