
rule MB_37ea33b5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:04:05.134734"
        sha256 = "37ea33b5a35f8d57c2ea1198c737ed642adf81d5ac99773a6515b5e633a2c287"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
