
rule MB_6eb3f3ab
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:22.790159"
        sha256 = "6eb3f3ababec7193e1e1c056eabb9a8e871129bcbd7ae926c6bc5daa26c1c93c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
