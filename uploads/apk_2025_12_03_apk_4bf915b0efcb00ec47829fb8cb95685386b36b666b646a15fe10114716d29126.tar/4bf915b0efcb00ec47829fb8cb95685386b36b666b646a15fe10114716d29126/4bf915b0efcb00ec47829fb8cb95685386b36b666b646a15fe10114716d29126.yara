
rule MB_4bf915b0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:38.621768"
        sha256 = "4bf915b0efcb00ec47829fb8cb95685386b36b666b646a15fe10114716d29126"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
