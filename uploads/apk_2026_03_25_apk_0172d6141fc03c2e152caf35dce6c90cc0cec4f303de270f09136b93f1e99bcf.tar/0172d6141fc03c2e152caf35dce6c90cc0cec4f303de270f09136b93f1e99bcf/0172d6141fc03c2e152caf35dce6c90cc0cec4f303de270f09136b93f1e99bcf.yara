
rule MB_0172d614
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-24T23:00:34.022476"
        sha256 = "0172d6141fc03c2e152caf35dce6c90cc0cec4f303de270f09136b93f1e99bcf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
