
rule MB_191fbf87
{
    meta:
        description = "Auto-generated rule for IRATA"
        author = "MB-Collector"
        date = "2025-10-20T11:37:42.806227"
        sha256 = "191fbf8741177e03e6b3b179b6c0a33dec5ffb0aa560a58bbe2bbee0cfea4480"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
