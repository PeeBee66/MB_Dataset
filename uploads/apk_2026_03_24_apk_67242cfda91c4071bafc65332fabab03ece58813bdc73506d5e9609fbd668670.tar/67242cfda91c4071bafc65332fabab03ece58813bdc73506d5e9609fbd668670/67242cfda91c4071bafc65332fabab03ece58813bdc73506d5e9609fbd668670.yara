
rule MB_67242cfd
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:35.321580"
        sha256 = "67242cfda91c4071bafc65332fabab03ece58813bdc73506d5e9609fbd668670"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
