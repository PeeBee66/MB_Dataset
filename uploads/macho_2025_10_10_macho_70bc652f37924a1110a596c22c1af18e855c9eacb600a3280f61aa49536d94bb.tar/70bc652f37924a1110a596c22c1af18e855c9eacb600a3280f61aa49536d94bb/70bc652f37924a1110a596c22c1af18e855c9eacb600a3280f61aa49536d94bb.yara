
rule MB_70bc652f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:38.080541"
        sha256 = "70bc652f37924a1110a596c22c1af18e855c9eacb600a3280f61aa49536d94bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
