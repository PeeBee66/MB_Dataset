
rule MB_1da17ebc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:30.071168"
        sha256 = "1da17ebc326c3a093a1afd7565184950a741a3527a5ec86d45a8cbc3193b7406"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
