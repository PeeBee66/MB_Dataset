
rule MB_559159a0
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:43.875412"
        sha256 = "559159a0dd28d27437b2857b2848aec07c65ef929947865e4a04a08b483e687b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
