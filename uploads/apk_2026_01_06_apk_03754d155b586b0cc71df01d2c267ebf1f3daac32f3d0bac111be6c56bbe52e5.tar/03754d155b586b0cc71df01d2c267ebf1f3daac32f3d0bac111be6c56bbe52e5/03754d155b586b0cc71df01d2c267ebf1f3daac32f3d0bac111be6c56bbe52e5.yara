
rule MB_03754d15
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:26.095938"
        sha256 = "03754d155b586b0cc71df01d2c267ebf1f3daac32f3d0bac111be6c56bbe52e5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
