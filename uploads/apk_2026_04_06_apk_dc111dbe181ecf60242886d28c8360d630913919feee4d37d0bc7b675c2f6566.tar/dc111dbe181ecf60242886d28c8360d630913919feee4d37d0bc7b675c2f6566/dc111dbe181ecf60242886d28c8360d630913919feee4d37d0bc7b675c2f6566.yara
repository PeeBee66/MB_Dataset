
rule MB_dc111dbe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-06T00:00:22.449915"
        sha256 = "dc111dbe181ecf60242886d28c8360d630913919feee4d37d0bc7b675c2f6566"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
