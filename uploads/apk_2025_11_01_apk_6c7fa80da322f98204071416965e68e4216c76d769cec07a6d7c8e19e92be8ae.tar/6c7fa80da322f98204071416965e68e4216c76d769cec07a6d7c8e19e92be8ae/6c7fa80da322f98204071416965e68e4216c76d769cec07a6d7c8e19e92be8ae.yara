
rule MB_6c7fa80d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:21.009519"
        sha256 = "6c7fa80da322f98204071416965e68e4216c76d769cec07a6d7c8e19e92be8ae"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
