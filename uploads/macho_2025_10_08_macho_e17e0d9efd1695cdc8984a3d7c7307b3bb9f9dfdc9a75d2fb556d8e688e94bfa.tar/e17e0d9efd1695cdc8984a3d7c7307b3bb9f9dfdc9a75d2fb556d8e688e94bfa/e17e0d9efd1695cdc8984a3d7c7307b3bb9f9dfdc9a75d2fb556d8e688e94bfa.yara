
rule MB_e17e0d9e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:31.133457"
        sha256 = "e17e0d9efd1695cdc8984a3d7c7307b3bb9f9dfdc9a75d2fb556d8e688e94bfa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
