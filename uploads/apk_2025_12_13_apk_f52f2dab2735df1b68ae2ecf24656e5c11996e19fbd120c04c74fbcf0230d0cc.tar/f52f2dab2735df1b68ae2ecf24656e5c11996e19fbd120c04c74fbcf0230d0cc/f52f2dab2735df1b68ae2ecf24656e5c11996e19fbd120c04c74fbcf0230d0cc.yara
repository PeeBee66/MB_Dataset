
rule MB_f52f2dab
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:27.602003"
        sha256 = "f52f2dab2735df1b68ae2ecf24656e5c11996e19fbd120c04c74fbcf0230d0cc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
