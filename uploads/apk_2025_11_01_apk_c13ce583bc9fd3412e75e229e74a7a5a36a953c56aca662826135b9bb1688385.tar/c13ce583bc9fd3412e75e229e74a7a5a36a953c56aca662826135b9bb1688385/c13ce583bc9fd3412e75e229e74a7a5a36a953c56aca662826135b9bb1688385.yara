
rule MB_c13ce583
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:11.511595"
        sha256 = "c13ce583bc9fd3412e75e229e74a7a5a36a953c56aca662826135b9bb1688385"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
