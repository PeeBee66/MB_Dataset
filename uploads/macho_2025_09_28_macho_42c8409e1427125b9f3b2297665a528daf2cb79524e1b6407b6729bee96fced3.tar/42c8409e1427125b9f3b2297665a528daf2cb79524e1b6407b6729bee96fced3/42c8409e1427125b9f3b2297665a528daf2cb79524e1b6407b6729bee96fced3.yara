
rule MB_42c8409e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:59.502279"
        sha256 = "42c8409e1427125b9f3b2297665a528daf2cb79524e1b6407b6729bee96fced3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
