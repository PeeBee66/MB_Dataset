
rule MB_eafeccc6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-22T23:00:25.498287"
        sha256 = "eafeccc6925130db1ebc5150b8922bf3371ab94dbbc2d600d9cf7cd6849b056e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
