
rule MB_a628996f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:06.633909"
        sha256 = "a628996f01f5d967d9b1276e0d4ebdb62c2b5462a39be19e783c9a65ec4ff571"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
