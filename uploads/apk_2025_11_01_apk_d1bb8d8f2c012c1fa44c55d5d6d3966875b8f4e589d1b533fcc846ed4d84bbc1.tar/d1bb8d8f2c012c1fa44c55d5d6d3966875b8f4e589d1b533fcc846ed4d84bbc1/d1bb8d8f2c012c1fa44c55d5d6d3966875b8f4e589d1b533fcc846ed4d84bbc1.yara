
rule MB_d1bb8d8f
{
    meta:
        description = "Auto-generated rule for SMSEye"
        author = "MB-Collector"
        date = "2025-10-31T23:04:34.423710"
        sha256 = "d1bb8d8f2c012c1fa44c55d5d6d3966875b8f4e589d1b533fcc846ed4d84bbc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
