
rule MB_a9d2af33
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:13.156822"
        sha256 = "a9d2af33acfb4f7d6b75199eae29f2ff6ba983547269c8ce1c54dcde72991a1a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
