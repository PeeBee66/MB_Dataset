
rule MB_51e6ba1d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:44.325177"
        sha256 = "51e6ba1d9cd86961b374224d5c04b7fb698bff7461bbd9dc556d548db7aa3ad7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
