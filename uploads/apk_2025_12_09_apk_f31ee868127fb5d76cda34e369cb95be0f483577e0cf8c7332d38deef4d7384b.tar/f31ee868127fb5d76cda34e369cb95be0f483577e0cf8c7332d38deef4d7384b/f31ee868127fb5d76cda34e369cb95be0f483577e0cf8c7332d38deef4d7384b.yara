
rule MB_f31ee868
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:34.814340"
        sha256 = "f31ee868127fb5d76cda34e369cb95be0f483577e0cf8c7332d38deef4d7384b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
