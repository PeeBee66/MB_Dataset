
rule MB_280df905
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:09.878359"
        sha256 = "280df905ee0f6fb2539cd85c5b31b8bf403d91363fa6a108e48e58e85c721894"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
