
rule MB_ea19a703
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:52:40.408726"
        sha256 = "ea19a7030fed1c317793e9b92f3911e0ba42b1dc58e07ac36dd0e0a614a84109"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
