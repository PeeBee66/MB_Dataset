
rule MB_ad726cfb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:07.921387"
        sha256 = "ad726cfb2aa2e3cbbcb0f43361f0c33f8fb64bb870a5b5d98cb3a60aa4fab66a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
