
rule MB_9c859f4e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:52.598337"
        sha256 = "9c859f4ec7db40e01ae74b43b59705c347faab489b493c4849879585b8383a2c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
