
rule MB_4f8a8696
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:02.800469"
        sha256 = "4f8a8696061267810cbc0737e247cfba7550e605ab2851daf8841823e96ce5ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
