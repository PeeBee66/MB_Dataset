
rule MB_010ce652
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:25.665966"
        sha256 = "010ce6526d4f2b67c5e33c612da559dcbf847829cf215c5f5a152d5e6eb9754d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
