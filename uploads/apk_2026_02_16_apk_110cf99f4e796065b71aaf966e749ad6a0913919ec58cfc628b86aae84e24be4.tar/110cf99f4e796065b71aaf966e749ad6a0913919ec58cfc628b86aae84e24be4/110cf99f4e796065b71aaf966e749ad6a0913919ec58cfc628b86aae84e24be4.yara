
rule MB_110cf99f
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-02-15T23:00:32.646328"
        sha256 = "110cf99f4e796065b71aaf966e749ad6a0913919ec58cfc628b86aae84e24be4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
