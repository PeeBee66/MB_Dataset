
rule MB_ad95828b
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:22:45.240696"
        sha256 = "ad95828bcd54380149b2876a243c12f99d6c78cba27092f684af991fc5a279c0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
