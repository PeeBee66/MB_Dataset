
rule MB_30208552
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:22:48.541544"
        sha256 = "30208552a677cce35d4863d3d85b857848fc6b33df44196bfd26a7142f586035"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
