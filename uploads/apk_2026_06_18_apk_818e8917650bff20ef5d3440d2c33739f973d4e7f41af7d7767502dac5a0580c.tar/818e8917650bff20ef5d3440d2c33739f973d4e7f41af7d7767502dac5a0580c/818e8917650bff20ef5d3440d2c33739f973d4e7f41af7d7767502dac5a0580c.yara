
rule MB_818e8917
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:01:21.249254"
        sha256 = "818e8917650bff20ef5d3440d2c33739f973d4e7f41af7d7767502dac5a0580c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
