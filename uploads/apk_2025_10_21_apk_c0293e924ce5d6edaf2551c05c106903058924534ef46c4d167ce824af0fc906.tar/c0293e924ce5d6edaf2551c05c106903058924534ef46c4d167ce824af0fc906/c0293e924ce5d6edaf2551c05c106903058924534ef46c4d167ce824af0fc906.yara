
rule MB_c0293e92
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:37:02.025339"
        sha256 = "c0293e924ce5d6edaf2551c05c106903058924534ef46c4d167ce824af0fc906"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
