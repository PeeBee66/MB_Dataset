
rule MB_6a3d6703
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:22.889349"
        sha256 = "6a3d670364b5cea68b0c26ba8182a31c475b3e1a7c755678e4af72639cf7461e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
