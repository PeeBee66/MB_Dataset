
rule MB_66018dcb
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:19.891463"
        sha256 = "66018dcba913253f0e7d9611abb6e3eb31ac3872302d0cb7efe432971dd09bbf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
