
rule MB_e0504c88
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:00:55.315414"
        sha256 = "e0504c88094b3f42859443cfe68ab2f805264f2230d4f639e999a083277e2bf3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
