
rule MB_501e35f1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-05T00:00:18.893952"
        sha256 = "501e35f1600ce0548226c9957eed76f5f04cb2e1dbfd4f3fb8652009b38e8c9f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
