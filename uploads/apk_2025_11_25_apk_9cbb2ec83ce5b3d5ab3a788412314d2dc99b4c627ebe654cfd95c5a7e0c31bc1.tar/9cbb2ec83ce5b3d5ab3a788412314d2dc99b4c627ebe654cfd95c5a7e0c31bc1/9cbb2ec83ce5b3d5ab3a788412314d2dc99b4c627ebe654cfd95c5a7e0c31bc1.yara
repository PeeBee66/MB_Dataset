
rule MB_9cbb2ec8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:40.719158"
        sha256 = "9cbb2ec83ce5b3d5ab3a788412314d2dc99b4c627ebe654cfd95c5a7e0c31bc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
