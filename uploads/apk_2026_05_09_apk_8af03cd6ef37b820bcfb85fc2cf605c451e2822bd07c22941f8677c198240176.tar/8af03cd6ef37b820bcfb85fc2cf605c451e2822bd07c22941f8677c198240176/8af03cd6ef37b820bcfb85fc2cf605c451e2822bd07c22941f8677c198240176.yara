
rule MB_8af03cd6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:01:37.704162"
        sha256 = "8af03cd6ef37b820bcfb85fc2cf605c451e2822bd07c22941f8677c198240176"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
