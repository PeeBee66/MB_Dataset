
rule MB_01f08f4b
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:01:30.097558"
        sha256 = "01f08f4b84932336ac315aadf3b4a87a6bbd9c94034f9525904b36b17b519707"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
