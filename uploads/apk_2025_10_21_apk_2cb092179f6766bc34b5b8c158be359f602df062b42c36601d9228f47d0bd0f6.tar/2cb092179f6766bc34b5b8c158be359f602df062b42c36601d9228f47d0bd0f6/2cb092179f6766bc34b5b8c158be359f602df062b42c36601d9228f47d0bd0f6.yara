
rule MB_2cb09217
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:42.147035"
        sha256 = "2cb092179f6766bc34b5b8c158be359f602df062b42c36601d9228f47d0bd0f6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
