
rule MB_31656b8a
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:11:25.891470"
        sha256 = "31656b8a21590093c702cd51eb2bcac013cf7dac62fbb2c51b773bcdaad31f61"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
