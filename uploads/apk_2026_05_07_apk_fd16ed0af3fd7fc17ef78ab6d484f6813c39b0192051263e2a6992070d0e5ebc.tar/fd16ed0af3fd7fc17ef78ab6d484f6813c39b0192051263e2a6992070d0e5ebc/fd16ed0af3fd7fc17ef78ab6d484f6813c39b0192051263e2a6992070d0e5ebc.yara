
rule MB_fd16ed0a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:41.481170"
        sha256 = "fd16ed0af3fd7fc17ef78ab6d484f6813c39b0192051263e2a6992070d0e5ebc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
