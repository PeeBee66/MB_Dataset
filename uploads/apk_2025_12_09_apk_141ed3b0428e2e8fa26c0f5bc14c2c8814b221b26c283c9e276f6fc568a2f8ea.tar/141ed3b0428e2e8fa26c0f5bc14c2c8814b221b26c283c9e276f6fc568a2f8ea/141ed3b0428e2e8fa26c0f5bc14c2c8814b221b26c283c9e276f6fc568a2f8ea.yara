
rule MB_141ed3b0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:29.848073"
        sha256 = "141ed3b0428e2e8fa26c0f5bc14c2c8814b221b26c283c9e276f6fc568a2f8ea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
