
rule MB_4b2b411e
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:45:11.142739"
        sha256 = "4b2b411e03aafaa19ea93286fadd39a5134f4a039db2d5019b1054547c0d5601"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
