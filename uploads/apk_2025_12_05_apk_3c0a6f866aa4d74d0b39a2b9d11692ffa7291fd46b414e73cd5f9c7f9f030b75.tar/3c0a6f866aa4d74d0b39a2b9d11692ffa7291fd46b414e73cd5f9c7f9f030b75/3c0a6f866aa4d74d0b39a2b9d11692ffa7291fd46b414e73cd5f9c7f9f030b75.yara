
rule MB_3c0a6f86
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:01:13.666480"
        sha256 = "3c0a6f866aa4d74d0b39a2b9d11692ffa7291fd46b414e73cd5f9c7f9f030b75"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
