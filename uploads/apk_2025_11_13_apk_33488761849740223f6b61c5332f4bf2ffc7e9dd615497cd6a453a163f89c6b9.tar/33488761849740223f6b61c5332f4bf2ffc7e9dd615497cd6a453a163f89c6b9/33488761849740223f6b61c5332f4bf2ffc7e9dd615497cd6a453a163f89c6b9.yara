
rule MB_33488761
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:41.728207"
        sha256 = "33488761849740223f6b61c5332f4bf2ffc7e9dd615497cd6a453a163f89c6b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
