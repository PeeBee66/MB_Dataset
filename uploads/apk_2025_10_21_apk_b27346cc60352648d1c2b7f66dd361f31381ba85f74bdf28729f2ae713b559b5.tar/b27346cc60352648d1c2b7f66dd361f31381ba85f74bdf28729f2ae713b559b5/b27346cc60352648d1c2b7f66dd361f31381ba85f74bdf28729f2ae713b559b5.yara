
rule MB_b27346cc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:12.037773"
        sha256 = "b27346cc60352648d1c2b7f66dd361f31381ba85f74bdf28729f2ae713b559b5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
