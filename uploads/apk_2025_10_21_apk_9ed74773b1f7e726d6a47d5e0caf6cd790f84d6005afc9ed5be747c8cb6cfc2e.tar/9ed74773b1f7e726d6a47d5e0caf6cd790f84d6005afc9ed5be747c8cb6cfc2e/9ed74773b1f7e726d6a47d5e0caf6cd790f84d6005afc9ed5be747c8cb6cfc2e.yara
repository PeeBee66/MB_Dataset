
rule MB_9ed74773
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:39:19.322820"
        sha256 = "9ed74773b1f7e726d6a47d5e0caf6cd790f84d6005afc9ed5be747c8cb6cfc2e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
