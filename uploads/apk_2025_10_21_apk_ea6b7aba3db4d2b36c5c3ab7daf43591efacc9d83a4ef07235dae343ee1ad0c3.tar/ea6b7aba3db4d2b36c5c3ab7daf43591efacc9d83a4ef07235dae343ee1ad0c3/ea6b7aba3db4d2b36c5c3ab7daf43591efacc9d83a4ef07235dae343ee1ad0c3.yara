
rule MB_ea6b7aba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:01.411367"
        sha256 = "ea6b7aba3db4d2b36c5c3ab7daf43591efacc9d83a4ef07235dae343ee1ad0c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
