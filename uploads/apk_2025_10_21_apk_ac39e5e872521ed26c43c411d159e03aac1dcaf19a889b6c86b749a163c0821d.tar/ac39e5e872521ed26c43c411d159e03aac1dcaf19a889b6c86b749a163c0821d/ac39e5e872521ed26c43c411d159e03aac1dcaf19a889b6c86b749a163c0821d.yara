
rule MB_ac39e5e8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:49.097673"
        sha256 = "ac39e5e872521ed26c43c411d159e03aac1dcaf19a889b6c86b749a163c0821d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
