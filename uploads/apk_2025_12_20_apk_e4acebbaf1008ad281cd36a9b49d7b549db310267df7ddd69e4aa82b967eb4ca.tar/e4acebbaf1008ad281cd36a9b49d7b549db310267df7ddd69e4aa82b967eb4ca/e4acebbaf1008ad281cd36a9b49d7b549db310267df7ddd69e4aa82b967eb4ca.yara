
rule MB_e4acebba
{
    meta:
        description = "Auto-generated rule for BankBot"
        author = "MB-Collector"
        date = "2025-12-19T23:00:42.405066"
        sha256 = "e4acebbaf1008ad281cd36a9b49d7b549db310267df7ddd69e4aa82b967eb4ca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
