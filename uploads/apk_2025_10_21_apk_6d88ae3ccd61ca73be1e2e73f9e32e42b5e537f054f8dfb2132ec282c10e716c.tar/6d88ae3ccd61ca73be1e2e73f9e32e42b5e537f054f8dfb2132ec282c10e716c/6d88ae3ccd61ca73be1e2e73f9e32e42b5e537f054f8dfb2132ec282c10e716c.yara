
rule MB_6d88ae3c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:26.977363"
        sha256 = "6d88ae3ccd61ca73be1e2e73f9e32e42b5e537f054f8dfb2132ec282c10e716c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
