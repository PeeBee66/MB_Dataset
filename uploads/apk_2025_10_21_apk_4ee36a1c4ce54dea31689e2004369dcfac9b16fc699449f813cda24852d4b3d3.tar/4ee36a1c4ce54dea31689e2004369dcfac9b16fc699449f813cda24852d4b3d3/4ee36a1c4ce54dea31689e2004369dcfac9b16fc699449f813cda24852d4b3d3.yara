
rule MB_4ee36a1c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:27.338394"
        sha256 = "4ee36a1c4ce54dea31689e2004369dcfac9b16fc699449f813cda24852d4b3d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
