
rule MB_8127c09e
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-01-04T23:00:16.299382"
        sha256 = "8127c09ea8b0e40aa49f9f1cbf52be0ed7323720792a528d4e12746b91f9766b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
