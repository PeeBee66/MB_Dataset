
rule MB_d37e6d13
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:22:55.014319"
        sha256 = "d37e6d13be9070f4715a3575c68c4d4262228109c20ce3c559a0d96258181450"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
