
rule MB_a6d9e6c7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:58.741280"
        sha256 = "a6d9e6c72d1f692780d184ba90ec9a57aedff60eb426c1f7bd29b0fa8aff61f2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
