
rule MB_c48dfdf4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:01:20.489750"
        sha256 = "c48dfdf4b80091611a199bb2880499d8b2fdac6e07df2f6bbfe74cefd10d4340"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
