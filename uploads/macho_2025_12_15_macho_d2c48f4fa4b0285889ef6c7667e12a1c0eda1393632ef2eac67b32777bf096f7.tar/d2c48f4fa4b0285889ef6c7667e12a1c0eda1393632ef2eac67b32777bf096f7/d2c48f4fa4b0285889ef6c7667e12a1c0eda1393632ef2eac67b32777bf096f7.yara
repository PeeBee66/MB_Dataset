
rule MB_d2c48f4f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-14T23:00:20.031126"
        sha256 = "d2c48f4fa4b0285889ef6c7667e12a1c0eda1393632ef2eac67b32777bf096f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
