
rule MB_d9b75d60
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-05T23:00:25.264969"
        sha256 = "d9b75d606803968d04015bed042da887905e9c1cb1b40b4ff11852b88c8b4d21"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
