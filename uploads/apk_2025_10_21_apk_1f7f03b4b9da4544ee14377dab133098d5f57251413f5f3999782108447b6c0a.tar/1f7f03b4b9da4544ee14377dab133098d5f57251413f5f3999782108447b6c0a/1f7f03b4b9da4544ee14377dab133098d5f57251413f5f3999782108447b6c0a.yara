
rule MB_1f7f03b4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:29.963184"
        sha256 = "1f7f03b4b9da4544ee14377dab133098d5f57251413f5f3999782108447b6c0a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
