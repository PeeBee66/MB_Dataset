
rule MB_c9e5baef
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:01:14.598732"
        sha256 = "c9e5baefd4916b4cbf73c45fa89d7458f00dee615a548d7f7a9c04bee6544ebf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
