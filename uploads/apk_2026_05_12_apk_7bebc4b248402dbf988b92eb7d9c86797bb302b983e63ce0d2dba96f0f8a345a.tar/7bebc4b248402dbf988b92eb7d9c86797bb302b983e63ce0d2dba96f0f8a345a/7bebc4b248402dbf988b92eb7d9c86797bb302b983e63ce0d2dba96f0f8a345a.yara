
rule MB_7bebc4b2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-12T00:00:13.603832"
        sha256 = "7bebc4b248402dbf988b92eb7d9c86797bb302b983e63ce0d2dba96f0f8a345a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
