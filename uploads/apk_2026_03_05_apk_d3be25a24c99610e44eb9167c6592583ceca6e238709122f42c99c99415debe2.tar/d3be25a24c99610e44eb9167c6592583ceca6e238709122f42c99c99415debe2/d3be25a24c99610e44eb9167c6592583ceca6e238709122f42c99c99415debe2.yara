
rule MB_d3be25a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:18.410673"
        sha256 = "d3be25a24c99610e44eb9167c6592583ceca6e238709122f42c99c99415debe2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
