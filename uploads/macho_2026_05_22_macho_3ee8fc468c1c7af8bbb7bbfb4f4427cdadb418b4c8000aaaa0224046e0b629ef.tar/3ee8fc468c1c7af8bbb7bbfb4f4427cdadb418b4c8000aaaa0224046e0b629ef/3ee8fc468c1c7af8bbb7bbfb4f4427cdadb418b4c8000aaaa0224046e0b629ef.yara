
rule MB_3ee8fc46
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:56.243443"
        sha256 = "3ee8fc468c1c7af8bbb7bbfb4f4427cdadb418b4c8000aaaa0224046e0b629ef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
