
rule MB_aae6837f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:57.674683"
        sha256 = "aae6837ffec783e20b0527407ab0e0fc78810cd6d78cf2f3bf5a611c1afbc083"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
