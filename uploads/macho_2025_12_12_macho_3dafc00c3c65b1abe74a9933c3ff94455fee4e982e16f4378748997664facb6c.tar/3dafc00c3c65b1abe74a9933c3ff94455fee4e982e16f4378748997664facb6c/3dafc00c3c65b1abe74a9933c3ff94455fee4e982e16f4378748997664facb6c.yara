
rule MB_3dafc00c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-11T23:00:37.254308"
        sha256 = "3dafc00c3c65b1abe74a9933c3ff94455fee4e982e16f4378748997664facb6c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
