
rule MB_7c35a601
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:38.440110"
        sha256 = "7c35a60136762d28c659950584a63295db3a524ffedb99fc0d5646d0a374cbba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
