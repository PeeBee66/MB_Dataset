
rule MB_55adf5e3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:27.922531"
        sha256 = "55adf5e3842ec5570accf590cb5d65ff46d59176ed7172ce901516b656221496"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
