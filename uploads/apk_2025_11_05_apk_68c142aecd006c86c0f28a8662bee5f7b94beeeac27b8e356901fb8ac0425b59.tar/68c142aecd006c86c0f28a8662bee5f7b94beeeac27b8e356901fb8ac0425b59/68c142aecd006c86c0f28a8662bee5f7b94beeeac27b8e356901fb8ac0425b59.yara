
rule MB_68c142ae
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:47.335171"
        sha256 = "68c142aecd006c86c0f28a8662bee5f7b94beeeac27b8e356901fb8ac0425b59"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
