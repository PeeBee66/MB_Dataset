
rule MB_91e97f78
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:48.367193"
        sha256 = "91e97f78d1700980e634f67d2abd46c65f315c49edf28de76263a9227bb443c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
