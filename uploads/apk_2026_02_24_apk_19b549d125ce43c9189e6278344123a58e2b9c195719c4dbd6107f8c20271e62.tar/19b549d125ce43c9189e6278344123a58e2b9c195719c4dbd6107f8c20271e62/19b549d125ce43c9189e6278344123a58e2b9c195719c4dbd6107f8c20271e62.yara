
rule MB_19b549d1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-23T23:00:17.657199"
        sha256 = "19b549d125ce43c9189e6278344123a58e2b9c195719c4dbd6107f8c20271e62"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
