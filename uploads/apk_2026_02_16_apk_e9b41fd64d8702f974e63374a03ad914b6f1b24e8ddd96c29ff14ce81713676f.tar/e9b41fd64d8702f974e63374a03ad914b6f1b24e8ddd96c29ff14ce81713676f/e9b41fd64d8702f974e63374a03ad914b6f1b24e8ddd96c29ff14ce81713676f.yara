
rule MB_e9b41fd6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-15T23:00:23.763183"
        sha256 = "e9b41fd64d8702f974e63374a03ad914b6f1b24e8ddd96c29ff14ce81713676f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
