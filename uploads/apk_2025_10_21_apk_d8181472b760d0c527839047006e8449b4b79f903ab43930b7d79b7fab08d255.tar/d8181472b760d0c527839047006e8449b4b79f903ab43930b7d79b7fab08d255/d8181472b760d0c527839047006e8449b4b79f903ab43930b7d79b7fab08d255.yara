
rule MB_d8181472
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:38.323466"
        sha256 = "d8181472b760d0c527839047006e8449b4b79f903ab43930b7d79b7fab08d255"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
