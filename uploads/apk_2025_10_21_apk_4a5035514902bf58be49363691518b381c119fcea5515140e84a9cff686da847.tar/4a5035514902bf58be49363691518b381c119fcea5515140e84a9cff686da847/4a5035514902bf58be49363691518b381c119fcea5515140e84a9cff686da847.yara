
rule MB_4a503551
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:27.418228"
        sha256 = "4a5035514902bf58be49363691518b381c119fcea5515140e84a9cff686da847"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
