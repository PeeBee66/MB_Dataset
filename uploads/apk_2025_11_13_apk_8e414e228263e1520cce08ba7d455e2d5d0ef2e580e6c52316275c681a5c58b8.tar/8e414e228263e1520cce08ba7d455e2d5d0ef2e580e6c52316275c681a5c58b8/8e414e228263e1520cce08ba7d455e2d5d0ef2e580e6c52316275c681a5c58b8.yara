
rule MB_8e414e22
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:20.826588"
        sha256 = "8e414e228263e1520cce08ba7d455e2d5d0ef2e580e6c52316275c681a5c58b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
