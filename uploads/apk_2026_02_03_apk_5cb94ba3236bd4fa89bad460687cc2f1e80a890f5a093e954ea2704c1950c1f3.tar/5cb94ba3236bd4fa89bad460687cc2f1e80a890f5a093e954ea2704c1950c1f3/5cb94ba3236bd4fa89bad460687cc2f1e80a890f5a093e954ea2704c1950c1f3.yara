
rule MB_5cb94ba3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:38.231627"
        sha256 = "5cb94ba3236bd4fa89bad460687cc2f1e80a890f5a093e954ea2704c1950c1f3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
