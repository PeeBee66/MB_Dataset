
rule MB_fbe4f64d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:06.751864"
        sha256 = "fbe4f64d30ec42097efb126f21fe4737546226978afb5d81a4108dbde65d1112"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
