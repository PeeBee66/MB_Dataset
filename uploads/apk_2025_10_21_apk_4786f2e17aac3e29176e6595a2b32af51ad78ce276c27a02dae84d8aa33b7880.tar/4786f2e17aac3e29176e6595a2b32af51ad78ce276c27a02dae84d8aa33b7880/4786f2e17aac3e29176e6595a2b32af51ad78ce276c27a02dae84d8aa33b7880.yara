
rule MB_4786f2e1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:54.217685"
        sha256 = "4786f2e17aac3e29176e6595a2b32af51ad78ce276c27a02dae84d8aa33b7880"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
