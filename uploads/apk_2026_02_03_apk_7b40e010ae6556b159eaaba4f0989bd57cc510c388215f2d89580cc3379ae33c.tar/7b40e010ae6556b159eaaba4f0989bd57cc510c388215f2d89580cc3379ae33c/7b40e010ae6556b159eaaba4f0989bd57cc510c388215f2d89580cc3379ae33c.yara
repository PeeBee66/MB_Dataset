
rule MB_7b40e010
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:13.859537"
        sha256 = "7b40e010ae6556b159eaaba4f0989bd57cc510c388215f2d89580cc3379ae33c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
