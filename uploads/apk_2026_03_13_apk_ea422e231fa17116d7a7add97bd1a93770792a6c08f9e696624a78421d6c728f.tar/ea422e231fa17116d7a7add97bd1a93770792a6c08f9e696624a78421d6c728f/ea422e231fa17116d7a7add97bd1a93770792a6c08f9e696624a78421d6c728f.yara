
rule MB_ea422e23
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:01:07.080676"
        sha256 = "ea422e231fa17116d7a7add97bd1a93770792a6c08f9e696624a78421d6c728f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
