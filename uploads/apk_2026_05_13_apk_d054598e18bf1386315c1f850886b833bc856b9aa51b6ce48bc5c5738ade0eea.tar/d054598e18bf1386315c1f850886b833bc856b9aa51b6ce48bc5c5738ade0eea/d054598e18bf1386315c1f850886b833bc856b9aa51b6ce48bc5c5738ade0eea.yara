
rule MB_d054598e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-13T00:00:13.591344"
        sha256 = "d054598e18bf1386315c1f850886b833bc856b9aa51b6ce48bc5c5738ade0eea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
