
rule MB_61344919
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:53.169190"
        sha256 = "61344919db462bc621d875887c68e748b42a5969b6d45b6539fb68dd7a66d408"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
