
rule MB_06171012
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:00:49.458951"
        sha256 = "061710123a06e34b280d0bb696950692a9cf2c92a54ea997551a9bb3d29ebde4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
