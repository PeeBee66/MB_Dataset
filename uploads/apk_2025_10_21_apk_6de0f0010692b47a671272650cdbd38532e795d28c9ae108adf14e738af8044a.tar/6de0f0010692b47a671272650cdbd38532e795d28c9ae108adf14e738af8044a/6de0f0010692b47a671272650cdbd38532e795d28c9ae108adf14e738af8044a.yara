
rule MB_6de0f001
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:54:48.807609"
        sha256 = "6de0f0010692b47a671272650cdbd38532e795d28c9ae108adf14e738af8044a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
