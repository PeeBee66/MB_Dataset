
rule MB_4f53997f
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:04:55.600549"
        sha256 = "4f53997faa7a60348ac82ff28c7581b93738ca641db6d887a8a1182bc1ce1712"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
