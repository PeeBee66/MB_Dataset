
rule MB_5a616700
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:24.075747"
        sha256 = "5a616700a3fa6a7a14bd38ae6155f53ba2e6578b772abfd8c8978fdb2bcaeb44"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
