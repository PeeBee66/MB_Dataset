
rule MB_002a0aa5
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:38.347093"
        sha256 = "002a0aa5d6c6e213af273f5348721d24afe743ec969e92a0bea87425d6056981"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
