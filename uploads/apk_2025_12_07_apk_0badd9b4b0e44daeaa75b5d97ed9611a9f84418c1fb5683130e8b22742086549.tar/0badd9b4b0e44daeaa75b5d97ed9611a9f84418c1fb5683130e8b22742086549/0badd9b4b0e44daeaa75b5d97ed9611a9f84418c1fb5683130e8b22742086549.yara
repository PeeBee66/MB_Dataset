
rule MB_0badd9b4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-06T23:00:40.936797"
        sha256 = "0badd9b4b0e44daeaa75b5d97ed9611a9f84418c1fb5683130e8b22742086549"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
