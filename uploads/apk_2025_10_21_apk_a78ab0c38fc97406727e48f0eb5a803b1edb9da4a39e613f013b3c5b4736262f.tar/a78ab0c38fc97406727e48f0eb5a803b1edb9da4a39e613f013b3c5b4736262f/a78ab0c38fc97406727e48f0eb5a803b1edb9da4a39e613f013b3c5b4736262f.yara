
rule MB_a78ab0c3
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:32:04.738805"
        sha256 = "a78ab0c38fc97406727e48f0eb5a803b1edb9da4a39e613f013b3c5b4736262f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
