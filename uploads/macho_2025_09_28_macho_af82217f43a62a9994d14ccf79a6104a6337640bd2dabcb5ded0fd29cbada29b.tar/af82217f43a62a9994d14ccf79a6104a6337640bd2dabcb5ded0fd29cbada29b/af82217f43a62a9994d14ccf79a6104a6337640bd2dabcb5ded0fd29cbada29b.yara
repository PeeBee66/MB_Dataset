
rule MB_af82217f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:09.175447"
        sha256 = "af82217f43a62a9994d14ccf79a6104a6337640bd2dabcb5ded0fd29cbada29b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
