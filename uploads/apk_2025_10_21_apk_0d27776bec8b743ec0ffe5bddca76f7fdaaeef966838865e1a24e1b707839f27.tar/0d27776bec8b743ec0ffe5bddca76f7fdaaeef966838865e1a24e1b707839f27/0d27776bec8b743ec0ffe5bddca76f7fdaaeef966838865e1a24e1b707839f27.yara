
rule MB_0d27776b
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:29:19.597098"
        sha256 = "0d27776bec8b743ec0ffe5bddca76f7fdaaeef966838865e1a24e1b707839f27"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
