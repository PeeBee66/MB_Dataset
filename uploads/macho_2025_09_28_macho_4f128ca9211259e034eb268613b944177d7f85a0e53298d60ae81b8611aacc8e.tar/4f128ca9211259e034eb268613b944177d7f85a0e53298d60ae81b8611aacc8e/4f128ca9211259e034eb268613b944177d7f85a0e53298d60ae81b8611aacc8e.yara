
rule MB_4f128ca9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:24.073321"
        sha256 = "4f128ca9211259e034eb268613b944177d7f85a0e53298d60ae81b8611aacc8e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
