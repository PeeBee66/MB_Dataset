
rule MB_17fabae3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-14T23:00:39.948675"
        sha256 = "17fabae3433c096512170c43493ad30870fe1c2ff507176d07e4ad088471582e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
