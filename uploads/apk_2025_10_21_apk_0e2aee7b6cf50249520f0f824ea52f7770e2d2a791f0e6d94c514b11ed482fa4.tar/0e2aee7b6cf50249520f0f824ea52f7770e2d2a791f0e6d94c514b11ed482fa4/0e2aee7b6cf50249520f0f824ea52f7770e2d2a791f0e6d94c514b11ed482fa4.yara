
rule MB_0e2aee7b
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:46:37.560302"
        sha256 = "0e2aee7b6cf50249520f0f824ea52f7770e2d2a791f0e6d94c514b11ed482fa4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
