
rule MB_85bed283
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-22T00:00:50.771974"
        sha256 = "85bed283ba95d40d99e79437e6a3161336c94ec0acbc0cd38599d0fc9b2e393c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
