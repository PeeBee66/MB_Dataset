
rule MB_37184910
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:00:25.026595"
        sha256 = "371849109d64a72f05d42573890d1c6826bf6921b961ced32caf4b038eccbdde"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
