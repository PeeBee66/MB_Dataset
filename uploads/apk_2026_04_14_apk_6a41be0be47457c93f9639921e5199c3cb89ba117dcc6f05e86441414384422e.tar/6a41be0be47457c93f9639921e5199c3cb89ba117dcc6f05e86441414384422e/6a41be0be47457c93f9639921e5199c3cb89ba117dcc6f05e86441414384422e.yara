
rule MB_6a41be0b
{
    meta:
        description = "Auto-generated rule for Herodotus"
        author = "MB-Collector"
        date = "2026-04-14T00:00:22.040389"
        sha256 = "6a41be0be47457c93f9639921e5199c3cb89ba117dcc6f05e86441414384422e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
