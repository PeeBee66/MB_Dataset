
rule MB_9a607850
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:00:31.109766"
        sha256 = "9a607850b33ca84a9296d280bcf10e02541d269e3723c003baba8d279b0abe15"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
