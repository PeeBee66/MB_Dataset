
rule MB_1929e224
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:00:53.347086"
        sha256 = "1929e224e17e121829d53d4a5fa7c253de92bb5f1859684eeddad926a0b92fed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
