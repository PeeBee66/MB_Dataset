
rule MB_33b18fc3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:19.425650"
        sha256 = "33b18fc3cd932e84288473359d0fff63d35bf3c29e5d19580168fa78059417ad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
