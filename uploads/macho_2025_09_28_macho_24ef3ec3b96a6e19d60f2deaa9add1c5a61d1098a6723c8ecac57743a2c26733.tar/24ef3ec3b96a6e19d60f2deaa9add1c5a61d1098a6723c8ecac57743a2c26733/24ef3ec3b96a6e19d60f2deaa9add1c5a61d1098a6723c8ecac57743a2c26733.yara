
rule MB_24ef3ec3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:13.053839"
        sha256 = "24ef3ec3b96a6e19d60f2deaa9add1c5a61d1098a6723c8ecac57743a2c26733"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
