
rule MB_d381074c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:01.521293"
        sha256 = "d381074c4202ebc33e2b42fe61611de2b114d7e1daa8b91a62fd2ad623027686"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
