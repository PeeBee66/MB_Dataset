
rule MB_d005f232
{
    meta:
        description = "Auto-generated rule for 888rat"
        author = "MB-Collector"
        date = "2025-10-20T11:51:29.496342"
        sha256 = "d005f232dba733233480510687d2e1e7b3857347a8416ae82db9daa1404e6f38"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
