
rule MB_f3d745f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:33.530450"
        sha256 = "f3d745f693f29c15c2da62a42fadea92055577aca061fd73090c1a7d2533b82e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
