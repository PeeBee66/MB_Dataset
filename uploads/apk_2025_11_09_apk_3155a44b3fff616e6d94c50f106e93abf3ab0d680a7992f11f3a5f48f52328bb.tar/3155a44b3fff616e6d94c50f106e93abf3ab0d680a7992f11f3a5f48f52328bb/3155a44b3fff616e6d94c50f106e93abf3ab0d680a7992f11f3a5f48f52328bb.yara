
rule MB_3155a44b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-08T23:00:24.948243"
        sha256 = "3155a44b3fff616e6d94c50f106e93abf3ab0d680a7992f11f3a5f48f52328bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
