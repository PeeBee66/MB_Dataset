
rule MB_e163a088
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-05T23:00:29.434959"
        sha256 = "e163a088d174d4eb41479b53e6df04831dc40899b893a0b183d080d2dfe52cd7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
