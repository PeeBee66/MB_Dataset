
rule MB_6f5f2fe5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:36.003727"
        sha256 = "6f5f2fe579dfeee04901aea62e1a167b3399877b74cbee1d291dc94eea696ce9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
