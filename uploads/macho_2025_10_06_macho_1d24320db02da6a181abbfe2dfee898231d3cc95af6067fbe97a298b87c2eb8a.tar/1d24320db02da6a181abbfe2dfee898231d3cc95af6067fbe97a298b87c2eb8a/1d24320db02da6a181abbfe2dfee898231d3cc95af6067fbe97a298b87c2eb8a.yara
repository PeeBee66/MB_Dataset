
rule MB_1d24320d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:27.203312"
        sha256 = "1d24320db02da6a181abbfe2dfee898231d3cc95af6067fbe97a298b87c2eb8a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
