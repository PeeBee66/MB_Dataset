
rule MB_5c852fd7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-22T23:00:13.757700"
        sha256 = "5c852fd7458957b89d9b639c6cdede1dc9ab72c384661c4ebc0b3d201344133c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
