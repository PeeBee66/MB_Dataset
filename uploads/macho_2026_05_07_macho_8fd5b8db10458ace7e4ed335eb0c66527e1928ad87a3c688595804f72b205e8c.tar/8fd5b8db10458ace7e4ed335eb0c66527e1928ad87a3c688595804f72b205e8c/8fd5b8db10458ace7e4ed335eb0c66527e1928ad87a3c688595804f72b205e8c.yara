
rule MB_8fd5b8db
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:37.877429"
        sha256 = "8fd5b8db10458ace7e4ed335eb0c66527e1928ad87a3c688595804f72b205e8c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
