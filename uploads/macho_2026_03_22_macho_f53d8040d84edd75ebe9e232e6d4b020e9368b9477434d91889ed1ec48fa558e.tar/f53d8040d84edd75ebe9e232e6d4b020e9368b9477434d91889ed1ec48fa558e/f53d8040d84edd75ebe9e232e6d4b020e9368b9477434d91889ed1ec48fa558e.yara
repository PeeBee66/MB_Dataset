
rule MB_f53d8040
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:06.727840"
        sha256 = "f53d8040d84edd75ebe9e232e6d4b020e9368b9477434d91889ed1ec48fa558e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
