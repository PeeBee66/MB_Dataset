
rule MB_17fc5d1c
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-12-01T23:01:08.807448"
        sha256 = "17fc5d1c8bd8b10471131282e42ec289bb1e1ee107ca676f369bb42fc3643af3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
