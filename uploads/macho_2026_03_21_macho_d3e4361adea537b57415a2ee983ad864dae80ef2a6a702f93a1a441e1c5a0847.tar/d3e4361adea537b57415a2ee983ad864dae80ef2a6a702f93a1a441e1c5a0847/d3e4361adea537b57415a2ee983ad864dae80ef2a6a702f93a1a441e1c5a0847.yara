
rule MB_d3e4361a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:00:28.022925"
        sha256 = "d3e4361adea537b57415a2ee983ad864dae80ef2a6a702f93a1a441e1c5a0847"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
