
rule MB_6d2d48d2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:42.547163"
        sha256 = "6d2d48d24070647c7621b38f927f05454688bba2d2dd5cdaa8a93246595cef5f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
