
rule MB_3e6edebc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-27T23:00:20.087555"
        sha256 = "3e6edebc2da9a4a80507eeb7abf529c9c3a70201927f1ae864f9f257ca64bc2e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
