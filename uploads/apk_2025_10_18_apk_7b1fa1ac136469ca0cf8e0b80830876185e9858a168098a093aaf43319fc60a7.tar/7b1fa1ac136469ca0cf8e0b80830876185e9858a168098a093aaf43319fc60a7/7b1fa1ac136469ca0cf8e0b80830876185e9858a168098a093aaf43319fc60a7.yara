
rule MB_7b1fa1ac
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-17T23:00:31.947158"
        sha256 = "7b1fa1ac136469ca0cf8e0b80830876185e9858a168098a093aaf43319fc60a7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
