
rule MB_abf62033
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-27T00:00:17.901286"
        sha256 = "abf62033c4b913bf8368de607fdc4dd2677f9441541db3c2a9375dd9130ff9bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
