
rule MB_4d751dd3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:01:00.970255"
        sha256 = "4d751dd363298589cb436d78cd302f9d794ae1e3670722a464884be908671a9c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
