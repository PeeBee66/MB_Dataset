
rule MB_948e359c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:38.896344"
        sha256 = "948e359c1e7c46e6b60e479a8e54b203399f9655c329a6595ec46a3c7a932079"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
