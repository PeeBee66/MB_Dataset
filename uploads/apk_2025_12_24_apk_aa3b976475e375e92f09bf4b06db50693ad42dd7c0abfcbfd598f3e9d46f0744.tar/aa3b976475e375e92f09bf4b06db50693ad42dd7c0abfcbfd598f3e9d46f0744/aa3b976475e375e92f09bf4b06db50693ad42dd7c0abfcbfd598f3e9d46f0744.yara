
rule MB_aa3b9764
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:25.595024"
        sha256 = "aa3b976475e375e92f09bf4b06db50693ad42dd7c0abfcbfd598f3e9d46f0744"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
