
rule MB_923ab14a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:06:40.746189"
        sha256 = "923ab14afe5d68aa3fbf669237fbac5a214feabd6b71d1628196b85a7c3f431d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
