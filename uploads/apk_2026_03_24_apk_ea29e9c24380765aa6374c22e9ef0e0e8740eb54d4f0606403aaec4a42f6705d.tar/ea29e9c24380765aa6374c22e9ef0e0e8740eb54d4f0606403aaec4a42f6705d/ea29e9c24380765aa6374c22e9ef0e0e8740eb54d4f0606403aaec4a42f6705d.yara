
rule MB_ea29e9c2
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:55.116979"
        sha256 = "ea29e9c24380765aa6374c22e9ef0e0e8740eb54d4f0606403aaec4a42f6705d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
