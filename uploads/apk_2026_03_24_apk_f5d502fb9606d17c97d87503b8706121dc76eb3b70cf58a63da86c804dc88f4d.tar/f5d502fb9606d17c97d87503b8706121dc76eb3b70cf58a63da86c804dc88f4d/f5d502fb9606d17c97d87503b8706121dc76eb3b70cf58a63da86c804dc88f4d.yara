
rule MB_f5d502fb
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:34.715205"
        sha256 = "f5d502fb9606d17c97d87503b8706121dc76eb3b70cf58a63da86c804dc88f4d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
