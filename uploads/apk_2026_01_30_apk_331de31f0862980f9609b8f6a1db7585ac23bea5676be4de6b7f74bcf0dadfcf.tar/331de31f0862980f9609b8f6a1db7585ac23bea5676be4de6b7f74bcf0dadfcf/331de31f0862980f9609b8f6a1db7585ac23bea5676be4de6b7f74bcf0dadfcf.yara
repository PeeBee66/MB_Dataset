
rule MB_331de31f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:28.241348"
        sha256 = "331de31f0862980f9609b8f6a1db7585ac23bea5676be4de6b7f74bcf0dadfcf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
