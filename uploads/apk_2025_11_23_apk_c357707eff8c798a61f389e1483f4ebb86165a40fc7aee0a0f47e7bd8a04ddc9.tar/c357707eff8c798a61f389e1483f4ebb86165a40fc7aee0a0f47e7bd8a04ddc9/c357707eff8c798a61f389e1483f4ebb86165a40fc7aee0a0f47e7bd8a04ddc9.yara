
rule MB_c357707e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:47.212715"
        sha256 = "c357707eff8c798a61f389e1483f4ebb86165a40fc7aee0a0f47e7bd8a04ddc9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
