
rule MB_5ebd725d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:54.376827"
        sha256 = "5ebd725d3b158d56d9629a6226b8d7cd3dae030cfbb7c4b506308f6d4c6b6eca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
