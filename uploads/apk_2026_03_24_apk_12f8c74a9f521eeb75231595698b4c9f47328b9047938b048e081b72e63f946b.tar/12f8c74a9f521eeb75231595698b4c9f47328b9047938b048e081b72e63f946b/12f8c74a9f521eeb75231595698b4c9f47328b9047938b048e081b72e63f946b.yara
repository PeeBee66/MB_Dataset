
rule MB_12f8c74a
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:13.575294"
        sha256 = "12f8c74a9f521eeb75231595698b4c9f47328b9047938b048e081b72e63f946b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
