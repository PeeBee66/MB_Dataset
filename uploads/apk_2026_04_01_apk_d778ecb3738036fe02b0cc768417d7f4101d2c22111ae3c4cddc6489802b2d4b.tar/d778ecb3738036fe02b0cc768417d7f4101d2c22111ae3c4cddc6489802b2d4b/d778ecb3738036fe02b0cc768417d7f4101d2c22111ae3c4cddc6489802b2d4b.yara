
rule MB_d778ecb3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-31T23:00:18.669682"
        sha256 = "d778ecb3738036fe02b0cc768417d7f4101d2c22111ae3c4cddc6489802b2d4b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
