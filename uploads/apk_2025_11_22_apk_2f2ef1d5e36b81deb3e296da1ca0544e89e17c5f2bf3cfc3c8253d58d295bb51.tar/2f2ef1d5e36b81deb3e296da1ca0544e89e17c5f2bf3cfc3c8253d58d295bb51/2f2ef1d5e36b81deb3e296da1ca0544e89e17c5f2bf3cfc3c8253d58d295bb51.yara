
rule MB_2f2ef1d5
{
    meta:
        description = "Auto-generated rule for LazarusStealer"
        author = "MB-Collector"
        date = "2025-11-21T23:00:12.435838"
        sha256 = "2f2ef1d5e36b81deb3e296da1ca0544e89e17c5f2bf3cfc3c8253d58d295bb51"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
