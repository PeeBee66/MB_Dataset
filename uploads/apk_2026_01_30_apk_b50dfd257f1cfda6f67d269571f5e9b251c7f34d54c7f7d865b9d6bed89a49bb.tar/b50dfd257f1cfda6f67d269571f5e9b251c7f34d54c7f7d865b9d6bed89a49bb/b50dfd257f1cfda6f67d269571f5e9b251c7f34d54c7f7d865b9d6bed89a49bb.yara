
rule MB_b50dfd25
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:01:19.068465"
        sha256 = "b50dfd257f1cfda6f67d269571f5e9b251c7f34d54c7f7d865b9d6bed89a49bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
