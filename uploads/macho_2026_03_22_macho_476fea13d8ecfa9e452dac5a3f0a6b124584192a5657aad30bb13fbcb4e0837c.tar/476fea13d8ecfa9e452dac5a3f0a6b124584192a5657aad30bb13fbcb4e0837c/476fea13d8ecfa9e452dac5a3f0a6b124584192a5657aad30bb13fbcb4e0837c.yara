
rule MB_476fea13
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:01:06.415714"
        sha256 = "476fea13d8ecfa9e452dac5a3f0a6b124584192a5657aad30bb13fbcb4e0837c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
