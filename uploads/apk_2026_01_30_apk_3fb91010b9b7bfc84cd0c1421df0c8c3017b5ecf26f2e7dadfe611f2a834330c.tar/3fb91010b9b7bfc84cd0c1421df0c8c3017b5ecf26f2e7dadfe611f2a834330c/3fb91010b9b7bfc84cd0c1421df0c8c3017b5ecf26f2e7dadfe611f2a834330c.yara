
rule MB_3fb91010
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:48.366574"
        sha256 = "3fb91010b9b7bfc84cd0c1421df0c8c3017b5ecf26f2e7dadfe611f2a834330c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
