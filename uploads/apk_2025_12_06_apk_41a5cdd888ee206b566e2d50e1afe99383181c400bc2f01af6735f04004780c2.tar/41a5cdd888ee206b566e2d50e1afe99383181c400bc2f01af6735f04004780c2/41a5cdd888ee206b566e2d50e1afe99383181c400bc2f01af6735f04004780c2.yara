
rule MB_41a5cdd8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-05T23:00:21.116071"
        sha256 = "41a5cdd888ee206b566e2d50e1afe99383181c400bc2f01af6735f04004780c2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
