
rule MB_6fa27245
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:13.786104"
        sha256 = "6fa272457cbcf5f200f58e9e8f46e0bd702e9e627f5dc2378a7e56b65d410e1d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
