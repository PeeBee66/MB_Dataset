
rule MB_2b6d2074
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-28T23:00:42.425068"
        sha256 = "2b6d20746ed11f62b35a7c29d1912de18248e9e10247c29a6ee0929877a57d77"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
