
rule MB_bb7cfd52
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:05:43.362537"
        sha256 = "bb7cfd52964a0d103f1fa88cc333bc1b9c80389d56ca2c1be6d0150397cc2096"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
