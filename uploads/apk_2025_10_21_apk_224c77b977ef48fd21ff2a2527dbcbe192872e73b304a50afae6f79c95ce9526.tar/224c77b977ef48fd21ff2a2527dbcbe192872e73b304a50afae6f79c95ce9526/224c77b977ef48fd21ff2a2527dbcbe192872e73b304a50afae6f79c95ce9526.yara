
rule MB_224c77b9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:20:14.961860"
        sha256 = "224c77b977ef48fd21ff2a2527dbcbe192872e73b304a50afae6f79c95ce9526"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
