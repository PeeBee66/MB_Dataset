
rule MB_8314ece9
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-28T23:00:17.368074"
        sha256 = "8314ece95207ff28466d4fc8bf6cef22cc6e28fef47e9bede381b502f038b552"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
