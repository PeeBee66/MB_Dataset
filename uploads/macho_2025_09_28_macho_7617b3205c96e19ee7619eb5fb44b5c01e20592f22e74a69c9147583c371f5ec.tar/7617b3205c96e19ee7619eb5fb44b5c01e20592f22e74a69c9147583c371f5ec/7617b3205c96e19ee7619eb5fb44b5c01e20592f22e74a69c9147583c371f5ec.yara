
rule MB_7617b320
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:32.149749"
        sha256 = "7617b3205c96e19ee7619eb5fb44b5c01e20592f22e74a69c9147583c371f5ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
