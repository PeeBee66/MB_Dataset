
rule MB_31e59832
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:00:26.307420"
        sha256 = "31e598329b51d2b0caaf1c78f09c2dc986f66509a1e4c5302391bcff5deaff1e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
