
rule MB_f52d870f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:16.874128"
        sha256 = "f52d870f879f27274393f89e1cd69ba8a8bd04d953f6865fb4862fb9d64286be"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
