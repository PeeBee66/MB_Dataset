
rule MB_442886c6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:50.381423"
        sha256 = "442886c68c78b7e5031a952801dd09476c518f99d6ce460fb8634895ba299b2d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
