
rule MB_23b249c4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:19.237633"
        sha256 = "23b249c408fd2cceba3d47965a8c71ca404457ae8c8651b433816d1c1f387818"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
