
rule MB_4c894a05
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:10.166016"
        sha256 = "4c894a056ff7b09389f7c0efaddc047d11c2e799d4e96b4c59528e0c3db2a077"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
