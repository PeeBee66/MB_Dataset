
rule MB_fe8a7349
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:25.792699"
        sha256 = "fe8a73497c0604f236298b7e78540a67319b0b9eb2b1a85453b66821a8aa8e70"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
