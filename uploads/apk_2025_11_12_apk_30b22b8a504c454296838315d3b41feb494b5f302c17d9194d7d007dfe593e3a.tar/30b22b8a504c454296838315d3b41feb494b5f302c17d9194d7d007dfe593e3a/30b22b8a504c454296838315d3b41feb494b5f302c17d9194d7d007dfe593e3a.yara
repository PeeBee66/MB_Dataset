
rule MB_30b22b8a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:32.103734"
        sha256 = "30b22b8a504c454296838315d3b41feb494b5f302c17d9194d7d007dfe593e3a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
