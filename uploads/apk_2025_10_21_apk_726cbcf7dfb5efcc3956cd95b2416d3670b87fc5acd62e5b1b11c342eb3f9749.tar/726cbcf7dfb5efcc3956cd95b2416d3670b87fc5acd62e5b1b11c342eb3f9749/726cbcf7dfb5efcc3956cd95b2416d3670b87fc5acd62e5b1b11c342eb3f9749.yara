
rule MB_726cbcf7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:45:21.526332"
        sha256 = "726cbcf7dfb5efcc3956cd95b2416d3670b87fc5acd62e5b1b11c342eb3f9749"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
