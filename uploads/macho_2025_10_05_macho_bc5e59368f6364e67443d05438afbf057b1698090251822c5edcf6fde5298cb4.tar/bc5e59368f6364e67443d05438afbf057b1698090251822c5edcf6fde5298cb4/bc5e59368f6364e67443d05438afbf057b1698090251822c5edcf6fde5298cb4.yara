
rule MB_bc5e5936
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:24.849722"
        sha256 = "bc5e59368f6364e67443d05438afbf057b1698090251822c5edcf6fde5298cb4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
