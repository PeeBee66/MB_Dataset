
rule MB_31b0624d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:00:16.163687"
        sha256 = "31b0624d16882eec282adc3817b18e4c8b3c80a9dbaa82e057a902cf7a27732b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
