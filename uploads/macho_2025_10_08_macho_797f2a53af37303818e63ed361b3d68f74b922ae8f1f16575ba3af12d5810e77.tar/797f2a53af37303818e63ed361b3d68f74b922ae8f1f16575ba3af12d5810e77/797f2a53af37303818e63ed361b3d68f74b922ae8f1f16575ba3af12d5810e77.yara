
rule MB_797f2a53
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:00.037301"
        sha256 = "797f2a53af37303818e63ed361b3d68f74b922ae8f1f16575ba3af12d5810e77"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
