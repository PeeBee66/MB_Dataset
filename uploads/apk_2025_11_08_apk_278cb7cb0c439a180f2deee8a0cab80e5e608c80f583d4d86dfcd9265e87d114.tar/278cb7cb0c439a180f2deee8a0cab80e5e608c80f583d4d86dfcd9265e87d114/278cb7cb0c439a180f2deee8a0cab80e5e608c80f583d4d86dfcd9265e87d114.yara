
rule MB_278cb7cb
{
    meta:
        description = "Auto-generated rule for ClayRAT"
        author = "MB-Collector"
        date = "2025-11-07T23:00:39.021218"
        sha256 = "278cb7cb0c439a180f2deee8a0cab80e5e608c80f583d4d86dfcd9265e87d114"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
