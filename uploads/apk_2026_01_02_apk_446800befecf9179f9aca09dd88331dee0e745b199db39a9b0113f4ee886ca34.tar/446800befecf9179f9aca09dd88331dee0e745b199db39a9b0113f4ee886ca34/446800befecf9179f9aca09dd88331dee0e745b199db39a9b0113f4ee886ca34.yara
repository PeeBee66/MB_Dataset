
rule MB_446800be
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-01T23:00:12.544524"
        sha256 = "446800befecf9179f9aca09dd88331dee0e745b199db39a9b0113f4ee886ca34"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
