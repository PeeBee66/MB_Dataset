
rule MB_0143bd24
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:01:04.598518"
        sha256 = "0143bd249e3195c08f34fcdb78e7e63b1c743f7d7c5ac4d1554788ace62374a6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
