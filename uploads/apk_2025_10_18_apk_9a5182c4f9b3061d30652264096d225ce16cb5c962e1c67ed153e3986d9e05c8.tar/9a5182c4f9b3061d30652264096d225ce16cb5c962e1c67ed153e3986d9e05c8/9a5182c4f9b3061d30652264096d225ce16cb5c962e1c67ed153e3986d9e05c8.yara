
rule MB_9a5182c4
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-17T23:00:36.430354"
        sha256 = "9a5182c4f9b3061d30652264096d225ce16cb5c962e1c67ed153e3986d9e05c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
