
rule MB_65336d04
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:46.373397"
        sha256 = "65336d043397311f7995ff147fdc769bd8f6ac49ad8d09b4e716adeff560ec5c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
