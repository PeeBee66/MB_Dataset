
rule MB_a0610f08
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-25T23:00:21.968044"
        sha256 = "a0610f08c783ff5486a66022fedf483e1ac81dfe48935680b5d9d29b309338c5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
