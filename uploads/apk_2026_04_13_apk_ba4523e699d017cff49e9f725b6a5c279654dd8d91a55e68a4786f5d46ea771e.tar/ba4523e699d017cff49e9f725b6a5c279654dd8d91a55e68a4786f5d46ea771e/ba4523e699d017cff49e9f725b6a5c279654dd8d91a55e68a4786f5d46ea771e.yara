
rule MB_ba4523e6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-13T00:00:18.409648"
        sha256 = "ba4523e699d017cff49e9f725b6a5c279654dd8d91a55e68a4786f5d46ea771e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
