
rule MB_e4a64874
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:09.628608"
        sha256 = "e4a64874fcf3ab34410c3b5a415d1f49ab3ed61ac0ca18e2dab1aca8806806aa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
