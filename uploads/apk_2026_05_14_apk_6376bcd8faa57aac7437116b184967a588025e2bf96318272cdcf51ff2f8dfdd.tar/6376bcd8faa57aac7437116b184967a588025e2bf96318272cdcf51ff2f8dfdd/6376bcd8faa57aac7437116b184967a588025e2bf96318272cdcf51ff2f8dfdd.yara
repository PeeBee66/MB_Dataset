
rule MB_6376bcd8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-14T00:00:20.298383"
        sha256 = "6376bcd8faa57aac7437116b184967a588025e2bf96318272cdcf51ff2f8dfdd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
