
rule MB_abca2eeb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-04T23:00:36.996699"
        sha256 = "abca2eeb4070fa29f5cec8217d7c938973a8ecb184138aa83d3180bb4cfd8832"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
