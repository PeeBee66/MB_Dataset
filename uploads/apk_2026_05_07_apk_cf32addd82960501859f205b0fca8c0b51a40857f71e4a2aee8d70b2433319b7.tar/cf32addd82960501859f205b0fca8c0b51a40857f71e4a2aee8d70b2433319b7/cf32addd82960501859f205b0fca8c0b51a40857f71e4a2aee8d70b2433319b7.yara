
rule MB_cf32addd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:04.109200"
        sha256 = "cf32addd82960501859f205b0fca8c0b51a40857f71e4a2aee8d70b2433319b7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
