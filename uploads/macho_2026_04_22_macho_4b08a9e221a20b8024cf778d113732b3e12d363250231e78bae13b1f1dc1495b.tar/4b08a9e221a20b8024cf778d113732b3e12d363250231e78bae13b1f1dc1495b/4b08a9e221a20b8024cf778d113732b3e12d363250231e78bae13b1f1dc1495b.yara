
rule MB_4b08a9e2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-22T00:01:00.837931"
        sha256 = "4b08a9e221a20b8024cf778d113732b3e12d363250231e78bae13b1f1dc1495b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
