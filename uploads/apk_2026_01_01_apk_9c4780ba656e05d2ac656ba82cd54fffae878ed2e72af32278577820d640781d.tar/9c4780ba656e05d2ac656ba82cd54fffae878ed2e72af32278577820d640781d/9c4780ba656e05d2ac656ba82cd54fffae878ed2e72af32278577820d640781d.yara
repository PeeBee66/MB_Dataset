
rule MB_9c4780ba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-31T23:00:23.561971"
        sha256 = "9c4780ba656e05d2ac656ba82cd54fffae878ed2e72af32278577820d640781d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
