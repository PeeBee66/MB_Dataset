
rule MB_aa264d6f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:54.766541"
        sha256 = "aa264d6f85a121013d96bf0fe81239c328ae49c5965f49a91ca9049b968b2db8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
