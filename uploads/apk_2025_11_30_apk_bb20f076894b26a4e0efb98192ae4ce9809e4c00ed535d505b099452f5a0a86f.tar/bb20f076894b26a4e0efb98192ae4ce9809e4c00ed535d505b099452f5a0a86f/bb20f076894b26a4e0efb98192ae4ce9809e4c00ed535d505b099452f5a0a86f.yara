
rule MB_bb20f076
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:54.569583"
        sha256 = "bb20f076894b26a4e0efb98192ae4ce9809e4c00ed535d505b099452f5a0a86f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
