
rule MB_43609f03
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:01:13.156748"
        sha256 = "43609f03274c4816abf18780eb3f4502061468d2d8b4bb2487b526008e981c85"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
