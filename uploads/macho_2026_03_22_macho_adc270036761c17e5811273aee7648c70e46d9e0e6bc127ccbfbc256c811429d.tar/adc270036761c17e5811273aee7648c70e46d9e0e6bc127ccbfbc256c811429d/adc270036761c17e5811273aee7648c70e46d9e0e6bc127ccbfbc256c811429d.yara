
rule MB_adc27003
{
    meta:
        description = "Auto-generated rule for PEASS-NG"
        author = "MB-Collector"
        date = "2026-03-21T23:01:02.558968"
        sha256 = "adc270036761c17e5811273aee7648c70e46d9e0e6bc127ccbfbc256c811429d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
