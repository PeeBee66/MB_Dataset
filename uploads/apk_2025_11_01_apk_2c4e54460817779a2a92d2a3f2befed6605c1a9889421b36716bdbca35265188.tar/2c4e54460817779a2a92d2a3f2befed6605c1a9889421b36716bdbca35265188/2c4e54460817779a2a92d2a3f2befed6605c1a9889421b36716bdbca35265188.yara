
rule MB_2c4e5446
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:43.823369"
        sha256 = "2c4e54460817779a2a92d2a3f2befed6605c1a9889421b36716bdbca35265188"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
