
rule MB_75b4d9eb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:01:10.396993"
        sha256 = "75b4d9eb26ed9e20009c9a55a58e66457d7ec4d7d060179f09f6522e96c62e2e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
