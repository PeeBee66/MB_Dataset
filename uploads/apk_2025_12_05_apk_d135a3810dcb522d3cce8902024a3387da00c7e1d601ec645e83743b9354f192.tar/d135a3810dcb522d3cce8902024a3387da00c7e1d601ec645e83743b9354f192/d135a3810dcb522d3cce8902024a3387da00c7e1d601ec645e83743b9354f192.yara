
rule MB_d135a381
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:48.396441"
        sha256 = "d135a3810dcb522d3cce8902024a3387da00c7e1d601ec645e83743b9354f192"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
