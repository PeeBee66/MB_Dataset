
rule MB_4de76b01
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:52.961157"
        sha256 = "4de76b01bd2979d8e9585fe299ce1686627c2afea3d3fb09e09e131763f527d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
