
rule MB_28dd893b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:23.948469"
        sha256 = "28dd893bc360bd459025d7aa23beca5ac7394b9c6352702ea7830de39fbcce3a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
