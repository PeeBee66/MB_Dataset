
rule MB_b008e305
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-01-21T23:00:15.691247"
        sha256 = "b008e30590725d6a5bde09ebad2cfe6ff0b002b16b3b93fe9150a608a180f511"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
