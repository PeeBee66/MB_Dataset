
rule MB_eeca170d
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:04.947282"
        sha256 = "eeca170dca7ea9aec9883f5600c41bc75bb64ecac91bcf5d65f2132e59e6a9ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
