
rule MB_a2aadcd1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:39:11.189353"
        sha256 = "a2aadcd1148dd0f01d41514cfbe3ff3863032963e56842e4ece665d9c6b67459"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
