
rule MB_0b7f4c3b
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:05:28.362069"
        sha256 = "0b7f4c3be1d0b0f0b53495ff33e8c4b22adf122e01f8c72d705c489a975fe498"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
