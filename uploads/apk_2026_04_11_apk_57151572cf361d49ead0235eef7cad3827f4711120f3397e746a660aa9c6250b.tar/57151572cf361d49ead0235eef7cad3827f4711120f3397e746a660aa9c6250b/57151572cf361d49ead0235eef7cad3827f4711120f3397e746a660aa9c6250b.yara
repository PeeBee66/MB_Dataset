
rule MB_57151572
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:00:56.088384"
        sha256 = "57151572cf361d49ead0235eef7cad3827f4711120f3397e746a660aa9c6250b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
