
rule MB_4cf809b1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-13T00:00:22.256630"
        sha256 = "4cf809b14083143e921bd8fdb7e7725e20e303653d9a3e6c848d9596a33f6c8e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
