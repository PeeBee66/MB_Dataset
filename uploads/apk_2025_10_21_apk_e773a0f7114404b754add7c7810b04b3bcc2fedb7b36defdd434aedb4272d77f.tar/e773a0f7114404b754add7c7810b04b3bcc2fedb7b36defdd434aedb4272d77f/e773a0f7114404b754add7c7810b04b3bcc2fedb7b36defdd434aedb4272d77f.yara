
rule MB_e773a0f7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:16.676549"
        sha256 = "e773a0f7114404b754add7c7810b04b3bcc2fedb7b36defdd434aedb4272d77f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
