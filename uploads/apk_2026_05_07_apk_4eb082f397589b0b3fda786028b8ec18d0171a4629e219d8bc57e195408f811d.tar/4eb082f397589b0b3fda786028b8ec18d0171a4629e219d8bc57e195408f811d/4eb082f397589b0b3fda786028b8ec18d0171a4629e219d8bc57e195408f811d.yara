
rule MB_4eb082f3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:12.419380"
        sha256 = "4eb082f397589b0b3fda786028b8ec18d0171a4629e219d8bc57e195408f811d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
