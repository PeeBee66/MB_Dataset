
rule MB_1d73ddec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:53.197355"
        sha256 = "1d73ddece0d84c3e590d989f0025532857e492b58d811e1492b5c719c0dc7c1c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
