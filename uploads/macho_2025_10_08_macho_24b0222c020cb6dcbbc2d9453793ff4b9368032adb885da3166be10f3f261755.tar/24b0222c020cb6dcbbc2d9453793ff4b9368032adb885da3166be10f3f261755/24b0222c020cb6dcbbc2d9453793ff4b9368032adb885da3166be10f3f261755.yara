
rule MB_24b0222c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:31.089318"
        sha256 = "24b0222c020cb6dcbbc2d9453793ff4b9368032adb885da3166be10f3f261755"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
