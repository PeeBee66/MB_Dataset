
rule MB_71397dda
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:30.434656"
        sha256 = "71397dda0ea5d1a26cff325f56cc24e82718a966fa6a548bc5710ade8e6519b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
