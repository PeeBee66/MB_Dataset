
rule MB_04a162a5
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:01:44.610744"
        sha256 = "04a162a5b7da204dcb3c099294fa3cf502af6f925073d0edddc30e98993f505f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
