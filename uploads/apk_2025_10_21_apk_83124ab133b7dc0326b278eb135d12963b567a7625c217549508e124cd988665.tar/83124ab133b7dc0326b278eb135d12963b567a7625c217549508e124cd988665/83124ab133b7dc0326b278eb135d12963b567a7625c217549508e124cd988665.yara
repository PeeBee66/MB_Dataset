
rule MB_83124ab1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:25.993387"
        sha256 = "83124ab133b7dc0326b278eb135d12963b567a7625c217549508e124cd988665"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
