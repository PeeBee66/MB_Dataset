
rule MB_293cfa14
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:25.078257"
        sha256 = "293cfa1492f67730ef54ad9d89642c2524792bdf70789808c84341dbe8cc8638"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
