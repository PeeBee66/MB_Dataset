
rule MB_4cf416ef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:29.086164"
        sha256 = "4cf416efc71277c8a5e16e91aff941917d6e98ffd0ba88c06466325743ddfb80"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
