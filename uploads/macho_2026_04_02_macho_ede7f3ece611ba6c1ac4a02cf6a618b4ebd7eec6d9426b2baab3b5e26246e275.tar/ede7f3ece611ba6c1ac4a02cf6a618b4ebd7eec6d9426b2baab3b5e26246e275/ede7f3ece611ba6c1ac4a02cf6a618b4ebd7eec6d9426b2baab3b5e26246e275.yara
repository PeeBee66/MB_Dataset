
rule MB_ede7f3ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-01T23:01:00.198699"
        sha256 = "ede7f3ece611ba6c1ac4a02cf6a618b4ebd7eec6d9426b2baab3b5e26246e275"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
