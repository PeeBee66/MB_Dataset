
rule MB_a994b966
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:46.954594"
        sha256 = "a994b9664d2f0b664f7e97e2a6ca7f1d2ddff8888e2bff7313e75766260fb164"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
