
rule MB_214ffeff
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:54:54.398273"
        sha256 = "214ffeff218180c2d34bd0af11474bcc54cedcbc00364faaa7256311e512a114"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
