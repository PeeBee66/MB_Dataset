
rule MB_618d8b4c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:04.075009"
        sha256 = "618d8b4c1be86ea20c9971a3d23c6362e4fdc9a3c032409022b02645a54c2c9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
