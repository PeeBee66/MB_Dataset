
rule MB_839185a9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:43.171389"
        sha256 = "839185a918e0a4c27020897c8b207caab7448651187a9d528ef6d41eaa9d35b1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
