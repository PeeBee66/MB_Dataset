
rule MB_ebf32ae1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:21.550214"
        sha256 = "ebf32ae1637e79af8cf68c94b1b199212d4bfd0332e3fb3f811ea863baa9bdb4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
