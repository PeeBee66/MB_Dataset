
rule MB_9a778fbb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-06T00:00:29.213496"
        sha256 = "9a778fbb730ee653f45b36700a369c81792509f855c2529aca73de1443c62de8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
