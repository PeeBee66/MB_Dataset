
rule MB_678ee44a
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:00:51.244344"
        sha256 = "678ee44afb89903d3199378f2e6d9de0b4167c23e548bf4d7f863e1545ef912e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
