
rule MB_16f961b4
{
    meta:
        description = "Auto-generated rule for SuperCardX"
        author = "MB-Collector"
        date = "2026-04-25T00:00:30.773848"
        sha256 = "16f961b4f3f974109ae0de2546b092138bd29dcc1b8ec12efc487d34ddea2bd4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
