
rule MB_2f34843d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:35.293343"
        sha256 = "2f34843df1e01625f34027abf947d256b97a4064398e8a83a891868938867580"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
