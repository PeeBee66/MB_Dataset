
rule MB_2756ceb2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:05.502389"
        sha256 = "2756ceb20a6e282b37caf0525ec0d76e86bc015f27508c9a24aaf9245021e1bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
