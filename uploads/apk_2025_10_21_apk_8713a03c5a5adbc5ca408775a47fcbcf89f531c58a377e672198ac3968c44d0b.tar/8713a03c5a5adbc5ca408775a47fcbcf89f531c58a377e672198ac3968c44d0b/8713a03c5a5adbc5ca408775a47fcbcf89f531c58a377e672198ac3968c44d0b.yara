
rule MB_8713a03c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:58.601424"
        sha256 = "8713a03c5a5adbc5ca408775a47fcbcf89f531c58a377e672198ac3968c44d0b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
