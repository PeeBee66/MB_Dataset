
rule MB_cffb82a9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:13.611115"
        sha256 = "cffb82a922594b930d0e4457dac6b28de33a5573bf6b5d1ac2efafef58b5ba74"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
