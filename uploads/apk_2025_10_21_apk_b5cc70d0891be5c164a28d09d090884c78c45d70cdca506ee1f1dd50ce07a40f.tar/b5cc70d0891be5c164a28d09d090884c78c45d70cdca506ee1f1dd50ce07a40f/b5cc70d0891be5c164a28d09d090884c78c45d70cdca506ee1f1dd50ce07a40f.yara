
rule MB_b5cc70d0
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:25:30.441326"
        sha256 = "b5cc70d0891be5c164a28d09d090884c78c45d70cdca506ee1f1dd50ce07a40f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
