
rule MB_b65d879b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:00:46.410106"
        sha256 = "b65d879b93d39a373aa6045bc7a6487bb15b740743d576e29b3c64421594bc28"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
