
rule MB_b8e8b584
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T11:31:52.858605"
        sha256 = "b8e8b584f5de2f13818e7068fb5e2063c18c644667a9909d79bb7ddec76a0468"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
