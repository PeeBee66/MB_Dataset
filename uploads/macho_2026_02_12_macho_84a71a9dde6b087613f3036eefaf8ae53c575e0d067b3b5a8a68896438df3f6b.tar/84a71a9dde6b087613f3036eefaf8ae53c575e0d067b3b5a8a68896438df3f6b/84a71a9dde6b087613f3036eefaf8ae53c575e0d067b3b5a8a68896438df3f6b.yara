
rule MB_84a71a9d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:38.040090"
        sha256 = "84a71a9dde6b087613f3036eefaf8ae53c575e0d067b3b5a8a68896438df3f6b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
