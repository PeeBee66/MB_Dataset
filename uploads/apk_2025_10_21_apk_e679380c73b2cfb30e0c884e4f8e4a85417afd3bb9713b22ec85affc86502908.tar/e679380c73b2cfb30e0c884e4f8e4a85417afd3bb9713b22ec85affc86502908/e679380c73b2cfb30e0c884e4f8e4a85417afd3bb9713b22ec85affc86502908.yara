
rule MB_e679380c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:05:32.182533"
        sha256 = "e679380c73b2cfb30e0c884e4f8e4a85417afd3bb9713b22ec85affc86502908"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
