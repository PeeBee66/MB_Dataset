
rule MB_d8a736b8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-30T23:00:40.546801"
        sha256 = "d8a736b8f6dcf3fe4f63dd5cfb1a05f587b1073f7e085f86e3cc4065a4c5babe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
