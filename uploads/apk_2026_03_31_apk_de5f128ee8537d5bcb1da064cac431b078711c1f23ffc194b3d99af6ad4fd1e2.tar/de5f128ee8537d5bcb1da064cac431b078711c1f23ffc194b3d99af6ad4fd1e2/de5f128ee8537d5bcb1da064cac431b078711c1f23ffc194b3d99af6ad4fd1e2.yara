
rule MB_de5f128e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-30T23:00:26.359023"
        sha256 = "de5f128ee8537d5bcb1da064cac431b078711c1f23ffc194b3d99af6ad4fd1e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
