
rule MB_29ccb358
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:13.969155"
        sha256 = "29ccb3585dec92da7ebe625f46b1e6e35deacda1ca2b6224ff483a6c7e08356b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
