
rule MB_78d302f5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:00:57.200202"
        sha256 = "78d302f5041caae85aeb25d70d98a087754b1e970cb29461999f82c5cf7cdb82"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
