
rule MB_d4625418
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:25.121325"
        sha256 = "d462541823ee65569f97ababb9b5b4fe095c4b1a1cc955db498b9c5fc877aa0c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
