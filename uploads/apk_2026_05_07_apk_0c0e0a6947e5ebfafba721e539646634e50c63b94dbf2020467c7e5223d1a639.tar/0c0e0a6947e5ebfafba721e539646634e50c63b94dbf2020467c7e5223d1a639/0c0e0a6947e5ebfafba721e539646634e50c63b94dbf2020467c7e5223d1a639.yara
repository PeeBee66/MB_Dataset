
rule MB_0c0e0a69
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:59.107031"
        sha256 = "0c0e0a6947e5ebfafba721e539646634e50c63b94dbf2020467c7e5223d1a639"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
