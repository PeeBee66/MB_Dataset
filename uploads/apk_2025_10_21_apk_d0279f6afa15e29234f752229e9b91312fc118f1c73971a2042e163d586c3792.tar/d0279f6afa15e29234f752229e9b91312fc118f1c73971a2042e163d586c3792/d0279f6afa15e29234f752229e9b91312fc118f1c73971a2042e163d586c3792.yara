
rule MB_d0279f6a
{
    meta:
        description = "Auto-generated rule for Ermac"
        author = "MB-Collector"
        date = "2025-10-20T11:45:18.109993"
        sha256 = "d0279f6afa15e29234f752229e9b91312fc118f1c73971a2042e163d586c3792"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
