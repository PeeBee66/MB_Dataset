
rule MB_75a8511b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-27T23:00:32.774447"
        sha256 = "75a8511b83604e6b10f58a7827f0640a222329f867c15b16b65d1e050078b7d1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
