
rule MB_2a72f7ad
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:38.465261"
        sha256 = "2a72f7adec8610009356139701b21e025193e4956e8ff6812e95241920637525"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
