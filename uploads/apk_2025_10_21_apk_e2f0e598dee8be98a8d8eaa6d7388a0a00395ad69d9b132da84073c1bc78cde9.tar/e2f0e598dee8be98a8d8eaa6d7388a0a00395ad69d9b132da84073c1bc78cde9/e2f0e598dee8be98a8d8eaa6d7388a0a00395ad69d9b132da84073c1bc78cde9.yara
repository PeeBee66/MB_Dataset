
rule MB_e2f0e598
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:25.570761"
        sha256 = "e2f0e598dee8be98a8d8eaa6d7388a0a00395ad69d9b132da84073c1bc78cde9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
