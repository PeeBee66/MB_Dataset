
rule MB_217a2b99
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:36.820085"
        sha256 = "217a2b99079ab08a6e67a98729032cf1c499ba4a6e423ef1017581bfdfac747c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
