
rule MB_f987d245
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:26.122335"
        sha256 = "f987d24529dcbd158bc6fcececfd2b6755e86fcd3b1358353b5df1d9eb8b8830"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
