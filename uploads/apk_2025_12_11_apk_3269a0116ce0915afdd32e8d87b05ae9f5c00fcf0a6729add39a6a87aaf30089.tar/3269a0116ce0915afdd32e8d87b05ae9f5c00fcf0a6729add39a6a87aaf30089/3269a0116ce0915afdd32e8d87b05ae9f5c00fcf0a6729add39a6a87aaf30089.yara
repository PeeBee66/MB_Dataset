
rule MB_3269a011
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-10T23:00:13.524025"
        sha256 = "3269a0116ce0915afdd32e8d87b05ae9f5c00fcf0a6729add39a6a87aaf30089"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
