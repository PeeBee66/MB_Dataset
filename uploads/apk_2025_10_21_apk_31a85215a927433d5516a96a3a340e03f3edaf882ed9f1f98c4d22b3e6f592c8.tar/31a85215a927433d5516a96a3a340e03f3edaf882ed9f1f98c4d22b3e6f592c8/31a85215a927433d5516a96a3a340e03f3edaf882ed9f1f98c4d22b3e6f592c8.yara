
rule MB_31a85215
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:49:26.112205"
        sha256 = "31a85215a927433d5516a96a3a340e03f3edaf882ed9f1f98c4d22b3e6f592c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
