
rule MB_d266c16e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:22.581246"
        sha256 = "d266c16e4cb401f00ce3df5860d06e80819821085dce3a7c76edc74c40356694"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
