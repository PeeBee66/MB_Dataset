
rule MB_f902a8c4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:19.928197"
        sha256 = "f902a8c4de97bd168839457fb1a3e89149c3e44d8eacbbab070d969ad655ee07"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
