
rule MB_091870b3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:53.296402"
        sha256 = "091870b3f90c9a98000e0d14a67be2db5891ce98a0b1e24b721e3d96241620a5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
