
rule MB_7ff61823
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:40:21.098729"
        sha256 = "7ff6182372551125a2434591a6760b253f2480bce0198f80809deb98b56a6339"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
