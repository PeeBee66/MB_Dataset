
rule MB_994869ca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:27.138099"
        sha256 = "994869cacc3615cde8d4196cdfe1e2877f0e1328ff32a292963ffd0983b450fa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
