
rule MB_51863351
{
    meta:
        description = "Auto-generated rule for FantasyHub"
        author = "MB-Collector"
        date = "2026-02-13T23:00:15.054529"
        sha256 = "51863351193ab67148e3e47255cad4927eb13939292c7854121ebedb4de28590"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
