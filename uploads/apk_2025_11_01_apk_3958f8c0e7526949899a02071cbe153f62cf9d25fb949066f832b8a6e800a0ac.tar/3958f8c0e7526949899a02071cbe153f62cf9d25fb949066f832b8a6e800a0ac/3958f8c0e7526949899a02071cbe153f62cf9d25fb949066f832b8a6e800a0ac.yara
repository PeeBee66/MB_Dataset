
rule MB_3958f8c0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:10.496673"
        sha256 = "3958f8c0e7526949899a02071cbe153f62cf9d25fb949066f832b8a6e800a0ac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
