
rule MB_c7944bda
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-11T00:00:15.947028"
        sha256 = "c7944bdac5ce3255a56e77c6f2a83917f4b8a909646396669d408f207e751772"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
