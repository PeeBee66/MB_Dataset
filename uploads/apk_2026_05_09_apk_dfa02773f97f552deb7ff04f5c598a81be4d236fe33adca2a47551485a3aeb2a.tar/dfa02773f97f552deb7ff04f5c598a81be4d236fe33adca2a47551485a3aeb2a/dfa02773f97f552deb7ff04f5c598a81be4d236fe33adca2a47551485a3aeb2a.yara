
rule MB_dfa02773
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:23.475360"
        sha256 = "dfa02773f97f552deb7ff04f5c598a81be4d236fe33adca2a47551485a3aeb2a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
