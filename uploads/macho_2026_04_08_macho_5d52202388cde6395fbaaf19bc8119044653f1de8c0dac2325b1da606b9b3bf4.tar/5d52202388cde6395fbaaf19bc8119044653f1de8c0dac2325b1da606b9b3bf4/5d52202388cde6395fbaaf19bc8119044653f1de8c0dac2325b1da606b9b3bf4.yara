
rule MB_5d522023
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-04-08T00:01:17.496967"
        sha256 = "5d52202388cde6395fbaaf19bc8119044653f1de8c0dac2325b1da606b9b3bf4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
