
rule MB_56d29b36
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:06.786225"
        sha256 = "56d29b362a976b3402afc3fa602ca0152bdf1504f1a2a1745238df1fe761898e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
