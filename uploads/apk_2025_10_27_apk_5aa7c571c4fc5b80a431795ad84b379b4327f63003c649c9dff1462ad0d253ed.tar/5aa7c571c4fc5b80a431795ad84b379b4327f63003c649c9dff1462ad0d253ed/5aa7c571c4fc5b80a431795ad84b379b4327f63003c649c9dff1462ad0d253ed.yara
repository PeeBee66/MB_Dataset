
rule MB_5aa7c571
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-26T23:00:28.977280"
        sha256 = "5aa7c571c4fc5b80a431795ad84b379b4327f63003c649c9dff1462ad0d253ed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
