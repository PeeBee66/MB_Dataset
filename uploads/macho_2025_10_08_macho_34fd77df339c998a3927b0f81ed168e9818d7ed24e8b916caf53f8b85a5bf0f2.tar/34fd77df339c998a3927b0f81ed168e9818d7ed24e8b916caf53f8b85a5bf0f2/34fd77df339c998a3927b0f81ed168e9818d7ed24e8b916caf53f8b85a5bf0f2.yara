
rule MB_34fd77df
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:21.579800"
        sha256 = "34fd77df339c998a3927b0f81ed168e9818d7ed24e8b916caf53f8b85a5bf0f2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
