
rule MB_1e4ed6b3
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T12:03:08.886335"
        sha256 = "1e4ed6b38ca75c7a198c5409591e974cf84baa92706aee65bda17e1d7295b3a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
