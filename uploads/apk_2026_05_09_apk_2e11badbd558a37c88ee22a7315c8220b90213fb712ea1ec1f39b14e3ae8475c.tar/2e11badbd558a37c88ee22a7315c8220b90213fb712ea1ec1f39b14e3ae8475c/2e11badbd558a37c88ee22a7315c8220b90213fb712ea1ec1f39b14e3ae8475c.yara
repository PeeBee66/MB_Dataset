
rule MB_2e11badb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:17.008498"
        sha256 = "2e11badbd558a37c88ee22a7315c8220b90213fb712ea1ec1f39b14e3ae8475c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
