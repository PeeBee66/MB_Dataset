
rule MB_14094f20
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:33.339556"
        sha256 = "14094f203057eed466676ef9b4baf1d8a60cfd1a089bb7ede6a2312a56a775e5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
