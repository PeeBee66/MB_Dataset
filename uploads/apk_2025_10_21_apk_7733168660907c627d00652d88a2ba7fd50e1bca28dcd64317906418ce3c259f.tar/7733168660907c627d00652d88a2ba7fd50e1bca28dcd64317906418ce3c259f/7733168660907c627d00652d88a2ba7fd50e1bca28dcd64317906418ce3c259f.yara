
rule MB_77331686
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:34.814312"
        sha256 = "7733168660907c627d00652d88a2ba7fd50e1bca28dcd64317906418ce3c259f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
