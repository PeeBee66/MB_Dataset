
rule MB_d5cf65ac
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:33:04.351692"
        sha256 = "d5cf65acbd68949c7bb826172722f5287af4b51dc463b2d39c0962fd70aa5826"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
