
rule MB_09cae941
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:01:02.715820"
        sha256 = "09cae9413387356f4a1f138be252b8a2ffe8f61990cc353738776bfaeeee761d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
