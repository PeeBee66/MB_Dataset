
rule MB_a693dc74
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:16.811873"
        sha256 = "a693dc74b646da11d2124f196c8e7da3758a6b5e932fa7e8fb7a42c1bc3d81a1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
