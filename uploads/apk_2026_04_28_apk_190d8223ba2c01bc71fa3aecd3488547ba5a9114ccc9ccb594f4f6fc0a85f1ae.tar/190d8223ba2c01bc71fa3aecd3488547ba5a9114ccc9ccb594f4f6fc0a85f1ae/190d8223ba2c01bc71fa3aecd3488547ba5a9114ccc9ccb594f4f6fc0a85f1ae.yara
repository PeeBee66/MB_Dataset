
rule MB_190d8223
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-28T00:00:27.424110"
        sha256 = "190d8223ba2c01bc71fa3aecd3488547ba5a9114ccc9ccb594f4f6fc0a85f1ae"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
