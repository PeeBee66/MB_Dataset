
rule MB_2ab29825
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-25T00:00:34.503452"
        sha256 = "2ab29825e9454a4b87d661dfc55842943e30b86600d2848796d96241e92307c2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
