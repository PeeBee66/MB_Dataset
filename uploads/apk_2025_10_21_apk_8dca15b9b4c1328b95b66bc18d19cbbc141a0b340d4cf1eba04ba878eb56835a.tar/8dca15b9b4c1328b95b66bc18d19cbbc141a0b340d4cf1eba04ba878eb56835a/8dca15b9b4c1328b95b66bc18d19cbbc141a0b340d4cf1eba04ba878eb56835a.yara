
rule MB_8dca15b9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:21:12.372622"
        sha256 = "8dca15b9b4c1328b95b66bc18d19cbbc141a0b340d4cf1eba04ba878eb56835a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
