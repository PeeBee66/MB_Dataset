
rule MB_2f5fc296
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-04T01:13:43.322122"
        sha256 = "2f5fc29634ce479d339508ce1078714de5265162d056b4d3f00a40283b5e1908"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
