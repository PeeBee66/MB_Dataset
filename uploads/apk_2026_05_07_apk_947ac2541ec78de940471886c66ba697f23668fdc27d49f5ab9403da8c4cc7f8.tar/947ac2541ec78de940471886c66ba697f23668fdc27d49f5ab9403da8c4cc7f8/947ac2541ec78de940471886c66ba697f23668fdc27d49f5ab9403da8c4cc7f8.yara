
rule MB_947ac254
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:43.950776"
        sha256 = "947ac2541ec78de940471886c66ba697f23668fdc27d49f5ab9403da8c4cc7f8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
