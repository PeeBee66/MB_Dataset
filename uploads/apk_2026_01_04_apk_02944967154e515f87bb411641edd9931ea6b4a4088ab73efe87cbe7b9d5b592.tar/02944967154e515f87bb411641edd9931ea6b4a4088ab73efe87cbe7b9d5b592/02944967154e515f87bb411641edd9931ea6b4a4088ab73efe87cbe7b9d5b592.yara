
rule MB_02944967
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-01-03T23:00:16.486760"
        sha256 = "02944967154e515f87bb411641edd9931ea6b4a4088ab73efe87cbe7b9d5b592"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
