
rule MB_7c25f109
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-24T23:00:13.577313"
        sha256 = "7c25f1090921bb3692900dc333a466fad7feb25631cb2fd2fc7f85ab1eaf729f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
