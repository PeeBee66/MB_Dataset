
rule MB_9c0ff19b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:04.257783"
        sha256 = "9c0ff19b36c20abfbb8bb4085aec62885f81b12c7f2560d68f87c6c0e0212889"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
