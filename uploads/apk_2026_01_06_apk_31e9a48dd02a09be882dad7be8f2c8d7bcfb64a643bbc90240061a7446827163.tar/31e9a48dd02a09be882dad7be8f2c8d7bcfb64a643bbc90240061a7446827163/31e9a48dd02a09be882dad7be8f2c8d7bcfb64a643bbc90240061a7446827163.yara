
rule MB_31e9a48d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:35.336206"
        sha256 = "31e9a48dd02a09be882dad7be8f2c8d7bcfb64a643bbc90240061a7446827163"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
