
rule MB_07f6fad0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:17.760005"
        sha256 = "07f6fad0ab8e5dad71d6526b4033056b9ed7ae1110998d5fd2a7e2bd4f92d452"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
