
rule MB_0d6475e0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:05.341526"
        sha256 = "0d6475e07069e6b62eace3521e6f4900a01ebfd1aa41f55431c3ca9570d81102"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
