
rule MB_2ea688a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:37:51.715011"
        sha256 = "2ea688a2fd5f0c9d5e6fe34eeda03d2153c667bb16ab0a598383378645d8054a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
