
rule MB_a91d954f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-06-18T00:01:38.047389"
        sha256 = "a91d954fa5a9a1f167625e7ac8314a481e32a9dbee4635533b52be21be4e508b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
