
rule MB_1099eede
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:01:14.172365"
        sha256 = "1099eede57e825fa5158b33f01559dc76e6d67e2fca37b97f76e7d3aa9a4208a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
