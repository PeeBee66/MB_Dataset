
rule MB_3390fb79
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:13.568089"
        sha256 = "3390fb79bca5fcd27c8a7e4f68e729e507db8becaab30d717dcdf905193f9b27"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
