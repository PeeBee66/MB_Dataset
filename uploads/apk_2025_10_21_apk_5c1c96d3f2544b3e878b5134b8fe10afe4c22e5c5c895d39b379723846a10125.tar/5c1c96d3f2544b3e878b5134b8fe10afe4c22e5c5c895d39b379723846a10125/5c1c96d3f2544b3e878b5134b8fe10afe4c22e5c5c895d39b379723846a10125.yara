
rule MB_5c1c96d3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:35:17.628355"
        sha256 = "5c1c96d3f2544b3e878b5134b8fe10afe4c22e5c5c895d39b379723846a10125"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
