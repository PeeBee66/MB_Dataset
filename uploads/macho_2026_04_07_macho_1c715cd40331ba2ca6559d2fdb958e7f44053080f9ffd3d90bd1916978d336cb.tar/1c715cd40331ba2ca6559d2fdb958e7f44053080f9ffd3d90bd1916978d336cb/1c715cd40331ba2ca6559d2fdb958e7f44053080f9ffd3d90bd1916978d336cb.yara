
rule MB_1c715cd4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-07T00:00:57.848560"
        sha256 = "1c715cd40331ba2ca6559d2fdb958e7f44053080f9ffd3d90bd1916978d336cb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
