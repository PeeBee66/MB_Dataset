
rule MB_779e8559
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:29.354637"
        sha256 = "779e8559f506c5b3a4f259eecd86ff02e0c2b98fbcec84115f1eaf852fcc65d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
