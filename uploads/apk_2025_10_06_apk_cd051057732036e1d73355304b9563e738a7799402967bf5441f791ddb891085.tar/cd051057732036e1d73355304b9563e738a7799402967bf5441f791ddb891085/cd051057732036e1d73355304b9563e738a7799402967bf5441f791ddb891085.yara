
rule MB_cd051057
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-05T23:00:16.522200"
        sha256 = "cd051057732036e1d73355304b9563e738a7799402967bf5441f791ddb891085"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
