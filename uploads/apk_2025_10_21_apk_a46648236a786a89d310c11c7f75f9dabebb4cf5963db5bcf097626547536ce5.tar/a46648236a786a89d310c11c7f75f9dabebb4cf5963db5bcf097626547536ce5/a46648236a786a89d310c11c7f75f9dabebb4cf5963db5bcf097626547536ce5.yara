
rule MB_a4664823
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:54.312736"
        sha256 = "a46648236a786a89d310c11c7f75f9dabebb4cf5963db5bcf097626547536ce5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
