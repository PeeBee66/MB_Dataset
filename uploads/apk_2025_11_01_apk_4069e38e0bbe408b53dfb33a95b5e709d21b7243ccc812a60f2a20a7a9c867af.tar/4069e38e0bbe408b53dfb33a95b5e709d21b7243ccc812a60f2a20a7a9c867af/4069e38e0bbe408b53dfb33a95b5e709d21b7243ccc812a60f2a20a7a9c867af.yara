
rule MB_4069e38e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:53.313445"
        sha256 = "4069e38e0bbe408b53dfb33a95b5e709d21b7243ccc812a60f2a20a7a9c867af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
