
rule MB_4338ab77
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-12-30T23:00:31.169054"
        sha256 = "4338ab77d05aeacd7eac5acbe9eed5568778c8e3e9499562816805b54b4d1a6a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
