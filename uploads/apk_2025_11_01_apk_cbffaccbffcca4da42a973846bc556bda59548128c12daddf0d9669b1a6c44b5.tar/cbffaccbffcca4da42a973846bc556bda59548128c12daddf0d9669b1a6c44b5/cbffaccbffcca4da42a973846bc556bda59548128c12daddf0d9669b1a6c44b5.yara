
rule MB_cbffaccb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:37.452123"
        sha256 = "cbffaccbffcca4da42a973846bc556bda59548128c12daddf0d9669b1a6c44b5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
