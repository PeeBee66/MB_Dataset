
rule MB_171e5b1e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:55.921902"
        sha256 = "171e5b1e8f74f71e76e38cac85180865f4042b7aaab2f863901e40bc0da11d11"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
