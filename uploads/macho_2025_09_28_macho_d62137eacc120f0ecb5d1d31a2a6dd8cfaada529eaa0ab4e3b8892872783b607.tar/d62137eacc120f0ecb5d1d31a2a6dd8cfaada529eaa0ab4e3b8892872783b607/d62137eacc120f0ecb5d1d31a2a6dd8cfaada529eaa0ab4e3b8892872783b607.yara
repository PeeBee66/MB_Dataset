
rule MB_d62137ea
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:15.267530"
        sha256 = "d62137eacc120f0ecb5d1d31a2a6dd8cfaada529eaa0ab4e3b8892872783b607"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
