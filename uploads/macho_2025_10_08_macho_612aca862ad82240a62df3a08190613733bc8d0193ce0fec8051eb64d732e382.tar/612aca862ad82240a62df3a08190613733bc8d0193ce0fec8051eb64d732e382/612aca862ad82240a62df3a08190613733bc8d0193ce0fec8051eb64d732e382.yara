
rule MB_612aca86
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:00.059665"
        sha256 = "612aca862ad82240a62df3a08190613733bc8d0193ce0fec8051eb64d732e382"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
