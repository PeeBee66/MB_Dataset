
rule MB_d787c7dd
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-03-24T23:01:17.735242"
        sha256 = "d787c7dd04ddb7ff7904970df06b24ffe4c5326581c1e273a00253bc0b9afae3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
