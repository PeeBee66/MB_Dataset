
rule MB_8fe017ef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:18:59.384124"
        sha256 = "8fe017ef37ed33f41cc84c1a46c27d091fd8b3d08a01cc847712557be543628c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
