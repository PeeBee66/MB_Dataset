
rule MB_dce3a699
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:59.442712"
        sha256 = "dce3a69992c02835ef19d0fc7165fc20ffe3d5bbbd46620911adccbcb7c9dfd9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
