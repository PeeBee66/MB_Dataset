
rule MB_c794a6c7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:00:53.924187"
        sha256 = "c794a6c7506b9f5b40b25fc108267a5b90e300cba69d175d40829615815f43a8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
