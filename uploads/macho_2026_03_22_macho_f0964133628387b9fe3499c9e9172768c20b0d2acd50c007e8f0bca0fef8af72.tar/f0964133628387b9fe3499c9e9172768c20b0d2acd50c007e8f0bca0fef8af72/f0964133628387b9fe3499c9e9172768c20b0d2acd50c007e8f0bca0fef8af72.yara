
rule MB_f0964133
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:03:10.114871"
        sha256 = "f0964133628387b9fe3499c9e9172768c20b0d2acd50c007e8f0bca0fef8af72"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
