
rule MB_44a88b81
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-18T23:01:02.811384"
        sha256 = "44a88b810323b1daaa76543881a4adacbb8f8c69808a279a2952f4642eecb6d7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
