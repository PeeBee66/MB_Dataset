
rule MB_29f7632b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:52.816550"
        sha256 = "29f7632b7d36bbaaa9154646c8c050c103bb40685747d24deda8e6032e4527b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
