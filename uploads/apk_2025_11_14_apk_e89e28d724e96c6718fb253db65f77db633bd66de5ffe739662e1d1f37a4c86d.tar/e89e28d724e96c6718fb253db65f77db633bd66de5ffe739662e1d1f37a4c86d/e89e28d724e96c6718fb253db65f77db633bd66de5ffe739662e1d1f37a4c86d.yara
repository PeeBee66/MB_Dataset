
rule MB_e89e28d7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:20.800509"
        sha256 = "e89e28d724e96c6718fb253db65f77db633bd66de5ffe739662e1d1f37a4c86d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
