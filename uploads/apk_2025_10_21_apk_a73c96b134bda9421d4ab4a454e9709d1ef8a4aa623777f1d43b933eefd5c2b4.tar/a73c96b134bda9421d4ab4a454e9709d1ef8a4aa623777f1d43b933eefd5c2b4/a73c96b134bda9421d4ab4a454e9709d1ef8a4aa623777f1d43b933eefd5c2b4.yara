
rule MB_a73c96b1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:57.835183"
        sha256 = "a73c96b134bda9421d4ab4a454e9709d1ef8a4aa623777f1d43b933eefd5c2b4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
