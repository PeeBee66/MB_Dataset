
rule MB_605a39a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:02.775784"
        sha256 = "605a39a282d30b86c15f1c8b715542e5b56a64e91103a9daf2204004efd910e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
