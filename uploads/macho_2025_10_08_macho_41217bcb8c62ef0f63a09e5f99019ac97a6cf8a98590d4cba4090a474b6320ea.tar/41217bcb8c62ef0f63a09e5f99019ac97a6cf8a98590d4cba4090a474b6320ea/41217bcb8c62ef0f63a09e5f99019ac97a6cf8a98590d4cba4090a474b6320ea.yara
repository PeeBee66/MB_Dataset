
rule MB_41217bcb
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:55.226220"
        sha256 = "41217bcb8c62ef0f63a09e5f99019ac97a6cf8a98590d4cba4090a474b6320ea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
