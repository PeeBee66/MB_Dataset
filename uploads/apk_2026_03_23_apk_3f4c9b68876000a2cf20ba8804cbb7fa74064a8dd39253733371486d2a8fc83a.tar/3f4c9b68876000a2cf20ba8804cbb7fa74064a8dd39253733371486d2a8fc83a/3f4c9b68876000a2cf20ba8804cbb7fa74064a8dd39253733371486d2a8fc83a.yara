
rule MB_3f4c9b68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-22T23:00:17.126810"
        sha256 = "3f4c9b68876000a2cf20ba8804cbb7fa74064a8dd39253733371486d2a8fc83a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
