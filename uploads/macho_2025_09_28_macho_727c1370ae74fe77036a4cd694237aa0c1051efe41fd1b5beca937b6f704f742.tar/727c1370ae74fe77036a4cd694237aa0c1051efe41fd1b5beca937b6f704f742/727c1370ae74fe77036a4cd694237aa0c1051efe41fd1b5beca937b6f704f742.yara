
rule MB_727c1370
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:41.158127"
        sha256 = "727c1370ae74fe77036a4cd694237aa0c1051efe41fd1b5beca937b6f704f742"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
