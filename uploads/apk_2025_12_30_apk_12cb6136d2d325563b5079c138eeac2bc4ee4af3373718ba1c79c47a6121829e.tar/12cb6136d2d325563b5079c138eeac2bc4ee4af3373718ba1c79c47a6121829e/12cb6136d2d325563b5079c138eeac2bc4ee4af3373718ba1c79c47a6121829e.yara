
rule MB_12cb6136
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-29T23:00:22.755084"
        sha256 = "12cb6136d2d325563b5079c138eeac2bc4ee4af3373718ba1c79c47a6121829e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
