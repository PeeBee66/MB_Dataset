
rule MB_0e52566c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:20.664156"
        sha256 = "0e52566ccff4830e30ef45d2ad804eefba4ffe42062919398bf1334aab74dd65"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
