
rule MB_5b6a8b91
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:09.734727"
        sha256 = "5b6a8b9107cc5922ea36fe8d584299b5f35a1f5b7a616b5f39c55910e8a51fbd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
