
rule MB_a1aaf288
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:56:52.279229"
        sha256 = "a1aaf288c309945d7f3f1d407f01f328bd80bff64a87580af59fc7b83300640f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
