
rule MB_7e69f9c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:48.003260"
        sha256 = "7e69f9c1dd10709a9e259cdccf20c4c14216144871bb2e8132f9faa1d39a83d9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
