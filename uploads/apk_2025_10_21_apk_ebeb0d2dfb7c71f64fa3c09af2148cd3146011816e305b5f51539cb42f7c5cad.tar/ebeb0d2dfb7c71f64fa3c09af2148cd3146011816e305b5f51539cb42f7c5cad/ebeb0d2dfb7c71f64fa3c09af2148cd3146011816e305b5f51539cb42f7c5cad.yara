
rule MB_ebeb0d2d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:32.296219"
        sha256 = "ebeb0d2dfb7c71f64fa3c09af2148cd3146011816e305b5f51539cb42f7c5cad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
