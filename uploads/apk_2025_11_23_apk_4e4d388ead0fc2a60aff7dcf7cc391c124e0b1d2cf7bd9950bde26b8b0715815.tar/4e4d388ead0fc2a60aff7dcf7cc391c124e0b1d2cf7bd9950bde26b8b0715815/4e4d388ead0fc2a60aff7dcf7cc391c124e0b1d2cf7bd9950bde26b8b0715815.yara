
rule MB_4e4d388e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:32.822065"
        sha256 = "4e4d388ead0fc2a60aff7dcf7cc391c124e0b1d2cf7bd9950bde26b8b0715815"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
