
rule MB_5222b5ba
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:28.766354"
        sha256 = "5222b5baedb92afa31d06bcf6e670623537f8b5473ee2af5c56c7e5d90506f20"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
