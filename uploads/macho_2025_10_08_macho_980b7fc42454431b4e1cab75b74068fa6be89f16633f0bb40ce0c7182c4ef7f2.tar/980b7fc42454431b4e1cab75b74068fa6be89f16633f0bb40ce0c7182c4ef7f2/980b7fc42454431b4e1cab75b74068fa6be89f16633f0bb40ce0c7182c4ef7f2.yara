
rule MB_980b7fc4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:38.358596"
        sha256 = "980b7fc42454431b4e1cab75b74068fa6be89f16633f0bb40ce0c7182c4ef7f2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
