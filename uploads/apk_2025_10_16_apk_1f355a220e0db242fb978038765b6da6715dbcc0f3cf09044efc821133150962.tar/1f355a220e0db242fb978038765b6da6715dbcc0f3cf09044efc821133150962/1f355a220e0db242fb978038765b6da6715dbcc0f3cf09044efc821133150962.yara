
rule MB_1f355a22
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-15T23:00:26.945140"
        sha256 = "1f355a220e0db242fb978038765b6da6715dbcc0f3cf09044efc821133150962"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
