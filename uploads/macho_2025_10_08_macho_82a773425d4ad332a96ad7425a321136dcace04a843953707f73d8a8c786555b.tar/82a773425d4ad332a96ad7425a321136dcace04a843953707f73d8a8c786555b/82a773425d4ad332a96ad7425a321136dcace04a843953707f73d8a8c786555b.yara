
rule MB_82a77342
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:40.726237"
        sha256 = "82a773425d4ad332a96ad7425a321136dcace04a843953707f73d8a8c786555b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
