
rule MB_e29ef1d6
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:14.095535"
        sha256 = "e29ef1d6f384a2307133b257ebd4fd26d797b2dd461cc9e7d9f85c92c370d3ac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
