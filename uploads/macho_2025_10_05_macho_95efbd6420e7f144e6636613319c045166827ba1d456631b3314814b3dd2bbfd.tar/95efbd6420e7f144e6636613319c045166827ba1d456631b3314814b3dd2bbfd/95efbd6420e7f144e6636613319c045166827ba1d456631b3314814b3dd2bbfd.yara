
rule MB_95efbd64
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:46.432290"
        sha256 = "95efbd6420e7f144e6636613319c045166827ba1d456631b3314814b3dd2bbfd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
