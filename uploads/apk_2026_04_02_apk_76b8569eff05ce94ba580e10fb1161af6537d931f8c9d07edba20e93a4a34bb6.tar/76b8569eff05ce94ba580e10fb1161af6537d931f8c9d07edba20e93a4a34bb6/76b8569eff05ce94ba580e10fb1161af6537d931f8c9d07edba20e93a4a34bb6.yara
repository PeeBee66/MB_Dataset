
rule MB_76b8569e
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-01T23:00:21.106487"
        sha256 = "76b8569eff05ce94ba580e10fb1161af6537d931f8c9d07edba20e93a4a34bb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
