
rule MB_bb737029
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:49.411631"
        sha256 = "bb7370296fbe1e30fcb32bd96d052674cf4d60eca535fe63ea1e4beda713e140"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
