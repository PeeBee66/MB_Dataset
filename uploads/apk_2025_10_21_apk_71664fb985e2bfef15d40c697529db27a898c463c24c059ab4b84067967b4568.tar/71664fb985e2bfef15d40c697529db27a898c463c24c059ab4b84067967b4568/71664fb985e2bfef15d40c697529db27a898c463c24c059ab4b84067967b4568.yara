
rule MB_71664fb9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:04:09.489245"
        sha256 = "71664fb985e2bfef15d40c697529db27a898c463c24c059ab4b84067967b4568"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
