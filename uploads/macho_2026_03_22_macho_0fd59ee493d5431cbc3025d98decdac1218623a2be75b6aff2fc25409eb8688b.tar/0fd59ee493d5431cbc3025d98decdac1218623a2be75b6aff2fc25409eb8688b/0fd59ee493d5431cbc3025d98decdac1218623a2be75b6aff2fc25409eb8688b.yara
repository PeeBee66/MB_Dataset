
rule MB_0fd59ee4
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:50.272087"
        sha256 = "0fd59ee493d5431cbc3025d98decdac1218623a2be75b6aff2fc25409eb8688b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
