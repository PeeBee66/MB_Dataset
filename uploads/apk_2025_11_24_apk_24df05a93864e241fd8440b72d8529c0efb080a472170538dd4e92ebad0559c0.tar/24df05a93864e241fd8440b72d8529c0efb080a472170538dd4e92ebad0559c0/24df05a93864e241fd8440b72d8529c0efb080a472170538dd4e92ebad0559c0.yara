
rule MB_24df05a9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:34.584141"
        sha256 = "24df05a93864e241fd8440b72d8529c0efb080a472170538dd4e92ebad0559c0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
