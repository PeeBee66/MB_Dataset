
rule MB_79f56edc
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:01:26.341314"
        sha256 = "79f56edc1bb111c0323762dc0c25d9c50c9a62ec4dedc2cf2e0c2010e518b6b4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
