
rule MB_93fb6a99
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:36.115634"
        sha256 = "93fb6a99be064a1bb014110ea21eb2822f8d075299c833dbb515e63acde1cb72"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
