
rule MB_2c0bce17
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-01T23:00:37.014223"
        sha256 = "2c0bce17bc9bbfbea95e5b75e6294fd1d5205b915b24729d1f2377e2a6f2b578"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
