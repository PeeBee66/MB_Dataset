
rule MB_7b218f7d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:31.701282"
        sha256 = "7b218f7df29eebcee1983aaf1e5c031eb903642f026ad5a910b06ea0495fb276"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
