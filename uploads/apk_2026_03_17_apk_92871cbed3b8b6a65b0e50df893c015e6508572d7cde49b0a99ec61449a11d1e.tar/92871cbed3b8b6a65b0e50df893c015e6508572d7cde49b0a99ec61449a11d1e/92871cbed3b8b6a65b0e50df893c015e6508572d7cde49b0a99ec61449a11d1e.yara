
rule MB_92871cbe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-16T23:00:14.932054"
        sha256 = "92871cbed3b8b6a65b0e50df893c015e6508572d7cde49b0a99ec61449a11d1e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
