
rule MB_1e60421e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:41.515148"
        sha256 = "1e60421e83a317cfbfce980fefa926a847964bcc7b047908db65161148d0f624"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
