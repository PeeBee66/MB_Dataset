
rule MB_5d4972e8
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:01:17.099610"
        sha256 = "5d4972e846d795b495d70fa054821c53678d2335b6879b4bf9a9116e101a8826"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
