
rule MB_c9d216c2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:46.384577"
        sha256 = "c9d216c2fd4a9956740c416836bbb257097ceb2935da57b48b694267bb447c00"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
