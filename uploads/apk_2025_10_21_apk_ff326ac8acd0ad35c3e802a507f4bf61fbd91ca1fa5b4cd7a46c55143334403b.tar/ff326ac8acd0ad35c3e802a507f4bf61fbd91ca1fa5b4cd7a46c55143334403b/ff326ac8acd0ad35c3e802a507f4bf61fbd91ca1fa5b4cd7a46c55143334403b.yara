
rule MB_ff326ac8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:03.307826"
        sha256 = "ff326ac8acd0ad35c3e802a507f4bf61fbd91ca1fa5b4cd7a46c55143334403b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
