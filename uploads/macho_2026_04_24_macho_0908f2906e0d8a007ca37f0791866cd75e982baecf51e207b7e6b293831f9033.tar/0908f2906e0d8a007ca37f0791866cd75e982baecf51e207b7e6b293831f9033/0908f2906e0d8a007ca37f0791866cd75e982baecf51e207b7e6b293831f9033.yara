
rule MB_0908f290
{
    meta:
        description = "Auto-generated rule for Lazarus"
        author = "MB-Collector"
        date = "2026-04-24T00:03:11.435646"
        sha256 = "0908f2906e0d8a007ca37f0791866cd75e982baecf51e207b7e6b293831f9033"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
