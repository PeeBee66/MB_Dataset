
rule MB_56792736
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:31.628350"
        sha256 = "56792736eefe2d74878db2968856af80991d9ab4d9fffd5e790639554a9c115d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
