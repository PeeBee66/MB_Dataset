
rule MB_e4f0ec8d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:21.950052"
        sha256 = "e4f0ec8d6d2e042eb2ee7a2cb127f9d0540596a66564d550cc7f519a08c608e0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
