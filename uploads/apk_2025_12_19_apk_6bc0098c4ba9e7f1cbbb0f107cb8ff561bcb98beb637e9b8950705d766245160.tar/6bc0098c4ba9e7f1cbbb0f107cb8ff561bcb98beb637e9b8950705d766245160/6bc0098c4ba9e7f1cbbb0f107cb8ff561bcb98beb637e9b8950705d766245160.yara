
rule MB_6bc0098c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-18T23:00:14.416054"
        sha256 = "6bc0098c4ba9e7f1cbbb0f107cb8ff561bcb98beb637e9b8950705d766245160"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
