
rule MB_6e27089c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:11.169337"
        sha256 = "6e27089cfc95031ecfbac01be8beaf035b2a8eba97350517c95f7cba5abb70a8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
