
rule MB_9f6e0831
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-23T23:00:13.726045"
        sha256 = "9f6e0831e8936b8e14c6b3a699ed0442736281dcaf92396de66848c5fcb3eab4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
