
rule MB_28f4dd61
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:33.090703"
        sha256 = "28f4dd61677c87df05687f9bf0e7323700b4a264ea56af06a74a475bd0c6239f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
