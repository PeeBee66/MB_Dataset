
rule MB_e2b2f428
{
    meta:
        description = "Auto-generated rule for AMOS"
        author = "MB-Collector"
        date = "2025-10-27T23:00:21.341414"
        sha256 = "e2b2f42878dbbb41e09cd46f2495d8e645abe352e69f48c122e046d0c5d3b82a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
