
rule MB_f53abfef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:29.553216"
        sha256 = "f53abfef648869e1b824555c96993a61d9bec8155ba720cc439e1b8ceecc6ab5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
