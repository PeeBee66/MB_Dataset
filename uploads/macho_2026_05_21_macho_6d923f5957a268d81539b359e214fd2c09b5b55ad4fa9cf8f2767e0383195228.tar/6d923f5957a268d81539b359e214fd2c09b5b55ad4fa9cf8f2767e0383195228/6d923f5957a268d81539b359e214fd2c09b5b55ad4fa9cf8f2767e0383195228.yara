
rule MB_6d923f59
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-21T00:00:24.098433"
        sha256 = "6d923f5957a268d81539b359e214fd2c09b5b55ad4fa9cf8f2767e0383195228"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
