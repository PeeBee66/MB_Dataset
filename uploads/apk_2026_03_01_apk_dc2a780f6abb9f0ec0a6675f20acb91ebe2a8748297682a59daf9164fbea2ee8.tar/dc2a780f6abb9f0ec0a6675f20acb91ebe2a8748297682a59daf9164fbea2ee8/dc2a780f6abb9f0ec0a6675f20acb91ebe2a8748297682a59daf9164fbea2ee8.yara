
rule MB_dc2a780f
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2026-02-28T23:00:14.830139"
        sha256 = "dc2a780f6abb9f0ec0a6675f20acb91ebe2a8748297682a59daf9164fbea2ee8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
