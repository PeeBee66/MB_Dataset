
rule MB_83f87364
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-20T00:00:35.398856"
        sha256 = "83f87364e05ff509464d246cb7969f7b05e12f4ee4daaf741cc331cb92dc5025"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
