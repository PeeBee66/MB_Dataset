
rule MB_16094089
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:05:20.502604"
        sha256 = "160940892dc1983ed1b46d8756f1a529d9ec9ce5e3c4481f75c57c568748a38c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
