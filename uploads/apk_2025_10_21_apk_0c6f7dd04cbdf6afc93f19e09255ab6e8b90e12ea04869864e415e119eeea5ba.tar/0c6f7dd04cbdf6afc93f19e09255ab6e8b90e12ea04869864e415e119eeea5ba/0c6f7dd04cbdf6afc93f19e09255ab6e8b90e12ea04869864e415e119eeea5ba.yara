
rule MB_0c6f7dd0
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:11:01.802758"
        sha256 = "0c6f7dd04cbdf6afc93f19e09255ab6e8b90e12ea04869864e415e119eeea5ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
