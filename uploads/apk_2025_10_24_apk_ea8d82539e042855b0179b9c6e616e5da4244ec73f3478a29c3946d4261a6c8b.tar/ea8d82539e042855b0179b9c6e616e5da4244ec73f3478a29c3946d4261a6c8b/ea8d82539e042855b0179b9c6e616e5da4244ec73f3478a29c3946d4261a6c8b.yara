
rule MB_ea8d8253
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-23T23:00:22.120506"
        sha256 = "ea8d82539e042855b0179b9c6e616e5da4244ec73f3478a29c3946d4261a6c8b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
