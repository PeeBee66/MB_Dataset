
rule MB_3af52984
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:50.525253"
        sha256 = "3af529848c8c1a1a4e819f7979e9503a9a560170731cde32ef75b35820ae066c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
