
rule MB_9c8c002c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:30.522940"
        sha256 = "9c8c002c090cb49acc73558492fe1e58ad5d17afb5694df815d67684386baeee"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
