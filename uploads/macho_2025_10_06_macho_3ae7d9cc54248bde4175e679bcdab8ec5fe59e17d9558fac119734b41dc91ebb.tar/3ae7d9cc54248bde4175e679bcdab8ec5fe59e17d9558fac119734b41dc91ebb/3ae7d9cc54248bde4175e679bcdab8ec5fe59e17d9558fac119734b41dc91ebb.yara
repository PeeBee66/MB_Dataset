
rule MB_3ae7d9cc
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:19.211365"
        sha256 = "3ae7d9cc54248bde4175e679bcdab8ec5fe59e17d9558fac119734b41dc91ebb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
