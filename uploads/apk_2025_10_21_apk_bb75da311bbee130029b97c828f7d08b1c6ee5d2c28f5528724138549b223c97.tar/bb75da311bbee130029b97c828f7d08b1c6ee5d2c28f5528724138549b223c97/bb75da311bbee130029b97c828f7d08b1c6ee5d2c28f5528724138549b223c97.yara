
rule MB_bb75da31
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:31:38.048239"
        sha256 = "bb75da311bbee130029b97c828f7d08b1c6ee5d2c28f5528724138549b223c97"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
