
rule MB_d5a84c85
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:00:28.420346"
        sha256 = "d5a84c85508c444743d055be354a464eb22dc5b33cba41e4b149829d182f4dca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
