
rule MB_c9b0c232
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:01:01.280855"
        sha256 = "c9b0c23290773618f4fa671fdba25809b764203d2fa928f4d3f0241592b12cc5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
