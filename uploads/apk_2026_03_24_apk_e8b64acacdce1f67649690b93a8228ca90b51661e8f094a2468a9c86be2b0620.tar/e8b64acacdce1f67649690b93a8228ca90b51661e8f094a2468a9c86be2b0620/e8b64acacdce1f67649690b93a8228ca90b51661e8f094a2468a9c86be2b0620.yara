
rule MB_e8b64aca
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:29.557916"
        sha256 = "e8b64acacdce1f67649690b93a8228ca90b51661e8f094a2468a9c86be2b0620"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
