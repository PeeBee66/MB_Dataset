
rule MB_877bda65
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:52.368144"
        sha256 = "877bda655f641698c3a49a8b8a37e173710c328ab52b0fb731142f3570bc5e5c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
