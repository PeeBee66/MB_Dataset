
rule MB_afc18031
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-10T00:00:21.569076"
        sha256 = "afc1803107162699dd2af420dd2ada2a313eee6f08c6f9081a566870341087a3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
