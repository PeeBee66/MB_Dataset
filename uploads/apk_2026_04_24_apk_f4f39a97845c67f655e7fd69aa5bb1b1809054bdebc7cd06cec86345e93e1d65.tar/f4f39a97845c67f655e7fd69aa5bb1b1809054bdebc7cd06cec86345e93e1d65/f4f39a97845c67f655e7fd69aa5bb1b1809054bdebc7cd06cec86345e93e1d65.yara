
rule MB_f4f39a97
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:16.560494"
        sha256 = "f4f39a97845c67f655e7fd69aa5bb1b1809054bdebc7cd06cec86345e93e1d65"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
