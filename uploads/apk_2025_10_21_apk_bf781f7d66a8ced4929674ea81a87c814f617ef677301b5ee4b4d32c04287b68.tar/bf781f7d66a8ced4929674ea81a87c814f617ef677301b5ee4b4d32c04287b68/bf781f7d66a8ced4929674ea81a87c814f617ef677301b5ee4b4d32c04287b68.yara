
rule MB_bf781f7d
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T12:05:28.869276"
        sha256 = "bf781f7d66a8ced4929674ea81a87c814f617ef677301b5ee4b4d32c04287b68"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
