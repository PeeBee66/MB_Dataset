
rule MB_909eceed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:01:57.237366"
        sha256 = "909eceed253fd71879cf6a7f628ac34927705c3ac7d49fc207c25f1be7bc413c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
