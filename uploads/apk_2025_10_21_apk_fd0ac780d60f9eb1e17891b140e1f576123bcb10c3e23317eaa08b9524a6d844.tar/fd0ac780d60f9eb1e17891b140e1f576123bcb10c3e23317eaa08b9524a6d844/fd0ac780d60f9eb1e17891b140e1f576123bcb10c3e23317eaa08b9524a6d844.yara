
rule MB_fd0ac780
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:18:33.157066"
        sha256 = "fd0ac780d60f9eb1e17891b140e1f576123bcb10c3e23317eaa08b9524a6d844"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
