
rule MB_6ace30c2
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:29.370994"
        sha256 = "6ace30c2832b85ef093f86c13b9920a528dc86c3d561148a7a641f2d2b80db00"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
