
rule MB_fc075a04
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:01:58.985427"
        sha256 = "fc075a04586519306868d0089966425e7824be432fc74a1d9e8fa1a5358a1bc7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
