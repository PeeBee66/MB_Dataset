
rule MB_a6578e2c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:24:57.151236"
        sha256 = "a6578e2c4eac002ef1c5d0f7be941dc7189b5b8c6bb59bbbc1ed17dfbdf39eea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
