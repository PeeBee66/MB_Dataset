
rule MB_9a8afd1c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:48.910601"
        sha256 = "9a8afd1cdcf97e923b2b984cdec8fee9afe0aa73003f96d79545abaf716a6cc9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
