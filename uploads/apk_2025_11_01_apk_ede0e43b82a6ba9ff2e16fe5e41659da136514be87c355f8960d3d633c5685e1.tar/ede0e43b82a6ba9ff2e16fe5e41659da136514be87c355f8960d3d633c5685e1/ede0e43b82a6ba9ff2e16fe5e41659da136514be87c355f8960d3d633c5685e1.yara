
rule MB_ede0e43b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:26.174628"
        sha256 = "ede0e43b82a6ba9ff2e16fe5e41659da136514be87c355f8960d3d633c5685e1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
