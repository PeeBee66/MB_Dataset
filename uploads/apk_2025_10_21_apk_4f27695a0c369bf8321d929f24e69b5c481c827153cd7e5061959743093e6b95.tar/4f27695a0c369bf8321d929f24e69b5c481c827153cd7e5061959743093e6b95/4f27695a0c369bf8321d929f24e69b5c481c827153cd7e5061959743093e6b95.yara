
rule MB_4f27695a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:00.857128"
        sha256 = "4f27695a0c369bf8321d929f24e69b5c481c827153cd7e5061959743093e6b95"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
