
rule MB_beee0449
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-24T23:00:15.945299"
        sha256 = "beee04490d0faa4901256044602892a9d427b3875bf925a8f7798161be089dfa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
