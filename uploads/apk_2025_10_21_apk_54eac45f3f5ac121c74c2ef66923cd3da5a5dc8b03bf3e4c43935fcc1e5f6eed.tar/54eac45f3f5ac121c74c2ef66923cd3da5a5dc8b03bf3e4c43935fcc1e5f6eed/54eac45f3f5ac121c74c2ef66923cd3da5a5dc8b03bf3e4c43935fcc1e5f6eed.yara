
rule MB_54eac45f
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:45:42.675100"
        sha256 = "54eac45f3f5ac121c74c2ef66923cd3da5a5dc8b03bf3e4c43935fcc1e5f6eed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
