
rule MB_7f0671a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:47.409363"
        sha256 = "7f0671a2c0774fe8fb5d4f17fc5447fd1e61486db9784fda5595c693f3c4fbd7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
