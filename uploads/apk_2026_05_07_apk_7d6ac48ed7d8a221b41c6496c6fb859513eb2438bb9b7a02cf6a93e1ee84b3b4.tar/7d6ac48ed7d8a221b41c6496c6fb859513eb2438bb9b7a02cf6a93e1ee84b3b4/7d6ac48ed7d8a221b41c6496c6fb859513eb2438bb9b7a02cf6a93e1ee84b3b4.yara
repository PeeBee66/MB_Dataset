
rule MB_7d6ac48e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:28.916373"
        sha256 = "7d6ac48ed7d8a221b41c6496c6fb859513eb2438bb9b7a02cf6a93e1ee84b3b4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
