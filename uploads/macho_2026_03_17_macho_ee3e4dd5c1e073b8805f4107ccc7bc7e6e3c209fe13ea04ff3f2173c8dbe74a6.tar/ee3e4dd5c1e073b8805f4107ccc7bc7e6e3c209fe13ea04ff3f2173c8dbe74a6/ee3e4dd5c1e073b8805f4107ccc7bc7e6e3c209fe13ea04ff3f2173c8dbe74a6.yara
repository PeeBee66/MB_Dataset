
rule MB_ee3e4dd5
{
    meta:
        description = "Auto-generated rule for GlassWorm"
        author = "MB-Collector"
        date = "2026-03-16T23:00:49.750534"
        sha256 = "ee3e4dd5c1e073b8805f4107ccc7bc7e6e3c209fe13ea04ff3f2173c8dbe74a6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
