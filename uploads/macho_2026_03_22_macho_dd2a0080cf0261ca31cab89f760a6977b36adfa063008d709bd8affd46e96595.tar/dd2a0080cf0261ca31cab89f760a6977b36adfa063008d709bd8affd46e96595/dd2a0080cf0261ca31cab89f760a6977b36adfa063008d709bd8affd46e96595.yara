
rule MB_dd2a0080
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:28.143331"
        sha256 = "dd2a0080cf0261ca31cab89f760a6977b36adfa063008d709bd8affd46e96595"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
