
rule MB_25c4d369
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-04T23:00:38.730983"
        sha256 = "25c4d3695c82d6a652f70eb8213a66d206d9c9949af5516376856051dceb8c79"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
