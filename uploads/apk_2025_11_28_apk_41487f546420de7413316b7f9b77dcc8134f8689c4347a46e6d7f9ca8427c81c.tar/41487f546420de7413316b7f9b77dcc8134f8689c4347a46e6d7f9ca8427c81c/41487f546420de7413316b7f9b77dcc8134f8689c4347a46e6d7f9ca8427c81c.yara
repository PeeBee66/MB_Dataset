
rule MB_41487f54
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-27T23:00:29.863755"
        sha256 = "41487f546420de7413316b7f9b77dcc8134f8689c4347a46e6d7f9ca8427c81c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
