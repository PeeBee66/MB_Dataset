
rule MB_1e637ae9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:56.894344"
        sha256 = "1e637ae91f7fbe2c8ae070233c816dbfee507bb7b7f2a97fd92d104ec89c5cb5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
