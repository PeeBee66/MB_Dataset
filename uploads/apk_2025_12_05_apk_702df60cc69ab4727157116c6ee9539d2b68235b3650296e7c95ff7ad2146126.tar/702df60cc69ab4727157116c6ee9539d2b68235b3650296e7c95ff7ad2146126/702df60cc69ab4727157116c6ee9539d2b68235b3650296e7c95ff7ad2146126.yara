
rule MB_702df60c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:25.304264"
        sha256 = "702df60cc69ab4727157116c6ee9539d2b68235b3650296e7c95ff7ad2146126"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
