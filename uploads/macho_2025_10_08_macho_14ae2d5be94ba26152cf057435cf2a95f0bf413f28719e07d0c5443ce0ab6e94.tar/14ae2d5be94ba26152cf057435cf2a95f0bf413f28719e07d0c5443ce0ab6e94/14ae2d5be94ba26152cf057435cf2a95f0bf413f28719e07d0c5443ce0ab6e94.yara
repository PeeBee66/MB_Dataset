
rule MB_14ae2d5b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:23.991680"
        sha256 = "14ae2d5be94ba26152cf057435cf2a95f0bf413f28719e07d0c5443ce0ab6e94"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
