
rule MB_6a99e6d4
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-12-04T23:00:43.574984"
        sha256 = "6a99e6d4abc66f09a490443786432d90c675cb6282c791fae996136cbb69b7e9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
