
rule MB_b2be8ef1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-15T00:00:37.379952"
        sha256 = "b2be8ef1895f42981a717359ab2d263dc1351f7893ac8629ea6863dc76601d8e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
