
rule MB_ad1d8a9a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:45.343094"
        sha256 = "ad1d8a9a421583964a04935a6a1d66f8a7c3dc6b81dcb844a3cf5be3f1a7a0dd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
