
rule MB_770bf9f1
{
    meta:
        description = "Auto-generated rule for IRATA"
        author = "MB-Collector"
        date = "2025-11-03T23:00:20.508401"
        sha256 = "770bf9f191773bf5ae538c40530ca99dbac7698a5edf30777aa1ae92ca54815e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
