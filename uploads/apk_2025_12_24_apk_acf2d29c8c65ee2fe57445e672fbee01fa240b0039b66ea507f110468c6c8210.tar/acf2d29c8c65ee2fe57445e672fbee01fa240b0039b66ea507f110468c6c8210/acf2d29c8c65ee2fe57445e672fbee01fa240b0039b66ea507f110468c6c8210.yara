
rule MB_acf2d29c
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:20.637031"
        sha256 = "acf2d29c8c65ee2fe57445e672fbee01fa240b0039b66ea507f110468c6c8210"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
