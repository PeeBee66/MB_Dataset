
rule MB_da647747
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-05T23:00:13.329396"
        sha256 = "da647747526edf2db62cf53652f45ac1f29cb67f5176fcb15c7bf2819450131b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
