
rule MB_42dc108a
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:17.474873"
        sha256 = "42dc108aff50ca1bbc7381b82ae97b042ee8208c949fdaa3f9719664dcd8d392"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
