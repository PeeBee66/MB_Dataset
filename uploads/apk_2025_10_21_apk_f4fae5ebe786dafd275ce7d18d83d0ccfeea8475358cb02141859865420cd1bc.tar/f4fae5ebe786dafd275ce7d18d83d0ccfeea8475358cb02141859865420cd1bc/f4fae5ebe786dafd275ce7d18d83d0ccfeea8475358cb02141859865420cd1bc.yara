
rule MB_f4fae5eb
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:07:40.644600"
        sha256 = "f4fae5ebe786dafd275ce7d18d83d0ccfeea8475358cb02141859865420cd1bc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
