
rule MB_fdcd0668
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:56.257704"
        sha256 = "fdcd06685d903376381212452bb6b89d36f8fd836a37cb2a6d92393d0ae5ed77"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
