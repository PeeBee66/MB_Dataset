
rule MB_2eb62756
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:51.183286"
        sha256 = "2eb62756704f169e6da9f0921442a637cf67aa256ced56226cb265db5838b239"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
