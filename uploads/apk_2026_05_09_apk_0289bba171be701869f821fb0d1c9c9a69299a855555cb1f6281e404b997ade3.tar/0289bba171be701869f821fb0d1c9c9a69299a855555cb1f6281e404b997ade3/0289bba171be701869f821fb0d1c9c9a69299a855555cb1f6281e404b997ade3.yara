
rule MB_0289bba1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:13.139522"
        sha256 = "0289bba171be701869f821fb0d1c9c9a69299a855555cb1f6281e404b997ade3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
