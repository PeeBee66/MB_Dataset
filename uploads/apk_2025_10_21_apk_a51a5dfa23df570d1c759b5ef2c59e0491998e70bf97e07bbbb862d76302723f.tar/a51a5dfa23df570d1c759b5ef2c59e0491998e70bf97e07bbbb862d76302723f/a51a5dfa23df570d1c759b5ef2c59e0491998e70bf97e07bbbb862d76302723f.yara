
rule MB_a51a5dfa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:53.309246"
        sha256 = "a51a5dfa23df570d1c759b5ef2c59e0491998e70bf97e07bbbb862d76302723f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
