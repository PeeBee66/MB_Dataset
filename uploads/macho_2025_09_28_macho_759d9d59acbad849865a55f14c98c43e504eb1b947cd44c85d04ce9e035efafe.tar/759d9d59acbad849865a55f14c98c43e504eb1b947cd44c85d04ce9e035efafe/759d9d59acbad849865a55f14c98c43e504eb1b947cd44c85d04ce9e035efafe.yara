
rule MB_759d9d59
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:45.755215"
        sha256 = "759d9d59acbad849865a55f14c98c43e504eb1b947cd44c85d04ce9e035efafe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
