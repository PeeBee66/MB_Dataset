
rule MB_5a0cd09a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:01.387444"
        sha256 = "5a0cd09adb09a79071a85edc931e02c8d565d6cb7cb58e5b0bffd866e6a2ffb4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
