
rule MB_d74ec55f
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:53:15.567814"
        sha256 = "d74ec55f29f7f8ba631ed311e8d926e53095f008e0f5d7dc738f446e7ae59ca3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
