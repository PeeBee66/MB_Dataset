
rule MB_5769ae3c
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:27:41.165904"
        sha256 = "5769ae3cc93943dda4d1743f2febf6cec1282a0a6289da68cb55bb4724ec9332"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
