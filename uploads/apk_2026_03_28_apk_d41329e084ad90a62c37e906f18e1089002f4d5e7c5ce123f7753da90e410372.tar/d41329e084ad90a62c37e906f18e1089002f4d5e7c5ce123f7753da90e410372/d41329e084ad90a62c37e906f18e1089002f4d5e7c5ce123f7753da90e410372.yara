
rule MB_d41329e0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-27T23:00:31.947945"
        sha256 = "d41329e084ad90a62c37e906f18e1089002f4d5e7c5ce123f7753da90e410372"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
