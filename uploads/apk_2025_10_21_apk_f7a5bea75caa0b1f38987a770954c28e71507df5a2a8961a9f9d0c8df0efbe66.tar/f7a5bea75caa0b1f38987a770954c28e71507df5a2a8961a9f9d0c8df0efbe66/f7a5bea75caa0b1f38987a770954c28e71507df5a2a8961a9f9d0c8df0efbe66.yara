
rule MB_f7a5bea7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:35.658735"
        sha256 = "f7a5bea75caa0b1f38987a770954c28e71507df5a2a8961a9f9d0c8df0efbe66"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
