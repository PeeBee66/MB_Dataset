
rule MB_87214443
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:28.339646"
        sha256 = "872144436643ddba621a34f5953ab6e1a405937c1c844626d890790cb144bc9d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
