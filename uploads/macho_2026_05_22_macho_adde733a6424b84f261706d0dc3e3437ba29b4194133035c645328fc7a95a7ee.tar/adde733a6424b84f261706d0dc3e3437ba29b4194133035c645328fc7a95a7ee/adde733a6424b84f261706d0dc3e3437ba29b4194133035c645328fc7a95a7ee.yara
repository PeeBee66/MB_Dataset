
rule MB_adde733a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:52.931099"
        sha256 = "adde733a6424b84f261706d0dc3e3437ba29b4194133035c645328fc7a95a7ee"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
