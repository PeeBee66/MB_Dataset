
rule MB_089cb679
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:12.999615"
        sha256 = "089cb67929c70e9361b2cb1c305b5ea227145675a13e5dbff8e95f7d16db200d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
