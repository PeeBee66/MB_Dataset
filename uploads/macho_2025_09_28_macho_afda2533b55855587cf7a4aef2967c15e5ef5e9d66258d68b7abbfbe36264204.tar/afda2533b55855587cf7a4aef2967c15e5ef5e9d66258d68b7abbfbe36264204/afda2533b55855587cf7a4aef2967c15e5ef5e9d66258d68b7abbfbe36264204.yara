
rule MB_afda2533
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:25.097679"
        sha256 = "afda2533b55855587cf7a4aef2967c15e5ef5e9d66258d68b7abbfbe36264204"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
