
rule MB_54c478b4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-23T23:00:56.339332"
        sha256 = "54c478b499829a41f57edf93753b9842ab67dc13cff2cc1326ad7ced2f3dc0b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
