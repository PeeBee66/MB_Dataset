
rule MB_f584b764
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:24:47.554246"
        sha256 = "f584b764e76d3aaa938cb88a773dfbd4633654bf677df8629b375794560e4e48"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
