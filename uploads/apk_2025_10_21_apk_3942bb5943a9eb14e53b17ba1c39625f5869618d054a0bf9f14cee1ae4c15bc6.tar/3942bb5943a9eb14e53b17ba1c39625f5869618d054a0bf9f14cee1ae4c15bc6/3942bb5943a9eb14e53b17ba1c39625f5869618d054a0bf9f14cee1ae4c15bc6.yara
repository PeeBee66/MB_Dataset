
rule MB_3942bb59
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:18.808280"
        sha256 = "3942bb5943a9eb14e53b17ba1c39625f5869618d054a0bf9f14cee1ae4c15bc6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
