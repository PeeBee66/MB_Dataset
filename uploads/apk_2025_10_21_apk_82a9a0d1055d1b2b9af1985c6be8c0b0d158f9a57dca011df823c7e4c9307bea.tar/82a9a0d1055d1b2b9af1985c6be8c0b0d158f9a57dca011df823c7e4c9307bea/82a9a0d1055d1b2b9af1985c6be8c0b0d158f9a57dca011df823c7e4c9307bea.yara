
rule MB_82a9a0d1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:14.680738"
        sha256 = "82a9a0d1055d1b2b9af1985c6be8c0b0d158f9a57dca011df823c7e4c9307bea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
