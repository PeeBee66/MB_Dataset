
rule MB_b8246a27
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:00:59.718598"
        sha256 = "b8246a279b413af7fd6a5019ae6bca474c8d97a362d066b694297404bab69e45"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
