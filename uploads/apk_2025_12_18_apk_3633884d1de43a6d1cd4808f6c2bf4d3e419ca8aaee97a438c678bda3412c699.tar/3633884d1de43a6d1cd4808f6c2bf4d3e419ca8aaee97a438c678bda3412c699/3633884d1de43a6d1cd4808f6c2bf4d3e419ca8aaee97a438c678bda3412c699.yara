
rule MB_3633884d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-17T23:00:15.042514"
        sha256 = "3633884d1de43a6d1cd4808f6c2bf4d3e419ca8aaee97a438c678bda3412c699"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
