
rule MB_59bd5011
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-18T23:00:28.900182"
        sha256 = "59bd5011be93e9f724a61549099ddacc7471e406c96ea25dd78cfd711ccff09f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
