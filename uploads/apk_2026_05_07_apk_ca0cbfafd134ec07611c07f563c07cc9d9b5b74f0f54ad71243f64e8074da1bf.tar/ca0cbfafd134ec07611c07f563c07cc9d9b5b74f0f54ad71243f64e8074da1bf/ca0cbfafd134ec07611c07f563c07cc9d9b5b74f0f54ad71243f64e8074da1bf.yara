
rule MB_ca0cbfaf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:26.707624"
        sha256 = "ca0cbfafd134ec07611c07f563c07cc9d9b5b74f0f54ad71243f64e8074da1bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
