
rule MB_6d21f5eb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:53.325707"
        sha256 = "6d21f5eb5a9f7ee3745d4f6a977fe025e928e41ff271a33b4ab20612989f49cf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
