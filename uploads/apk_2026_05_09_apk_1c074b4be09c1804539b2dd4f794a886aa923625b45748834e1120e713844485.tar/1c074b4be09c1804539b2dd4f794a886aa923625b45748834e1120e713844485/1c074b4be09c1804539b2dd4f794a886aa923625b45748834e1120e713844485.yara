
rule MB_1c074b4b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:04:43.615789"
        sha256 = "1c074b4be09c1804539b2dd4f794a886aa923625b45748834e1120e713844485"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
