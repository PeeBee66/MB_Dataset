
rule MB_822b541d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:00:25.925710"
        sha256 = "822b541df8d54222c91889c923a65c7aff28ec372f211392213dd93d43d30c2a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
