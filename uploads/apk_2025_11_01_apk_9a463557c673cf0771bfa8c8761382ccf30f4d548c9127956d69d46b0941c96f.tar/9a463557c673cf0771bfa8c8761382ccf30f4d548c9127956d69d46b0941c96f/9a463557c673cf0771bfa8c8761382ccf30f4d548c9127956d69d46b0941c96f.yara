
rule MB_9a463557
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:11.561285"
        sha256 = "9a463557c673cf0771bfa8c8761382ccf30f4d548c9127956d69d46b0941c96f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
