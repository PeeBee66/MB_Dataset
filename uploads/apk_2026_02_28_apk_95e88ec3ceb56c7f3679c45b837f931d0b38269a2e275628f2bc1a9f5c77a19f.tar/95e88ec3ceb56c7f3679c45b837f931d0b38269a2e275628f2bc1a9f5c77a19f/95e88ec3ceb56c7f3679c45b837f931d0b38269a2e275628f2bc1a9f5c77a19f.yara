
rule MB_95e88ec3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-27T23:00:18.337667"
        sha256 = "95e88ec3ceb56c7f3679c45b837f931d0b38269a2e275628f2bc1a9f5c77a19f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
