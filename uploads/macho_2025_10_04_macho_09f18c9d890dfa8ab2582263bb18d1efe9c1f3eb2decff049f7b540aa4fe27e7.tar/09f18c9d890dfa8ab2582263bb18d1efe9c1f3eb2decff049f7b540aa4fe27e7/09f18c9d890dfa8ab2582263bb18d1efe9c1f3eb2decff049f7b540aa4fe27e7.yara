
rule MB_09f18c9d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:50.512752"
        sha256 = "09f18c9d890dfa8ab2582263bb18d1efe9c1f3eb2decff049f7b540aa4fe27e7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
