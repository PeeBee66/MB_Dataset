
rule MB_def269ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:00:59.008458"
        sha256 = "def269ce55605eb1b9e681964f5466b7f954e476749a879148e9614f9ab69a0e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
