
rule MB_6a9a8768
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:04:26.227506"
        sha256 = "6a9a8768aa04b3ac4aa2df4e5b7ab8bf49292b8c28df838fca37869bc9223baf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
