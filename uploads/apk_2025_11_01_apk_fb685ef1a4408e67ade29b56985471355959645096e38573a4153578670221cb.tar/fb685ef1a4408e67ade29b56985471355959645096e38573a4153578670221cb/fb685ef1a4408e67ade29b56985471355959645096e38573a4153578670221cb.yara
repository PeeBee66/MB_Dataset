
rule MB_fb685ef1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:38.591663"
        sha256 = "fb685ef1a4408e67ade29b56985471355959645096e38573a4153578670221cb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
