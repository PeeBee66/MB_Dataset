
rule MB_f5ebb7fa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:40.784502"
        sha256 = "f5ebb7fab5aec573f555be634e0f0431fb742b0a4524973760ef045e3d1b2cf5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
