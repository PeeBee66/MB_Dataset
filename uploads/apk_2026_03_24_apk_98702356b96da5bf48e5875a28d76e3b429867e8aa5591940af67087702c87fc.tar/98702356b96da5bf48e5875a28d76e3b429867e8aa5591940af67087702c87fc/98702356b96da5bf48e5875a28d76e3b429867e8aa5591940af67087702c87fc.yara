
rule MB_98702356
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:23.595778"
        sha256 = "98702356b96da5bf48e5875a28d76e3b429867e8aa5591940af67087702c87fc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
