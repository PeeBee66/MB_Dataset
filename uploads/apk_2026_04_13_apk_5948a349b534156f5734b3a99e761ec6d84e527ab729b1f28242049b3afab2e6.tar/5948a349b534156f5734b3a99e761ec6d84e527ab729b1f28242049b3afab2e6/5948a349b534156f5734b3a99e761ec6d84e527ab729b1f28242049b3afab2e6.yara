
rule MB_5948a349
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-13T00:00:33.254515"
        sha256 = "5948a349b534156f5734b3a99e761ec6d84e527ab729b1f28242049b3afab2e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
