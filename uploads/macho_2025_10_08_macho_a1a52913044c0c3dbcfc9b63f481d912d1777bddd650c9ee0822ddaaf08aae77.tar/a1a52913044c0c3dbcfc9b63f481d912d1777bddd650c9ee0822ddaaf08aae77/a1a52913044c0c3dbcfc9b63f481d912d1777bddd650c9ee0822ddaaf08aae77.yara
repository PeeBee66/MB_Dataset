
rule MB_a1a52913
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:55.303316"
        sha256 = "a1a52913044c0c3dbcfc9b63f481d912d1777bddd650c9ee0822ddaaf08aae77"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
