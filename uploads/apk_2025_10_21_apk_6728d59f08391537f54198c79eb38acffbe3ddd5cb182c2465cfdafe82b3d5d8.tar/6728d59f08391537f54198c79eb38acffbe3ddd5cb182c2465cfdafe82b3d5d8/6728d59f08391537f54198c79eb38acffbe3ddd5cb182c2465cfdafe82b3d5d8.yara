
rule MB_6728d59f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:55.992772"
        sha256 = "6728d59f08391537f54198c79eb38acffbe3ddd5cb182c2465cfdafe82b3d5d8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
