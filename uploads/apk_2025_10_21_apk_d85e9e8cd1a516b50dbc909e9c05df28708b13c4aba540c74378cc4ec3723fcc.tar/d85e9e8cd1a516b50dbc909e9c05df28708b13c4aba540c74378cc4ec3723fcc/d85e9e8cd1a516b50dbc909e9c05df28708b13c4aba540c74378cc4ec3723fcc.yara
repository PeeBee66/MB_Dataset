
rule MB_d85e9e8c
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:45:58.088550"
        sha256 = "d85e9e8cd1a516b50dbc909e9c05df28708b13c4aba540c74378cc4ec3723fcc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
