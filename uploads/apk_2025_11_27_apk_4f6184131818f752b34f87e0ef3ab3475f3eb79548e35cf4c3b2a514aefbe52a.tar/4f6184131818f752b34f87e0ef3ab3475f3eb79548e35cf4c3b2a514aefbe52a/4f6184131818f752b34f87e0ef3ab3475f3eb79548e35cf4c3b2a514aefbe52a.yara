
rule MB_4f618413
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:00:55.359132"
        sha256 = "4f6184131818f752b34f87e0ef3ab3475f3eb79548e35cf4c3b2a514aefbe52a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
