
rule MB_3ae18838
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-06T00:00:16.824412"
        sha256 = "3ae188387dd8b01cd5595b9ad937dae48d90c4d17fa8ba7f85d3a1f34d1ef3c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
