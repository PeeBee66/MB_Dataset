
rule MB_0be8a2ec
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:52:37.473306"
        sha256 = "0be8a2ecfa365ff6bf3ecbf82445a242ab6c6a5d36d53ad1b737a368fd1754a1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
