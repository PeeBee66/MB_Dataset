
rule MB_c784ead3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:28.646322"
        sha256 = "c784ead35c0a5ce88ddf21ac2250ffc71a395ededbe5f2f65c72d3e496800271"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
