
rule MB_050d91cd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-17T00:00:27.741872"
        sha256 = "050d91cde706f7c981f90878dbd50d92038caeedd38852a10e018e57f188e79b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
