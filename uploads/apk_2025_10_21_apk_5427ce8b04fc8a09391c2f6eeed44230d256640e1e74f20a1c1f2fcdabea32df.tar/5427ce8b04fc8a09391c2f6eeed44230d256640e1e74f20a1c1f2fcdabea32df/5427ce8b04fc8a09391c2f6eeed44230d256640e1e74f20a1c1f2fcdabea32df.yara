
rule MB_5427ce8b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:24.903232"
        sha256 = "5427ce8b04fc8a09391c2f6eeed44230d256640e1e74f20a1c1f2fcdabea32df"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
