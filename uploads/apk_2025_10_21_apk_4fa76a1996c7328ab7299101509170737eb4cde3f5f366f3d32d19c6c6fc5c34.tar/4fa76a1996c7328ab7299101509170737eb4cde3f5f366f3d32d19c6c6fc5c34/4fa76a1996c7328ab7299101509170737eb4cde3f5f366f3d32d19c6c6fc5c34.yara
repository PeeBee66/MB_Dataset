
rule MB_4fa76a19
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:33:57.223042"
        sha256 = "4fa76a1996c7328ab7299101509170737eb4cde3f5f366f3d32d19c6c6fc5c34"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
