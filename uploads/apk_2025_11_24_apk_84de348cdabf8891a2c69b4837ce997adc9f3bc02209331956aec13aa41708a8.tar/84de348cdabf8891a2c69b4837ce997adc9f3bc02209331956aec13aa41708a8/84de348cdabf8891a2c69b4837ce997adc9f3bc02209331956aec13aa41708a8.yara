
rule MB_84de348c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:46.487240"
        sha256 = "84de348cdabf8891a2c69b4837ce997adc9f3bc02209331956aec13aa41708a8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
