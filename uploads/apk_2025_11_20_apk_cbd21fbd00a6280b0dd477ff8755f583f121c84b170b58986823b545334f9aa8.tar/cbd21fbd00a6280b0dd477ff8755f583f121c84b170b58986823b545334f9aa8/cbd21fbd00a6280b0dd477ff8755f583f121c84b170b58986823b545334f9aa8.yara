
rule MB_cbd21fbd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:43.569359"
        sha256 = "cbd21fbd00a6280b0dd477ff8755f583f121c84b170b58986823b545334f9aa8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
