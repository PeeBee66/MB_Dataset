
rule MB_5bbc7312
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-04T01:13:30.477841"
        sha256 = "5bbc7312cf8096e7c11912f443c74f088d41b237c0d79e3498cdca370750cba1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
