
rule MB_0c8085ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-05T23:00:33.632131"
        sha256 = "0c8085cea946d655b266998fd60b1da33df73a4285328da3dabc7f0e7211411d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
