
rule MB_1c28b1ae
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:31.320358"
        sha256 = "1c28b1ae8472cdf59dff4cd5547c39d770f489ec49f424a96e9cdac655ccbd1b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
