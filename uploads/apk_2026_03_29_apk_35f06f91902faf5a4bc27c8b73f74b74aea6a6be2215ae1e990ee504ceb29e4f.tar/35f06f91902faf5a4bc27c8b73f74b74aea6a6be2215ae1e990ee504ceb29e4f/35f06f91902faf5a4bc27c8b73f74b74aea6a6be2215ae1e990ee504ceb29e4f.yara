
rule MB_35f06f91
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-28T23:00:35.648235"
        sha256 = "35f06f91902faf5a4bc27c8b73f74b74aea6a6be2215ae1e990ee504ceb29e4f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
