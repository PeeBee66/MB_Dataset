
rule MB_f690e30b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:57:11.722799"
        sha256 = "f690e30b6ee25c153effc5620fd7ec61481a449a127b54a67c7afc4c13d7917f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
