
rule MB_4e6c3f36
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-26T00:00:18.094011"
        sha256 = "4e6c3f36a00638652d94b6a79722c7e40e11d73674fc49b4dbdadbe82acae581"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
