
rule MB_faa72926
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:25.572259"
        sha256 = "faa72926f0d65694c64083cfd48a8a99afc00367b70abfcf1f57869426cae318"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
