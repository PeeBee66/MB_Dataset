
rule MB_c4f51ccd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:00:31.852198"
        sha256 = "c4f51ccde0525887b61fb919eefc5830b24ec35fdcb2af2aa3893e5f56957c40"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
