
rule MB_2dc25824
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:21.981254"
        sha256 = "2dc258246d84bab81f6684165084861f714f76d013222d944db2eed257e27c60"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
