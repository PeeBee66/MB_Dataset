
rule MB_64b4f8c8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:30.646173"
        sha256 = "64b4f8c86ea5ef925da573e7667ca93d32f4fb27fd6a702f5e99ccc4d087f612"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
