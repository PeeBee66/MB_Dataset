
rule MB_ee90df06
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:01:59.948511"
        sha256 = "ee90df061740b8cf0cdce8dba04ff34c205adf3271695e5310d04723dd9a2a47"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
