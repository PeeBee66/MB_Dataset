
rule MB_d5704d5e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:00:34.804417"
        sha256 = "d5704d5e103be01ad86683b6271edb65ce7949ff121dc964a4276bf30fb7622d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
