
rule MB_a6ed100a
{
    meta:
        description = "Auto-generated rule for GodFather"
        author = "MB-Collector"
        date = "2026-04-07T00:00:46.514089"
        sha256 = "a6ed100ae42e4fdabfd1b4c992762152bc4a11cc8e521b647b444c75bb7a9782"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
