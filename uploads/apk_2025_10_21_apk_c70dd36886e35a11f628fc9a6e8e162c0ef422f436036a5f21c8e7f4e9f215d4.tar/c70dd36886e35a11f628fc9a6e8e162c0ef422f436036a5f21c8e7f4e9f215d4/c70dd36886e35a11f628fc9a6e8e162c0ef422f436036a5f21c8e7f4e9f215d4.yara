
rule MB_c70dd368
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:28:11.993209"
        sha256 = "c70dd36886e35a11f628fc9a6e8e162c0ef422f436036a5f21c8e7f4e9f215d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
