
rule MB_e95e642a
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:46:05.812710"
        sha256 = "e95e642a99f9c281a9355441ba062de9239ba0f8464a862bfa61db371ea38436"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
