
rule MB_cec6fc64
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:27.809432"
        sha256 = "cec6fc6496687b177b14d6699d82a18840b528bff5543dfb6e23c0849f3c8de2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
