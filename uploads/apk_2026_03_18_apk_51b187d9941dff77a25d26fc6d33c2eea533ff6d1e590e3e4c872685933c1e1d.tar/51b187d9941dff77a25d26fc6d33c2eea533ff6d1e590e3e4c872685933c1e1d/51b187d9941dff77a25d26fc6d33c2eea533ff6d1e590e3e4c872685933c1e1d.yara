
rule MB_51b187d9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:00:19.319702"
        sha256 = "51b187d9941dff77a25d26fc6d33c2eea533ff6d1e590e3e4c872685933c1e1d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
