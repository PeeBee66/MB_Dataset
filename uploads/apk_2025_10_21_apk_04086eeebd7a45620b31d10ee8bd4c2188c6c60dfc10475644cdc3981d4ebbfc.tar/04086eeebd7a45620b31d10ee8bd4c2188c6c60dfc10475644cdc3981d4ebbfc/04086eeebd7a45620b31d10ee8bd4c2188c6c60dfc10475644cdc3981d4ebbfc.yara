
rule MB_04086eee
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:36.471992"
        sha256 = "04086eeebd7a45620b31d10ee8bd4c2188c6c60dfc10475644cdc3981d4ebbfc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
