
rule MB_115a5502
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:05:55.617296"
        sha256 = "115a55024958c72796a213161cc1378159ee41a4beae51267b0cd2a87ae1e376"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
