
rule MB_dbb1e32c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:52.699494"
        sha256 = "dbb1e32c62ab33822baeb4f35744075831f17af8a0b6303c1dcd389d41dc5eaa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
