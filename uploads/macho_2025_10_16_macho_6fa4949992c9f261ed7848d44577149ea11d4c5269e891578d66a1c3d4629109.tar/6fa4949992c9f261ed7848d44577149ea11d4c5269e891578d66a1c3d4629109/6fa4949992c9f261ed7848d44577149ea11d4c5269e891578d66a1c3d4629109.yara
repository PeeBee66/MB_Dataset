
rule MB_6fa49499
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-15T23:00:41.700181"
        sha256 = "6fa4949992c9f261ed7848d44577149ea11d4c5269e891578d66a1c3d4629109"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
