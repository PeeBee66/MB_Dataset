
rule MB_90676ad3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-27T23:00:12.991227"
        sha256 = "90676ad3a1a23d832f9d532f688d4b2d2dd366d5fd0fdab7b6f85fec764a542e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
