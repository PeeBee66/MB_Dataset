
rule MB_38cfda78
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:26.858437"
        sha256 = "38cfda78856fff910ca24d071dbfc886557714f4ef0e46b9b8b2d5b1a7944d71"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
