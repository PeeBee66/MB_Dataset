
rule MB_cde77aaa
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:22.450345"
        sha256 = "cde77aaa27981cddc0930f5151deeaae7c98edf56fccbd1d00685dd879b46dc2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
