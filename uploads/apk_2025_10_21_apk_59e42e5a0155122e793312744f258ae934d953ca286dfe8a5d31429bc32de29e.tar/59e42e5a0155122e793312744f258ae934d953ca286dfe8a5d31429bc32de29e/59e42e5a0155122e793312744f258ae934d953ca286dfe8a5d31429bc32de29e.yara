
rule MB_59e42e5a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:10.410067"
        sha256 = "59e42e5a0155122e793312744f258ae934d953ca286dfe8a5d31429bc32de29e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
