
rule MB_6564e736
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:52.159302"
        sha256 = "6564e7362b89d453173884e35d96ff5ce1de7ecbad102b0f5450300418b5de9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
