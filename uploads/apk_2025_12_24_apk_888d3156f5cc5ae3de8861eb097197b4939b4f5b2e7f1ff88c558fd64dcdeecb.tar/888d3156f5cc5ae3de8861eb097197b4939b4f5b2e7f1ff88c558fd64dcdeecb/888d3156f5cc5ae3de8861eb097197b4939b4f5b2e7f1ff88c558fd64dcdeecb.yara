
rule MB_888d3156
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:23.246019"
        sha256 = "888d3156f5cc5ae3de8861eb097197b4939b4f5b2e7f1ff88c558fd64dcdeecb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
