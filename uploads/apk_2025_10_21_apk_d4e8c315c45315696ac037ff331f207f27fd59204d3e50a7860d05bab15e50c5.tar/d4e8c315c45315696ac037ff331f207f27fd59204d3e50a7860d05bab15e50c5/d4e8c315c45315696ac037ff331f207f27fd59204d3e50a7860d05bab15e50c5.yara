
rule MB_d4e8c315
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:03.837437"
        sha256 = "d4e8c315c45315696ac037ff331f207f27fd59204d3e50a7860d05bab15e50c5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
