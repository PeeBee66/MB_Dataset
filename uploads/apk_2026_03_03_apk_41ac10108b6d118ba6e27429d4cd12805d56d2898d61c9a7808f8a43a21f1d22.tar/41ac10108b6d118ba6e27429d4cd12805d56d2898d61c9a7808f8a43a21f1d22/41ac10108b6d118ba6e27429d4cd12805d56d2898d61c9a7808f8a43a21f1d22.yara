
rule MB_41ac1010
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-02T23:00:27.401840"
        sha256 = "41ac10108b6d118ba6e27429d4cd12805d56d2898d61c9a7808f8a43a21f1d22"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
