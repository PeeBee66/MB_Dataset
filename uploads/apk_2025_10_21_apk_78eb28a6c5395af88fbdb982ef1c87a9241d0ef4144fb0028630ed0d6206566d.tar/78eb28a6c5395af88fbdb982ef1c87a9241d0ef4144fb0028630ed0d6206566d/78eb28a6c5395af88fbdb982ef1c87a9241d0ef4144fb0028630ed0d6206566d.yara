
rule MB_78eb28a6
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:11:30.883103"
        sha256 = "78eb28a6c5395af88fbdb982ef1c87a9241d0ef4144fb0028630ed0d6206566d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
