
rule MB_5494db78
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-12T00:00:17.930908"
        sha256 = "5494db78d03c9b3061c780520fc6713fa16cc8469c18ec9acb3d8eddff91964a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
