
rule MB_563bc028
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:32.017188"
        sha256 = "563bc028fac5f38f3849a3808bcba9cc41beeaf4b9ff771d383954beb1267e0b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
