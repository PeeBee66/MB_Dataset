
rule MB_5b8e04cf
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-05-05T00:00:21.007945"
        sha256 = "5b8e04cf2b647df686f9be2fc3186cdcc070dff5ba772fb9848c8cd0f2a5427d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
