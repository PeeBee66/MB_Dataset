
rule MB_f85434e6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:01:32.787576"
        sha256 = "f85434e67d0263de0ef643d05823722e096459221d10fd9bba67569bb8c440e4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
