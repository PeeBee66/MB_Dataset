
rule MB_1c5d65a7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:11.677600"
        sha256 = "1c5d65a779e0cf35aa382fc53eb142c11bd0e0779b791f3d41a6f524dcd3a4c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
