
rule MB_b0372780
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:14.036688"
        sha256 = "b0372780f0567411a31ac05e3c1a47d3499946f54002218da75a23fac68511c5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
