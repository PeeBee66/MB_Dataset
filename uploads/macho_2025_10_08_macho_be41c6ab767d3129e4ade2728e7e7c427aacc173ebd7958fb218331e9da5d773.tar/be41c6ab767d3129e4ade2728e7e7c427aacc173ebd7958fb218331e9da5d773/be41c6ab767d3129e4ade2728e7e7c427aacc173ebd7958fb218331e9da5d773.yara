
rule MB_be41c6ab
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:35.958669"
        sha256 = "be41c6ab767d3129e4ade2728e7e7c427aacc173ebd7958fb218331e9da5d773"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
