
rule MB_ac1da53a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:15.024989"
        sha256 = "ac1da53ad3a946c59dec4d5e1beac874448d14e0939d18fb8a5d7775e9560cd3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
