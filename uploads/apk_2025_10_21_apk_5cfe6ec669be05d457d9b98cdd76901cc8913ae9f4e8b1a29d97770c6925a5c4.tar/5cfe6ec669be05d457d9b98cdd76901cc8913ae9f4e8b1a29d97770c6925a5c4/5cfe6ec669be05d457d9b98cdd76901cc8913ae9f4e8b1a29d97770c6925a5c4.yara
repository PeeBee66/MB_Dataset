
rule MB_5cfe6ec6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:28:37.042783"
        sha256 = "5cfe6ec669be05d457d9b98cdd76901cc8913ae9f4e8b1a29d97770c6925a5c4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
