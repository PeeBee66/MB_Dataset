
rule MB_f262ff39
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:53.864337"
        sha256 = "f262ff39e4916629d4c33ce0e5de06a2e5537818811e5b668f69dac550307e0c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
