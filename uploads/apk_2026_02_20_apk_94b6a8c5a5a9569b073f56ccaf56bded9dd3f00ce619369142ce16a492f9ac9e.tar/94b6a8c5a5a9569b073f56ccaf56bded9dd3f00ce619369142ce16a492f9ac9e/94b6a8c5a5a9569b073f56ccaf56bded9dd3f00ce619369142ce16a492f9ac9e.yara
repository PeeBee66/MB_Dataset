
rule MB_94b6a8c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-19T23:00:20.600523"
        sha256 = "94b6a8c5a5a9569b073f56ccaf56bded9dd3f00ce619369142ce16a492f9ac9e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
