
rule MB_6f1fb8d7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:04.610827"
        sha256 = "6f1fb8d7517ac977118ddfd4ec96f79d67cc57b63f03f7c22e8e8d79e1408e5d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
