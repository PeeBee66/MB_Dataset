
rule MB_ff3169bc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:45:25.415143"
        sha256 = "ff3169bc112b0773eec49a4c091edd7756eb72ef2e60c23c30161f003f752509"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
