
rule MB_9aadd8fb
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-04T23:00:13.709311"
        sha256 = "9aadd8fb01918d7ecbb9b2613d1a7551a51d69db97e51a056963adfa38b08370"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
