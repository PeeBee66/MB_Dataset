
rule MB_9d3f0d7a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:00:54.034534"
        sha256 = "9d3f0d7a99c12c031b92f855c32971de7bd6bacdbff0b54482ecfe75497662d5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
