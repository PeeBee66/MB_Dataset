
rule MB_1584dff2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:14.130124"
        sha256 = "1584dff2acdc099a85a5a5d051f75104955b486c3759f02507da2659e9eb3dd7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
