
rule MB_2625df6b
{
    meta:
        description = "Auto-generated rule for ClayRAT"
        author = "MB-Collector"
        date = "2025-11-07T23:00:43.044792"
        sha256 = "2625df6b52a737543cbf542325dfcfc6208d2be67c4aa0cd26b6a0e3aa5bdb33"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
