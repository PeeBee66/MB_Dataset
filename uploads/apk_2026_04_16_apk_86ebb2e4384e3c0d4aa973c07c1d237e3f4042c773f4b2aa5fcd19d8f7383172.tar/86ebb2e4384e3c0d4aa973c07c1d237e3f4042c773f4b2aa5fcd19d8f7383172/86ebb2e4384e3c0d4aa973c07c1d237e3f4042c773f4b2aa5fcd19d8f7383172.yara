
rule MB_86ebb2e4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:02:06.064368"
        sha256 = "86ebb2e4384e3c0d4aa973c07c1d237e3f4042c773f4b2aa5fcd19d8f7383172"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
