
rule MB_16cb7952
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-14T00:00:16.395146"
        sha256 = "16cb7952ab3ce88ec30b57e1c5f16a8871457e9985d43675aae47d8ddb5044c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
