
rule MB_d58ef410
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:21.172769"
        sha256 = "d58ef410f18b146fe4e2827e6e347dc97bf5dd84cb8cfa9a578e10d9473a94ac"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
