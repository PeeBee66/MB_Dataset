
rule MB_118f0bba
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:32.091976"
        sha256 = "118f0bba26f3fd4f1c535ba9117ec80eda9945e6a7fe8af7511178ac60a77170"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
