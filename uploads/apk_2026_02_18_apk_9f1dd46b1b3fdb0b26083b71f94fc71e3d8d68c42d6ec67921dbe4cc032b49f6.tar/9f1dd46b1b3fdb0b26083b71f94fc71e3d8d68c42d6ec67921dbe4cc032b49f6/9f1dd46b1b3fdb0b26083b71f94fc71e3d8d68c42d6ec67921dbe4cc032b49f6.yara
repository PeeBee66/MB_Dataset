
rule MB_9f1dd46b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-17T23:00:38.670760"
        sha256 = "9f1dd46b1b3fdb0b26083b71f94fc71e3d8d68c42d6ec67921dbe4cc032b49f6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
