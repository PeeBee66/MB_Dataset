
rule MB_2cdfb07d
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-20T11:51:14.995849"
        sha256 = "2cdfb07d6cad4b2dcbbdb2713a99ae70dcdd2c049d2e3b356de4609a905e500a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
