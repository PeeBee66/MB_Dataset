
rule MB_ef570e12
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:16.851218"
        sha256 = "ef570e12807142d59dbb278bf5533949c70662b679313384191afbc957f4df2f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
