
rule MB_0dff1024
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:07.139288"
        sha256 = "0dff1024d58783938afb93259f7e5030845c3a36452cba66e4d25b43b9aab212"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
