
rule MB_f9b6deff
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:47.633934"
        sha256 = "f9b6deff3cb6ea3733befb27efdf20d3ad21da4a27801f1e69eb142e76ec2fb5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
