
rule MB_3b6a4cb6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:54.918123"
        sha256 = "3b6a4cb657b016bde13deaadf63e92be40d981ab4c83135c6fc58bded3abfa14"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
