
rule MB_f7dc2496
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:13.257764"
        sha256 = "f7dc24966272b86432e72bfe7e0d56fb27e951ce67f3044c14e486c37bf116f8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
