
rule MB_1ae0c4ff
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:48:52.074493"
        sha256 = "1ae0c4ffe18e7934c019ad1279219d1e8e8491bf62e8b34102e1497010c58247"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
