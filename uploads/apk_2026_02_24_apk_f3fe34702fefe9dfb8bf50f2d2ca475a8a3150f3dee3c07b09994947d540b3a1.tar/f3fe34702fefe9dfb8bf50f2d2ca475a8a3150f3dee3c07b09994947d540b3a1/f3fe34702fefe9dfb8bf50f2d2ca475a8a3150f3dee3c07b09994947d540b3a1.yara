
rule MB_f3fe3470
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:27.440352"
        sha256 = "f3fe34702fefe9dfb8bf50f2d2ca475a8a3150f3dee3c07b09994947d540b3a1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
