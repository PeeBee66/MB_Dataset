
rule MB_8d7a00c6
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:05:36.119474"
        sha256 = "8d7a00c635ab25bcffc225610b693302aee57c239df278f070d374b28b9f28b5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
