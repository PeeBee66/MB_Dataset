
rule MB_1495da4f
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:20.065287"
        sha256 = "1495da4ff455fceb8fc73f38b75d65be3435c649b2aaf014124e9c58da930c37"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
