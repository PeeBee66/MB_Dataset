
rule MB_77c54058
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:34.832504"
        sha256 = "77c54058a2bb45219e6ee860430f5ea8ce8e6ed2e58fba05f0d9bf74ffb7b4ef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
