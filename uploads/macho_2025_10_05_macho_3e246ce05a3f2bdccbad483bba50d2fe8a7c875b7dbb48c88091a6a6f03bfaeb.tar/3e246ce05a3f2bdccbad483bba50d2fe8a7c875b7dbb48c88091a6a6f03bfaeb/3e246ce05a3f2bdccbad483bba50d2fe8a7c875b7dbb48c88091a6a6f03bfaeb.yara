
rule MB_3e246ce0
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:06.132237"
        sha256 = "3e246ce05a3f2bdccbad483bba50d2fe8a7c875b7dbb48c88091a6a6f03bfaeb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
