
rule MB_f80ff072
{
    meta:
        description = "Auto-generated rule for MacSync"
        author = "MB-Collector"
        date = "2026-04-16T00:03:20.040790"
        sha256 = "f80ff072316e2d62490df743cbd5363bfb6ec5459409cc162d0602f7a1c607bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
