
rule MB_9bf82be9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:01.035413"
        sha256 = "9bf82be9de4ad5dc7c80a6fbaa035cd23c2b8bd6390e9f763611a0b70755710c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
