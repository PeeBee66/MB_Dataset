
rule MB_3cae7631
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:02:07.247401"
        sha256 = "3cae76312e7018523e42436b1c2ea551ccea37eb37a426cfe7fea1ca5e003cb0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
