
rule MB_6a7b196e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-28T00:00:20.843839"
        sha256 = "6a7b196e473df511ee7d8436f77f71a9c7eff0c120f9c47eb9f12113c7e8c4be"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
