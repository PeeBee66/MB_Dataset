
rule MB_360966ad
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:32:17.710461"
        sha256 = "360966ad8752d040e9aaae5cb4a5913e6f85edcf56ecfeb8246729b45d0e6c78"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
