
rule MB_b7e06f27
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:07.906128"
        sha256 = "b7e06f27f442e6406fe1bbbbfa1db5e9ad6c57c15b34539ef56e743b54c2f10b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
