
rule MB_244ee6d2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:16.401771"
        sha256 = "244ee6d20ab518f4bfb34bfad110467b034e06bddcaaf6bb90ffba983a0aaa85"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
