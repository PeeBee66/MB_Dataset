
rule MB_c54861f5
{
    meta:
        description = "Auto-generated rule for Herodotus"
        author = "MB-Collector"
        date = "2026-01-16T23:00:25.507996"
        sha256 = "c54861f54bcf72de5f16611ef0eec32c5c5f937bf3fdb5d6e611b2a2f9acdf2a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
