
rule MB_9c75acc4
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:29:34.660950"
        sha256 = "9c75acc4f184c07a96a8c6fcdf0f03eb6089145e74b70d22e84fdfedaf439650"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
