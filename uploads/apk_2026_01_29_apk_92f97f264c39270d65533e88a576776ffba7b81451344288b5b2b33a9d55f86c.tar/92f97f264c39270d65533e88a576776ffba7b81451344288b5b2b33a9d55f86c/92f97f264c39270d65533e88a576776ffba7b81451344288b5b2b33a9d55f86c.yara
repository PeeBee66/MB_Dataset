
rule MB_92f97f26
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-28T23:00:13.383594"
        sha256 = "92f97f264c39270d65533e88a576776ffba7b81451344288b5b2b33a9d55f86c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
