
rule MB_ec461744
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:38:42.469470"
        sha256 = "ec461744c75f66d73f74a4da4b5da9597d84dd5d5a9e35dd826a80b33cff814d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
