
rule MB_a0540000
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:35.939735"
        sha256 = "a05400000843fbad6b28d2b76fc201c3d415a72d88d8dc548fafd8bae073c640"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
