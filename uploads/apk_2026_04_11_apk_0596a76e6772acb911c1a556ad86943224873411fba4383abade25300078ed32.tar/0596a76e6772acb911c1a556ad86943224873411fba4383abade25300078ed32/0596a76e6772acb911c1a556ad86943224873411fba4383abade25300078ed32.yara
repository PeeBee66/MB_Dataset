
rule MB_0596a76e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:01:01.215568"
        sha256 = "0596a76e6772acb911c1a556ad86943224873411fba4383abade25300078ed32"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
