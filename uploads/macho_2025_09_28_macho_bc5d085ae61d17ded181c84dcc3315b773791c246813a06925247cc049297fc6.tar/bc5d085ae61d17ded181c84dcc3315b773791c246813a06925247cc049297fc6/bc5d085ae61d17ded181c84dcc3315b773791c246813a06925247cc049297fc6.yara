
rule MB_bc5d085a
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:53.926339"
        sha256 = "bc5d085ae61d17ded181c84dcc3315b773791c246813a06925247cc049297fc6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
