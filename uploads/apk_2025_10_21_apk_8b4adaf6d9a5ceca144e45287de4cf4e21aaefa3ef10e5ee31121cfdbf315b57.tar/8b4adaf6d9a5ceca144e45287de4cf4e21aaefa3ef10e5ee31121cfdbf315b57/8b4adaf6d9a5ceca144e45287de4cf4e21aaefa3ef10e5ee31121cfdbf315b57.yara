
rule MB_8b4adaf6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:11.022808"
        sha256 = "8b4adaf6d9a5ceca144e45287de4cf4e21aaefa3ef10e5ee31121cfdbf315b57"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
