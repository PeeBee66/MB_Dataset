
rule MB_d89f3a1a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:52.962956"
        sha256 = "d89f3a1a36fb2a782956545e19c540b514643ed48098cdd1ff0ef84dc2571e3c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
