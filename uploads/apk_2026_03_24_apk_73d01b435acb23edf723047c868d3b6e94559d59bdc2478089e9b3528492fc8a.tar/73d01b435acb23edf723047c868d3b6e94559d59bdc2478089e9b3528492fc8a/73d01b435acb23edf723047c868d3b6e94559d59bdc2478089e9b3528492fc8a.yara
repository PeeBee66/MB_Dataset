
rule MB_73d01b43
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-23T23:00:27.108969"
        sha256 = "73d01b435acb23edf723047c868d3b6e94559d59bdc2478089e9b3528492fc8a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
