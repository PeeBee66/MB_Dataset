
rule MB_d8e50cca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:29:00.756854"
        sha256 = "d8e50ccaacdf3a4eeda5d57c427d457ff8849c82541a10ddbbe818474cce2ef0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
