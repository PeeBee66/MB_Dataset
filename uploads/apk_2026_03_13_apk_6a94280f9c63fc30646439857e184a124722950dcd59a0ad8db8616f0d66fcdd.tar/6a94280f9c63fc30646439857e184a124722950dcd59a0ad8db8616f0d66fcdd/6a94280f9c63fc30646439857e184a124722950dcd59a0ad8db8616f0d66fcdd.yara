
rule MB_6a94280f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:00:41.636717"
        sha256 = "6a94280f9c63fc30646439857e184a124722950dcd59a0ad8db8616f0d66fcdd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
