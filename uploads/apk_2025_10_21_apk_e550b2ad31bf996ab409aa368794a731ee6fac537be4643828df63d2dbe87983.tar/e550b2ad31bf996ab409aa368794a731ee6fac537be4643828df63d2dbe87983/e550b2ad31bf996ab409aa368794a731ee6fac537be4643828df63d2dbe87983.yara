
rule MB_e550b2ad
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:29:58.613952"
        sha256 = "e550b2ad31bf996ab409aa368794a731ee6fac537be4643828df63d2dbe87983"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
