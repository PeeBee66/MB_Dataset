
rule MB_7d66a60b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-11T23:00:23.560351"
        sha256 = "7d66a60bcc92d38789d530fbaddac8132b1285ae23bc51e51d929b1eec7ce8dd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
