
rule MB_55fe4f5c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:51.200581"
        sha256 = "55fe4f5c26339f7732d696f87757ed471c63dbff35f82d0e95358684140cb77a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
