
rule MB_16d9768d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:00:16.052554"
        sha256 = "16d9768d71ce48325213018fa6358498875415b5284c8fea6c2583c343a6dee1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
