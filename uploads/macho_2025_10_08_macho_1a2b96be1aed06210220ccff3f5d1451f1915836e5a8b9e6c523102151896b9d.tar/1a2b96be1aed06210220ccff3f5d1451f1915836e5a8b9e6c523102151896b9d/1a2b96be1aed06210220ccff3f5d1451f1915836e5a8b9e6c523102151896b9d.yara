
rule MB_1a2b96be
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:18.886074"
        sha256 = "1a2b96be1aed06210220ccff3f5d1451f1915836e5a8b9e6c523102151896b9d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
