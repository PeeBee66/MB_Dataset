
rule MB_ca5b40e9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:00:48.898287"
        sha256 = "ca5b40e938f68321dfa3a7f1ad2a03db4ff6ba27fdae5e230654cd5c30090692"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
