
rule MB_292a74d8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:01:27.526993"
        sha256 = "292a74d8e56e7605802cace34f2ee9adef38a1455970b7468a83061ad86550da"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
