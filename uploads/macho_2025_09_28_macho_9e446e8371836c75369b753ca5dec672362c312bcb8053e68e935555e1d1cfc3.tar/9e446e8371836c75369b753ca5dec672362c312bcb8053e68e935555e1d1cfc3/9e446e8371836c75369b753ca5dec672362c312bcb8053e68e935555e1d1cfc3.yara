
rule MB_9e446e83
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:14.818402"
        sha256 = "9e446e8371836c75369b753ca5dec672362c312bcb8053e68e935555e1d1cfc3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
