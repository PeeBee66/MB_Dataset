
rule MB_3b1b8202
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:19.386515"
        sha256 = "3b1b82025c2ee1548752ef331426d1cd6e0085e99f2ac9141a5b16e95bd51f6f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
