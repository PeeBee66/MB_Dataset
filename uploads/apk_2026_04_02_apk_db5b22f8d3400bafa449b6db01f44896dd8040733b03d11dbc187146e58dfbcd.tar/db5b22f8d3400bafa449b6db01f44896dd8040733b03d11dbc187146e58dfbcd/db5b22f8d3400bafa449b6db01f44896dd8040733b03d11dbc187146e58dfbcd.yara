
rule MB_db5b22f8
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-01T23:00:24.888682"
        sha256 = "db5b22f8d3400bafa449b6db01f44896dd8040733b03d11dbc187146e58dfbcd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
