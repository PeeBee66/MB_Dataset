
rule MB_ef16cc81
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:28.739525"
        sha256 = "ef16cc8137d29356d0ef23b61ddb9cfd5e2784578fa818d54fe670bfa1e6ef73"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
