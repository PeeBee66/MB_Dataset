
rule MB_6cae7636
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-12T23:00:39.759235"
        sha256 = "6cae7636767bb48d5091d62ada45db718169e7b16d876640af4e98df8e6e6def"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
