
rule MB_ab7d708a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:45:34.514123"
        sha256 = "ab7d708afceccba163e07a574a8ccc25895f8c680758f693a6a76fdbe9fd8e56"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
