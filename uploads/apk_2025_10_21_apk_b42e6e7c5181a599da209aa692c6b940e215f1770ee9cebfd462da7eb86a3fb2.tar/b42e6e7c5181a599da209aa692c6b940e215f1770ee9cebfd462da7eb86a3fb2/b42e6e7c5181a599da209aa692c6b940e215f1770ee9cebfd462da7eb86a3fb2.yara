
rule MB_b42e6e7c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:59.583172"
        sha256 = "b42e6e7c5181a599da209aa692c6b940e215f1770ee9cebfd462da7eb86a3fb2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
