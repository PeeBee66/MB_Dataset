
rule MB_3ba6e955
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:12.254879"
        sha256 = "3ba6e9551aeae6fbbacff487bd89045e0c1536ef879c12ac12c1c155011672f6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
