
rule MB_fd57efac
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:42.348743"
        sha256 = "fd57efac4a5b16fef63d10eb1e8fcbd69d21c2f136d6c5b1de4b0b44455c87e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
