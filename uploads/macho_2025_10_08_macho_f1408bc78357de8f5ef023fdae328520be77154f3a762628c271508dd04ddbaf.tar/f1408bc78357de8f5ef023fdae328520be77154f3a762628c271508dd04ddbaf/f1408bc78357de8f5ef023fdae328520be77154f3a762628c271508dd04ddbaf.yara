
rule MB_f1408bc7
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:47.999108"
        sha256 = "f1408bc78357de8f5ef023fdae328520be77154f3a762628c271508dd04ddbaf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
