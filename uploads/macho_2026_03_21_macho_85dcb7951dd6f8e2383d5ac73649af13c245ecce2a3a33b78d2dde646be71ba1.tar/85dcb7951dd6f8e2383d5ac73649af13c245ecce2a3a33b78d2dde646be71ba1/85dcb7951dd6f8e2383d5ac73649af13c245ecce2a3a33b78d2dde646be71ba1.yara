
rule MB_85dcb795
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:00:44.797105"
        sha256 = "85dcb7951dd6f8e2383d5ac73649af13c245ecce2a3a33b78d2dde646be71ba1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
