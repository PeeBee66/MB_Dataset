
rule MB_c55f4e69
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:50.414247"
        sha256 = "c55f4e69dbe9e269573b3ce8135c0589906fac005549e940d5d7d37c566fe032"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
