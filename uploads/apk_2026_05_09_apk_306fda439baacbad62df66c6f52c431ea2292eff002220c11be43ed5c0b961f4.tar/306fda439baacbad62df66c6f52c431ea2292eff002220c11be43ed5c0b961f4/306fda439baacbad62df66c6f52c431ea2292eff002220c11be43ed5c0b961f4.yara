
rule MB_306fda43
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:51.506239"
        sha256 = "306fda439baacbad62df66c6f52c431ea2292eff002220c11be43ed5c0b961f4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
