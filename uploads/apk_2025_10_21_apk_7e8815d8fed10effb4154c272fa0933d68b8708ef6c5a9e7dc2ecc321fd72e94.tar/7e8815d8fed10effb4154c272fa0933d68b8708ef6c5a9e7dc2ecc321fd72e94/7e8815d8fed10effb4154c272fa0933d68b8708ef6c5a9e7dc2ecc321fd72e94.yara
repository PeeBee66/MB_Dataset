
rule MB_7e8815d8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:48.999479"
        sha256 = "7e8815d8fed10effb4154c272fa0933d68b8708ef6c5a9e7dc2ecc321fd72e94"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
