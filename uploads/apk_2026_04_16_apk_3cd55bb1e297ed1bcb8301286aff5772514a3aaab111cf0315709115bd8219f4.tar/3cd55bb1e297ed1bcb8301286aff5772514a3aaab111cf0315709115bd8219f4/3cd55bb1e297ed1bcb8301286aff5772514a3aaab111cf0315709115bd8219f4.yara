
rule MB_3cd55bb1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:45.002307"
        sha256 = "3cd55bb1e297ed1bcb8301286aff5772514a3aaab111cf0315709115bd8219f4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
