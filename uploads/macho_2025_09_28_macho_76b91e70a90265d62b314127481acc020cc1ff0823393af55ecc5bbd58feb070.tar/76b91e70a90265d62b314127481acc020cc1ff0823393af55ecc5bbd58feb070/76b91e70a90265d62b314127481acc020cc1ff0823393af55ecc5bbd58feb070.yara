
rule MB_76b91e70
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:43.542662"
        sha256 = "76b91e70a90265d62b314127481acc020cc1ff0823393af55ecc5bbd58feb070"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
