
rule MB_835f900a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-15T23:00:12.625799"
        sha256 = "835f900aa962403926bebe047f61015a79afcf567fd44018bc721b9dee7c19fb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
