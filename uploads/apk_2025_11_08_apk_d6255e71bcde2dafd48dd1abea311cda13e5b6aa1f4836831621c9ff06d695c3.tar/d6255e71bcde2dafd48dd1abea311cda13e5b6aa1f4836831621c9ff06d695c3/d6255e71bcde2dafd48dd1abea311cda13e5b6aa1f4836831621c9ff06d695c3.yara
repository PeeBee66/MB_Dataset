
rule MB_d6255e71
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:00:12.264822"
        sha256 = "d6255e71bcde2dafd48dd1abea311cda13e5b6aa1f4836831621c9ff06d695c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
