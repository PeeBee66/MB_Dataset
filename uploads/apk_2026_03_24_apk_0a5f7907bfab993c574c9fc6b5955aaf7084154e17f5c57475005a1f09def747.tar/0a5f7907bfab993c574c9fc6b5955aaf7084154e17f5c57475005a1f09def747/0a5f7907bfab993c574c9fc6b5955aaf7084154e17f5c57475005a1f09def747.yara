
rule MB_0a5f7907
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:09.399423"
        sha256 = "0a5f7907bfab993c574c9fc6b5955aaf7084154e17f5c57475005a1f09def747"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
