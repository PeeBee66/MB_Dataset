
rule MB_b2ec7345
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:54.936830"
        sha256 = "b2ec734521133a5355293480b3807f481c45f4921aec91e38bad5284e0a15242"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
