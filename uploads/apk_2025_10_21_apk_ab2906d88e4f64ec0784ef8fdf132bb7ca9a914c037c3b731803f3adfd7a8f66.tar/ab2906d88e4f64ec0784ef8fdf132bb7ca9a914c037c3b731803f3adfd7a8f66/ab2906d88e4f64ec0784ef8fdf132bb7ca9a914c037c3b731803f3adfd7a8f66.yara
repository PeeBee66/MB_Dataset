
rule MB_ab2906d8
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:27:10.902602"
        sha256 = "ab2906d88e4f64ec0784ef8fdf132bb7ca9a914c037c3b731803f3adfd7a8f66"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
