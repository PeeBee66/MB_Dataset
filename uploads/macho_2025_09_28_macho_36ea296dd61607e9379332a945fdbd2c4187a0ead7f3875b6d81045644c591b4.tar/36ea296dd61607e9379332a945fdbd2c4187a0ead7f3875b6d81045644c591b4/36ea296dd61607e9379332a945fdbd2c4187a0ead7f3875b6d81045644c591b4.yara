
rule MB_36ea296d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:21.870505"
        sha256 = "36ea296dd61607e9379332a945fdbd2c4187a0ead7f3875b6d81045644c591b4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
