
rule MB_b1d9da01
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:40.757957"
        sha256 = "b1d9da016ace01139cf5f3036fbd853631e4b776dba8b2a31d69bcd5dabd53ef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
