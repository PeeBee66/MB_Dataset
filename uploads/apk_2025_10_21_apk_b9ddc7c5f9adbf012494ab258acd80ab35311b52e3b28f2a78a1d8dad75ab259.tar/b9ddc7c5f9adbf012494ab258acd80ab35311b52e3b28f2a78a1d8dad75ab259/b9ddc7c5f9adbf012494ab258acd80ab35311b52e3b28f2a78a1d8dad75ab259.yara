
rule MB_b9ddc7c5
{
    meta:
        description = "Auto-generated rule for Crocodilus"
        author = "MB-Collector"
        date = "2025-10-20T11:52:19.773508"
        sha256 = "b9ddc7c5f9adbf012494ab258acd80ab35311b52e3b28f2a78a1d8dad75ab259"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
