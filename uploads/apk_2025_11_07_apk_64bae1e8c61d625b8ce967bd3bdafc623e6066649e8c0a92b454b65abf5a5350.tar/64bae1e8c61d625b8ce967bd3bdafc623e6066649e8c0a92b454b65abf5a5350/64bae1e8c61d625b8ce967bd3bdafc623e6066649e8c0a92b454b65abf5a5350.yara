
rule MB_64bae1e8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:00:13.412488"
        sha256 = "64bae1e8c61d625b8ce967bd3bdafc623e6066649e8c0a92b454b65abf5a5350"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
