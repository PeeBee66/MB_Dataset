
rule MB_2bd3c84e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:41.363980"
        sha256 = "2bd3c84e99c8d96bc328f7f8a6bb5f7395951c5b75720e15a593e66455a7335d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
