
rule MB_eab38fff
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:51.334393"
        sha256 = "eab38fff15b885790083ba4d4e27f51f8a6a50fdd0be204569d71704818e3f07"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
