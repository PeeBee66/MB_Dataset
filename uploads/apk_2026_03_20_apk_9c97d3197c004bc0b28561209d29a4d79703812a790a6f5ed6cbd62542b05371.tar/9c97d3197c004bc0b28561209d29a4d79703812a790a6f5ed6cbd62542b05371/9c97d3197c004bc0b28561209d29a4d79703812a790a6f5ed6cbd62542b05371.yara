
rule MB_9c97d319
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-03-19T23:00:37.194861"
        sha256 = "9c97d3197c004bc0b28561209d29a4d79703812a790a6f5ed6cbd62542b05371"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
