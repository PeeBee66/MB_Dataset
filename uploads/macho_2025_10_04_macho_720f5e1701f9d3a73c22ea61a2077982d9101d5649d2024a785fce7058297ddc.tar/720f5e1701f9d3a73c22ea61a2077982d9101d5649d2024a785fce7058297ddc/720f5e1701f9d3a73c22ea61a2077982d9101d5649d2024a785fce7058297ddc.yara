
rule MB_720f5e17
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:11.229802"
        sha256 = "720f5e1701f9d3a73c22ea61a2077982d9101d5649d2024a785fce7058297ddc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
