
rule MB_afaab76f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:00:31.100281"
        sha256 = "afaab76f446dc734de64c1d94e0dd1ae850a01c69fde12ccb98bacb98df82e9d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
