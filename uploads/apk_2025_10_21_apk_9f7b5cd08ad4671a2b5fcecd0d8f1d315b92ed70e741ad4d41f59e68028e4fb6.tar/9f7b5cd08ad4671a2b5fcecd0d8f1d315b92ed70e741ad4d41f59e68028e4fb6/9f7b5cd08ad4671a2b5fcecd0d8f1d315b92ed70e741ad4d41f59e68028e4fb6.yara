
rule MB_9f7b5cd0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:15.037053"
        sha256 = "9f7b5cd08ad4671a2b5fcecd0d8f1d315b92ed70e741ad4d41f59e68028e4fb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
