
rule MB_08c5044e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:00:37.307076"
        sha256 = "08c5044e32926a19f1ea6a176aa068a387cdf135c1af842ed25289f2ad63a85c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
