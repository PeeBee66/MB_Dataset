
rule MB_ad588cb1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:47.167304"
        sha256 = "ad588cb1dcff0b4d0acbdb31627b2e04ba0ef82aead492784d4a651f6fb11865"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
