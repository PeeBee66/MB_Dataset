
rule MB_99004f64
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:02:02.497673"
        sha256 = "99004f64b9fd6e5d86c1c451c121e90873a146bc52fa5195e153a05a06955912"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
