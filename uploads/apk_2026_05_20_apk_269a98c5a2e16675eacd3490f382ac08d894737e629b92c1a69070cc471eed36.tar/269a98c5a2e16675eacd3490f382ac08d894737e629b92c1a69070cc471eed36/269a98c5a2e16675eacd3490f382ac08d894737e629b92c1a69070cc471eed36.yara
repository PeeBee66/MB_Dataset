
rule MB_269a98c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-20T00:00:14.487346"
        sha256 = "269a98c5a2e16675eacd3490f382ac08d894737e629b92c1a69070cc471eed36"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
