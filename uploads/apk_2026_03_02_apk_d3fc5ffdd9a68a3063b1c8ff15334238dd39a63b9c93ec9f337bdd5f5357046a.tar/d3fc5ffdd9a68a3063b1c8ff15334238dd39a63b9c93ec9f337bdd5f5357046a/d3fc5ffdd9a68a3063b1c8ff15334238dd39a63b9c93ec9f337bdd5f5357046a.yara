
rule MB_d3fc5ffd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-01T23:00:14.264225"
        sha256 = "d3fc5ffdd9a68a3063b1c8ff15334238dd39a63b9c93ec9f337bdd5f5357046a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
