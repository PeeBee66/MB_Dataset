
rule MB_49b40786
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:26.051537"
        sha256 = "49b40786a01886ad8e962bd74e5d2e3ede8472de5cabe7b060284c54e5941182"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
