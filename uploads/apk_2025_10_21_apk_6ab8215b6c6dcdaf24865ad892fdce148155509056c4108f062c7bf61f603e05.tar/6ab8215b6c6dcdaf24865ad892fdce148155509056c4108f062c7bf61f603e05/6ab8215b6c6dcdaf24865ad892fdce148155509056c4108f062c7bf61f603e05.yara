
rule MB_6ab8215b
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:29:29.243340"
        sha256 = "6ab8215b6c6dcdaf24865ad892fdce148155509056c4108f062c7bf61f603e05"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
