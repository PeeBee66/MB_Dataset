
rule MB_8631fb6a
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:44.201624"
        sha256 = "8631fb6acec67e26e4fb8846ff26d64fda761f71027376d99766f76d2f043309"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
