
rule MB_5ba8803e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:21.766291"
        sha256 = "5ba8803e9ad73e72d1523d7bb16a4c117c6e031b8a10c70d70bc901a542c5b81"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
