
rule MB_c2d3a874
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:15.337821"
        sha256 = "c2d3a87445b3494264debb09bf57141109bb090da86e25a4f31fb3159a1e30e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
