
rule MB_fefcf775
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:47.783704"
        sha256 = "fefcf77539aea9754191c1a217436d2a7e6e1f9db6bd75cf3d70534c9322af1e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
