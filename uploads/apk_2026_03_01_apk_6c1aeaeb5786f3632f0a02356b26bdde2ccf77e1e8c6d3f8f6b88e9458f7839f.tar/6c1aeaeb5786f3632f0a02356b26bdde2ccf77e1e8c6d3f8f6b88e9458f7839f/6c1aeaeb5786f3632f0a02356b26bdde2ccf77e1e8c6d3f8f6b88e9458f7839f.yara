
rule MB_6c1aeaeb
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-28T23:00:32.561487"
        sha256 = "6c1aeaeb5786f3632f0a02356b26bdde2ccf77e1e8c6d3f8f6b88e9458f7839f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
