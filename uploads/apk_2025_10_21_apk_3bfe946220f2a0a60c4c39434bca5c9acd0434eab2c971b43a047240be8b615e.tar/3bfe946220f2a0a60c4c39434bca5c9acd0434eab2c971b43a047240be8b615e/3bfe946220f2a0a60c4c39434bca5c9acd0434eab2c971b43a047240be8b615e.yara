
rule MB_3bfe9462
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:26.109497"
        sha256 = "3bfe946220f2a0a60c4c39434bca5c9acd0434eab2c971b43a047240be8b615e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
