
rule MB_ef2001f6
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:19:09.085624"
        sha256 = "ef2001f670cc5a338be175847dfbeb2bccb52629d890b39c866dc8e1ea1f0620"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
