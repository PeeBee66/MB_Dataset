
rule MB_e3dedeed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-05T23:00:14.459913"
        sha256 = "e3dedeedfa33296dcc07590df9a3735e92c5dd23e4940a6b1caaa44460eaca76"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
