
rule MB_b3ff86f6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:01:16.322382"
        sha256 = "b3ff86f6fc849693a84e525b4839a58111c530c60fb117739a23dc7a7441f56c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
