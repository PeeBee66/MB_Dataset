
rule MB_6196536b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-09T23:02:04.835278"
        sha256 = "6196536b18c744a00202c54927ac18028566ed5255229fa048bf18367f388702"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
