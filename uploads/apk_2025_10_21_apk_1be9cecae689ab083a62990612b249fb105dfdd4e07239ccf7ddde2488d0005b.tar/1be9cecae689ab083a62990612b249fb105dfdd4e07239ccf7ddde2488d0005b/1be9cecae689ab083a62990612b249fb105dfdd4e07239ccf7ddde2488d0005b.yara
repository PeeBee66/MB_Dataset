
rule MB_1be9ceca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:51.190390"
        sha256 = "1be9cecae689ab083a62990612b249fb105dfdd4e07239ccf7ddde2488d0005b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
