
rule MB_4be8d630
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:38:04.592433"
        sha256 = "4be8d630cb586be691ace192030021185f630f45ccdd4752543389114f345fa2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
