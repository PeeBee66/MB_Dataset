
rule MB_f136736a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:04:52.279330"
        sha256 = "f136736a6aff1a46fbd39cc92e454ae76a1bce2812e159dcb50a7e71b6b386fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
