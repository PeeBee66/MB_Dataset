
rule MB_77938e7d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-16T23:00:45.930756"
        sha256 = "77938e7d01bf97cf19e7ab0be0f81a366ad5d2e8ccbae332f69383fb641ed1a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
