
rule MB_85527203
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:55:06.543422"
        sha256 = "855272032d5950c77c0971d6e70de5ccd69879a53660dffe0d8589706c28e484"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
