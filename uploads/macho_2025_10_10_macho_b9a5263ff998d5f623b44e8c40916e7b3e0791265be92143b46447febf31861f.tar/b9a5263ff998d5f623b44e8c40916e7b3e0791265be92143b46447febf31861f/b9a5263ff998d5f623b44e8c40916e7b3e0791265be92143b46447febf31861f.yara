
rule MB_b9a5263f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:35.692169"
        sha256 = "b9a5263ff998d5f623b44e8c40916e7b3e0791265be92143b46447febf31861f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
