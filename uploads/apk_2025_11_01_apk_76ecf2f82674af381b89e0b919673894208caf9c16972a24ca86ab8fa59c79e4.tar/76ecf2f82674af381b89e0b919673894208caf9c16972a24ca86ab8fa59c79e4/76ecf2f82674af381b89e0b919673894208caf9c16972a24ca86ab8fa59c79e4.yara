
rule MB_76ecf2f8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:25.791060"
        sha256 = "76ecf2f82674af381b89e0b919673894208caf9c16972a24ca86ab8fa59c79e4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
