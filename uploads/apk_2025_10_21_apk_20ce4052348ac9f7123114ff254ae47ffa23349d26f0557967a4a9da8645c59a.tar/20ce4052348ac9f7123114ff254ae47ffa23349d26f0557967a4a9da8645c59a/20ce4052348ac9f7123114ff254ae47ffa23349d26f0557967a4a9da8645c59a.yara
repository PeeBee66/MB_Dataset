
rule MB_20ce4052
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:35:53.303243"
        sha256 = "20ce4052348ac9f7123114ff254ae47ffa23349d26f0557967a4a9da8645c59a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
