
rule MB_b115b04b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-17T23:00:31.155509"
        sha256 = "b115b04b197b112eecf668fa549f65189e683cb87050708a72fcca268c9258e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
