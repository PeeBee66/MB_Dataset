
rule MB_6c570d1e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:00:57.251567"
        sha256 = "6c570d1e755b28bd8d2a9ec5c181a539e68e69bb56e354e4c6cece5c7aab027d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
