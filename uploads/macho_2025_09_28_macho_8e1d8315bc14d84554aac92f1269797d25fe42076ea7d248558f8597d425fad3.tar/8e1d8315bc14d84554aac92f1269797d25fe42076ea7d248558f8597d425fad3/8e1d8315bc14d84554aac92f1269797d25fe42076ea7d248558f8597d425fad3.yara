
rule MB_8e1d8315
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:33.115702"
        sha256 = "8e1d8315bc14d84554aac92f1269797d25fe42076ea7d248558f8597d425fad3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
