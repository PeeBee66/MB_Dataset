
rule MB_6d6b8a49
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-14T23:00:28.944356"
        sha256 = "6d6b8a49585f66d4eec4f4532dbfb0083e32558dea468942d75664cfbd30ad52"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
