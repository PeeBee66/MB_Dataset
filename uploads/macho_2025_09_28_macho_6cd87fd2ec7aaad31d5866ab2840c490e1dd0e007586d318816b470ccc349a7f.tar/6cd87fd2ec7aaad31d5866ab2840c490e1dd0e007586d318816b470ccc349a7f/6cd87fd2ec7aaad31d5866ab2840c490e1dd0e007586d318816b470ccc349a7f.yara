
rule MB_6cd87fd2
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:37.262599"
        sha256 = "6cd87fd2ec7aaad31d5866ab2840c490e1dd0e007586d318816b470ccc349a7f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
