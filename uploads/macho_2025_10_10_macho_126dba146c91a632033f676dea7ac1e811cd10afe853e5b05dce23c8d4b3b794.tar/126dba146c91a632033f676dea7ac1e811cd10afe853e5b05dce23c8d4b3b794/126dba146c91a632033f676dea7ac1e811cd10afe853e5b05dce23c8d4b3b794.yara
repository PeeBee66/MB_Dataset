
rule MB_126dba14
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:43.303619"
        sha256 = "126dba146c91a632033f676dea7ac1e811cd10afe853e5b05dce23c8d4b3b794"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
