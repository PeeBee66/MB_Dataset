
⚠️ DEFENSIVE RESEARCH USE ONLY ⚠️
This tool is for defensive security research purposes only.
Do NOT execute any downloaded samples.
All samples must be stored in quarantined volumes with noexec mount options.
Use in accordance with local laws and MalwareBazaar Terms of Service.
