
rule MB_6d55d90d
{
    meta:
        description = "Auto-generated rule for Crocodilus"
        author = "MB-Collector"
        date = "2025-10-20T11:53:00.413692"
        sha256 = "6d55d90d021b0980528f56d040e78fa7b85a96f5c244e23f330f24c8e80c1cb2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
