
rule MB_f2559c75
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-03T23:00:18.394981"
        sha256 = "f2559c75597cd7ab5ad85ff689191d0f8fd91f0c1e2af541c341baf6db8d32d7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
