
rule MB_abbb8095
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:18.207370"
        sha256 = "abbb809594dfee8ad6a7fd61a4e9c1b527ef6c700ab82f3644e07adeedb58839"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
