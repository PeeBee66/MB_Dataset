
rule MB_5c275341
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:02:01.783053"
        sha256 = "5c2753418101b4adac009b710b20834cea7259335495663c5d951d68f7300b27"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
