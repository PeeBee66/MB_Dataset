
rule MB_14ebed0d
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-23T23:00:29.200014"
        sha256 = "14ebed0d51768cfa90ace0d74ce17763a7accd1c526976e5b4609156521e7ca8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
