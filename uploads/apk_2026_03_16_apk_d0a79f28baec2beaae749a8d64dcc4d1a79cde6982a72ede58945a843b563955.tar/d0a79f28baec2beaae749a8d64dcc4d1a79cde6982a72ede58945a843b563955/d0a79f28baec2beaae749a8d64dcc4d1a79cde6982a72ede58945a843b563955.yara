
rule MB_d0a79f28
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:01:08.785675"
        sha256 = "d0a79f28baec2beaae749a8d64dcc4d1a79cde6982a72ede58945a843b563955"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
