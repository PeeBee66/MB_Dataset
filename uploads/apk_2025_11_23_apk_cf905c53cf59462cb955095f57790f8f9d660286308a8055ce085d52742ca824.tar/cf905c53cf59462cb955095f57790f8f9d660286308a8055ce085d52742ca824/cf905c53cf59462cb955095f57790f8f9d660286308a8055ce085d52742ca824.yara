
rule MB_cf905c53
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:01:11.703158"
        sha256 = "cf905c53cf59462cb955095f57790f8f9d660286308a8055ce085d52742ca824"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
