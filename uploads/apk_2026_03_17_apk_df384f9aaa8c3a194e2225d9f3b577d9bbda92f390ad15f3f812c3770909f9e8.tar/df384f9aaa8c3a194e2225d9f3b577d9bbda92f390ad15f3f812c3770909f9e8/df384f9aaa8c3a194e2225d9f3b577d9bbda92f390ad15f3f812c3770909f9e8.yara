
rule MB_df384f9a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-16T23:00:32.650581"
        sha256 = "df384f9aaa8c3a194e2225d9f3b577d9bbda92f390ad15f3f812c3770909f9e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
