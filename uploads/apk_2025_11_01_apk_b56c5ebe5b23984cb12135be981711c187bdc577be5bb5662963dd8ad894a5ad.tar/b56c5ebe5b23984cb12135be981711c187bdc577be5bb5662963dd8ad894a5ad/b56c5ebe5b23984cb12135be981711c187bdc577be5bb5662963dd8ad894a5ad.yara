
rule MB_b56c5ebe
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:16.896769"
        sha256 = "b56c5ebe5b23984cb12135be981711c187bdc577be5bb5662963dd8ad894a5ad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
