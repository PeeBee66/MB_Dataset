
rule MB_765aaded
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:09.371171"
        sha256 = "765aaded911b8286c83f5ac17fae581c72db5e864a708887a7eb6379e1afaeeb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
