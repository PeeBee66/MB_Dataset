
rule MB_0f297c48
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-16T23:00:31.480930"
        sha256 = "0f297c48875602c428e5099d22ffa1ceed64bf523fda55c08701ded6ecac03c7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
