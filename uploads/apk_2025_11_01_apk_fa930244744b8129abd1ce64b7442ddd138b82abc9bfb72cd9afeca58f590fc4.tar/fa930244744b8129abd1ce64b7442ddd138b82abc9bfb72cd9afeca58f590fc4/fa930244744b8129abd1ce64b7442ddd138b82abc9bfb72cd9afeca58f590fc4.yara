
rule MB_fa930244
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:15.908948"
        sha256 = "fa930244744b8129abd1ce64b7442ddd138b82abc9bfb72cd9afeca58f590fc4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
