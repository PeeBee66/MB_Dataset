
rule MB_1e7ebdce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-10T23:00:23.626162"
        sha256 = "1e7ebdcef5d6a5ab149872c4fbe9c23ba46e81b19e902350b77d645ccabcc1a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
