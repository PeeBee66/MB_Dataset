
rule MB_8580499c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:41.009608"
        sha256 = "8580499ca2e4891ab2cd25a8cfee7b4003444efddec23052a1a95cbeaab415f9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
