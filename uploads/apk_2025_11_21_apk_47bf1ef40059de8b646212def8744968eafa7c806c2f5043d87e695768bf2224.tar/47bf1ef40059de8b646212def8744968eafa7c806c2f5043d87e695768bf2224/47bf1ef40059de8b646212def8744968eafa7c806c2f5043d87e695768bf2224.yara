
rule MB_47bf1ef4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-20T23:00:47.343218"
        sha256 = "47bf1ef40059de8b646212def8744968eafa7c806c2f5043d87e695768bf2224"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
