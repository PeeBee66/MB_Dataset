
rule MB_c0d060d1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-17T23:00:19.043843"
        sha256 = "c0d060d1d7774daa163b08982f7e40ad8286c7c4b314e5071a688a524f976e73"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
