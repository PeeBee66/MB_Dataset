
rule MB_435badaa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:01:07.582548"
        sha256 = "435badaaeaf08f425a6918f343f079507e7f58fd9b72779ad31341608248a0c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
