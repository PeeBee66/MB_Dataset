
rule MB_e12642ad
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:43.560599"
        sha256 = "e12642ad644f3c62a15ae0b00cf34040ef299b2c9432c367f70535ba39e2bb0e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
