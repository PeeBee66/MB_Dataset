
rule MB_a6266178
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-08T23:00:20.311817"
        sha256 = "a6266178ca46c95564cf34767488cb03e44841e931d28f7371eaf96ea0f2f012"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
