
rule MB_773f8c3c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:35.959138"
        sha256 = "773f8c3c750304c2d1a4379b1ebdb5698c9de47149e298ddbd6ad28333196cb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
