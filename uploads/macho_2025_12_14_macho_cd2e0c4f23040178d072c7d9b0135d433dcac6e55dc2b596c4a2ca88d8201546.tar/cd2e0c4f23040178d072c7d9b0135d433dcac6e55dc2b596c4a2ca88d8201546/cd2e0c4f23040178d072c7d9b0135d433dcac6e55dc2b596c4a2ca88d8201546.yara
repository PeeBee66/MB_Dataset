
rule MB_cd2e0c4f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:01:00.350073"
        sha256 = "cd2e0c4f23040178d072c7d9b0135d433dcac6e55dc2b596c4a2ca88d8201546"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
