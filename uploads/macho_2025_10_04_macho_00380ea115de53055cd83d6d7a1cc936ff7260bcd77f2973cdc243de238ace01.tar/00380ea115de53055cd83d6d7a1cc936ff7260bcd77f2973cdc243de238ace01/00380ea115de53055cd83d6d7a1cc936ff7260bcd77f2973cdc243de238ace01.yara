
rule MB_00380ea1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:30.304575"
        sha256 = "00380ea115de53055cd83d6d7a1cc936ff7260bcd77f2973cdc243de238ace01"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
