
rule MB_3638754e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-11T23:00:26.783867"
        sha256 = "3638754e7fd889e9ced9127e7abe08191b7e8df3d60ed284c7b507e1e8082613"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
