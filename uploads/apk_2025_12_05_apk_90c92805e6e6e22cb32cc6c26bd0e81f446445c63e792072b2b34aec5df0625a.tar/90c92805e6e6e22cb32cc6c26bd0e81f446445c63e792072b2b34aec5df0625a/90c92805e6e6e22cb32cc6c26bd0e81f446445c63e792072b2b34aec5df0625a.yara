
rule MB_90c92805
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:32.534760"
        sha256 = "90c92805e6e6e22cb32cc6c26bd0e81f446445c63e792072b2b34aec5df0625a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
