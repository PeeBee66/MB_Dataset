
rule MB_9fbc8e45
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:48.030122"
        sha256 = "9fbc8e455843eb4c546e52108a47914d3d8dbbcce320b51bc859ef3309da7496"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
