
rule MB_4f621122
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:33.317450"
        sha256 = "4f621122c29871e1d0464421c2abfc01036f27f1d3523b8b4d143f82a2c08c5a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
