
rule MB_472bf6ea
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-14T23:00:50.469327"
        sha256 = "472bf6eacd2976aff240286f9368d903950e62377ddc7b5c0a82edbfc6f9cf19"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
