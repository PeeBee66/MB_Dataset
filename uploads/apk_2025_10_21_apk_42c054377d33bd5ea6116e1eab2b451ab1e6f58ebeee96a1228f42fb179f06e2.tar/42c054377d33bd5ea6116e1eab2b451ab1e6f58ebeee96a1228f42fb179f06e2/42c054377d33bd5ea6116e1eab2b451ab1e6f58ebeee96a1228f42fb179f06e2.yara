
rule MB_42c05437
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:41.130329"
        sha256 = "42c054377d33bd5ea6116e1eab2b451ab1e6f58ebeee96a1228f42fb179f06e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
