
rule MB_a1409171
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:13.000628"
        sha256 = "a140917183b3a1e51dca80b5a0f87dc5dc6eba21bc4d53d328f9ba24312d6075"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
