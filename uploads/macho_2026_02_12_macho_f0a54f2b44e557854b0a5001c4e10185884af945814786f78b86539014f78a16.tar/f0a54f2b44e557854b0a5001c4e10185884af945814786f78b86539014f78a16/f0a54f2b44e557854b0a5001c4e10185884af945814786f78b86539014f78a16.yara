
rule MB_f0a54f2b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:22.676111"
        sha256 = "f0a54f2b44e557854b0a5001c4e10185884af945814786f78b86539014f78a16"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
