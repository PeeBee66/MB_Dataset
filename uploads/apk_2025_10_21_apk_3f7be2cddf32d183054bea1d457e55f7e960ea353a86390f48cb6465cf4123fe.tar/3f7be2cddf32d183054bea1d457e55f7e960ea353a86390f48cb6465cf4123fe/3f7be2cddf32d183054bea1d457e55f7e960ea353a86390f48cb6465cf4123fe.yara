
rule MB_3f7be2cd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:55.531046"
        sha256 = "3f7be2cddf32d183054bea1d457e55f7e960ea353a86390f48cb6465cf4123fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
