
rule MB_4ce84f4e
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:29:48.094679"
        sha256 = "4ce84f4efe623a11b395038c8e324e2d744cc53c7aefcb33243bc3f0bba4b64d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
