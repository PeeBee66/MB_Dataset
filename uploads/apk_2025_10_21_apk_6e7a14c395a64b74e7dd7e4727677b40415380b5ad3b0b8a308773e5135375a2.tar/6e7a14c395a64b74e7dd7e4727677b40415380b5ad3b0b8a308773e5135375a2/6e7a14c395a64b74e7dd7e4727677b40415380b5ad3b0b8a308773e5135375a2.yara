
rule MB_6e7a14c3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:50.433827"
        sha256 = "6e7a14c395a64b74e7dd7e4727677b40415380b5ad3b0b8a308773e5135375a2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
