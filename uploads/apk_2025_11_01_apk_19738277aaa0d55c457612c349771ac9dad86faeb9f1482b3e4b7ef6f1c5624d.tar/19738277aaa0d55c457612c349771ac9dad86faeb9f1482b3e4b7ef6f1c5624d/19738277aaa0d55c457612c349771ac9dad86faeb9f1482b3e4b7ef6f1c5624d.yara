
rule MB_19738277
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:11.153137"
        sha256 = "19738277aaa0d55c457612c349771ac9dad86faeb9f1482b3e4b7ef6f1c5624d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
