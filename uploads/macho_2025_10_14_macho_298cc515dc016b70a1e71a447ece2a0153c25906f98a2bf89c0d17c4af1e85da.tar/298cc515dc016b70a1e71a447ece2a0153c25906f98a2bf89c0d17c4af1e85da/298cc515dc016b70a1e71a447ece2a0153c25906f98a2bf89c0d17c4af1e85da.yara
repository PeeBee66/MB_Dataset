
rule MB_298cc515
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-13T23:00:21.126285"
        sha256 = "298cc515dc016b70a1e71a447ece2a0153c25906f98a2bf89c0d17c4af1e85da"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
