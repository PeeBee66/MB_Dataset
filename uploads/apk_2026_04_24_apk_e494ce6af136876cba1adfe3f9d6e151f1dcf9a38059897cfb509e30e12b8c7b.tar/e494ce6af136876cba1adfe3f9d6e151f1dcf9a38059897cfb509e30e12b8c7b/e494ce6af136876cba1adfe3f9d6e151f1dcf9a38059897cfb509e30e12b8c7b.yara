
rule MB_e494ce6a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:00:30.875309"
        sha256 = "e494ce6af136876cba1adfe3f9d6e151f1dcf9a38059897cfb509e30e12b8c7b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
