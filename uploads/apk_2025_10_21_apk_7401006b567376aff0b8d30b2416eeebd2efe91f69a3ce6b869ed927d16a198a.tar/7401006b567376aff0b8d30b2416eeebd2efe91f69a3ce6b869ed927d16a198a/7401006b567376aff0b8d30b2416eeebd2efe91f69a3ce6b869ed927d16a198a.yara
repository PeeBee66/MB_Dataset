
rule MB_7401006b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:08.853374"
        sha256 = "7401006b567376aff0b8d30b2416eeebd2efe91f69a3ce6b869ed927d16a198a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
