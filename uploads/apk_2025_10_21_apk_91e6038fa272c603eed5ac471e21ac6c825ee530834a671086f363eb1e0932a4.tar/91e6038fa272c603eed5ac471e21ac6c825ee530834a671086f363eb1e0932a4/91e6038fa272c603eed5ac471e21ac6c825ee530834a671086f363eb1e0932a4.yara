
rule MB_91e6038f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:42.457104"
        sha256 = "91e6038fa272c603eed5ac471e21ac6c825ee530834a671086f363eb1e0932a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
