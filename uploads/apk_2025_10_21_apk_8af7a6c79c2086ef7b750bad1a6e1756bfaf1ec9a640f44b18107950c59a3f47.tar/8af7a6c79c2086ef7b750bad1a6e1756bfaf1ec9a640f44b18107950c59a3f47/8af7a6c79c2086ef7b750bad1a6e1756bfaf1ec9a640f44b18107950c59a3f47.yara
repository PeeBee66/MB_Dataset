
rule MB_8af7a6c7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:16.826696"
        sha256 = "8af7a6c79c2086ef7b750bad1a6e1756bfaf1ec9a640f44b18107950c59a3f47"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
