
rule MB_862cdb13
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:26:04.021593"
        sha256 = "862cdb13528a03d2dfbeb9df5cdc9eb88fc46ce962e58d52eaf106e469414caa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
