
rule MB_bbae4580
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:00:17.611116"
        sha256 = "bbae45807e85f1d4b9a11fdea352cb403ef97ddf915fbfaa54a917f98bf67c09"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
