
rule MB_946b2295
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:34.642573"
        sha256 = "946b2295d0c28b16cde1ba70fa3b6d14ffe08bea6bb178c96747c77b09332a81"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
