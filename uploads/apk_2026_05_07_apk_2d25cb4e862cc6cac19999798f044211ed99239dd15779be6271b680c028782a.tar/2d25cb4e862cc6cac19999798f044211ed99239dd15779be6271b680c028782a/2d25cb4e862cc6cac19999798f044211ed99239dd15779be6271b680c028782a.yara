
rule MB_2d25cb4e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:56.894963"
        sha256 = "2d25cb4e862cc6cac19999798f044211ed99239dd15779be6271b680c028782a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
