
rule MB_595355da
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-27T23:00:26.268729"
        sha256 = "595355daaa6aad284090210cd55c4a2e276c5263c83d2b202e1486d347af3701"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
