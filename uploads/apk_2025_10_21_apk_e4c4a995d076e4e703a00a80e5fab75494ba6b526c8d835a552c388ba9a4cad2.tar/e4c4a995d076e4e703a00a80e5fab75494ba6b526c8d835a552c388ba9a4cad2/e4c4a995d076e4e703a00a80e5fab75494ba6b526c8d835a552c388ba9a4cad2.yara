
rule MB_e4c4a995
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:28:06.311549"
        sha256 = "e4c4a995d076e4e703a00a80e5fab75494ba6b526c8d835a552c388ba9a4cad2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
