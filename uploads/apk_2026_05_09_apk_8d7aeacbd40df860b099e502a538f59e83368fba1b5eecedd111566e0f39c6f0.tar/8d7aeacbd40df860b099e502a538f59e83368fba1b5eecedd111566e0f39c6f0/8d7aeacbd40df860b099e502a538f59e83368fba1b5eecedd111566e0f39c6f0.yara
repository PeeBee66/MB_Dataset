
rule MB_8d7aeacb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:45.339489"
        sha256 = "8d7aeacbd40df860b099e502a538f59e83368fba1b5eecedd111566e0f39c6f0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
