
rule MB_f07deea7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-13T00:00:14.904286"
        sha256 = "f07deea7b1b1053728c0079d30240d92c07853e3e37c86fa32540ee5e638d941"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
