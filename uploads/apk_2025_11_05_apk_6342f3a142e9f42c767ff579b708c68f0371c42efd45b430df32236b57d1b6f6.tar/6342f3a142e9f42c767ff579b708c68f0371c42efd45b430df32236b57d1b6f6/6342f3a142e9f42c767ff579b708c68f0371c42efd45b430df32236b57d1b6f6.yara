
rule MB_6342f3a1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:21.192625"
        sha256 = "6342f3a142e9f42c767ff579b708c68f0371c42efd45b430df32236b57d1b6f6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
