
rule MB_7e15a3a8
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:05:39.734605"
        sha256 = "7e15a3a87f9a2ce9ba7f3c5a9034e76678772fff627f142d0dd1de261598003c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
