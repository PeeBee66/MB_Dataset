
rule MB_f0c5f41c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:29.374645"
        sha256 = "f0c5f41cde6805629993f709996ee73beb34699e0aa2b349832d65cfbc7a792e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
