
rule MB_98ba2489
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:22.522895"
        sha256 = "98ba248991fb5e722fb5d4c28d252014faa62472418fe2f9d340d00b7266b65d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
