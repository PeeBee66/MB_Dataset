
rule MB_44ced697
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:15.543176"
        sha256 = "44ced69776e2e0004d2f80011938a9c13d337e4a1db92ae054a9f99c8a49fff2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
