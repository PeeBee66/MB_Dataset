
rule MB_8a954aaa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-03T23:00:20.996555"
        sha256 = "8a954aaaeaa2abc16c8a562a6108f569d38fbd62ae8974f29131df0e4df4e096"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
