
rule MB_ccf7f767
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:53.701418"
        sha256 = "ccf7f7678965105142f6878d7b1f1f1c6f31fdbc45b0e50b8e70d0441f0b7472"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
