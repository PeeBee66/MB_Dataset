
rule MB_c265c163
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:54:21.083762"
        sha256 = "c265c163074aa3f601e7d507a4448c6e335bb2309ea7c235ed03d0468dfa8956"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
