
rule MB_8159c79c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:00:27.066442"
        sha256 = "8159c79c8a9b54ad363516f9b53c7cada3ea4afa0b2d0f6e7dc66fe147d03a93"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
