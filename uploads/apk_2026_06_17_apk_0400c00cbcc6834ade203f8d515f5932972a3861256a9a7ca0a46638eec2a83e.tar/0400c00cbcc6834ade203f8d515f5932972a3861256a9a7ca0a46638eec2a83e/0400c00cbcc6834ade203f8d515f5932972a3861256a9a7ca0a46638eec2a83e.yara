
rule MB_0400c00c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-17T00:00:22.288123"
        sha256 = "0400c00cbcc6834ade203f8d515f5932972a3861256a9a7ca0a46638eec2a83e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
