
rule MB_994172af
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:35:11.357878"
        sha256 = "994172af0cf22a54448f9b8486fd7a9a410cc608632602d820aaa291aa416382"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
