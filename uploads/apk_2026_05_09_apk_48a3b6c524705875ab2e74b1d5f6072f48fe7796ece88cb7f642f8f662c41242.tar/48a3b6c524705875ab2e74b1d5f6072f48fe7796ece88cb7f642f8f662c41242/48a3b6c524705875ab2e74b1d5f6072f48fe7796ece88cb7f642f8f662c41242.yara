
rule MB_48a3b6c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:17.172204"
        sha256 = "48a3b6c524705875ab2e74b1d5f6072f48fe7796ece88cb7f642f8f662c41242"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
