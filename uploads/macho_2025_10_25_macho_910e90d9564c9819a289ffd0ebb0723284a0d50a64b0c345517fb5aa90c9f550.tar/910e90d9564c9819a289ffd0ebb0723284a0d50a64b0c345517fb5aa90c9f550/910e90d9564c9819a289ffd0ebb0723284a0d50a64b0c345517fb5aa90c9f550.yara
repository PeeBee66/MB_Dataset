
rule MB_910e90d9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-24T23:00:18.562456"
        sha256 = "910e90d9564c9819a289ffd0ebb0723284a0d50a64b0c345517fb5aa90c9f550"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
