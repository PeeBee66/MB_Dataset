
rule MB_73897532
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:20.599030"
        sha256 = "73897532562e359d067a2f6fac87c16ca7578434f6d7797c484ec2f35eb6a0d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
