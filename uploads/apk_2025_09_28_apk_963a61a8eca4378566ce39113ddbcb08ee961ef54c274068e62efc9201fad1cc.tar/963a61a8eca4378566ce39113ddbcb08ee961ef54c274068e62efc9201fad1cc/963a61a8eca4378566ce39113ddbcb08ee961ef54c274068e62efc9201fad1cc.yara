
rule MB_963a61a8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:19.488606"
        sha256 = "963a61a8eca4378566ce39113ddbcb08ee961ef54c274068e62efc9201fad1cc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
