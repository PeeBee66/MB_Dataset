
rule MB_04be6360
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:19.044576"
        sha256 = "04be63606f7815c89dfc37871950795c4e998fa3c4dff0e7320b755b4193a421"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
