
rule MB_a0ca420d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-13T23:00:19.395622"
        sha256 = "a0ca420d421c3efb6e079a013d766ce28c41865912231ee51ad2c9a208a85751"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
