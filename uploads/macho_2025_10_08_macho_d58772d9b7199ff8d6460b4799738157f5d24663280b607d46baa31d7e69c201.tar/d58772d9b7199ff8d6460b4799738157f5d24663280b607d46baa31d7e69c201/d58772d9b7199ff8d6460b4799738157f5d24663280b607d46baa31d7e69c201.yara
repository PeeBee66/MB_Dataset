
rule MB_d58772d9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:16.461089"
        sha256 = "d58772d9b7199ff8d6460b4799738157f5d24663280b607d46baa31d7e69c201"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
