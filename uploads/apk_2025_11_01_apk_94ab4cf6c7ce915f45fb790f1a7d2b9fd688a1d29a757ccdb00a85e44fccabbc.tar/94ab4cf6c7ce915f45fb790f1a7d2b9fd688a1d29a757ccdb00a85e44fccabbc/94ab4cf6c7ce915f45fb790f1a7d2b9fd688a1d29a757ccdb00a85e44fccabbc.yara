
rule MB_94ab4cf6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:33.643050"
        sha256 = "94ab4cf6c7ce915f45fb790f1a7d2b9fd688a1d29a757ccdb00a85e44fccabbc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
