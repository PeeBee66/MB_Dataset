
rule MB_ac010be7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:21.841278"
        sha256 = "ac010be7a325657d142e500894852f52b96d03cb6890f831de5751303a95c927"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
