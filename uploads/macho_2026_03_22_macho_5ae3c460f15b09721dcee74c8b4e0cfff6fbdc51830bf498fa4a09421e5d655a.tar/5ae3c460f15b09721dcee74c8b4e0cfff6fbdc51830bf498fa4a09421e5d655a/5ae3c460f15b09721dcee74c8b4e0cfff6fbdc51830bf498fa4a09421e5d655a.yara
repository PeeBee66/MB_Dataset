
rule MB_5ae3c460
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:13.570559"
        sha256 = "5ae3c460f15b09721dcee74c8b4e0cfff6fbdc51830bf498fa4a09421e5d655a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
