
rule MB_8c0aa92c
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:02:25.035920"
        sha256 = "8c0aa92c31ec950bcd8d8b714b2ef80ae7b35d55964e92088ba81095f132fb81"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
