
rule MB_355a160a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:00:46.334427"
        sha256 = "355a160af963b0451a9b257aa38de86f0d1f718b6e0406ddd71695ebf264f549"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
