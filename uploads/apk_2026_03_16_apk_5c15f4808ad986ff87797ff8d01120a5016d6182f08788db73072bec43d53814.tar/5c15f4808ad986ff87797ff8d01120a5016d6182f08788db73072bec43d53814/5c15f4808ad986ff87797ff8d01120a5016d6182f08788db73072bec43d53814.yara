
rule MB_5c15f480
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:01:19.748319"
        sha256 = "5c15f4808ad986ff87797ff8d01120a5016d6182f08788db73072bec43d53814"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
