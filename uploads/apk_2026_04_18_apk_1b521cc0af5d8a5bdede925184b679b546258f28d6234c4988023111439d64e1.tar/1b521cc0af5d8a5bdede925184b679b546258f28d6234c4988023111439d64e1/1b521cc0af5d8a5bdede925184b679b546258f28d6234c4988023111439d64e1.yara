
rule MB_1b521cc0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:20.402449"
        sha256 = "1b521cc0af5d8a5bdede925184b679b546258f28d6234c4988023111439d64e1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
