
rule MB_ce462b41
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-16T00:00:36.864248"
        sha256 = "ce462b41ab7480dce4f290a9921fca51ba40e502d480a348d50770607e3d02b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
