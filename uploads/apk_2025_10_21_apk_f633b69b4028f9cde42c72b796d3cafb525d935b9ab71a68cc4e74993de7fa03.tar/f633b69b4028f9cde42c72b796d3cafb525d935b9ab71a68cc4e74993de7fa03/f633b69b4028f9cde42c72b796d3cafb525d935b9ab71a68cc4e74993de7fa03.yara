
rule MB_f633b69b
{
    meta:
        description = "Auto-generated rule for Tanglebot"
        author = "MB-Collector"
        date = "2025-10-20T11:29:24.390070"
        sha256 = "f633b69b4028f9cde42c72b796d3cafb525d935b9ab71a68cc4e74993de7fa03"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
