
rule MB_6fcd6efe
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:32.865264"
        sha256 = "6fcd6efe00a59a652f1a7a53c1f39dba81d19b6936df68fab846b09754f3420f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
