
rule MB_b68049d3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:17.076094"
        sha256 = "b68049d3c350a64e7ad5fcce97934c76e930b0b2f9311168cf75f48101c4cb3e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
