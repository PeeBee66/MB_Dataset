
rule MB_6ac62209
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:43.535100"
        sha256 = "6ac62209696c3c335a4511eb55c597f5f4373c61745173b9bc11dd546f07d8dc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
