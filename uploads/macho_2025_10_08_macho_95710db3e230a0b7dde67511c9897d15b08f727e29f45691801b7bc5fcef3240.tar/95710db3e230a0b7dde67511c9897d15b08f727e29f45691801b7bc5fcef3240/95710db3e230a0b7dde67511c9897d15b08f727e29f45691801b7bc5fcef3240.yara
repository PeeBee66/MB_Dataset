
rule MB_95710db3
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:21.291276"
        sha256 = "95710db3e230a0b7dde67511c9897d15b08f727e29f45691801b7bc5fcef3240"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
