
rule MB_ecd8e69d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:36.604525"
        sha256 = "ecd8e69dbfb52980cd70ad5c0d6e79a62725afd5d05b13fdad50069de63b0e72"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
