
rule MB_b459742f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:50.762662"
        sha256 = "b459742f75504efda93e1154e73c41bc07bac7d23333b71f11ca3043db752217"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
