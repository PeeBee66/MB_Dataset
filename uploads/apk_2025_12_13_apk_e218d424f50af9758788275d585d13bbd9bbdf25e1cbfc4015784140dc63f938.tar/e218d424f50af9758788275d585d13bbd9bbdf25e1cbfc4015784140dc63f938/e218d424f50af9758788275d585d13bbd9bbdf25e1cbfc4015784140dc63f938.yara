
rule MB_e218d424
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-12T23:01:14.394355"
        sha256 = "e218d424f50af9758788275d585d13bbd9bbdf25e1cbfc4015784140dc63f938"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
