
rule MB_ece7e5bf
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:57.628318"
        sha256 = "ece7e5bf958857e267813dbaa64e538199fd2e3b5bd5c3bf833a994d627a5370"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
