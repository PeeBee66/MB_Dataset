
rule MB_6845352f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:22.280560"
        sha256 = "6845352f4ec958e002003bbb76cdd28b0a67ee6a49d92b7bd9e7a980c1c67f3d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
