
rule MB_abe6dc28
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:00:15.436067"
        sha256 = "abe6dc28293f0323533e4bb9692a8a55009808c5a5b14495367461c6060a35e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
