
rule MB_d3c63ecb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:58.997873"
        sha256 = "d3c63ecb3a95272a043b3e0ab792a70738c867ba18e896c455d9c39d32fff4d3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
