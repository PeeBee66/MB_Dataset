
rule MB_ac1756b4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-22T00:00:49.571265"
        sha256 = "ac1756b496da979bb04333f466deeaa93b9c243a7f5a072d4d6b00fbb4335d73"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
