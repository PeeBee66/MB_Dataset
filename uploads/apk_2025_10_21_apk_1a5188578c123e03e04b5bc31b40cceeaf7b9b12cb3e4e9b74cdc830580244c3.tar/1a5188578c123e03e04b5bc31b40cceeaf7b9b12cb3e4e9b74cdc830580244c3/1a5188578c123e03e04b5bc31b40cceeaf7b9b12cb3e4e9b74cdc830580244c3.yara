
rule MB_1a518857
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:24:38.313549"
        sha256 = "1a5188578c123e03e04b5bc31b40cceeaf7b9b12cb3e4e9b74cdc830580244c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
