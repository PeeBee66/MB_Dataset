
rule MB_ad9f39e6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-25T00:00:40.519167"
        sha256 = "ad9f39e6166a47ae16359777b607055198cda23f004d9d7b066e22c0d0cf1e6d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
