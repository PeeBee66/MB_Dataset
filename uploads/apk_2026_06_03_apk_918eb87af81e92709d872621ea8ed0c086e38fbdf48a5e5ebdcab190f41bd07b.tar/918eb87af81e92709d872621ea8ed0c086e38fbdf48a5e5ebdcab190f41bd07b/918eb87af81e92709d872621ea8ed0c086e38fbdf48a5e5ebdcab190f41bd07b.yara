
rule MB_918eb87a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-03T00:00:24.424137"
        sha256 = "918eb87af81e92709d872621ea8ed0c086e38fbdf48a5e5ebdcab190f41bd07b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
