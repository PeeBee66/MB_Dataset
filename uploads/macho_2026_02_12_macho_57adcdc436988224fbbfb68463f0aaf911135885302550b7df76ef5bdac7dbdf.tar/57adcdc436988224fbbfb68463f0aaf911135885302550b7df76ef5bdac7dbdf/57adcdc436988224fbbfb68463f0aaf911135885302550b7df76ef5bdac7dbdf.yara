
rule MB_57adcdc4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:40.104434"
        sha256 = "57adcdc436988224fbbfb68463f0aaf911135885302550b7df76ef5bdac7dbdf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
