
rule MB_c773dc02
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:08.644393"
        sha256 = "c773dc02e0a8aa62211387f5e1b7ec357bf541be9378e17eb09e7f6cb0ed9eff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
