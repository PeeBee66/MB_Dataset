
rule MB_58cc948b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-18T00:00:52.761354"
        sha256 = "58cc948bd809292143e604c3e03735c9517f94b37dd35299ca5e81d7b902d620"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
