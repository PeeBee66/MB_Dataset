
rule MB_6a702c55
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-11T23:00:17.912428"
        sha256 = "6a702c55f4ee54eeb35a991d7413328da1e56dde6e719babec23682423bec23f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
