
rule MB_9220b2f1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:58.354361"
        sha256 = "9220b2f18dd79bef1d9b3739d42da538bfbcc73cda4f9b0028c2f425be501fb1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
