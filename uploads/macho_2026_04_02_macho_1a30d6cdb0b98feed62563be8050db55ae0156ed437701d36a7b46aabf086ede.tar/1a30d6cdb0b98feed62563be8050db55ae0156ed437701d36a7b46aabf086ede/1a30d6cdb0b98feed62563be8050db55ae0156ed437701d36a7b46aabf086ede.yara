
rule MB_1a30d6cd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-01T23:01:11.512986"
        sha256 = "1a30d6cdb0b98feed62563be8050db55ae0156ed437701d36a7b46aabf086ede"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
