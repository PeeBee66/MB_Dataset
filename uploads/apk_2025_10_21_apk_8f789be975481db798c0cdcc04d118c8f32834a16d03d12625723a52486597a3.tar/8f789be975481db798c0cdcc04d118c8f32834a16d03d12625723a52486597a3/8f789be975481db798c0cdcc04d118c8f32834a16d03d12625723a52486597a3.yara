
rule MB_8f789be9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:38:13.985728"
        sha256 = "8f789be975481db798c0cdcc04d118c8f32834a16d03d12625723a52486597a3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
