
rule MB_88740276
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:53.251759"
        sha256 = "88740276252861174ee4e0d98a6a7567a8b3cd8204dec646e4aee41cb8a17f66"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
