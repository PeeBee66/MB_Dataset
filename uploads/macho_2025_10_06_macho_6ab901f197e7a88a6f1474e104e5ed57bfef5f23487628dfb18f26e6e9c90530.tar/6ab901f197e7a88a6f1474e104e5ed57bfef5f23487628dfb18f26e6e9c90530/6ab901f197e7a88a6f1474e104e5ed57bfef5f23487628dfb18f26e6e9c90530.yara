
rule MB_6ab901f1
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:59.666264"
        sha256 = "6ab901f197e7a88a6f1474e104e5ed57bfef5f23487628dfb18f26e6e9c90530"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
