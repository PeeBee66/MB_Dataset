
rule MB_9fb8a940
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-31T23:00:21.697184"
        sha256 = "9fb8a940492ee6095a24b4a34ecfa252a515fb681f16636a8f00b1e0e7d47fe2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
