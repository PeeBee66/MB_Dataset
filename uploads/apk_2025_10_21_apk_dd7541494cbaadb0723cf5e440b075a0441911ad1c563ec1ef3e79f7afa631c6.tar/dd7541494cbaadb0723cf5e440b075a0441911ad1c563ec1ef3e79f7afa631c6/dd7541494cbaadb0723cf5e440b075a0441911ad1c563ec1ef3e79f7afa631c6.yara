
rule MB_dd754149
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:00.294177"
        sha256 = "dd7541494cbaadb0723cf5e440b075a0441911ad1c563ec1ef3e79f7afa631c6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
