
rule MB_28ba4fa2
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:21.558078"
        sha256 = "28ba4fa22e90c1a5abbbca66601726af3c6357e93f59e98848988547daa4fd5b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
