
rule MB_f1b87727
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:33.561069"
        sha256 = "f1b8772720190687797648fa58d09f75830c148063850376e3cc05f9c5a0714f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
