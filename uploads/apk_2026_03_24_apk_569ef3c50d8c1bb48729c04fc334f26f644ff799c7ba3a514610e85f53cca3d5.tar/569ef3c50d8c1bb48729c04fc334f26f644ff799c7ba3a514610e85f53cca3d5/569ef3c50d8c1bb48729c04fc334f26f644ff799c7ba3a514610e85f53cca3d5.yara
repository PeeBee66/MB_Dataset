
rule MB_569ef3c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-23T23:00:51.711670"
        sha256 = "569ef3c50d8c1bb48729c04fc334f26f644ff799c7ba3a514610e85f53cca3d5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
