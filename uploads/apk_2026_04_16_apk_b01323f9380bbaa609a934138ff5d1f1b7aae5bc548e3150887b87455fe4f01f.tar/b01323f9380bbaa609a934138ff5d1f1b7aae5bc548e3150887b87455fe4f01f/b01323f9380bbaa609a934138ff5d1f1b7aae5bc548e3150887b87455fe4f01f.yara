
rule MB_b01323f9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:00:32.393573"
        sha256 = "b01323f9380bbaa609a934138ff5d1f1b7aae5bc548e3150887b87455fe4f01f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
