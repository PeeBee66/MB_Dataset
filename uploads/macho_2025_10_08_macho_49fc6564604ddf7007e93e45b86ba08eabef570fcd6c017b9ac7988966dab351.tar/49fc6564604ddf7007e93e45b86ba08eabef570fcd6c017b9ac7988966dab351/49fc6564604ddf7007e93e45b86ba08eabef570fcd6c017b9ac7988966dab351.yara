
rule MB_49fc6564
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:43.131823"
        sha256 = "49fc6564604ddf7007e93e45b86ba08eabef570fcd6c017b9ac7988966dab351"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
