
rule MB_ad33594c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:51.947360"
        sha256 = "ad33594cb7cfa1bbc719d05c2c891c66f61a985cb18d4e99b5c4e1fb638c0151"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
