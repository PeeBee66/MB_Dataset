
rule MB_bc2a5090
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-20T00:00:30.144157"
        sha256 = "bc2a50906c59fdb0e7109274e322d2f8225600b456935d256b45c554975628d1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
