
rule MB_91eafc69
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:54.006677"
        sha256 = "91eafc69314abbc877818418b5c9b9b2663508e3a2b104843b903675f09789db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
