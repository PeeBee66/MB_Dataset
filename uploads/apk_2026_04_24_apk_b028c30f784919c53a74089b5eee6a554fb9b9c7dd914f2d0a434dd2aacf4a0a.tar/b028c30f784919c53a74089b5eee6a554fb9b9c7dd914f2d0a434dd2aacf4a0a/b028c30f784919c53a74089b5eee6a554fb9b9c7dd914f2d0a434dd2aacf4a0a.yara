
rule MB_b028c30f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:57.452862"
        sha256 = "b028c30f784919c53a74089b5eee6a554fb9b9c7dd914f2d0a434dd2aacf4a0a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
