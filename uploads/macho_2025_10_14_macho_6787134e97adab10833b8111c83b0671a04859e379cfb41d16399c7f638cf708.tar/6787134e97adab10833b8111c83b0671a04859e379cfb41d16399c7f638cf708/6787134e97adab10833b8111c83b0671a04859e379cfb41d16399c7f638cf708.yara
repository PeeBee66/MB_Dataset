
rule MB_6787134e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-13T23:00:22.888807"
        sha256 = "6787134e97adab10833b8111c83b0671a04859e379cfb41d16399c7f638cf708"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
