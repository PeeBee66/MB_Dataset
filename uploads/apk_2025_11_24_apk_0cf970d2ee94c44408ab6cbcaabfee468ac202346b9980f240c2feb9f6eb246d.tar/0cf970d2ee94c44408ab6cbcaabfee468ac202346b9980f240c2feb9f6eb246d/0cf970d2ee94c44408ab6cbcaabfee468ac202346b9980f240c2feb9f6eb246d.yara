
rule MB_0cf970d2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:21.563990"
        sha256 = "0cf970d2ee94c44408ab6cbcaabfee468ac202346b9980f240c2feb9f6eb246d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
