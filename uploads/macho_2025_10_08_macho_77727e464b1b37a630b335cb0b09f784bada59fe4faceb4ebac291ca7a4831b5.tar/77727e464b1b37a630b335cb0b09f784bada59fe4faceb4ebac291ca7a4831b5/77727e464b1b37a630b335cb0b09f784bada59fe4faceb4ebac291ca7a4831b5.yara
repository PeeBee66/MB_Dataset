
rule MB_77727e46
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:48.101421"
        sha256 = "77727e464b1b37a630b335cb0b09f784bada59fe4faceb4ebac291ca7a4831b5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
