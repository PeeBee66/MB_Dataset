
rule MB_8531e133
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:40.839745"
        sha256 = "8531e1339e156d5bafd0e145d7d65158cdfa6d22c25d2a1376a5b7e071be41a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
