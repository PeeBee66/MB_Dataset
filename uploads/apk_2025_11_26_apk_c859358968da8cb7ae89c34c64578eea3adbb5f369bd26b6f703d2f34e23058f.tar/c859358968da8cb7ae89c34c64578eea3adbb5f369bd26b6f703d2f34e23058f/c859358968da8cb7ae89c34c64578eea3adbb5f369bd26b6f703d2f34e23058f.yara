
rule MB_c8593589
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:13.438189"
        sha256 = "c859358968da8cb7ae89c34c64578eea3adbb5f369bd26b6f703d2f34e23058f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
