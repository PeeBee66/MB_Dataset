
rule MB_dfa35393
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-02T23:00:41.269310"
        sha256 = "dfa3539353b89089a3599f4775a296b270751738186af515bf3e630dc054bc7d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
