
rule MB_37931bdd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:57.296061"
        sha256 = "37931bddeba5272e7ca9ce53aff40ef07d7445e507b856a656ecac94b6b61b15"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
