
rule MB_1a91660c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:00:45.761996"
        sha256 = "1a91660cae8d1154e1979f31400b8956ed7e548586f314593e3e0f639838cffb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
