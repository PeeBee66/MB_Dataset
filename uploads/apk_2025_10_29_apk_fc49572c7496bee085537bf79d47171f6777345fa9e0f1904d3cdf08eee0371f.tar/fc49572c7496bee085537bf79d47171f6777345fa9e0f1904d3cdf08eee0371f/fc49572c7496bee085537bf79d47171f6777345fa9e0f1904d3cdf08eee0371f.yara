
rule MB_fc49572c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:01:24.408533"
        sha256 = "fc49572c7496bee085537bf79d47171f6777345fa9e0f1904d3cdf08eee0371f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
