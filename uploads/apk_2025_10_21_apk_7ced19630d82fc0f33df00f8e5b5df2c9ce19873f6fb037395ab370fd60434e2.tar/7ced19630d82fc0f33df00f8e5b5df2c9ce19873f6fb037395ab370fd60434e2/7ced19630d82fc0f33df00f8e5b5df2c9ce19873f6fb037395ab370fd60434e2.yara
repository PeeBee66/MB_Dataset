
rule MB_7ced1963
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:46.431577"
        sha256 = "7ced19630d82fc0f33df00f8e5b5df2c9ce19873f6fb037395ab370fd60434e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
