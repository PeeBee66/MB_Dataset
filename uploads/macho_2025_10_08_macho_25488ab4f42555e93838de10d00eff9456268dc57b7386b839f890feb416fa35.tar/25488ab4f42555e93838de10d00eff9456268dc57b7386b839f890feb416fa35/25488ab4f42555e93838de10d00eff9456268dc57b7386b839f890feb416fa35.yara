
rule MB_25488ab4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:02:14.406212"
        sha256 = "25488ab4f42555e93838de10d00eff9456268dc57b7386b839f890feb416fa35"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
