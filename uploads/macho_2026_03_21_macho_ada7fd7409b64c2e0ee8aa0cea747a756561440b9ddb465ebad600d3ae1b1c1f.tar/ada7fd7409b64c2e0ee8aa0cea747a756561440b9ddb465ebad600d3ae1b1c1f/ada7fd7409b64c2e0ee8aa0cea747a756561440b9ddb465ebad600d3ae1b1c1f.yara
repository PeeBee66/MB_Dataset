
rule MB_ada7fd74
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:01:49.961557"
        sha256 = "ada7fd7409b64c2e0ee8aa0cea747a756561440b9ddb465ebad600d3ae1b1c1f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
