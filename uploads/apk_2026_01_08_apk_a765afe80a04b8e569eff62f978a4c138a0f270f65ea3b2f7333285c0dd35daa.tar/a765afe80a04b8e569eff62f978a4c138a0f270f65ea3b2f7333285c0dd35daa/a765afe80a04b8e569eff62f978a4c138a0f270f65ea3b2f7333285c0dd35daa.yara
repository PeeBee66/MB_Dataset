
rule MB_a765afe8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-07T23:00:13.945274"
        sha256 = "a765afe80a04b8e569eff62f978a4c138a0f270f65ea3b2f7333285c0dd35daa"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
