
rule MB_04e4acc8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:02.529500"
        sha256 = "04e4acc8cd2a66f77260ebcfbe40646192ff452d5f9bbe54e0acbd0cabc3cfbc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
