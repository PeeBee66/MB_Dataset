
rule MB_6156697e
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:36.051135"
        sha256 = "6156697e3af94ce551b435c799bb2519dc35484efc46b637bbec4ead4cf235b3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
