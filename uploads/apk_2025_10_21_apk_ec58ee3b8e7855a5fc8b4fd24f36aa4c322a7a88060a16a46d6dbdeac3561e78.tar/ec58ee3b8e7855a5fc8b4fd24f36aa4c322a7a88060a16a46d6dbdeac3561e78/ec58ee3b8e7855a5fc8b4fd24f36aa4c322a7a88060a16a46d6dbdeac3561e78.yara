
rule MB_ec58ee3b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:24.752559"
        sha256 = "ec58ee3b8e7855a5fc8b4fd24f36aa4c322a7a88060a16a46d6dbdeac3561e78"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
