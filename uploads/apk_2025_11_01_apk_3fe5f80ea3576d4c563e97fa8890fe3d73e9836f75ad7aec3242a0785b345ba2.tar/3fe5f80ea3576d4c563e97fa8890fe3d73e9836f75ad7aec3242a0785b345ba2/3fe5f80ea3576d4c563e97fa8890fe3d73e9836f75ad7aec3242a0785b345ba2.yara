
rule MB_3fe5f80e
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-31T23:05:28.821956"
        sha256 = "3fe5f80ea3576d4c563e97fa8890fe3d73e9836f75ad7aec3242a0785b345ba2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
