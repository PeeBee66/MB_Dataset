
rule MB_7f38233d
{
    meta:
        description = "Auto-generated rule for SMSWorm"
        author = "MB-Collector"
        date = "2025-10-31T23:03:57.470250"
        sha256 = "7f38233d6efb651d52107d38a7b2d302b19de79091bfcae63a208e74a6bcb2ed"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
