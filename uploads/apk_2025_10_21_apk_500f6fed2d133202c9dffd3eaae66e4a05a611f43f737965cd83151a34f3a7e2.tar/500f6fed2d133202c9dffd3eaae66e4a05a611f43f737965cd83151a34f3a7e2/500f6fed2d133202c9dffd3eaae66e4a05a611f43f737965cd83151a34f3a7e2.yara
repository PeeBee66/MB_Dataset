
rule MB_500f6fed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:55.460363"
        sha256 = "500f6fed2d133202c9dffd3eaae66e4a05a611f43f737965cd83151a34f3a7e2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
