
rule MB_b9a4e10d
{
    meta:
        description = "Auto-generated rule for Metasploit"
        author = "MB-Collector"
        date = "2025-10-08T23:00:24.557520"
        sha256 = "b9a4e10d422e5a905be92970218968fa612338d1de4d7dbd22594805720defb2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
