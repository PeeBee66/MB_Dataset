
rule MB_ac679544
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:51.974670"
        sha256 = "ac679544188d1d635fd05d52b9962723c5a535039a1a0e2b62dee8b594930f55"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
