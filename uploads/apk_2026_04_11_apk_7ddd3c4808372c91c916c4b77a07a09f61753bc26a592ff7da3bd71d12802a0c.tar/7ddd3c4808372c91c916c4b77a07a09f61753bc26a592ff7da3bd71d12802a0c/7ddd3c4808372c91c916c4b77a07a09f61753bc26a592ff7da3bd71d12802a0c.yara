
rule MB_7ddd3c48
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-11T00:00:34.600480"
        sha256 = "7ddd3c4808372c91c916c4b77a07a09f61753bc26a592ff7da3bd71d12802a0c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
