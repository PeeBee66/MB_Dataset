
rule MB_6df0d3b1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:28:00.478490"
        sha256 = "6df0d3b1487449f63567a02ec8204301066d57ecd1b9249747bc39cfc91b1ce4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
