
rule MB_c0af5cd9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:15.920615"
        sha256 = "c0af5cd94575c0241c9e8c3252c348faf13ab0da615f8fca59aeb25e951d9d57"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
