
rule MB_e0171574
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-22T23:00:23.637984"
        sha256 = "e0171574e8d547f7ae80a7769ab84012feb1d97098dc9c5cfb04493a448fc28c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
