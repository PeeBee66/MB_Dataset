
rule MB_633c93ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-10T23:00:35.326905"
        sha256 = "633c93ceea6fb2126ba62f0547f2b8b17188aaaedeea6f43cc0bbb522fe48c8c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
