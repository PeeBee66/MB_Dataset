
rule MB_eee3e840
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:28.020701"
        sha256 = "eee3e8409d2136cc2ea8ab6be4befb5fbc4239635b542f687f53db481d50e4f6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
