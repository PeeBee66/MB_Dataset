
rule MB_724f82af
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:01.235528"
        sha256 = "724f82afbb4d457dc34ac115e2c628e68a9b1231f36ad1cd7addc338021abfae"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
