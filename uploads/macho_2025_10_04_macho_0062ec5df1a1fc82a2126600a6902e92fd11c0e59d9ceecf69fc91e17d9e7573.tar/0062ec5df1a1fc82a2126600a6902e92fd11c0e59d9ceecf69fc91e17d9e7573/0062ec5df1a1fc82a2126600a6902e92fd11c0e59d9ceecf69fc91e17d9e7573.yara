
rule MB_0062ec5d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:56.601148"
        sha256 = "0062ec5df1a1fc82a2126600a6902e92fd11c0e59d9ceecf69fc91e17d9e7573"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
