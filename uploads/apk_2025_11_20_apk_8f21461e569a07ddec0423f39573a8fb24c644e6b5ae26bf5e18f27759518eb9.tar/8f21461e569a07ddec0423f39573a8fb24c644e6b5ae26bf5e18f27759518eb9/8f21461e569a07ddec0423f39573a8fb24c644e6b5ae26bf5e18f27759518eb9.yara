
rule MB_8f21461e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-19T23:00:15.885136"
        sha256 = "8f21461e569a07ddec0423f39573a8fb24c644e6b5ae26bf5e18f27759518eb9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
