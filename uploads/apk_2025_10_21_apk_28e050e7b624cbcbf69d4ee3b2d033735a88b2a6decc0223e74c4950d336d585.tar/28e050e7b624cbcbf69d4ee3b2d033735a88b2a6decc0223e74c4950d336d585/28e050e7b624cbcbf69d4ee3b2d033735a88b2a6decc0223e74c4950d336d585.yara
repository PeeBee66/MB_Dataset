
rule MB_28e050e7
{
    meta:
        description = "Auto-generated rule for SpyLoan"
        author = "MB-Collector"
        date = "2025-10-20T11:47:14.319489"
        sha256 = "28e050e7b624cbcbf69d4ee3b2d033735a88b2a6decc0223e74c4950d336d585"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
