
rule MB_af05c902
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:05.785302"
        sha256 = "af05c902cf090ef0be0441b25d5918fd7d4aaf2b01f8ec06e7f6a298cf58640e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
