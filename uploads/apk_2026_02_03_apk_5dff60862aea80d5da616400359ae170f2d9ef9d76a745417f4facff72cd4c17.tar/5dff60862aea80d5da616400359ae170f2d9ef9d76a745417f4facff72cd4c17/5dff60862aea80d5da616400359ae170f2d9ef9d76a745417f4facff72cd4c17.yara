
rule MB_5dff6086
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:42.116138"
        sha256 = "5dff60862aea80d5da616400359ae170f2d9ef9d76a745417f4facff72cd4c17"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
