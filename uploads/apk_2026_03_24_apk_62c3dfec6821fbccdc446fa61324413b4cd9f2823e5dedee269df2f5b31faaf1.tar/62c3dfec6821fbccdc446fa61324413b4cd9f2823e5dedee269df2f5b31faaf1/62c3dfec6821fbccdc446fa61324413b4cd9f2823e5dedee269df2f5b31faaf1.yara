
rule MB_62c3dfec
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:19.042074"
        sha256 = "62c3dfec6821fbccdc446fa61324413b4cd9f2823e5dedee269df2f5b31faaf1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
