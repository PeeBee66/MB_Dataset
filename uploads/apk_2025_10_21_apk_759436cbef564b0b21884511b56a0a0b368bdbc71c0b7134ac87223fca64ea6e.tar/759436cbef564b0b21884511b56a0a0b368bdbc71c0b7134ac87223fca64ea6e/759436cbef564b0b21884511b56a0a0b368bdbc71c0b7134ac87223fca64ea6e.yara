
rule MB_759436cb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:48.081542"
        sha256 = "759436cbef564b0b21884511b56a0a0b368bdbc71c0b7134ac87223fca64ea6e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
