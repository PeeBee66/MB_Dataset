
rule MB_6743e5b8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:51:48.262826"
        sha256 = "6743e5b892d0192dd8498e99fa608f1f0b2d98c5437dc274f6eaa211bb60046c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
