
rule MB_744346bd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-26T23:00:31.772327"
        sha256 = "744346bd46f139837bf2825206fa95d48ddf6dc078e341492b34b35743a0b297"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
