
rule MB_f99486a6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:31.429001"
        sha256 = "f99486a60b7f8ae9ba5cf991d422954466017dfc4020ca7563655e9ebc8713f7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
