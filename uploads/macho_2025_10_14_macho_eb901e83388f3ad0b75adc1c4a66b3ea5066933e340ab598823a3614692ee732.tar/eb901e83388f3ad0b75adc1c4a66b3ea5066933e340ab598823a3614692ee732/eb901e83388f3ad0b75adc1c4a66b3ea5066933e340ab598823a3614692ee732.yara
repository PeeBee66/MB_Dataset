
rule MB_eb901e83
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-13T23:00:15.885513"
        sha256 = "eb901e83388f3ad0b75adc1c4a66b3ea5066933e340ab598823a3614692ee732"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
