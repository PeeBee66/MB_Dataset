
rule MB_1d9bdb35
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:53.634180"
        sha256 = "1d9bdb35234b01d219fd28c47a47bbaa6c9033e2b1f35b07f10cf09eaed00254"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
