
rule MB_8a00369c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:32:01.297485"
        sha256 = "8a00369c87714cdecdcb0c03c7bd94a04866869fa0476c0795158e34595c947c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
