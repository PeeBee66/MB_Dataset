
rule MB_ef1879ad
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:03:32.898411"
        sha256 = "ef1879ad7debb3fddd8b2826a061db46ebe3693eee8364ca559013008b816dfc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
