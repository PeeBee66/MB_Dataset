
rule MB_0da78888
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:00:25.367267"
        sha256 = "0da788889de28ceefe09df55634c021d1a96b64d4aa697cb294d51e77efb6188"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
