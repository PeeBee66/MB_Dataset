
rule MB_4397674e
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:03:25.335738"
        sha256 = "4397674e2b3f14b9b6e9e66b4aa8e30cf68ef082b8f1d4e80ec885958b08a9c7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
