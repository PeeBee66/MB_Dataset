
rule MB_a812545a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:08.585655"
        sha256 = "a812545aa9a5ab24a651890295ab43e45bee334630f97875e6dafbab28849a06"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
