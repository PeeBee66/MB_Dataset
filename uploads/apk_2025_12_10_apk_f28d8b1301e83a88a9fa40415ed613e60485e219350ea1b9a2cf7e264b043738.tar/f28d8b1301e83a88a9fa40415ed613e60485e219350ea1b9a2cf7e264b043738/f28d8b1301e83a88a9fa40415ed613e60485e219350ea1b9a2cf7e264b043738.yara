
rule MB_f28d8b13
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-09T23:00:22.785394"
        sha256 = "f28d8b1301e83a88a9fa40415ed613e60485e219350ea1b9a2cf7e264b043738"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
