
rule MB_b8fa21bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-17T23:00:13.016501"
        sha256 = "b8fa21bbd5261f2308a168c1f43b197220c0d37bdda0c4a1464be085a9f85300"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
