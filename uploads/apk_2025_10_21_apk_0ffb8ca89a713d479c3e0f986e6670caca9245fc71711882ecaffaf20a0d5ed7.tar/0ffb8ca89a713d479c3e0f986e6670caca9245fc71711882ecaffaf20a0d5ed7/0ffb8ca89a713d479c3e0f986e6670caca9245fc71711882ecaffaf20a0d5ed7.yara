
rule MB_0ffb8ca8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:06.040011"
        sha256 = "0ffb8ca89a713d479c3e0f986e6670caca9245fc71711882ecaffaf20a0d5ed7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
