
rule MB_fccc4fc5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:42.883378"
        sha256 = "fccc4fc537eb36ef71bdc07d70f00599d222d71b3ed8f8b613aaaba7d9e13988"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
