
rule MB_8e5b16b3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:16.602108"
        sha256 = "8e5b16b3c2d430d04d9d5e582fc5b0668f0bc3496d6147d20c4c8b2f91f4156f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
