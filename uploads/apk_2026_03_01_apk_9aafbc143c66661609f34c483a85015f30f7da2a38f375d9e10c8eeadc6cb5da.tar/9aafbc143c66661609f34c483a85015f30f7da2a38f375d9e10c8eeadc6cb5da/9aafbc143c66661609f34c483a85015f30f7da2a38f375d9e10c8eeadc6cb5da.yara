
rule MB_9aafbc14
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-28T23:00:28.209862"
        sha256 = "9aafbc143c66661609f34c483a85015f30f7da2a38f375d9e10c8eeadc6cb5da"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
