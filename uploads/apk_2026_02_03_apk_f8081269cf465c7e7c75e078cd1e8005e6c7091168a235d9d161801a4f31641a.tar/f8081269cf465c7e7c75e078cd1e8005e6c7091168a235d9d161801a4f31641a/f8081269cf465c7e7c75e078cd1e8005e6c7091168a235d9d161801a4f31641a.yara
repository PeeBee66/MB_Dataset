
rule MB_f8081269
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:59.053888"
        sha256 = "f8081269cf465c7e7c75e078cd1e8005e6c7091168a235d9d161801a4f31641a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
