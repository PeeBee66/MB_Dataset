
rule MB_2b701929
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:19:12.877525"
        sha256 = "2b7019290ecc3626e55f971dbcd3b1e83f127dae044271be8d7ceac90a216004"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
