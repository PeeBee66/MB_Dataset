
rule MB_561eaef9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:56.112712"
        sha256 = "561eaef9423c10bb2d98f6d7915f1626d33e8b364e4852a3801bebe0e359eb4a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
