
rule MB_3af625c6
{
    meta:
        description = "Auto-generated rule for IRATA"
        author = "MB-Collector"
        date = "2025-10-20T11:49:34.344327"
        sha256 = "3af625c6f425a5dc566c3884258cac3214e024b4e5a277978dfdcd6f1c0e7301"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
