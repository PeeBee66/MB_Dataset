
rule MB_ff0e3311
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-27T23:00:17.758241"
        sha256 = "ff0e3311f5d8e829b189adcd520037ce6174caee347452ded3d5fcdf48a3b4f2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
