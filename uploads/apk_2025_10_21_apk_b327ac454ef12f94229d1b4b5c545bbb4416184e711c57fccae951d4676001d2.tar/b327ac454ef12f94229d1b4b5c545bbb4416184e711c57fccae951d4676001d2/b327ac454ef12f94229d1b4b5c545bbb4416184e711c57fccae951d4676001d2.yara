
rule MB_b327ac45
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:54.964516"
        sha256 = "b327ac454ef12f94229d1b4b5c545bbb4416184e711c57fccae951d4676001d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
