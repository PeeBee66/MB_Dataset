
rule MB_970a5804
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:15.638095"
        sha256 = "970a5804fe2bc6f4de0377322b3b5c38ca1b148c49922f766e48653b424f75ca"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
