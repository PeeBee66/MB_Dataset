
rule MB_fb1d5ef3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:20.326098"
        sha256 = "fb1d5ef3277d5a127d57242f4a9451d30523896766b8c37c66f199402323fc82"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
