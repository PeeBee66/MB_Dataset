
rule MB_31c8aa3a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:16.691173"
        sha256 = "31c8aa3ad905a0db9afabc30e3dd21ab8e60f3e7a8651ca4b6e6d4d09e2f0332"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
