
rule MB_31fdaa61
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2025-10-20T11:46:21.649260"
        sha256 = "31fdaa61cadd545c4c859ed255ada413cbb09b2201f047745a7374ec1d54aa43"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
