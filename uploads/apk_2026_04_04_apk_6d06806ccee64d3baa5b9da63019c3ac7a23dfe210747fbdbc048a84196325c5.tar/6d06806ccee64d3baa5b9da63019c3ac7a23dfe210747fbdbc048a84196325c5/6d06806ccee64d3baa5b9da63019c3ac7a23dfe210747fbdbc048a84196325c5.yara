
rule MB_6d06806c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-03T23:00:21.711644"
        sha256 = "6d06806ccee64d3baa5b9da63019c3ac7a23dfe210747fbdbc048a84196325c5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
