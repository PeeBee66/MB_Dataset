
rule MB_37b660c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:50.612312"
        sha256 = "37b660c192d9154ea8f0fd766fca3e0ba90ca4f3fc2159a266c1b28e15a9cbf1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
