
rule MB_cc991231
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:01:00.160974"
        sha256 = "cc9912310caa4dbee677d104c181a7e274490134fbc733a5825a9340e4d4adbf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
