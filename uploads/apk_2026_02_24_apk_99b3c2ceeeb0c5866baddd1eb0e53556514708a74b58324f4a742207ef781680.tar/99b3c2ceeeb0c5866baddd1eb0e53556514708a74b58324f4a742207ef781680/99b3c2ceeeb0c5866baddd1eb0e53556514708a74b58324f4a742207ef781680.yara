
rule MB_99b3c2ce
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:02.965345"
        sha256 = "99b3c2ceeeb0c5866baddd1eb0e53556514708a74b58324f4a742207ef781680"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
