
rule MB_3978cc61
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-27T23:00:12.690774"
        sha256 = "3978cc61af032858bbaf2884aeb46776a5d5014cdedf0d9f88340ecb655fb54d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
