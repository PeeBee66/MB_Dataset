
rule MB_506033f7
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-12-30T23:00:23.589601"
        sha256 = "506033f7a6ea5c9e4d89f9edcc998ed1f33fb74e4a2a4f32af8cec2ec009a906"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
