
rule MB_65e074a6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:13.072441"
        sha256 = "65e074a68a1a1732d8930ee2b4d3d5a2651f526d0111d4929042618a9cbbb7bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
