
rule MB_e9cbaff8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:08.647286"
        sha256 = "e9cbaff8137a5614672ae70117f068379084d41567147630b82d52722515ca26"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
