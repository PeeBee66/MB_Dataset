
rule MB_d69108a9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-24T23:00:30.130186"
        sha256 = "d69108a94a9a81e07a05d456dc997cbf5b5a8cc8f0869eae7904fac1da60f335"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
