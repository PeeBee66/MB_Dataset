
rule MB_0960616a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-02T23:00:21.959578"
        sha256 = "0960616a0aeb78083983043d46d7fb6283550f5ea6335a5e88a3194fed9afdf4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
