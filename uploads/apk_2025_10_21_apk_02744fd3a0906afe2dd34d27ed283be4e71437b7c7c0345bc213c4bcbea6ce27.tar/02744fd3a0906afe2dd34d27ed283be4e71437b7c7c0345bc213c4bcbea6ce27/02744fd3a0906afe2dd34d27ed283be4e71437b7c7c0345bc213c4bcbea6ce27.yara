
rule MB_02744fd3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:46:54.623962"
        sha256 = "02744fd3a0906afe2dd34d27ed283be4e71437b7c7c0345bc213c4bcbea6ce27"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
