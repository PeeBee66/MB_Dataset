
rule MB_d5990506
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:20.104790"
        sha256 = "d5990506159749525b3f86f11bc4b04973074f3974d09f95a407e6b70a9bb312"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
