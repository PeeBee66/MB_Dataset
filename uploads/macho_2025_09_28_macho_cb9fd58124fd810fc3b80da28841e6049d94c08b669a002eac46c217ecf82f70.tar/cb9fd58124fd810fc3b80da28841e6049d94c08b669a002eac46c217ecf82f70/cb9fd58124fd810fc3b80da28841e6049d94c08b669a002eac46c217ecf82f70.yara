
rule MB_cb9fd581
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:00:43.781997"
        sha256 = "cb9fd58124fd810fc3b80da28841e6049d94c08b669a002eac46c217ecf82f70"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
