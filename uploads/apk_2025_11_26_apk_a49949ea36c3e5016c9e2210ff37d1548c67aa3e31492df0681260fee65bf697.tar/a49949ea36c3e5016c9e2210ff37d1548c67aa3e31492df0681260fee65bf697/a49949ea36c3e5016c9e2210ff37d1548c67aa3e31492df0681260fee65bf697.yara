
rule MB_a49949ea
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:35.248727"
        sha256 = "a49949ea36c3e5016c9e2210ff37d1548c67aa3e31492df0681260fee65bf697"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
