
rule MB_ff6d4078
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:03.245306"
        sha256 = "ff6d4078a1ccd4248cd5a9f235944af6f4e388c418f54aeffefea5f5d6d0ee82"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
