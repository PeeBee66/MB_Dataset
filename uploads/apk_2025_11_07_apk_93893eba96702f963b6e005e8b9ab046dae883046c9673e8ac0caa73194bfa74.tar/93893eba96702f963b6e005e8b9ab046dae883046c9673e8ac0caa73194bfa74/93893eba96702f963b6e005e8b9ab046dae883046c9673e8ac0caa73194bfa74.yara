
rule MB_93893eba
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:01:03.057335"
        sha256 = "93893eba96702f963b6e005e8b9ab046dae883046c9673e8ac0caa73194bfa74"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
