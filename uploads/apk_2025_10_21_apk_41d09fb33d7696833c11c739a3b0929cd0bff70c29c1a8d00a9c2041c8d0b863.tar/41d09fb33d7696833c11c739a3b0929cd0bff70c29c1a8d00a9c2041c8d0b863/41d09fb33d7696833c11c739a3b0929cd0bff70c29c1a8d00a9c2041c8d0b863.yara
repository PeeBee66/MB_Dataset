
rule MB_41d09fb3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:47:33.104595"
        sha256 = "41d09fb33d7696833c11c739a3b0929cd0bff70c29c1a8d00a9c2041c8d0b863"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
