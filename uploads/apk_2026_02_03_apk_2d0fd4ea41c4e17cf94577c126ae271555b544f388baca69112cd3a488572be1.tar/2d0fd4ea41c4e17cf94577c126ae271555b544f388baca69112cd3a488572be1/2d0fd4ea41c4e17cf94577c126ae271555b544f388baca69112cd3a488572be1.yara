
rule MB_2d0fd4ea
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:37.901220"
        sha256 = "2d0fd4ea41c4e17cf94577c126ae271555b544f388baca69112cd3a488572be1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
