
rule MB_5fe1f09e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:02.801469"
        sha256 = "5fe1f09eabb1a5b1509d16b535edb2f32bb3a739e9546a624d14d7af704643e9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
