
rule MB_1ab5275f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:00:55.720520"
        sha256 = "1ab5275f1faff8498b7eafc2799679cbb248172b22d41bad6f85be07abb59259"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
