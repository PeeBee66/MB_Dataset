
rule MB_5c9f59fd
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:31.643356"
        sha256 = "5c9f59fd623e54840b9e32fb460c9e733961f82eb680f913239061a78e57dae1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
