
rule MB_f2eeee21
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-01-08T23:00:14.807193"
        sha256 = "f2eeee218056e8cbdc239b1a8ee60580667e1aaf4515987980722a35f6e2dd4d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
