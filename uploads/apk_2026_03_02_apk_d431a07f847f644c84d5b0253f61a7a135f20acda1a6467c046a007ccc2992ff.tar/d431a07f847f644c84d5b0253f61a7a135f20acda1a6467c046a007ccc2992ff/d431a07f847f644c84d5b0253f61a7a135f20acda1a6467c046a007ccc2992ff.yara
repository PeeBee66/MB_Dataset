
rule MB_d431a07f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-01T23:00:25.122234"
        sha256 = "d431a07f847f644c84d5b0253f61a7a135f20acda1a6467c046a007ccc2992ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
