
rule MB_01787821
{
    meta:
        description = "Auto-generated rule for Crocodilus"
        author = "MB-Collector"
        date = "2025-10-20T11:52:30.945603"
        sha256 = "0178782131396a7fe379de4a244a6bc7896646fdbf824fcb8cb815efe1ac2d81"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
