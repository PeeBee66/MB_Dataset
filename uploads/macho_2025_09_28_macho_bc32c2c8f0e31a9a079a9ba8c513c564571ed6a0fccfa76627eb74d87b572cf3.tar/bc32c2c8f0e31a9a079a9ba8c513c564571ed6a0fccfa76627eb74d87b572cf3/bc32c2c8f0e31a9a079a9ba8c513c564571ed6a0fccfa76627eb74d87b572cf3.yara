
rule MB_bc32c2c8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:12.282609"
        sha256 = "bc32c2c8f0e31a9a079a9ba8c513c564571ed6a0fccfa76627eb74d87b572cf3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
