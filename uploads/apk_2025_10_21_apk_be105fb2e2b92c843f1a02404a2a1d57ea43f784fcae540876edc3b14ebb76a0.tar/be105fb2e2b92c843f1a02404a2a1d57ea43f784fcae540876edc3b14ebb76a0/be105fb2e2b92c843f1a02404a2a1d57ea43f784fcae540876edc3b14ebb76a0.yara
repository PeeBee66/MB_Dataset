
rule MB_be105fb2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:46:49.274914"
        sha256 = "be105fb2e2b92c843f1a02404a2a1d57ea43f784fcae540876edc3b14ebb76a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
