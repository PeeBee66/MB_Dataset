
rule MB_e7bc41c6
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:55.984162"
        sha256 = "e7bc41c6d3677ef941dfc8eb4b571435623dab1e8c0681b6253c37725844b268"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
