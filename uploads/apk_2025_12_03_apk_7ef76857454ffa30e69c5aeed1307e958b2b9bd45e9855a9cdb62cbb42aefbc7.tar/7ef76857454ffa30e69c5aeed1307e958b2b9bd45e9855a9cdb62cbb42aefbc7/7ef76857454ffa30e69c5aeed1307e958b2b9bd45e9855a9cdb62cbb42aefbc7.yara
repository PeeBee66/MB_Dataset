
rule MB_7ef76857
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:42.393228"
        sha256 = "7ef76857454ffa30e69c5aeed1307e958b2b9bd45e9855a9cdb62cbb42aefbc7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
