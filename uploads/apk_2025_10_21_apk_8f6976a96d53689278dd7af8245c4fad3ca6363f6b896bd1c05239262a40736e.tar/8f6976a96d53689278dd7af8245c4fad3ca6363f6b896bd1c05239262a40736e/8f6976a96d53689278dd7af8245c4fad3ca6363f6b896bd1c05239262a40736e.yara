
rule MB_8f6976a9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:16.043324"
        sha256 = "8f6976a96d53689278dd7af8245c4fad3ca6363f6b896bd1c05239262a40736e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
