
rule MB_17372844
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-03-23T23:00:17.327126"
        sha256 = "17372844a0ecb548c70275a5e06f522a2445f2781410a246130757e0b7bc5396"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
