
rule MB_5c2257ba
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:39.274503"
        sha256 = "5c2257ba51c49fa49d52d1f0b5be0b389ca47a94c2e88a00bb9b823339d55e19"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
