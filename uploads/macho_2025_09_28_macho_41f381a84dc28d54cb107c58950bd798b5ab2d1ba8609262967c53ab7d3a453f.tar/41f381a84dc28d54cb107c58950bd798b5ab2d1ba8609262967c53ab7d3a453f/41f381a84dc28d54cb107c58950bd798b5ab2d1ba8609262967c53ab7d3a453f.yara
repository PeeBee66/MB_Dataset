
rule MB_41f381a8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:30.236875"
        sha256 = "41f381a84dc28d54cb107c58950bd798b5ab2d1ba8609262967c53ab7d3a453f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
