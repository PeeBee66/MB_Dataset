
rule MB_a37e4fba
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:31.099213"
        sha256 = "a37e4fbad12a49cb8f0a3c8c567c570da54963932f43044c613c4b46be0ba176"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
