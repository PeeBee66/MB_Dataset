
rule MB_3ab3cc3c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-06T23:00:44.960950"
        sha256 = "3ab3cc3c0df02d723c850e712fa5f4a0de29f2addf2c50beffe222112c2baa38"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
