
rule MB_13d67a63
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:38.147156"
        sha256 = "13d67a630b8536f27c95a0df268741a27fb08ff0ccd27bb5424a5eeeb0741f52"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
