
rule MB_17adf891
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:01:26.469194"
        sha256 = "17adf891306aabe0605171ae5e5d44feaebf96f5fd359e888cc52629b76f86c5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
