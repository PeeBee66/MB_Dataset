
rule MB_03239b54
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:36.319752"
        sha256 = "03239b548d97f6ca493b851de41dc9563267cea385e390a45debc133edba59d8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
