
rule MB_0517ca46
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-27T00:00:25.062336"
        sha256 = "0517ca4649e33faefa3a6bfcd2707a8376a981be4b42b9d19146ebb93e7f8a35"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
