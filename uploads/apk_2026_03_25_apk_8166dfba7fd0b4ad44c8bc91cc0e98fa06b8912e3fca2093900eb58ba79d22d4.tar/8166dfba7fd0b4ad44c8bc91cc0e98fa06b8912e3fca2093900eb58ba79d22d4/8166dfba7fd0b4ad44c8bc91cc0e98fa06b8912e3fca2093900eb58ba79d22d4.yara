
rule MB_8166dfba
{
    meta:
        description = "Auto-generated rule for BankBot"
        author = "MB-Collector"
        date = "2026-03-24T23:00:50.191106"
        sha256 = "8166dfba7fd0b4ad44c8bc91cc0e98fa06b8912e3fca2093900eb58ba79d22d4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
