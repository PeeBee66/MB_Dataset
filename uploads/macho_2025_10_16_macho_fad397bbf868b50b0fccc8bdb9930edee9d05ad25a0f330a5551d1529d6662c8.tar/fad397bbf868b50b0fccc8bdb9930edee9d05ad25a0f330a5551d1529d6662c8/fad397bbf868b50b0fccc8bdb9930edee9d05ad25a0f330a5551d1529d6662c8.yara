
rule MB_fad397bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-15T23:00:46.563625"
        sha256 = "fad397bbf868b50b0fccc8bdb9930edee9d05ad25a0f330a5551d1529d6662c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
