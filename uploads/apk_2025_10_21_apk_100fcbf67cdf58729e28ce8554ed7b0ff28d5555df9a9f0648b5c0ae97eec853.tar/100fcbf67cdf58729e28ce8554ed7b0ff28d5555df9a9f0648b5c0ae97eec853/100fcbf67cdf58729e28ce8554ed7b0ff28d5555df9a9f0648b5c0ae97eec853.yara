
rule MB_100fcbf6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:59.142218"
        sha256 = "100fcbf67cdf58729e28ce8554ed7b0ff28d5555df9a9f0648b5c0ae97eec853"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
