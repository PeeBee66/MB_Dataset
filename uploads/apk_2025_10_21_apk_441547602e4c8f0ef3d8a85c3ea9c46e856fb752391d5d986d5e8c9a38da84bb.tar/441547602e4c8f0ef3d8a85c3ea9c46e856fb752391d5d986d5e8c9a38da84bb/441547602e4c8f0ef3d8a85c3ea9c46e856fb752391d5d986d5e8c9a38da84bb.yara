
rule MB_44154760
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:19:41.713239"
        sha256 = "441547602e4c8f0ef3d8a85c3ea9c46e856fb752391d5d986d5e8c9a38da84bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
