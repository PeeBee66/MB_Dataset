
rule MB_5b3d55fa
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:23.836307"
        sha256 = "5b3d55fae36847940935aa542d625ed9bf9fb7e7f74a2c86e9e6ecb0c7538483"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
