
rule MB_3e6ceaa7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-25T00:00:49.390062"
        sha256 = "3e6ceaa7fe833085ee34eb02414a13c21701d31e9d4342030340b0ebb72ea266"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
