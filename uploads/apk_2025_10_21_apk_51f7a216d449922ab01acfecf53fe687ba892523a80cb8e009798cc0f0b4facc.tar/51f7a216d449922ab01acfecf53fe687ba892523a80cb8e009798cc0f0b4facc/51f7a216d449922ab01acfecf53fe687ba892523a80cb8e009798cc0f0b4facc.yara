
rule MB_51f7a216
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:16.504110"
        sha256 = "51f7a216d449922ab01acfecf53fe687ba892523a80cb8e009798cc0f0b4facc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
