
rule MB_3cb66f8e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:19.973734"
        sha256 = "3cb66f8eeb3654ea2a0152be55ef5469731add50affe8a5cf587e91fd22dae64"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
