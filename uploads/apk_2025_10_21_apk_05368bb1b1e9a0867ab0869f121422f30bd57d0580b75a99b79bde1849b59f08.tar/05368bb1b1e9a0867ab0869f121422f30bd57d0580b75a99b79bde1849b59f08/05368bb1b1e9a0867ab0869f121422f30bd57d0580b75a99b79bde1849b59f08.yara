
rule MB_05368bb1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:05:43.025095"
        sha256 = "05368bb1b1e9a0867ab0869f121422f30bd57d0580b75a99b79bde1849b59f08"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
