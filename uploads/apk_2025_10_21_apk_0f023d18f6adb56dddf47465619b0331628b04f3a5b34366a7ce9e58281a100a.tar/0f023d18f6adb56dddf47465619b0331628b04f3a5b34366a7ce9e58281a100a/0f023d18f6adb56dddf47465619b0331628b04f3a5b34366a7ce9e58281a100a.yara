
rule MB_0f023d18
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:23.830590"
        sha256 = "0f023d18f6adb56dddf47465619b0331628b04f3a5b34366a7ce9e58281a100a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
