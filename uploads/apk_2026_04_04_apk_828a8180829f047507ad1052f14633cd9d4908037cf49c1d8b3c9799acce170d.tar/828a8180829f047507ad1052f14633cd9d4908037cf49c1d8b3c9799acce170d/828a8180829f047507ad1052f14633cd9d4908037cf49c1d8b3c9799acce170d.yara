
rule MB_828a8180
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:01:01.213738"
        sha256 = "828a8180829f047507ad1052f14633cd9d4908037cf49c1d8b3c9799acce170d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
