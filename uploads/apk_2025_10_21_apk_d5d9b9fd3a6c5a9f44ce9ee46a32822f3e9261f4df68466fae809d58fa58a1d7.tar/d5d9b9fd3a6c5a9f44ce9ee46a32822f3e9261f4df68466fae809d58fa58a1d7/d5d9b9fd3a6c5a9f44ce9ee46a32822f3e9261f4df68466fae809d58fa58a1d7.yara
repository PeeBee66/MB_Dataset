
rule MB_d5d9b9fd
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:45:15.167543"
        sha256 = "d5d9b9fd3a6c5a9f44ce9ee46a32822f3e9261f4df68466fae809d58fa58a1d7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
