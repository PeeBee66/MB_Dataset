
rule MB_02eb0058
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:36.429878"
        sha256 = "02eb0058ca9c37c4caf8418f93c8583f8c4cb062325290645a11e556e98faa38"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
