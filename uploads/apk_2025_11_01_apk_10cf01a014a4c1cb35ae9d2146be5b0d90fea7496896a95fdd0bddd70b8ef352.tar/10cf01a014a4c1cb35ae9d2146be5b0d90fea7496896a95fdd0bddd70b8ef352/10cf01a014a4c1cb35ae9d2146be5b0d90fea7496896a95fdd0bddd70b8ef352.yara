
rule MB_10cf01a0
{
    meta:
        description = "Auto-generated rule for SMSWorm"
        author = "MB-Collector"
        date = "2025-10-31T23:05:10.059388"
        sha256 = "10cf01a014a4c1cb35ae9d2146be5b0d90fea7496896a95fdd0bddd70b8ef352"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
