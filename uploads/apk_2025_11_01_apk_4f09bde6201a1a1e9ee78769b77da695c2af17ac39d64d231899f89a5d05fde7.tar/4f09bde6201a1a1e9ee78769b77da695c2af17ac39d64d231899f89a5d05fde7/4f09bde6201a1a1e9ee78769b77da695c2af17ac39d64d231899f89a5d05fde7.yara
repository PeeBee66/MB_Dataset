
rule MB_4f09bde6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:07:41.730406"
        sha256 = "4f09bde6201a1a1e9ee78769b77da695c2af17ac39d64d231899f89a5d05fde7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
