
rule MB_a2a53910
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-20T00:00:40.561939"
        sha256 = "a2a539109b77cfa720f6e1315fa09c82cfb8eb9980b304ba54de6a8279993dd4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
