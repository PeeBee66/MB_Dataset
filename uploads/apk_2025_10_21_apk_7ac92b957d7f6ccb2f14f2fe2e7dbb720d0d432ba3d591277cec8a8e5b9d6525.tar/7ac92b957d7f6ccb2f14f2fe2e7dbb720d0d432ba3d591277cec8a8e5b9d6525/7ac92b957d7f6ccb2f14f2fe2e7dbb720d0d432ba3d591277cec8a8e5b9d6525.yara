
rule MB_7ac92b95
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:20:20.205908"
        sha256 = "7ac92b957d7f6ccb2f14f2fe2e7dbb720d0d432ba3d591277cec8a8e5b9d6525"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
