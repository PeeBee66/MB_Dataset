
rule MB_4121afb7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:28.432520"
        sha256 = "4121afb78568de6b406608bf0514f0bf3056117bba10d2673ff69335ddb81ffb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
