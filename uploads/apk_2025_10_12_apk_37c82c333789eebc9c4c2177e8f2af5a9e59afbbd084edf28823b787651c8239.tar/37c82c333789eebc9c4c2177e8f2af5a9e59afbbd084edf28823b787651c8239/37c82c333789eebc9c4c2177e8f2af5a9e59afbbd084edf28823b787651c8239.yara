
rule MB_37c82c33
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-11T23:00:13.641639"
        sha256 = "37c82c333789eebc9c4c2177e8f2af5a9e59afbbd084edf28823b787651c8239"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
