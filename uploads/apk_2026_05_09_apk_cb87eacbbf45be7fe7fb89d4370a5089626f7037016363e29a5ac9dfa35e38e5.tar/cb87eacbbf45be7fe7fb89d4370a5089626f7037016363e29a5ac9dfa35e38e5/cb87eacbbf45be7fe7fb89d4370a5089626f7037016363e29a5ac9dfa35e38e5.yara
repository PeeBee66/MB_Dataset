
rule MB_cb87eacb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:22.561705"
        sha256 = "cb87eacbbf45be7fe7fb89d4370a5089626f7037016363e29a5ac9dfa35e38e5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
