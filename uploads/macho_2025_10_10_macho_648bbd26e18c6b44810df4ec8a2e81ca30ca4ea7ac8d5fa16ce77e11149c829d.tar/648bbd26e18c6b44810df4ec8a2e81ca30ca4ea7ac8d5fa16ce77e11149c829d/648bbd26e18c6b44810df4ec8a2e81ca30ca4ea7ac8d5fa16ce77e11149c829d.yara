
rule MB_648bbd26
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:31.834243"
        sha256 = "648bbd26e18c6b44810df4ec8a2e81ca30ca4ea7ac8d5fa16ce77e11149c829d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
