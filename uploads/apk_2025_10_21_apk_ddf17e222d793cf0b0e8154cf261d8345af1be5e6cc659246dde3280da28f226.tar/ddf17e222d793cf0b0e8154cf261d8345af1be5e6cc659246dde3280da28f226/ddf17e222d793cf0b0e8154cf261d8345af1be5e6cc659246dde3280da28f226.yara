
rule MB_ddf17e22
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:13.383254"
        sha256 = "ddf17e222d793cf0b0e8154cf261d8345af1be5e6cc659246dde3280da28f226"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
