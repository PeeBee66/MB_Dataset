
rule MB_e1d64e02
{
    meta:
        description = "Auto-generated rule for SpyLoan"
        author = "MB-Collector"
        date = "2025-10-20T11:47:09.858258"
        sha256 = "e1d64e0260853453afaab2a11c2d0ab4ff7bbd4131304bc954ce4daad4cd6749"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
