
rule MB_50990c11
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:05.878142"
        sha256 = "50990c1178790239445d4dea570e4affeca6efbb01a91cbf4af4498a0477dd2e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
