
rule MB_06c74829
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-22T23:00:42.433618"
        sha256 = "06c74829d8eee3c47e17d01c41361d314f12277d899cc9dfa789fe767c03693e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
