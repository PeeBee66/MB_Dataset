
rule MB_6ec2aec3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-06T23:00:25.512242"
        sha256 = "6ec2aec3151feaf7b4c6c7934e7ad601cca984266f0604b93676ae698ffed738"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
