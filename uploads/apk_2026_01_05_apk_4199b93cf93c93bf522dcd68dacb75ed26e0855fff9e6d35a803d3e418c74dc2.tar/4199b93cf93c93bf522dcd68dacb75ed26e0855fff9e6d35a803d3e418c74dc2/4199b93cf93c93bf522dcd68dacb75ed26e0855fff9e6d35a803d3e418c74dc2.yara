
rule MB_4199b93c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-04T23:00:12.851191"
        sha256 = "4199b93cf93c93bf522dcd68dacb75ed26e0855fff9e6d35a803d3e418c74dc2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
