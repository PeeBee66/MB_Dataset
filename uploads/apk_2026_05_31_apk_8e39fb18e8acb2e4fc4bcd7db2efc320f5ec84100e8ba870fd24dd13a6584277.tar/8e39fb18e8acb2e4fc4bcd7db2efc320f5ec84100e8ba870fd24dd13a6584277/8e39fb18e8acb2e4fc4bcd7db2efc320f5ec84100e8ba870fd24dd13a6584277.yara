
rule MB_8e39fb18
{
    meta:
        description = "Auto-generated rule for PixRevolution"
        author = "MB-Collector"
        date = "2026-05-31T00:00:28.485172"
        sha256 = "8e39fb18e8acb2e4fc4bcd7db2efc320f5ec84100e8ba870fd24dd13a6584277"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
