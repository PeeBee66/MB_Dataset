
rule MB_8525fe05
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-16T23:00:25.752372"
        sha256 = "8525fe052bd022f38a4e1414acedd110727e792d87e17253500bbbe26854e3a8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
