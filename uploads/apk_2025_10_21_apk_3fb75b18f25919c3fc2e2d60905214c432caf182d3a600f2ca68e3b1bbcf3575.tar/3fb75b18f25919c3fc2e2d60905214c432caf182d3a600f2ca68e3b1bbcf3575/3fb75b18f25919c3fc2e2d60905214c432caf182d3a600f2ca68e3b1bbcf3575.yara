
rule MB_3fb75b18
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-20T11:04:23.538232"
        sha256 = "3fb75b18f25919c3fc2e2d60905214c432caf182d3a600f2ca68e3b1bbcf3575"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
