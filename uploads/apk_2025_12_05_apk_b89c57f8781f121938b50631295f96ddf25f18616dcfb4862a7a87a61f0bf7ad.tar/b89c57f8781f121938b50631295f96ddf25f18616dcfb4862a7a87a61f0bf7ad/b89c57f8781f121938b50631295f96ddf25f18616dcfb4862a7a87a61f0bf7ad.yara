
rule MB_b89c57f8
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-12-04T23:00:54.834233"
        sha256 = "b89c57f8781f121938b50631295f96ddf25f18616dcfb4862a7a87a61f0bf7ad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
