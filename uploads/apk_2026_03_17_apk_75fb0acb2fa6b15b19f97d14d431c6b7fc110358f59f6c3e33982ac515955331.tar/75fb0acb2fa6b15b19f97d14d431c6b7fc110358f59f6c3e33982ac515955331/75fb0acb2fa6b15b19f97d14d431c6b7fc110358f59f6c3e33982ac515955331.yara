
rule MB_75fb0acb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-16T23:00:38.886949"
        sha256 = "75fb0acb2fa6b15b19f97d14d431c6b7fc110358f59f6c3e33982ac515955331"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
