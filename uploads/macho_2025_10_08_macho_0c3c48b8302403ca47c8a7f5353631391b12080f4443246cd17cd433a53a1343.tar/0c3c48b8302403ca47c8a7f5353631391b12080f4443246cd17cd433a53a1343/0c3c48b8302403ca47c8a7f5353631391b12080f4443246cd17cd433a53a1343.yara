
rule MB_0c3c48b8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:02.424258"
        sha256 = "0c3c48b8302403ca47c8a7f5353631391b12080f4443246cd17cd433a53a1343"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
