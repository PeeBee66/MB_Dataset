
rule MB_c3e3734c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:20.261404"
        sha256 = "c3e3734c19b1cc81ebd94aa2330f965ffcd1695cca1169a5d7100543cecd82e4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
