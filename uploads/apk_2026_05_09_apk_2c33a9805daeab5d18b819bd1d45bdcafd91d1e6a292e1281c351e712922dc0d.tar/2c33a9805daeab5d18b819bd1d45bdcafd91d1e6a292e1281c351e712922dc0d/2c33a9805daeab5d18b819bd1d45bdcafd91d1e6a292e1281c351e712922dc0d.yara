
rule MB_2c33a980
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:54.595754"
        sha256 = "2c33a9805daeab5d18b819bd1d45bdcafd91d1e6a292e1281c351e712922dc0d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
