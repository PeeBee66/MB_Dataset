
rule MB_44517d3d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:16.788249"
        sha256 = "44517d3ddc4ab115b2c7941b4cccd3a153ed7fc2d8f6bfa77b017b675f6b3979"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
