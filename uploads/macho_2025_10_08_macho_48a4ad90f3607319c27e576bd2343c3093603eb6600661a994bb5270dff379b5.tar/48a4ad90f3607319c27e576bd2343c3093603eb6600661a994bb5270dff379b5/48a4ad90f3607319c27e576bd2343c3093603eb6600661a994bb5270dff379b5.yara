
rule MB_48a4ad90
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:33.511621"
        sha256 = "48a4ad90f3607319c27e576bd2343c3093603eb6600661a994bb5270dff379b5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
