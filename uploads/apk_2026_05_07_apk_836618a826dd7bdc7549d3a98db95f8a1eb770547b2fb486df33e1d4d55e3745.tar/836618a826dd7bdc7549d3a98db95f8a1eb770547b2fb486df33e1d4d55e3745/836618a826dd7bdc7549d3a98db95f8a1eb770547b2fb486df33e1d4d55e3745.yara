
rule MB_836618a8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:19.432218"
        sha256 = "836618a826dd7bdc7549d3a98db95f8a1eb770547b2fb486df33e1d4d55e3745"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
