
rule MB_89cacc44
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:37:15.733692"
        sha256 = "89cacc44f42639f27efe324f4937b923e2711b88b67b1fdae8bbae1210f573e7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
