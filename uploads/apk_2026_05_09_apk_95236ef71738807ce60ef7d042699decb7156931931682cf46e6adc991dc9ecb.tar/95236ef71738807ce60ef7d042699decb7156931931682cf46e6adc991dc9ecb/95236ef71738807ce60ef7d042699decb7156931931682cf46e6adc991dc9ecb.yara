
rule MB_95236ef7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:00:19.760705"
        sha256 = "95236ef71738807ce60ef7d042699decb7156931931682cf46e6adc991dc9ecb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
