
rule MB_f6114a15
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:04:45.121459"
        sha256 = "f6114a15beb114619737710334d865a1a275525712d6590054128ee224f7e1ee"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
