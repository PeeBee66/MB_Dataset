
rule MB_38fce46e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:09.517651"
        sha256 = "38fce46e4ec7f0254584d44498e0e803785ab4739f21bb96599c766d1b9388e4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
