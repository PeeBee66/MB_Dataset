
rule MB_c659454d
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2026-02-17T23:00:43.420869"
        sha256 = "c659454dd6ed62bc7a0c9e0455297e41ba57b0b7935a826150c1f8c0db6f89d2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
