
rule MB_da0919c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:35:34.895090"
        sha256 = "da0919c56fd8ef279edc0b3169eedd391d9cdb30afad65054d0cd0b4e682d37b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
