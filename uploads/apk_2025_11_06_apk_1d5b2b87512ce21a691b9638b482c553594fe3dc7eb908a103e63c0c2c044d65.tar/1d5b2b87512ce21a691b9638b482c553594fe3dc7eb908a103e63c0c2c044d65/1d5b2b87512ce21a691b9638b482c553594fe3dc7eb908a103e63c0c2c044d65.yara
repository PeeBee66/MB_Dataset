
rule MB_1d5b2b87
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-11-05T23:00:20.703576"
        sha256 = "1d5b2b87512ce21a691b9638b482c553594fe3dc7eb908a103e63c0c2c044d65"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
