
rule MB_06304ec2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:47.268220"
        sha256 = "06304ec207779cc65e5c3dc82a1d1f5e84a1a3fe2a6545e489e8d15343846848"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
