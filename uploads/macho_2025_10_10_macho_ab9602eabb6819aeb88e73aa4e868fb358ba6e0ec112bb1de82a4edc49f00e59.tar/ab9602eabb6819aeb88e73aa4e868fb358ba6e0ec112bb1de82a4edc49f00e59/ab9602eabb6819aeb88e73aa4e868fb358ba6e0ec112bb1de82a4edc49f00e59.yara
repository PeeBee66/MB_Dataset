
rule MB_ab9602ea
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:48.150344"
        sha256 = "ab9602eabb6819aeb88e73aa4e868fb358ba6e0ec112bb1de82a4edc49f00e59"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
