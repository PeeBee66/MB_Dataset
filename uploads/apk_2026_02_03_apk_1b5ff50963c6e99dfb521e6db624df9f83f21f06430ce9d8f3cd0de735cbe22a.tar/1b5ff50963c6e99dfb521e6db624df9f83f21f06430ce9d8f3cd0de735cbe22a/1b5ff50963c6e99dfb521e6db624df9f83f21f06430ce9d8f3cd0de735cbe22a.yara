
rule MB_1b5ff509
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:18.428100"
        sha256 = "1b5ff50963c6e99dfb521e6db624df9f83f21f06430ce9d8f3cd0de735cbe22a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
