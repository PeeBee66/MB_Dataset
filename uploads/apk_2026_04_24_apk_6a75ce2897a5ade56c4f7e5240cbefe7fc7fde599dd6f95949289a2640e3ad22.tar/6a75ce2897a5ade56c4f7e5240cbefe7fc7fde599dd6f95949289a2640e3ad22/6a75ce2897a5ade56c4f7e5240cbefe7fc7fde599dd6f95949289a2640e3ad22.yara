
rule MB_6a75ce28
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:50.188800"
        sha256 = "6a75ce2897a5ade56c4f7e5240cbefe7fc7fde599dd6f95949289a2640e3ad22"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
