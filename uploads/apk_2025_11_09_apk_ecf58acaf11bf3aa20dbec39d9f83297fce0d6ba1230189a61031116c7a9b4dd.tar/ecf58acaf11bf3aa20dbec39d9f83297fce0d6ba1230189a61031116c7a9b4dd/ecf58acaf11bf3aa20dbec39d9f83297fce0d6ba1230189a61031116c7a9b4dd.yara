
rule MB_ecf58aca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-08T23:00:28.963536"
        sha256 = "ecf58acaf11bf3aa20dbec39d9f83297fce0d6ba1230189a61031116c7a9b4dd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
