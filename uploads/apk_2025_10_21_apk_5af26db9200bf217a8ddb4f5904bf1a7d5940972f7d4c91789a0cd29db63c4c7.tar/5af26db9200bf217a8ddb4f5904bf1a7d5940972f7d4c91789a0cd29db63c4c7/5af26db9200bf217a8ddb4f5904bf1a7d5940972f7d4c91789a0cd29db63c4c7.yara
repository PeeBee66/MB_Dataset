
rule MB_5af26db9
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:21:02.106458"
        sha256 = "5af26db9200bf217a8ddb4f5904bf1a7d5940972f7d4c91789a0cd29db63c4c7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
