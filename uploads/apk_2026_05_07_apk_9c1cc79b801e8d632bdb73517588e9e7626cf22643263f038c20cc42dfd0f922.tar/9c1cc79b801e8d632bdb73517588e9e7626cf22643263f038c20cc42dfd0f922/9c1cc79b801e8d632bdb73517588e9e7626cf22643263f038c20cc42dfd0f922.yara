
rule MB_9c1cc79b
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-05-07T00:03:09.165667"
        sha256 = "9c1cc79b801e8d632bdb73517588e9e7626cf22643263f038c20cc42dfd0f922"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
