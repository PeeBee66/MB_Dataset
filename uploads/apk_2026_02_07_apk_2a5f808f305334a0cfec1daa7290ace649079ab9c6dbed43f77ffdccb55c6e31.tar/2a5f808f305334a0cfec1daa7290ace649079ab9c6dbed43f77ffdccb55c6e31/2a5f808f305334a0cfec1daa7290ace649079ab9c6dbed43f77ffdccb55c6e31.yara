
rule MB_2a5f808f
{
    meta:
        description = "Auto-generated rule for FantasyHub"
        author = "MB-Collector"
        date = "2026-02-06T23:00:20.303340"
        sha256 = "2a5f808f305334a0cfec1daa7290ace649079ab9c6dbed43f77ffdccb55c6e31"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
