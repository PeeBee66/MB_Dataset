
rule MB_a41ee1ea
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-25T23:00:20.036561"
        sha256 = "a41ee1ea1fd091fe3e7c77a96f3198b86c6fcc63425924fb626b45413b841750"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
