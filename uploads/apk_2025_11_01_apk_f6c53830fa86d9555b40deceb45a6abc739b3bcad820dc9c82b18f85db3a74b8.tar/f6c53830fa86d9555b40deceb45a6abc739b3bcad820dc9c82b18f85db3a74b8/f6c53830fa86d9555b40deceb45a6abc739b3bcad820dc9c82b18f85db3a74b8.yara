
rule MB_f6c53830
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:43.719345"
        sha256 = "f6c53830fa86d9555b40deceb45a6abc739b3bcad820dc9c82b18f85db3a74b8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
