
rule MB_9cd9c946
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-11T23:00:29.705040"
        sha256 = "9cd9c9469367f2b606f237ffe83dde2a4e8dcef74106f8e8985f4c9bfef202b4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
