
rule MB_686a0efc
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:01.703876"
        sha256 = "686a0efc4fdb8a87dff7f417a4b5028134dfcdf38ebc12c87dd7040c70b724da"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
