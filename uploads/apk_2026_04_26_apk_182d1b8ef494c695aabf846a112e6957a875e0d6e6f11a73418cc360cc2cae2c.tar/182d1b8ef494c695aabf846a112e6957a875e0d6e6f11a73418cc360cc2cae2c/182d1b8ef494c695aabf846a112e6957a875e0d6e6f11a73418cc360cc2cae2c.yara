
rule MB_182d1b8e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-26T00:01:07.583954"
        sha256 = "182d1b8ef494c695aabf846a112e6957a875e0d6e6f11a73418cc360cc2cae2c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
