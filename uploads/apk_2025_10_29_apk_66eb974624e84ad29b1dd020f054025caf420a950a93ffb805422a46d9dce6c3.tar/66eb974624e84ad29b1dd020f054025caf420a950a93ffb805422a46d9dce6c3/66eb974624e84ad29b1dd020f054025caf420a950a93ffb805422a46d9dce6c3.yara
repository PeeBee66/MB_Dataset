
rule MB_66eb9746
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:00:45.263618"
        sha256 = "66eb974624e84ad29b1dd020f054025caf420a950a93ffb805422a46d9dce6c3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
