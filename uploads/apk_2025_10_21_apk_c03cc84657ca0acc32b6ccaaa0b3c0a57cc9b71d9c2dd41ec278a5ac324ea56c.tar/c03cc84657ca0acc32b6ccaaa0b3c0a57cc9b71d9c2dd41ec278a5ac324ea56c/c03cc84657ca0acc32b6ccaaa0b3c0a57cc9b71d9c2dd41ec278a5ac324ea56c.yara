
rule MB_c03cc846
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:26:26.448609"
        sha256 = "c03cc84657ca0acc32b6ccaaa0b3c0a57cc9b71d9c2dd41ec278a5ac324ea56c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
