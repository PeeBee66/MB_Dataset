
rule MB_be31c08b
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:02:42.662553"
        sha256 = "be31c08bd0f35fcc7f280720e4df7281c89fe443360ebeac8f6bd3b450974120"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
