
rule MB_4e0df7a9
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:59.148313"
        sha256 = "4e0df7a93457487237d09ae194648d09d92061e80f5ee07f2e9dd9a47b0de301"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
