
rule MB_91d58e4b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:57:17.176282"
        sha256 = "91d58e4bbd687b1cba419a2e54b00d385f2461faf53dd31a369da369450579db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
