
rule MB_0efd9027
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:03:46.184205"
        sha256 = "0efd90274fcafecd64dda6b73b5417537b9f5499a3046ee7d21bb65e0758e07d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
