
rule MB_a0bd52fd
{
    meta:
        description = "Auto-generated rule for Chisel"
        author = "MB-Collector"
        date = "2026-03-23T23:01:29.010675"
        sha256 = "a0bd52fd9d209e1de369f4e4ee944d8a76f6ce15da9f6038a5c4a0d57125f161"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
