
rule MB_2d9e986b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:29.710156"
        sha256 = "2d9e986bd8885cf3abf6d6a1ba7d5c6cc0c69670821fe49a559303d16bea02c4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
