
rule MB_d1c1d691
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:58.213398"
        sha256 = "d1c1d691dc9ec3d500a71551aeaaa992521f7974dccfbd748eaa481990f1b56e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
