
rule MB_f9ac55ae
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:00:26.569456"
        sha256 = "f9ac55ae787eca2c6a1dc1e5057cd1806d69d5f7b557ef5b1a6bfea397865ebf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
