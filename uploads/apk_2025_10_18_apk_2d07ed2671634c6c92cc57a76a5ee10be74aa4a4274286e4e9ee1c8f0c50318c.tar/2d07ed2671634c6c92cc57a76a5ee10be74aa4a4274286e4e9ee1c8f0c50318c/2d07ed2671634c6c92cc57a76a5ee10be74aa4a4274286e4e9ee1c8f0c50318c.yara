
rule MB_2d07ed26
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-17T23:00:21.764469"
        sha256 = "2d07ed2671634c6c92cc57a76a5ee10be74aa4a4274286e4e9ee1c8f0c50318c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
