
rule MB_dd7650a9
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:05:35.025574"
        sha256 = "dd7650a9cd3f853e109d2d0138ede785e1559d6c2d8c52eec2f2d9808a924f1c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
