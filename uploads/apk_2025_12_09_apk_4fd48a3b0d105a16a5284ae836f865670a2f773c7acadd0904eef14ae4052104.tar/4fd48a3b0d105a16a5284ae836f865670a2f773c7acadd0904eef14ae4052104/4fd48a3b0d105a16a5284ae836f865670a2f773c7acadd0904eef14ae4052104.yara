
rule MB_4fd48a3b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:48.046340"
        sha256 = "4fd48a3b0d105a16a5284ae836f865670a2f773c7acadd0904eef14ae4052104"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
