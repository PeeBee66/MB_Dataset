
rule MB_a8062f50
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-01T23:00:15.827426"
        sha256 = "a8062f50057c4d8be86c50b411addafa7429b451420b3aaeb1ec6f04aef18957"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
