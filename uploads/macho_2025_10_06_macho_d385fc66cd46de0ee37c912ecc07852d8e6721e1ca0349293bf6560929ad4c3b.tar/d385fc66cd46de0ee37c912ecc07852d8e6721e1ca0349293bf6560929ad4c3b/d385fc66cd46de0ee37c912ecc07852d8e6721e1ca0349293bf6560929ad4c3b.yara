
rule MB_d385fc66
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:16:41.319618"
        sha256 = "d385fc66cd46de0ee37c912ecc07852d8e6721e1ca0349293bf6560929ad4c3b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
