
rule MB_bfc16f17
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:26.269717"
        sha256 = "bfc16f17d42eca4d8161a0a292bb27b886e8c8b9dc92ba9d94ca0c34df2fd0d0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
