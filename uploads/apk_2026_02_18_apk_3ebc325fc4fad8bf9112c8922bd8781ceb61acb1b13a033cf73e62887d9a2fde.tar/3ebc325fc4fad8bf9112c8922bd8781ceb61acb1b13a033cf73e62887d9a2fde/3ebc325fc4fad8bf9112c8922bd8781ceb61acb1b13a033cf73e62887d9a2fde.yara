
rule MB_3ebc325f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-17T23:00:48.355030"
        sha256 = "3ebc325fc4fad8bf9112c8922bd8781ceb61acb1b13a033cf73e62887d9a2fde"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
