
rule MB_d3675e1a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-15T00:00:29.332415"
        sha256 = "d3675e1a6a02a52e9afa3c6742e6db05f9c2c937a26667f923f8579c83324246"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
