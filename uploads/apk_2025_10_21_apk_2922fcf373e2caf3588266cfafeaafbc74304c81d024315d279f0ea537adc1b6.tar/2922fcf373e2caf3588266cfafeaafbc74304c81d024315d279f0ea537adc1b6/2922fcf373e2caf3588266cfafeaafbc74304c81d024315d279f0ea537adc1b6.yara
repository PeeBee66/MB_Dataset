
rule MB_2922fcf3
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:31:18.268230"
        sha256 = "2922fcf373e2caf3588266cfafeaafbc74304c81d024315d279f0ea537adc1b6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
