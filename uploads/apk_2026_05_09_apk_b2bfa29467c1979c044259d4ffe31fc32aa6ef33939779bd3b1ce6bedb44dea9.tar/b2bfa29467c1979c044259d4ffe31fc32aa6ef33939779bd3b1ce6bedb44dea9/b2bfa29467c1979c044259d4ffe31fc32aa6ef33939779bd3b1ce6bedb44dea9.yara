
rule MB_b2bfa294
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:21.027173"
        sha256 = "b2bfa29467c1979c044259d4ffe31fc32aa6ef33939779bd3b1ce6bedb44dea9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
