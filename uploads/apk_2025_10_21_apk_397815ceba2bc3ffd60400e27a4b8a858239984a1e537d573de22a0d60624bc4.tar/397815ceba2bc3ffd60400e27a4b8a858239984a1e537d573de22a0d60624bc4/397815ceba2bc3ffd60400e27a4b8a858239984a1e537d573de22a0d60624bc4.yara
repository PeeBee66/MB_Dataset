
rule MB_397815ce
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:28.760295"
        sha256 = "397815ceba2bc3ffd60400e27a4b8a858239984a1e537d573de22a0d60624bc4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
