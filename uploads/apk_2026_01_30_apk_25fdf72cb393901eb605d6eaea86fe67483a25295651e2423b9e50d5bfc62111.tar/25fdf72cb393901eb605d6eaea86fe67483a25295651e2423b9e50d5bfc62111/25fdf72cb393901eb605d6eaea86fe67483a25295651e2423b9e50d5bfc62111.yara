
rule MB_25fdf72c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:01:23.264651"
        sha256 = "25fdf72cb393901eb605d6eaea86fe67483a25295651e2423b9e50d5bfc62111"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
