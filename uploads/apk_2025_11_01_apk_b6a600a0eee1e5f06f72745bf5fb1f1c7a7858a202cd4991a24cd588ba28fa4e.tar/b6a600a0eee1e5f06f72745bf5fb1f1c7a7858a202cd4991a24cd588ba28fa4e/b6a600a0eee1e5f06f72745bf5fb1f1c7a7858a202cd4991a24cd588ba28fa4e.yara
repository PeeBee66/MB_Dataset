
rule MB_b6a600a0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:54.980342"
        sha256 = "b6a600a0eee1e5f06f72745bf5fb1f1c7a7858a202cd4991a24cd588ba28fa4e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
