
rule MB_0640c40c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:43.255767"
        sha256 = "0640c40c9e71188765a7c32afbe49ef030d8db2afc67affcbea7885a7430db69"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
