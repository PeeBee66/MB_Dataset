
rule MB_a7a7b099
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:10:44.964522"
        sha256 = "a7a7b099378a6079e3da3cb28f4fca7179aeaa6dd675a41630574f2f7526181f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
