
rule MB_51a24f9c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-12T23:01:18.882037"
        sha256 = "51a24f9c488e0246f18bff1529dce77bc711a81c2b2e1eb3b437b7af16e8e02f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
