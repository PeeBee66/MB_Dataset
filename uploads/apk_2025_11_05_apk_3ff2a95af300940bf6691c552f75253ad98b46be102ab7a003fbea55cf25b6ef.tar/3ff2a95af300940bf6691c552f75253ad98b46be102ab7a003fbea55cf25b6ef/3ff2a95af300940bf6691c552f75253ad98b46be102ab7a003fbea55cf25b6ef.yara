
rule MB_3ff2a95a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:30.612756"
        sha256 = "3ff2a95af300940bf6691c552f75253ad98b46be102ab7a003fbea55cf25b6ef"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
