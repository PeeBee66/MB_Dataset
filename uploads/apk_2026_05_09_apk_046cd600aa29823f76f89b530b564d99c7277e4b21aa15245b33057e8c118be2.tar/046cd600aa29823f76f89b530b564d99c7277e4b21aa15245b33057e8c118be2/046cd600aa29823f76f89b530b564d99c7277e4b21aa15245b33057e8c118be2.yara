
rule MB_046cd600
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:28.749688"
        sha256 = "046cd600aa29823f76f89b530b564d99c7277e4b21aa15245b33057e8c118be2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
