
rule MB_29c60e17
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-04T01:13:26.254631"
        sha256 = "29c60e17d43f7268431929836c1b72df60d3b7643ed177f858a9d9bbab207783"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
