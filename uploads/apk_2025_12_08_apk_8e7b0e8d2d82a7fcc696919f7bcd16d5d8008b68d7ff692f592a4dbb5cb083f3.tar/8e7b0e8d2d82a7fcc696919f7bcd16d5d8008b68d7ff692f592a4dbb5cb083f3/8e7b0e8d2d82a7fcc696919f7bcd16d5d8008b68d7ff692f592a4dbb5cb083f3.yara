
rule MB_8e7b0e8d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:21.024439"
        sha256 = "8e7b0e8d2d82a7fcc696919f7bcd16d5d8008b68d7ff692f592a4dbb5cb083f3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
