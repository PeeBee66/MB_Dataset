
rule MB_bc5ecb77
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:45.051335"
        sha256 = "bc5ecb77e8aee510a380108013e073f0d0f3b41bd9ba2169bcb8eb85b405347f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
