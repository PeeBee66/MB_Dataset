
rule MB_841e432a
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2026-04-07T00:00:41.175258"
        sha256 = "841e432a41b9625040704fd636d4fc3814a6d4193fa315cd78cfed9aa3991c04"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
