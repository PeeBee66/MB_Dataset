
rule MB_79fa34a1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-02T23:00:15.732797"
        sha256 = "79fa34a1078a6cf6f248aa23131efdcde7b6a0ba4c0e2581c1486fbcd826fdd3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
