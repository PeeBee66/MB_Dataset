
rule MB_7e24d4ab
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:01:05.496839"
        sha256 = "7e24d4ab3211cf8d3e96b17975978b35e1760a8b01bbc8eff1f865df6ee4d6d5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
