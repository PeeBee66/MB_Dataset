
rule MB_0a108cca
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-18T23:00:23.381603"
        sha256 = "0a108cca92abc4326b5897466ed7c8f7f8737d3aab14f59a8d1e5eb4a48167b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
