
rule MB_01bfd9cf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-28T00:00:17.000342"
        sha256 = "01bfd9cf8b9244053df93dc0d33ca945d91381423ef746cecdb19f8a6f093c38"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
