
rule MB_2f99bf11
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:23:00.342275"
        sha256 = "2f99bf11370ebeb4e5f701fe3f0bb1ecd0a69ccdca48102ca38acd8c78be51bb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
