
rule MB_21c66fe5
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:27:37.510427"
        sha256 = "21c66fe505f2bcd7b29d413189920b3a85df48da0ecf4eb6962d6a504a7fdcd8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
