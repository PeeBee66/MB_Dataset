
rule MB_37cc44bc
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:14:35.429800"
        sha256 = "37cc44bc534f6a41da88e7eed50fcd2ceed97ee03f03845e8c69ce20aa6d3121"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
