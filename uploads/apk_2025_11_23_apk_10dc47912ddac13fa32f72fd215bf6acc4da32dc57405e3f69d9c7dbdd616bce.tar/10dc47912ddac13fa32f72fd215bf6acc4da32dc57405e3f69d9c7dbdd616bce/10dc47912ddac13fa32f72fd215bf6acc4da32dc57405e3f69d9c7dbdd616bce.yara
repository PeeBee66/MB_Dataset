
rule MB_10dc4791
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:00:11.699081"
        sha256 = "10dc47912ddac13fa32f72fd215bf6acc4da32dc57405e3f69d9c7dbdd616bce"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
