
rule MB_4ee3b09d
{
    meta:
        description = "Auto-generated rule for PromptSpy"
        author = "MB-Collector"
        date = "2026-02-19T23:00:40.315694"
        sha256 = "4ee3b09dd9a787ebbb02a637f8af192a7e91d4b7af1515d8e5c21e1233f0f1c7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
