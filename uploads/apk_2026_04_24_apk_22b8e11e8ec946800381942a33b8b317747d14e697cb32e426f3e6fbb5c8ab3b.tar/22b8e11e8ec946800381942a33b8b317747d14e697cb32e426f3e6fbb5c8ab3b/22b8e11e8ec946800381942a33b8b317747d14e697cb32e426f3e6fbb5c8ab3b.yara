
rule MB_22b8e11e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:01:31.541940"
        sha256 = "22b8e11e8ec946800381942a33b8b317747d14e697cb32e426f3e6fbb5c8ab3b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
