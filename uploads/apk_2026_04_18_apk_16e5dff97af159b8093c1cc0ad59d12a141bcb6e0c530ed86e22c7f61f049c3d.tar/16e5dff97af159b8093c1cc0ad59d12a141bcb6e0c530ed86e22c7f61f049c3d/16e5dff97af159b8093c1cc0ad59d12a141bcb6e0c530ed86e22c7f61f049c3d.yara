
rule MB_16e5dff9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:30.833225"
        sha256 = "16e5dff97af159b8093c1cc0ad59d12a141bcb6e0c530ed86e22c7f61f049c3d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
