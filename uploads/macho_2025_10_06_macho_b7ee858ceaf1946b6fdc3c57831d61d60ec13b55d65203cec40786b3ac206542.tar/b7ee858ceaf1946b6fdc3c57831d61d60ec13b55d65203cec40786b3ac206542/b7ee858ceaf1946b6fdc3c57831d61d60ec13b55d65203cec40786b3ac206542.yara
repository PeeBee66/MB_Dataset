
rule MB_b7ee858c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:34.861435"
        sha256 = "b7ee858ceaf1946b6fdc3c57831d61d60ec13b55d65203cec40786b3ac206542"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
