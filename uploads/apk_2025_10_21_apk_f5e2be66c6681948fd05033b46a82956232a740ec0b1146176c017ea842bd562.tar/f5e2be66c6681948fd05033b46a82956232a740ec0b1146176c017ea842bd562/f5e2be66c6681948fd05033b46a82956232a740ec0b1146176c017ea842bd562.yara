
rule MB_f5e2be66
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:52:04.162065"
        sha256 = "f5e2be66c6681948fd05033b46a82956232a740ec0b1146176c017ea842bd562"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
