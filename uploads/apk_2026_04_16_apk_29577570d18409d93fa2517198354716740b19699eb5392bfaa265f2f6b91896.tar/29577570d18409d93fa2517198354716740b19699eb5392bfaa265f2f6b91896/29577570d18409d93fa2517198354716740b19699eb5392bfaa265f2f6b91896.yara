
rule MB_29577570
{
    meta:
        description = "Auto-generated rule for Mirax"
        author = "MB-Collector"
        date = "2026-04-16T00:02:55.903190"
        sha256 = "29577570d18409d93fa2517198354716740b19699eb5392bfaa265f2f6b91896"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
