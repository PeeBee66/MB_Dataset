
rule MB_43996d45
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:38.460882"
        sha256 = "43996d454961143bad870d9b94a3d00912f7c29b76371244ac59423595ae0860"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
