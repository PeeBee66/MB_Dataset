
rule MB_7d7aa039
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:31.112317"
        sha256 = "7d7aa039203ffc7626aa054b2dcae0dbaf1e6e9d1b7f5dc30545841615e6d008"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
