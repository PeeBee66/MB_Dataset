
rule MB_1ec3da86
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-17T23:00:38.299735"
        sha256 = "1ec3da86a88a4037bc288073ea564cab08c4faa903dffe304748ad8054f6fa18"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
