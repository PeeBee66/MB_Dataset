
rule MB_7b12d3e1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-02T23:00:16.453458"
        sha256 = "7b12d3e19c69a30625b9e29cd03ca4f1930b9e311b32a2abab7571cf4f872209"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
