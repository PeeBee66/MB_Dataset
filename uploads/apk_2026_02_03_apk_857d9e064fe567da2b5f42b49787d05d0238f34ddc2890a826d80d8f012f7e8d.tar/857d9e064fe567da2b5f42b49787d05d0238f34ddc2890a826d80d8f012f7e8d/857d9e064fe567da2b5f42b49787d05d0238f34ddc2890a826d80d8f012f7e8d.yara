
rule MB_857d9e06
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:09.242616"
        sha256 = "857d9e064fe567da2b5f42b49787d05d0238f34ddc2890a826d80d8f012f7e8d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
