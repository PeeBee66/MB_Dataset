
rule MB_a9b2ca36
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-07T23:00:50.910506"
        sha256 = "a9b2ca36bd59919b2b136fdc5eb090df8ddc3524f3d329844e42f810f118b3dc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
