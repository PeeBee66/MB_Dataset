
rule MB_53afd310
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:50:04.046350"
        sha256 = "53afd31051cd2755289dcd214f948e0edf69df039afffec950e24ead928aad16"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
