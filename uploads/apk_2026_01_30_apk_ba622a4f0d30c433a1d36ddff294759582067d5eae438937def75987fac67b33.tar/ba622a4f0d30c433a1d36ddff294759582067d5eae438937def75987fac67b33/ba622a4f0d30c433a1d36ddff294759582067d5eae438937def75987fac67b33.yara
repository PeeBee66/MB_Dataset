
rule MB_ba622a4f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-29T23:00:59.457389"
        sha256 = "ba622a4f0d30c433a1d36ddff294759582067d5eae438937def75987fac67b33"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
