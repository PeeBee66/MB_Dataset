
rule MB_6ca691c9
{
    meta:
        description = "Auto-generated rule for Hook"
        author = "MB-Collector"
        date = "2025-11-07T23:00:55.486107"
        sha256 = "6ca691c97ab0028ce9acade5d079289668b1d0339ad330181c84fc7e7114c509"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
