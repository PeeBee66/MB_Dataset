
rule MB_215d880d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:00:33.982337"
        sha256 = "215d880d85cd9784f3773bea68f1d84f2400498db8ec7556016e3e4f9380a233"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
