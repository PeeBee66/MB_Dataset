
rule MB_5e482564
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:33.744703"
        sha256 = "5e48256417d2fe4bae5b600f09c07696f05d2f2e3ba55cf892814884b281c73f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
