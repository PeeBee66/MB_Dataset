
rule MB_d1d8f20d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:15.842694"
        sha256 = "d1d8f20d2aeb7283e24319320202bb9a786eb3387a027487bc83734de9c1507e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
