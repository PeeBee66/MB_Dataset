
rule MB_b495f949
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:17.811888"
        sha256 = "b495f9491cd98dd5d5db6658458d576a44cf41afea9ada30a526ee7fa1771b84"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
