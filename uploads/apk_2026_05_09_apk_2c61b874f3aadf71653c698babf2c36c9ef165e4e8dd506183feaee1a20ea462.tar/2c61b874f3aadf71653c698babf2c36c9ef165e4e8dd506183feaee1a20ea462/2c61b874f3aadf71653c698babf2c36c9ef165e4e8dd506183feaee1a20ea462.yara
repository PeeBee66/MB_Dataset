
rule MB_2c61b874
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:37.020715"
        sha256 = "2c61b874f3aadf71653c698babf2c36c9ef165e4e8dd506183feaee1a20ea462"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
