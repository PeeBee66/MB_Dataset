
rule MB_7331d026
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:25:06.231148"
        sha256 = "7331d026ca436575004ee52eefe2ab1f2f67702976b1d8e834f1fe554330c086"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
