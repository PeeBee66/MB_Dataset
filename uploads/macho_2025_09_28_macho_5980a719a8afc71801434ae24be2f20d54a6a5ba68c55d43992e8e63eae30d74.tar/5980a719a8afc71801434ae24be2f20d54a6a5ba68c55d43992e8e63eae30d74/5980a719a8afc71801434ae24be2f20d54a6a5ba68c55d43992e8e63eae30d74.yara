
rule MB_5980a719
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:00:41.268532"
        sha256 = "5980a719a8afc71801434ae24be2f20d54a6a5ba68c55d43992e8e63eae30d74"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
