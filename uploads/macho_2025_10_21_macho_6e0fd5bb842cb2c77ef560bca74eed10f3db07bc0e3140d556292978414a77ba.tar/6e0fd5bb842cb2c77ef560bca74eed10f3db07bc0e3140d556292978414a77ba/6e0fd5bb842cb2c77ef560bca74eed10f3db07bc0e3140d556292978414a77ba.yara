
rule MB_6e0fd5bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T23:00:19.142274"
        sha256 = "6e0fd5bb842cb2c77ef560bca74eed10f3db07bc0e3140d556292978414a77ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
