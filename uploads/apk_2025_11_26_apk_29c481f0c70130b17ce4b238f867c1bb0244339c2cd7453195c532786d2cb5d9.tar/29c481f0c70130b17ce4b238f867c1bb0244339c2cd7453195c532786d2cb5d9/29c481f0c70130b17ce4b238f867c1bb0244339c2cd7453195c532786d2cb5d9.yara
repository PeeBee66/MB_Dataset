
rule MB_29c481f0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:49.962202"
        sha256 = "29c481f0c70130b17ce4b238f867c1bb0244339c2cd7453195c532786d2cb5d9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
