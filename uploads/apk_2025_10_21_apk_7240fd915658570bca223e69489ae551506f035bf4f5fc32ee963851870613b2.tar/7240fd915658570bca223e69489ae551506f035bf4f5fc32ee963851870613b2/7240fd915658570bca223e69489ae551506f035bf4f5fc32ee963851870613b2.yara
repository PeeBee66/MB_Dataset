
rule MB_7240fd91
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:29:14.757684"
        sha256 = "7240fd915658570bca223e69489ae551506f035bf4f5fc32ee963851870613b2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
