
rule MB_a4e184b9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:25.730314"
        sha256 = "a4e184b91b664603bdacd8e47273f248eb7cdbbf6655292e866ffce99a8385a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
