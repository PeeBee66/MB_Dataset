
rule MB_81021ea6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-03T00:00:23.141229"
        sha256 = "81021ea65f7f0dade4472d2be3489492f6421c110c02bc4a9d7b2f5a002eee78"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
