
rule MB_4af08f08
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:00:44.686294"
        sha256 = "4af08f08377457cb04e280615fc8647870f9b20ad763e1bd060731605d8a0c07"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
