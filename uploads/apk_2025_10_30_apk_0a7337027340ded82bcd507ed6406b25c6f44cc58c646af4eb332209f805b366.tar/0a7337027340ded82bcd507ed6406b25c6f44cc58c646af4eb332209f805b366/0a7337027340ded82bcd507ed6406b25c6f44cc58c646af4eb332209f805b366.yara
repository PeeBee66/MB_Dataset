
rule MB_0a733702
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-29T23:00:13.646804"
        sha256 = "0a7337027340ded82bcd507ed6406b25c6f44cc58c646af4eb332209f805b366"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
