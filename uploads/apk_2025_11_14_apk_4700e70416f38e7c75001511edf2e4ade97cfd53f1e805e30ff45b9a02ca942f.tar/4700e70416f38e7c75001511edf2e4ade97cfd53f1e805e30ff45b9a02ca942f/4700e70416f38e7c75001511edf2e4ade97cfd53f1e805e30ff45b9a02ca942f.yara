
rule MB_4700e704
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:01:07.330018"
        sha256 = "4700e70416f38e7c75001511edf2e4ade97cfd53f1e805e30ff45b9a02ca942f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
