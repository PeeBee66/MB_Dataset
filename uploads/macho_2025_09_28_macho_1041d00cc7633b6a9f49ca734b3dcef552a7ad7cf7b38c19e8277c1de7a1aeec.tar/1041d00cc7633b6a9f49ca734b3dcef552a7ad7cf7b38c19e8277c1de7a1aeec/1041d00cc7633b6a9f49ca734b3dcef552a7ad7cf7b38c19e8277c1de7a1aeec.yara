
rule MB_1041d00c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:00:56.949297"
        sha256 = "1041d00cc7633b6a9f49ca734b3dcef552a7ad7cf7b38c19e8277c1de7a1aeec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
