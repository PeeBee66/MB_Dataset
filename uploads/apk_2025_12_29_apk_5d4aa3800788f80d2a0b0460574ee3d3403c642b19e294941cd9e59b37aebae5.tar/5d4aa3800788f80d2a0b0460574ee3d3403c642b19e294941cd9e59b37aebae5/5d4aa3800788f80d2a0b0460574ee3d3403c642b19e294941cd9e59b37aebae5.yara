
rule MB_5d4aa380
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-28T23:00:23.480452"
        sha256 = "5d4aa3800788f80d2a0b0460574ee3d3403c642b19e294941cd9e59b37aebae5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
