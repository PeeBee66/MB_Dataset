
rule MB_9a0d1a25
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:12:48.045713"
        sha256 = "9a0d1a2544e7484daceb96c88e9978751a201d8a680643ef3b4d1975a9ab06e1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
