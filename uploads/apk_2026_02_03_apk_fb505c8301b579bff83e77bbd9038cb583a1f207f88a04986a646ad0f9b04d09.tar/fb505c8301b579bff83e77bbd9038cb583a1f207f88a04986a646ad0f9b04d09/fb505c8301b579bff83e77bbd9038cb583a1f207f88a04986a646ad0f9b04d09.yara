
rule MB_fb505c83
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:10.029923"
        sha256 = "fb505c8301b579bff83e77bbd9038cb583a1f207f88a04986a646ad0f9b04d09"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
