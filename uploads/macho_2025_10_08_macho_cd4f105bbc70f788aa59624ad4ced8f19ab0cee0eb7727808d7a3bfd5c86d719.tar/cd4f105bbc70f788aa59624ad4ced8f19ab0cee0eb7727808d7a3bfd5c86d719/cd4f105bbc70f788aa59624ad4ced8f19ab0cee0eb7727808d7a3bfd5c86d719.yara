
rule MB_cd4f105b
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:52.883279"
        sha256 = "cd4f105bbc70f788aa59624ad4ced8f19ab0cee0eb7727808d7a3bfd5c86d719"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
