
rule MB_24297c3f
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:01:35.342137"
        sha256 = "24297c3f89c311324f7b6203a69890cdf47d997f9086ee5edcc45a164818070f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
