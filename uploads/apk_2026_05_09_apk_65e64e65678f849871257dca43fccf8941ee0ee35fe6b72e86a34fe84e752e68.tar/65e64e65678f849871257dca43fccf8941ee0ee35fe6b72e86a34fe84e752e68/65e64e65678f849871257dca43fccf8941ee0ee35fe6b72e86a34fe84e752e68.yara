
rule MB_65e64e65
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:02:27.159237"
        sha256 = "65e64e65678f849871257dca43fccf8941ee0ee35fe6b72e86a34fe84e752e68"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
