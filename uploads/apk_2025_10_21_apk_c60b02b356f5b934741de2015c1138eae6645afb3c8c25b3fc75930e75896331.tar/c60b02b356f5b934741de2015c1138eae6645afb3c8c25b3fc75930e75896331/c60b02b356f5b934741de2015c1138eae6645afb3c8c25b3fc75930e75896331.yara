
rule MB_c60b02b3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:18.652003"
        sha256 = "c60b02b356f5b934741de2015c1138eae6645afb3c8c25b3fc75930e75896331"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
