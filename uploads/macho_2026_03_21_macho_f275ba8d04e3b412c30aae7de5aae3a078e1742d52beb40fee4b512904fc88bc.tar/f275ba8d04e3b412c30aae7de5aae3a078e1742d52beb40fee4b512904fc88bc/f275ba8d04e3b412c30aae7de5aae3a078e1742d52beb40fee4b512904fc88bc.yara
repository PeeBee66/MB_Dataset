
rule MB_f275ba8d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:00:39.381694"
        sha256 = "f275ba8d04e3b412c30aae7de5aae3a078e1742d52beb40fee4b512904fc88bc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
