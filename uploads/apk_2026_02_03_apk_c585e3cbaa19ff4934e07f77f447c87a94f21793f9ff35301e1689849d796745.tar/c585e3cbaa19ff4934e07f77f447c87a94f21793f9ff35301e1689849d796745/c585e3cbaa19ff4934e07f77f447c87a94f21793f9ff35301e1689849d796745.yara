
rule MB_c585e3cb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:16.512063"
        sha256 = "c585e3cbaa19ff4934e07f77f447c87a94f21793f9ff35301e1689849d796745"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
