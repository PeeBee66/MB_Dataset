
rule MB_da757675
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-11T23:00:18.147846"
        sha256 = "da757675c4ec5f6d4405eb4013784b122d3fe1e0443605a97b5a453b4f596cb2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
