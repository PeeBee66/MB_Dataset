
rule MB_c4fd1331
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:30.039534"
        sha256 = "c4fd13310c73168d05b2ef9befdf5e041162992306fd7124ecfb049f3c9f11c4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
