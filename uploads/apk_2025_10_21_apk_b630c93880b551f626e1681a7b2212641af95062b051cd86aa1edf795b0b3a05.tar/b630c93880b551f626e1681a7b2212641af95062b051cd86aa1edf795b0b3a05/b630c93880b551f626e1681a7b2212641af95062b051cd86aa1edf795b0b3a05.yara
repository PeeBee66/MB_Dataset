
rule MB_b630c938
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:46:43.476738"
        sha256 = "b630c93880b551f626e1681a7b2212641af95062b051cd86aa1edf795b0b3a05"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
