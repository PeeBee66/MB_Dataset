
rule MB_c800bfa7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:06:37.929490"
        sha256 = "c800bfa7f3196e1ad535350047d05bab729be9f57f97ee4b3aae47512afd9f09"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
