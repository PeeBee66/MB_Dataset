
rule MB_d3ad6c93
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-02-11T23:00:35.902820"
        sha256 = "d3ad6c9325b71044134c77b1e0c97c392a1f8d27f0af041d48325815dc1516db"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
