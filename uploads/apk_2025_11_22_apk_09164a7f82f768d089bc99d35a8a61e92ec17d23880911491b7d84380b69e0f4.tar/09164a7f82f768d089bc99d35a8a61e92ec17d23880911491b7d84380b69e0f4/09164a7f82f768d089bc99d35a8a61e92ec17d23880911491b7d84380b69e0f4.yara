
rule MB_09164a7f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-21T23:01:13.310191"
        sha256 = "09164a7f82f768d089bc99d35a8a61e92ec17d23880911491b7d84380b69e0f4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
