
rule MB_a02d7012
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:04.342183"
        sha256 = "a02d70127abf6fc2c950b150d42b0ac36bf7714c358524b8819b467f94ab758b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
