
rule MB_36c984ef
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:48.840294"
        sha256 = "36c984efc7db1206714814c9a6074fd1028dca5c5bf5a6e08e48e2f0413ed732"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
