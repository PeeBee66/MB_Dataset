
rule MB_4abd5f4e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:06:33.191848"
        sha256 = "4abd5f4e1c9c80470bd5bb2dc132633d70d831d58d531cdde13094f563c5895f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
