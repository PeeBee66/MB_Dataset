
rule MB_a4f8edb4
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:45.710785"
        sha256 = "a4f8edb453d59bfdeb1bfa1045cdeecd2626a82095bbfc33d543ac9d2b5d3adc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
