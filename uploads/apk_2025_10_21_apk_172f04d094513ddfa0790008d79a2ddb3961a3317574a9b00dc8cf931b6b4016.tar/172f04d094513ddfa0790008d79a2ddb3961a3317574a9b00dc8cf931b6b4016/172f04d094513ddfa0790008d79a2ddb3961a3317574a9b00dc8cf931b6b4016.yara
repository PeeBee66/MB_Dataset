
rule MB_172f04d0
{
    meta:
        description = "Auto-generated rule for PhantomCard"
        author = "MB-Collector"
        date = "2025-10-20T11:45:06.890575"
        sha256 = "172f04d094513ddfa0790008d79a2ddb3961a3317574a9b00dc8cf931b6b4016"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
