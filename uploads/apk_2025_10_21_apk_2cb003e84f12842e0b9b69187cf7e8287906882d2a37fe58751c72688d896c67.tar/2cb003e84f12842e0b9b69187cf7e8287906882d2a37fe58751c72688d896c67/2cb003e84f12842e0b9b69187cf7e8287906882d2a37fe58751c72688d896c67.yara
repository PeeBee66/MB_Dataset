
rule MB_2cb003e8
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-20T11:31:55.910500"
        sha256 = "2cb003e84f12842e0b9b69187cf7e8287906882d2a37fe58751c72688d896c67"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
