
rule MB_ad80d55e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-04T23:00:14.705918"
        sha256 = "ad80d55e20df318c575950e4d1c00b40a8ed78baadd4f6b5c701b28f77f551de"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
