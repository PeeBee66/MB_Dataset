
rule MB_4430b9f5
{
    meta:
        description = "Auto-generated rule for GlassWorm"
        author = "MB-Collector"
        date = "2026-03-25T23:01:13.316471"
        sha256 = "4430b9f555dfca96555698de32fecd0fd1e099c3f4690c13fb169f4c8972ce9d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
