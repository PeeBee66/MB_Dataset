
rule MB_3854c5a7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-06T23:00:30.036005"
        sha256 = "3854c5a7c3c1bf1eb2662d1178365053d356e2160a5dd82eaf9da4a1faa29639"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
