
rule MB_09eb8749
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:01:06.191119"
        sha256 = "09eb87493c014406a0d83996a8b1894da5257fd6166921878a9bbd42b1e9390e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
