
rule MB_5f6d901c
{
    meta:
        description = "Auto-generated rule for Datzbro"
        author = "MB-Collector"
        date = "2026-03-24T23:00:29.394012"
        sha256 = "5f6d901c7626694b8e0e37e572a375488980cd240782d9a5e82f4c463a9b098a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
