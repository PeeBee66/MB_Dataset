
rule MB_6ab8169b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-05T23:00:25.012305"
        sha256 = "6ab8169b26559ae475f6a4f4eb34cd9efb5a655fc4f3b6b7470887aa22c86345"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
