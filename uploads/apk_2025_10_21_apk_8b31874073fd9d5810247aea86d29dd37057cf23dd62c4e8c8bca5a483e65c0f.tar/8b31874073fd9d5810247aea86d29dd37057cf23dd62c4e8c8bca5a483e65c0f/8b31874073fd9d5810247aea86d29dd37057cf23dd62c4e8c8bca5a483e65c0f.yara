
rule MB_8b318740
{
    meta:
        description = "Auto-generated rule for BingoMod"
        author = "MB-Collector"
        date = "2025-10-20T11:39:38.784880"
        sha256 = "8b31874073fd9d5810247aea86d29dd37057cf23dd62c4e8c8bca5a483e65c0f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
