
rule MB_b9349454
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:01:38.362423"
        sha256 = "b93494549d589123455cd244d75765df29fdaf12b29f3faa4a16483d702a435f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
