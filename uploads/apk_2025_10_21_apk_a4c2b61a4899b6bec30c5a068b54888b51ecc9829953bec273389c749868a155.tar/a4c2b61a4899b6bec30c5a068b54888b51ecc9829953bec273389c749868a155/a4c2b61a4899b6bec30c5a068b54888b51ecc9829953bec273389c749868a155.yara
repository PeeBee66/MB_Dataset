
rule MB_a4c2b61a
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2025-10-20T11:20:38.408671"
        sha256 = "a4c2b61a4899b6bec30c5a068b54888b51ecc9829953bec273389c749868a155"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
