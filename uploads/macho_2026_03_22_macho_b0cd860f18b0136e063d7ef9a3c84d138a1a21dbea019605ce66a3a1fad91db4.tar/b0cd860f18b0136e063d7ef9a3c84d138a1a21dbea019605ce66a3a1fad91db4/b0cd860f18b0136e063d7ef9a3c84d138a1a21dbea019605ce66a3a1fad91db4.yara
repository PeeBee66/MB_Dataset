
rule MB_b0cd860f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-21T23:00:49.010028"
        sha256 = "b0cd860f18b0136e063d7ef9a3c84d138a1a21dbea019605ce66a3a1fad91db4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
