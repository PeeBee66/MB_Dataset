
rule MB_d478498d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:01.941240"
        sha256 = "d478498df797145c4b28bf63203dcb35726d77ce5e7559f2d6b83fb49bc809a7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
