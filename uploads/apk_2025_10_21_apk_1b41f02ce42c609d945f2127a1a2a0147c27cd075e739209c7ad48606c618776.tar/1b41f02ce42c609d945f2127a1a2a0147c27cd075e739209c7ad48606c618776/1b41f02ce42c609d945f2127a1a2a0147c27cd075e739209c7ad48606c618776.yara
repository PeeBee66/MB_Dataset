
rule MB_1b41f02c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:27.185399"
        sha256 = "1b41f02ce42c609d945f2127a1a2a0147c27cd075e739209c7ad48606c618776"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
