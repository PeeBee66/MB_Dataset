
rule MB_49c53b68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:29.413598"
        sha256 = "49c53b68494dd85d52f7657351eaaf696d10b7b900ca5d70eea73dfa2b8e0739"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
