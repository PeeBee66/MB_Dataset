
rule MB_5cb74f47
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:01:23.622271"
        sha256 = "5cb74f477ad66e31792f3348f0901e7ba273c54d8cd3518ceeb6c041d05638ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
