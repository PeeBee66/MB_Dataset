
rule MB_5610820e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:39.938231"
        sha256 = "5610820ebd39cc4891d91d5392891748700741935358fa176b056badf97f4880"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
