
rule MB_0210041f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:17.546364"
        sha256 = "0210041fc15cd7172b7e2901d1a65bba37d2966bd52debbd09ce40066942e85c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
