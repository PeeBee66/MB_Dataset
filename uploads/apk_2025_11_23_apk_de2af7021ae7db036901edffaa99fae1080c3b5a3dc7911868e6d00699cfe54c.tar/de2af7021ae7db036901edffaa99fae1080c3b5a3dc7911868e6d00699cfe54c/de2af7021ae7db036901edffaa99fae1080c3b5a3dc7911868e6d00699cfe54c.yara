
rule MB_de2af702
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-22T23:01:00.095313"
        sha256 = "de2af7021ae7db036901edffaa99fae1080c3b5a3dc7911868e6d00699cfe54c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
