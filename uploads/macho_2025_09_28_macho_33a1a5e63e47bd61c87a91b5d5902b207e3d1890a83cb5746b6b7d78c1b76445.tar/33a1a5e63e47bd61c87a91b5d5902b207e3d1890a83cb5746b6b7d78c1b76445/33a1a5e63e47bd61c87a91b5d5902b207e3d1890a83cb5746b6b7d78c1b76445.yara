
rule MB_33a1a5e6
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:00:35.362427"
        sha256 = "33a1a5e63e47bd61c87a91b5d5902b207e3d1890a83cb5746b6b7d78c1b76445"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
