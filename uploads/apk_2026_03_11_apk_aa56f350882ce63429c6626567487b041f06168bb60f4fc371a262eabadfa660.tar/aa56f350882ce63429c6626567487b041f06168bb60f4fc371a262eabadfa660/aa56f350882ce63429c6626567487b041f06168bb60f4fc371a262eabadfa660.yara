
rule MB_aa56f350
{
    meta:
        description = "Auto-generated rule for CoinMiner"
        author = "MB-Collector"
        date = "2026-03-10T23:00:41.708374"
        sha256 = "aa56f350882ce63429c6626567487b041f06168bb60f4fc371a262eabadfa660"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
