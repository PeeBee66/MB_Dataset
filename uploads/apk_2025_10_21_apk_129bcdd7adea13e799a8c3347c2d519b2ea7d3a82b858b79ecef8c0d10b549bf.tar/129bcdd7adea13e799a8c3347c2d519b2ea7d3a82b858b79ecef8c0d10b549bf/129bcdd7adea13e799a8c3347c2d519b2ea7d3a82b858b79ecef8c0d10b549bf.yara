
rule MB_129bcdd7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:19:05.017655"
        sha256 = "129bcdd7adea13e799a8c3347c2d519b2ea7d3a82b858b79ecef8c0d10b549bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
