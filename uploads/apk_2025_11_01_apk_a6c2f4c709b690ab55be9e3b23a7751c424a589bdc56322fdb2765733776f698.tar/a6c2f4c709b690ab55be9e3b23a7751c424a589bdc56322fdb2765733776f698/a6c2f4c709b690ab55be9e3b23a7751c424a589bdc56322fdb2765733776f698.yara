
rule MB_a6c2f4c7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:00:49.181422"
        sha256 = "a6c2f4c709b690ab55be9e3b23a7751c424a589bdc56322fdb2765733776f698"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
