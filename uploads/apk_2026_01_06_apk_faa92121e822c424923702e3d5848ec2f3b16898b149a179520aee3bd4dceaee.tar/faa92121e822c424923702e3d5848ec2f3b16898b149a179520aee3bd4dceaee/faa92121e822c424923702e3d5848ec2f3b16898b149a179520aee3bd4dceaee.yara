
rule MB_faa92121
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-05T23:00:11.876606"
        sha256 = "faa92121e822c424923702e3d5848ec2f3b16898b149a179520aee3bd4dceaee"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
