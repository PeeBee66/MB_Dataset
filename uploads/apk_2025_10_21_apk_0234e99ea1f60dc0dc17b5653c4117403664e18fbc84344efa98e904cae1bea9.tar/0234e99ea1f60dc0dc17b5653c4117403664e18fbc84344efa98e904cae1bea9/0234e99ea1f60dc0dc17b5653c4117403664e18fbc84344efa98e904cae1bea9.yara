
rule MB_0234e99e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:00:04.159371"
        sha256 = "0234e99ea1f60dc0dc17b5653c4117403664e18fbc84344efa98e904cae1bea9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
