
rule MB_1fc3ba39
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-01T23:00:40.358693"
        sha256 = "1fc3ba39f0ce8109bcb4f42441250df5e9c601744b738a2e7c40d612cd29fec3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
