
rule MB_134327fa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-13T23:00:16.841859"
        sha256 = "134327faf84fd493b16d027af9958fa93fc1129b6053c5eb0f372ea518691138"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
