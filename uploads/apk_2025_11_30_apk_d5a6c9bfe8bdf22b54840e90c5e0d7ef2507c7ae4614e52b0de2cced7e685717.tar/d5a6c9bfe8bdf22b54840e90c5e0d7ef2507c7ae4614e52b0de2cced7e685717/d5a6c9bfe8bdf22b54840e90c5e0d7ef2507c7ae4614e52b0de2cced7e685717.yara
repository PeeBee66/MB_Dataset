
rule MB_d5a6c9bf
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:33.186115"
        sha256 = "d5a6c9bfe8bdf22b54840e90c5e0d7ef2507c7ae4614e52b0de2cced7e685717"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
