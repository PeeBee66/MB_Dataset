
rule MB_408cfa70
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-31T23:06:11.181814"
        sha256 = "408cfa7080df7b1a81c6a219ef0c3a563af7a3d690cff96afa02333a58f40f05"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
