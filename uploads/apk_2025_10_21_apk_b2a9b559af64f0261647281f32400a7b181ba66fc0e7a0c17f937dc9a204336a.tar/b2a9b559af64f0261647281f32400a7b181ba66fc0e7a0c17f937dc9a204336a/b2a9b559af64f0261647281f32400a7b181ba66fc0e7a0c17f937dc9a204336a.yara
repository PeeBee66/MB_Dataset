
rule MB_b2a9b559
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:27:15.603276"
        sha256 = "b2a9b559af64f0261647281f32400a7b181ba66fc0e7a0c17f937dc9a204336a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
