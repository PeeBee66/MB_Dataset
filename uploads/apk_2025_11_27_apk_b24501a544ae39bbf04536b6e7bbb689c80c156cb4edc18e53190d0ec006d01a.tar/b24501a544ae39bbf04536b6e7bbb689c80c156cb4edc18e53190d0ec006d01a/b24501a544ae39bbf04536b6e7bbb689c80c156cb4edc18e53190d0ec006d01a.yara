
rule MB_b24501a5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:01:15.838782"
        sha256 = "b24501a544ae39bbf04536b6e7bbb689c80c156cb4edc18e53190d0ec006d01a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
