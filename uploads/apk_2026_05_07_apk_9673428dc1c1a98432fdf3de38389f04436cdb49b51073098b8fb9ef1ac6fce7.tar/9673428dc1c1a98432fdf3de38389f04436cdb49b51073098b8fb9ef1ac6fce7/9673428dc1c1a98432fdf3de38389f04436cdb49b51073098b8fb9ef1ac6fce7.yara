
rule MB_9673428d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:01:25.410639"
        sha256 = "9673428dc1c1a98432fdf3de38389f04436cdb49b51073098b8fb9ef1ac6fce7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
