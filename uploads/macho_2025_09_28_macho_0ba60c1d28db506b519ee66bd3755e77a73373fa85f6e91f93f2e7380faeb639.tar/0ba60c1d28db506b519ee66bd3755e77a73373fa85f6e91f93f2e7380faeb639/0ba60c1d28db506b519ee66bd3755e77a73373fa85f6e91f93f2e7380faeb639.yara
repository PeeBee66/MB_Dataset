
rule MB_0ba60c1d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:27.046806"
        sha256 = "0ba60c1d28db506b519ee66bd3755e77a73373fa85f6e91f93f2e7380faeb639"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
