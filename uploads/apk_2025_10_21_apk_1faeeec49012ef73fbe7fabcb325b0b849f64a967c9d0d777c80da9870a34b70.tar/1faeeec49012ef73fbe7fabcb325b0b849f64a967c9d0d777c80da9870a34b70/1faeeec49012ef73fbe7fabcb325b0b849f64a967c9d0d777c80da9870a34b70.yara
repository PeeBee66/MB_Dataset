
rule MB_1faeeec4
{
    meta:
        description = "Auto-generated rule for BingoMod"
        author = "MB-Collector"
        date = "2025-10-20T11:39:03.052364"
        sha256 = "1faeeec49012ef73fbe7fabcb325b0b849f64a967c9d0d777c80da9870a34b70"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
