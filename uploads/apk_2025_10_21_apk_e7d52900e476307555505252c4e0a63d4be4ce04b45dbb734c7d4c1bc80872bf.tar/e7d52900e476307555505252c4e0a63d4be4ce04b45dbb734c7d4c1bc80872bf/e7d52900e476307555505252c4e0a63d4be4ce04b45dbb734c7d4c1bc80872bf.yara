
rule MB_e7d52900
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:32.133430"
        sha256 = "e7d52900e476307555505252c4e0a63d4be4ce04b45dbb734c7d4c1bc80872bf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
