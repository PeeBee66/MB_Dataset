
rule MB_9bc2157f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:01:06.257476"
        sha256 = "9bc2157f451274b3e3c005e4b643a5b6637dc5878b6d20952d9c3f561fa9b067"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
