
rule MB_cf37a786
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:38.974796"
        sha256 = "cf37a786dd68d0c8100c05b4c3c38481d463fadeadd0a40bf47b4e198c088e9c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
