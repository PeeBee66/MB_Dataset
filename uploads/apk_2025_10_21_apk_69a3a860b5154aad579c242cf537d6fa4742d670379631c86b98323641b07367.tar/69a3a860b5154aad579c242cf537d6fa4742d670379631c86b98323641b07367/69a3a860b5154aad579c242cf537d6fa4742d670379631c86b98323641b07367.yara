
rule MB_69a3a860
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:34:01.141578"
        sha256 = "69a3a860b5154aad579c242cf537d6fa4742d670379631c86b98323641b07367"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
