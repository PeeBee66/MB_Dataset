
rule MB_557c02b5
{
    meta:
        description = "Auto-generated rule for PixRevolution"
        author = "MB-Collector"
        date = "2026-05-31T00:00:19.214704"
        sha256 = "557c02b5e9ca8103e6ad5413df1b447fae5c9ce086a0b5330bf9c79a578585df"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
