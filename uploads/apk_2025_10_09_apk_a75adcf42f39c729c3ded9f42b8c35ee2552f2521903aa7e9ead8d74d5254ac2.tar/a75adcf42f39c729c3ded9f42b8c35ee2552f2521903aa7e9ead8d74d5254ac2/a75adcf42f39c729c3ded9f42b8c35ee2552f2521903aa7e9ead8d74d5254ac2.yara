
rule MB_a75adcf4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-08T23:00:15.718326"
        sha256 = "a75adcf42f39c729c3ded9f42b8c35ee2552f2521903aa7e9ead8d74d5254ac2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
