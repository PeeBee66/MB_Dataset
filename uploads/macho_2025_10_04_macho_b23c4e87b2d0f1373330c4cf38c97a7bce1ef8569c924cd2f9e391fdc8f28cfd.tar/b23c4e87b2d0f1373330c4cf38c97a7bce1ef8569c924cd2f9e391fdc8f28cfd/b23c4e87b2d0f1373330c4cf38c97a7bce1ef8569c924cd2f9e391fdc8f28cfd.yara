
rule MB_b23c4e87
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:17:06.809490"
        sha256 = "b23c4e87b2d0f1373330c4cf38c97a7bce1ef8569c924cd2f9e391fdc8f28cfd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
