
rule MB_4845bbe3
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-18T23:00:21.997222"
        sha256 = "4845bbe3b1f17da3783db71b6a471b9dc073c8459fe2981004fbbcd70144ec01"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
