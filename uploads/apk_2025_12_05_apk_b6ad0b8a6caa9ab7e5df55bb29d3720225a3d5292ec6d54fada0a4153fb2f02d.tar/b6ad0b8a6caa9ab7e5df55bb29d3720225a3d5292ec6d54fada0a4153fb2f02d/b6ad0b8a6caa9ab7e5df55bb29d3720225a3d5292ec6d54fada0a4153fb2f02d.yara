
rule MB_b6ad0b8a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-04T23:00:52.036197"
        sha256 = "b6ad0b8a6caa9ab7e5df55bb29d3720225a3d5292ec6d54fada0a4153fb2f02d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
