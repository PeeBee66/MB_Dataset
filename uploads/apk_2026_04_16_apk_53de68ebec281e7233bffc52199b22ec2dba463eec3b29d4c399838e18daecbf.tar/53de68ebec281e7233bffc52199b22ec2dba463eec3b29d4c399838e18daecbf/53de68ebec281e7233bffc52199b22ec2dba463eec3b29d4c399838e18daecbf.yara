
rule MB_53de68eb
{
    meta:
        description = "Auto-generated rule for Mirax"
        author = "MB-Collector"
        date = "2026-04-16T00:02:36.481037"
        sha256 = "53de68ebec281e7233bffc52199b22ec2dba463eec3b29d4c399838e18daecbf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
