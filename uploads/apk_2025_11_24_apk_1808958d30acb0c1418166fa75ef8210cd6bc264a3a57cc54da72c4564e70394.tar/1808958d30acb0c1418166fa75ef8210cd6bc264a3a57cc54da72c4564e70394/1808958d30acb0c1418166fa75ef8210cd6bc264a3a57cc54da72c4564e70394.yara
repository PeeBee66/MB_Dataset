
rule MB_1808958d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-23T23:00:26.642739"
        sha256 = "1808958d30acb0c1418166fa75ef8210cd6bc264a3a57cc54da72c4564e70394"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
