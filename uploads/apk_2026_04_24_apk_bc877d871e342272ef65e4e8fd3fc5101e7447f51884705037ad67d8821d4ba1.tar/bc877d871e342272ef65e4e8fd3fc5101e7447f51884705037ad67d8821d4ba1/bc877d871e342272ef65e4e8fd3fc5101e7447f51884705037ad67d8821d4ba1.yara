
rule MB_bc877d87
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-24T00:02:10.253194"
        sha256 = "bc877d871e342272ef65e4e8fd3fc5101e7447f51884705037ad67d8821d4ba1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
