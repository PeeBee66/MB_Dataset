
rule MB_f136736a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-25T00:00:41.144032"
        sha256 = "f136736a6aff1a46fbd39cc92e454ae76a1bce2812e159dcb50a7e71b6b386fe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
