
rule MB_f4bbe4ba
{
    meta:
        description = "Auto-generated rule for TangleBot"
        author = "MB-Collector"
        date = "2025-10-20T11:15:38.693674"
        sha256 = "f4bbe4ba4d356d58894e479edf628ece3e3928d10e7c699d3cba0ce2ecf6613b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
