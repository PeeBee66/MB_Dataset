
rule MB_231e430c
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-28T00:01:14.291866"
        sha256 = "231e430c1239254963e859e853070f5526dc36757ce1eddaf24bd8fa5f6376a7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
