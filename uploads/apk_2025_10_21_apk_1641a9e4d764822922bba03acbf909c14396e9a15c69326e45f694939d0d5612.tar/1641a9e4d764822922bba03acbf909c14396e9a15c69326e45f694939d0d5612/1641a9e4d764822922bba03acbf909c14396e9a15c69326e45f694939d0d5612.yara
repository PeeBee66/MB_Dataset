
rule MB_1641a9e4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:03.228160"
        sha256 = "1641a9e4d764822922bba03acbf909c14396e9a15c69326e45f694939d0d5612"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
