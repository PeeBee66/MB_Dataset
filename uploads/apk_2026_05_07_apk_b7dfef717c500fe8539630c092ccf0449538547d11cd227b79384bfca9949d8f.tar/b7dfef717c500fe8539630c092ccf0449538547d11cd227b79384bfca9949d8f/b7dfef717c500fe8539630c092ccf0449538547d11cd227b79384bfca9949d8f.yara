
rule MB_b7dfef71
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:02:17.986786"
        sha256 = "b7dfef717c500fe8539630c092ccf0449538547d11cd227b79384bfca9949d8f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
