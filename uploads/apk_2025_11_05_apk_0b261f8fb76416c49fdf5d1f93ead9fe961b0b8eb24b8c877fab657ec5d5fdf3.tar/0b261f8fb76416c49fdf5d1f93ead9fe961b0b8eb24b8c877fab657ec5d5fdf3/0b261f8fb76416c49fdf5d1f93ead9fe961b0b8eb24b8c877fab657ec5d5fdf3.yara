
rule MB_0b261f8f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-04T23:00:25.231495"
        sha256 = "0b261f8fb76416c49fdf5d1f93ead9fe961b0b8eb24b8c877fab657ec5d5fdf3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
