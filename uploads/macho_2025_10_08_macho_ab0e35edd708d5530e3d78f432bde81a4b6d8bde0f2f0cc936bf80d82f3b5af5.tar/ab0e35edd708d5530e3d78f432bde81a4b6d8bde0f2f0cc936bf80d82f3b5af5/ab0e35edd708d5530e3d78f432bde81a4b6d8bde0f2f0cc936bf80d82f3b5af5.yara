
rule MB_ab0e35ed
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:26.232199"
        sha256 = "ab0e35edd708d5530e3d78f432bde81a4b6d8bde0f2f0cc936bf80d82f3b5af5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
