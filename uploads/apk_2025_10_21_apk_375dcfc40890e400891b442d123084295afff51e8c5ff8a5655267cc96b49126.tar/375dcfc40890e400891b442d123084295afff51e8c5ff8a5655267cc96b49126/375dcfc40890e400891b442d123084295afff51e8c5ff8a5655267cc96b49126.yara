
rule MB_375dcfc4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:36:56.769103"
        sha256 = "375dcfc40890e400891b442d123084295afff51e8c5ff8a5655267cc96b49126"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
