
rule MB_7ad1457e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:48:23.917172"
        sha256 = "7ad1457efca9adc03d4dcadd1085c683a4bde56fc9b1718723d3557d2b4c4cc5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
