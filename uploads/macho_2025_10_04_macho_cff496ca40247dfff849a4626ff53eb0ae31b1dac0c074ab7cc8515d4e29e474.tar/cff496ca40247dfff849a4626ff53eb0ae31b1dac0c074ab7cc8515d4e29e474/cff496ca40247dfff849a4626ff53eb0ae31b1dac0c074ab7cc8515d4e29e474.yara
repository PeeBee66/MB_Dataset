
rule MB_cff496ca
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-04T01:15:42.514372"
        sha256 = "cff496ca40247dfff849a4626ff53eb0ae31b1dac0c074ab7cc8515d4e29e474"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
