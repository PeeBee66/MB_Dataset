
rule MB_744a9558
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:09:42.194719"
        sha256 = "744a9558f546a0061a035c90a85d63c3f3b0e4223b9f092c61263435026ef642"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
