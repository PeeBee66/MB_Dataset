
rule MB_faab9174
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-11T23:00:30.792994"
        sha256 = "faab917444988b9a2e8d5d5bc06a0423c53718f92cbb8840cc6632f464c89130"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
