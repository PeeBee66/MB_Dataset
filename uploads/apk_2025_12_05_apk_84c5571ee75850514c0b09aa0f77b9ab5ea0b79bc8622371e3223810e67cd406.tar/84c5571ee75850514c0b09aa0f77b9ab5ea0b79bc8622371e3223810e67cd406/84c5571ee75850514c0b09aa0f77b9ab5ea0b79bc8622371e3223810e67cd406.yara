
rule MB_84c5571e
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-04T23:00:28.759788"
        sha256 = "84c5571ee75850514c0b09aa0f77b9ab5ea0b79bc8622371e3223810e67cd406"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
