
rule MB_78878d33
{
    meta:
        description = "Auto-generated rule for ClayRat"
        author = "MB-Collector"
        date = "2026-03-24T23:00:46.463140"
        sha256 = "78878d33b2b48747694ce2fdb24e896cd9ba027b1d66c66c107cf415ed46b89b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
