
rule MB_6752bb18
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-12T23:00:36.178456"
        sha256 = "6752bb18b980918e9e566e9abdb4ed5743cb286d489ac4503ba292a583197e7a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
