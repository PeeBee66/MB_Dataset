
rule MB_549ebc6a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:00:33.732321"
        sha256 = "549ebc6a6c62759f6fd86c207c4ede9daf9de431dd6eac98baef62a5fb440710"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
