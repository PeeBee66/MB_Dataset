
rule MB_6a1e4678
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:57.631094"
        sha256 = "6a1e4678ca325b354571cf4893fb3c429cc52068f979737974f49c2030710cdd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
