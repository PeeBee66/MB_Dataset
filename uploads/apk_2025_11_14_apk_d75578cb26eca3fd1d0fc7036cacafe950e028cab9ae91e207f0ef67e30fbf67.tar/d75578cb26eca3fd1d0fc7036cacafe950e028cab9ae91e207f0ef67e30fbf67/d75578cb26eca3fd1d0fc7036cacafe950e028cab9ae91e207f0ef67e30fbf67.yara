
rule MB_d75578cb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:29.953195"
        sha256 = "d75578cb26eca3fd1d0fc7036cacafe950e028cab9ae91e207f0ef67e30fbf67"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
