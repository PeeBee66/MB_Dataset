
rule MB_657881e9
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:02:13.957413"
        sha256 = "657881e96def3e69a401f79c678edff27c3db4db74ba802fb8989ae466f73cc9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
