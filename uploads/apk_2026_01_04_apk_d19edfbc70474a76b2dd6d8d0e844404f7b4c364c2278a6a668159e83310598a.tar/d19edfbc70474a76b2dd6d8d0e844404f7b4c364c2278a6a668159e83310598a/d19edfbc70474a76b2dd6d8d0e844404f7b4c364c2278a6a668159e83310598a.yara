
rule MB_d19edfbc
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-01-03T23:00:12.877319"
        sha256 = "d19edfbc70474a76b2dd6d8d0e844404f7b4c364c2278a6a668159e83310598a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
