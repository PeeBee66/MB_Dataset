
rule MB_c05e6843
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:25.144467"
        sha256 = "c05e684307457bb8c818228cd18569c649ec045a65f08b03a289cafdaf77f273"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
