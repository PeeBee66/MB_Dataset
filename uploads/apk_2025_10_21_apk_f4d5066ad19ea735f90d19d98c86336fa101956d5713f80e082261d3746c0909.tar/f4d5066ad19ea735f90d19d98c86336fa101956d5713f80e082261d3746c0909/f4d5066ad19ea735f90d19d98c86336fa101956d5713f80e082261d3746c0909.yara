
rule MB_f4d5066a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:16:18.336849"
        sha256 = "f4d5066ad19ea735f90d19d98c86336fa101956d5713f80e082261d3746c0909"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
