
rule MB_3522b20d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:01:01.185474"
        sha256 = "3522b20d6461dd3bcfcaa85c30e810f515045331116f9ff92c6555773342c3f5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
