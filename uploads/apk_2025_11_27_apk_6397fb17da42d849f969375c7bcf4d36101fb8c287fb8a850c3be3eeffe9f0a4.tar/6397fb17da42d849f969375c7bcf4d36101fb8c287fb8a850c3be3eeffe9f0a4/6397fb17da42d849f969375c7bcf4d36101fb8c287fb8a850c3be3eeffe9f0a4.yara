
rule MB_6397fb17
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-26T23:00:20.574561"
        sha256 = "6397fb17da42d849f969375c7bcf4d36101fb8c287fb8a850c3be3eeffe9f0a4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
