
rule MB_f702f13a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:05:58.313310"
        sha256 = "f702f13a69bc4af27555d3d980f8436bfa2d462a766a57e5c5ee238216bace66"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
