
rule MB_b196bbed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:33.101436"
        sha256 = "b196bbedf6de1b42b75374858d34d3adbed6c9679c901f1e6d4c74659636e70c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
