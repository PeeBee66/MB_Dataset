
rule MB_0619168a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-07T23:00:24.956440"
        sha256 = "0619168a8df6dd350052ca3a578abe15da0f2177e65acea55f44b5b59ed5f1c8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
