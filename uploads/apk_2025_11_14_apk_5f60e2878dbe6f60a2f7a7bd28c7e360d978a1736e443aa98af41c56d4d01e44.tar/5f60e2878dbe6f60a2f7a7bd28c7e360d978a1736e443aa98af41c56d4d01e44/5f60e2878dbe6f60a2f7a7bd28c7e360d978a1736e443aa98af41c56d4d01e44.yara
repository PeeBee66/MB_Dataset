
rule MB_5f60e287
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:00:39.335120"
        sha256 = "5f60e2878dbe6f60a2f7a7bd28c7e360d978a1736e443aa98af41c56d4d01e44"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
