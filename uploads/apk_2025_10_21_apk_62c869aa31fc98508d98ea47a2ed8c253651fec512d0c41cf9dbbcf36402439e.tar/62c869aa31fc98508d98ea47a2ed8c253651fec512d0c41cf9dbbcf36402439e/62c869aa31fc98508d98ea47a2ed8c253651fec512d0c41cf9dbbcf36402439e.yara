
rule MB_62c869aa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:13:47.689185"
        sha256 = "62c869aa31fc98508d98ea47a2ed8c253651fec512d0c41cf9dbbcf36402439e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
