
rule MB_b61a8614
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:03:18.321383"
        sha256 = "b61a86140af651a2c8659b1449fe0bdb9f8d7b7a44dd1c39a27209fd6f4977e8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
