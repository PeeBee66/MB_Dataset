
rule MB_41c84420
{
    meta:
        description = "Auto-generated rule for BankBot"
        author = "MB-Collector"
        date = "2025-10-20T11:49:06.055643"
        sha256 = "41c84420a3c42f854dab18df1edf7ef283e60a2bf5a6a9b608bc6c7a1cf8d41e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
