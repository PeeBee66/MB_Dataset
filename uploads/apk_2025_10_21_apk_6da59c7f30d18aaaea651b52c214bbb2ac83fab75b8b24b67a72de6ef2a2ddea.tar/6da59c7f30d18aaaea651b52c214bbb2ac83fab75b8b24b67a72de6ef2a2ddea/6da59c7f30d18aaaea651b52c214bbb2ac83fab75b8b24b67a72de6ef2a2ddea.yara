
rule MB_6da59c7f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:14:53.017378"
        sha256 = "6da59c7f30d18aaaea651b52c214bbb2ac83fab75b8b24b67a72de6ef2a2ddea"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
