
rule MB_41a9c5a2
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:01:11.702232"
        sha256 = "41a9c5a298128b8c000227443ed3c1bf4e6ea17c4c8b91496ca7674ca62b08d7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
