
rule MB_ffe908b9
{
    meta:
        description = "Auto-generated rule for ClayRAT"
        author = "MB-Collector"
        date = "2025-11-07T23:00:47.034333"
        sha256 = "ffe908b9697f064fab126514d6830ecdf7687557035d9940230086b13df6d8f2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
