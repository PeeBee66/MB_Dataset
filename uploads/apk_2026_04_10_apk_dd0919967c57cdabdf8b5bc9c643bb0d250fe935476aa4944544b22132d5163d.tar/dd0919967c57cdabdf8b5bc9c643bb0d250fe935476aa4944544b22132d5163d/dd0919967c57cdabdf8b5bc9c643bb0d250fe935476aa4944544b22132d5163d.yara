
rule MB_dd091996
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-10T00:00:21.081161"
        sha256 = "dd0919967c57cdabdf8b5bc9c643bb0d250fe935476aa4944544b22132d5163d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
