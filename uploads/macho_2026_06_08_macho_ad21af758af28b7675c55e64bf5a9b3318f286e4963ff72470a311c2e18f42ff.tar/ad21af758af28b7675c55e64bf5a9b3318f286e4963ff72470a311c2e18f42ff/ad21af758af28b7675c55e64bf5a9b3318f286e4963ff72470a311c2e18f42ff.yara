
rule MB_ad21af75
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-08T00:00:21.788286"
        sha256 = "ad21af758af28b7675c55e64bf5a9b3318f286e4963ff72470a311c2e18f42ff"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
