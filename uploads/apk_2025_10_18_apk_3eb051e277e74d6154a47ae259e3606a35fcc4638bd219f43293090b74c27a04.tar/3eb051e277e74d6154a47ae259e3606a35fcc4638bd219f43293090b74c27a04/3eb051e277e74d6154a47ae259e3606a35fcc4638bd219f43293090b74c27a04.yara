
rule MB_3eb051e2
{
    meta:
        description = "Auto-generated rule for Coper"
        author = "MB-Collector"
        date = "2025-10-17T23:00:14.287039"
        sha256 = "3eb051e277e74d6154a47ae259e3606a35fcc4638bd219f43293090b74c27a04"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
