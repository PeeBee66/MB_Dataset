
rule MB_39901ffa
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-16T00:01:04.174135"
        sha256 = "39901ffa746a6f6ac3de2b36d9e61e0d60b221f4d9510436fd3cb3d2d7362130"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
