
rule MB_2e68a33c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:07:31.852319"
        sha256 = "2e68a33c37c5ce8d0c1ccfe44868c2cd0931ccc41d3bc01784f2f02e7e5820c1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
