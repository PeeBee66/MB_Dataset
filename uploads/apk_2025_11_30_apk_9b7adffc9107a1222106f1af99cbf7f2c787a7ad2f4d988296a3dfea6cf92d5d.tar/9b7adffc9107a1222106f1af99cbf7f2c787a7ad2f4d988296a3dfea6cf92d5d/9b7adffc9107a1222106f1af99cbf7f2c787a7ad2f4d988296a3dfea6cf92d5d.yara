
rule MB_9b7adffc
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-29T23:00:16.323724"
        sha256 = "9b7adffc9107a1222106f1af99cbf7f2c787a7ad2f4d988296a3dfea6cf92d5d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
