
rule MB_ec2ce22a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-12T23:00:52.071810"
        sha256 = "ec2ce22af9b9215d78bf3ea71539017b73c765e0e2d9275cf51088fadc055c62"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
