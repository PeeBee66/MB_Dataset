
rule MB_60d38028
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:24.254769"
        sha256 = "60d380287c78391ef9d82206145a36ae47b5c648b1a712581c6526b0e7810100"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
