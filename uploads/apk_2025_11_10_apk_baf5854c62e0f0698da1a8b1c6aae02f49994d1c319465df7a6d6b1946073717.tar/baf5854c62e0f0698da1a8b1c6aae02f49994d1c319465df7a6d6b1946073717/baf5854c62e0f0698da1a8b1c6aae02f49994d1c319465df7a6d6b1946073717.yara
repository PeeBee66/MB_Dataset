
rule MB_baf5854c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-09T23:00:13.196658"
        sha256 = "baf5854c62e0f0698da1a8b1c6aae02f49994d1c319465df7a6d6b1946073717"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
