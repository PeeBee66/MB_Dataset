
rule MB_82ffd90e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:02:05.459178"
        sha256 = "82ffd90e4ab12c4f3e35cc19bbb3591c922ca97c0b5b6c07b3f66d82056ade30"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
