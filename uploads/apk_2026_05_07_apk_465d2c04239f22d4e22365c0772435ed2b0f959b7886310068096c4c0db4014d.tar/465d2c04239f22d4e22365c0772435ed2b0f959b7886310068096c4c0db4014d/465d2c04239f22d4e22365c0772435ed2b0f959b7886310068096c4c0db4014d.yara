
rule MB_465d2c04
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:04:22.080736"
        sha256 = "465d2c04239f22d4e22365c0772435ed2b0f959b7886310068096c4c0db4014d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
