
rule MB_79c3de87
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-08T23:00:43.164995"
        sha256 = "79c3de875a609b3109f51b8d0bde1a25da7013c5a78333b415551fd6c1eb24a6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
