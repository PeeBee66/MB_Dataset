
rule MB_e9a90d6f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-01T23:00:13.846283"
        sha256 = "e9a90d6f80b6bfadae40c0c044c696d06b5eeecc9d2274f44cb9d0e62b185ac5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
