
rule MB_2f7e0258
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:23.411160"
        sha256 = "2f7e0258caafa112284eb8977d61a3a78351ce96336bd9afb03cb263f2eff51d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
