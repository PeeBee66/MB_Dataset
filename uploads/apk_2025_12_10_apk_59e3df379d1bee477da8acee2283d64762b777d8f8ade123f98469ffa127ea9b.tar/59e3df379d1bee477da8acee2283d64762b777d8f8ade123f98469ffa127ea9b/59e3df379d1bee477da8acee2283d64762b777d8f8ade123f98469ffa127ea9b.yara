
rule MB_59e3df37
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-09T23:00:19.315995"
        sha256 = "59e3df379d1bee477da8acee2283d64762b777d8f8ade123f98469ffa127ea9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
