
rule MB_0f741d72
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-25T23:00:22.871852"
        sha256 = "0f741d7266ef1c8a3c18854d6ddfbade4d14129f88213ef9d27aeae7e8c6ff9d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
