
rule MB_614a2380
{
    meta:
        description = "Auto-generated rule for IRATA"
        author = "MB-Collector"
        date = "2025-10-20T11:38:00.246752"
        sha256 = "614a23807e2a423323bbd768b6eaaa95005c3f60bc5450bd7640d0f0013dd75a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
