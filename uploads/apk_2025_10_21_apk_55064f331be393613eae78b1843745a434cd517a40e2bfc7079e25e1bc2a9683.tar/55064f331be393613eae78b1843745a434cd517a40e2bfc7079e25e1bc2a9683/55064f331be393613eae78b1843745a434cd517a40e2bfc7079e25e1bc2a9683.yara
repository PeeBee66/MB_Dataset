
rule MB_55064f33
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:19:17.159893"
        sha256 = "55064f331be393613eae78b1843745a434cd517a40e2bfc7079e25e1bc2a9683"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
