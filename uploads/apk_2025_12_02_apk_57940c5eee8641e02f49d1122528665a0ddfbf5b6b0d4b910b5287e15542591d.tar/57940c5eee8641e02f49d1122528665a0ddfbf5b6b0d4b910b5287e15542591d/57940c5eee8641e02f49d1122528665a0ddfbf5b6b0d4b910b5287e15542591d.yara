
rule MB_57940c5e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-01T23:01:05.079991"
        sha256 = "57940c5eee8641e02f49d1122528665a0ddfbf5b6b0d4b910b5287e15542591d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
