
rule MB_c4614cd0
{
    meta:
        description = "Auto-generated rule for GlassWorm"
        author = "MB-Collector"
        date = "2026-03-25T23:01:23.049839"
        sha256 = "c4614cd001884175ff092c2e2c2c189e78d49e85551e507cdc5cfb16b631f2fc"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
