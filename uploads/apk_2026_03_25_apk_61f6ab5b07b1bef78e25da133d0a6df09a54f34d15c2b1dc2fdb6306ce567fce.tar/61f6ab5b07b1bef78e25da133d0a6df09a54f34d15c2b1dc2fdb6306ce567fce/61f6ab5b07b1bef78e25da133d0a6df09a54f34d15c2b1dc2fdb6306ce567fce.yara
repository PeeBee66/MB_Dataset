
rule MB_61f6ab5b
{
    meta:
        description = "Auto-generated rule for Metasploit"
        author = "MB-Collector"
        date = "2026-03-24T23:00:18.857390"
        sha256 = "61f6ab5b07b1bef78e25da133d0a6df09a54f34d15c2b1dc2fdb6306ce567fce"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
