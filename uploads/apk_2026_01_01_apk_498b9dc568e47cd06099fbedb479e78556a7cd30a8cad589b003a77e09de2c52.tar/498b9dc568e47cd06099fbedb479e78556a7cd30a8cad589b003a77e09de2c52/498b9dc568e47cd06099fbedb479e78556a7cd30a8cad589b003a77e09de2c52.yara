
rule MB_498b9dc5
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-12-31T23:00:27.385031"
        sha256 = "498b9dc568e47cd06099fbedb479e78556a7cd30a8cad589b003a77e09de2c52"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
