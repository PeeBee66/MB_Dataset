
rule MB_bbb41ec3
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-03-31T23:00:13.341665"
        sha256 = "bbb41ec382738c0ee5b94d023f023209928ca98893f146a8cfdaa608afe7b4e6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
