
rule MB_4e2c0396
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2026-06-18T00:01:33.567640"
        sha256 = "4e2c0396e96e3e5d763fdcba313ace876ca45333c7683a087698768ff2ea277f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
