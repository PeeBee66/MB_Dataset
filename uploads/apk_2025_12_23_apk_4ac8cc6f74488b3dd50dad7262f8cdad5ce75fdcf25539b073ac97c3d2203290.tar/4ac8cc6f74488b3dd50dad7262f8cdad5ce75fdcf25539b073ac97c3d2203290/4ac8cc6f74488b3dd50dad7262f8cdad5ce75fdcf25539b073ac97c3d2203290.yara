
rule MB_4ac8cc6f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-22T23:00:24.438976"
        sha256 = "4ac8cc6f74488b3dd50dad7262f8cdad5ce75fdcf25539b073ac97c3d2203290"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
