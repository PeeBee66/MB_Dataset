
rule MB_7f69d97e
{
    meta:
        description = "Auto-generated rule for LazarusStealer"
        author = "MB-Collector"
        date = "2026-03-24T23:00:42.195726"
        sha256 = "7f69d97eb87360953ececb7d8cce0bfb175910b74fd9f139932086b260aa07b3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
