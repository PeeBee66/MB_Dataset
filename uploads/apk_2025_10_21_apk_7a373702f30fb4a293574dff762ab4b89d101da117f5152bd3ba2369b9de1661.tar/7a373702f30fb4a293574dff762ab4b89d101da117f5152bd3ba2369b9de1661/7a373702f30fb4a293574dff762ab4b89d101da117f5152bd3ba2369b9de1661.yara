
rule MB_7a373702
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:48:31.802021"
        sha256 = "7a373702f30fb4a293574dff762ab4b89d101da117f5152bd3ba2369b9de1661"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
