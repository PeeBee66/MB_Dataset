
rule MB_2f595b30
{
    meta:
        description = "Auto-generated rule for MoqHao"
        author = "MB-Collector"
        date = "2026-03-24T23:00:37.716436"
        sha256 = "2f595b306756f39b0d525b19d5f5c1d50a5e6761ea049a63a390ec3e6709a2ba"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
