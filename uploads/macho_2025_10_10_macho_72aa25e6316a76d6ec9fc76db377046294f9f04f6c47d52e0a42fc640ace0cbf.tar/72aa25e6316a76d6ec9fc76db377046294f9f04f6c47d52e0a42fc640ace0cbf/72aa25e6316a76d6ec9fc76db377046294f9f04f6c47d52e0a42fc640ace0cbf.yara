
rule MB_72aa25e6
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:25.052276"
        sha256 = "72aa25e6316a76d6ec9fc76db377046294f9f04f6c47d52e0a42fc640ace0cbf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
