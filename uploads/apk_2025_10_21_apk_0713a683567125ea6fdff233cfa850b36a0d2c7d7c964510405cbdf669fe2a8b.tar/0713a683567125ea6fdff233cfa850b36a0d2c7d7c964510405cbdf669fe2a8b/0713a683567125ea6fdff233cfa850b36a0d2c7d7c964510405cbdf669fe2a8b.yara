
rule MB_0713a683
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2025-10-20T11:51:33.727338"
        sha256 = "0713a683567125ea6fdff233cfa850b36a0d2c7d7c964510405cbdf669fe2a8b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
