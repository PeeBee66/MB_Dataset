
rule MB_5ca83442
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-13T23:00:24.225370"
        sha256 = "5ca8344271951093b3b7cb5e6451648bbb7adc99ea970b2f7357888950d77a91"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
