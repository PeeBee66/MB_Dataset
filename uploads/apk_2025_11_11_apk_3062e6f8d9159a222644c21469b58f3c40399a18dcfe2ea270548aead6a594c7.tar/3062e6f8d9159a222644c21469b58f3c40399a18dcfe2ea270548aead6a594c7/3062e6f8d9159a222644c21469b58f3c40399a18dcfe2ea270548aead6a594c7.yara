
rule MB_3062e6f8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:00:43.206756"
        sha256 = "3062e6f8d9159a222644c21469b58f3c40399a18dcfe2ea270548aead6a594c7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
