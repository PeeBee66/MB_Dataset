
rule MB_0e7b445d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:05:02.788589"
        sha256 = "0e7b445d14584dbbab197cddc29ef90899863d003b2d1a7ea2910cf882ab75a1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
