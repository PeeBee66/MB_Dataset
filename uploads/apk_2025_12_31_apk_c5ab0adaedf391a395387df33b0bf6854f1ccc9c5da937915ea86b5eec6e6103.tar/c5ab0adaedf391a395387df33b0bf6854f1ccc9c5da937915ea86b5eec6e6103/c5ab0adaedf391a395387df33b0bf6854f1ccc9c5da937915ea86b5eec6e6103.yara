
rule MB_c5ab0ada
{
    meta:
        description = "Auto-generated rule for AndroRAT"
        author = "MB-Collector"
        date = "2025-12-30T23:00:34.430086"
        sha256 = "c5ab0adaedf391a395387df33b0bf6854f1ccc9c5da937915ea86b5eec6e6103"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
