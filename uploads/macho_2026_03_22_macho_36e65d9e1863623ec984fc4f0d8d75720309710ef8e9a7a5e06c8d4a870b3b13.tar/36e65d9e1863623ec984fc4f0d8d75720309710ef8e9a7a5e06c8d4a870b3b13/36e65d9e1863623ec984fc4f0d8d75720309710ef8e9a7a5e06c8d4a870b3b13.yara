
rule MB_36e65d9e
{
    meta:
        description = "Auto-generated rule for AzureHound"
        author = "MB-Collector"
        date = "2026-03-21T23:01:37.675561"
        sha256 = "36e65d9e1863623ec984fc4f0d8d75720309710ef8e9a7a5e06c8d4a870b3b13"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
