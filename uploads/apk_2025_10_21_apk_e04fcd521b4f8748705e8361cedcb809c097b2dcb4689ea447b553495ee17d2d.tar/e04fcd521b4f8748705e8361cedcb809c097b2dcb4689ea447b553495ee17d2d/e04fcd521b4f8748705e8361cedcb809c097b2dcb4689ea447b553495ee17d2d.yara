
rule MB_e04fcd52
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:54:15.484549"
        sha256 = "e04fcd521b4f8748705e8361cedcb809c097b2dcb4689ea447b553495ee17d2d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
