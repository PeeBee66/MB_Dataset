
rule MB_f701e109
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:03:57.239254"
        sha256 = "f701e10937b00d99c9642e472c5a2805d5ba4a9772a66c85eccf4a44dd7b4f13"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
