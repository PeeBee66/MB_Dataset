
rule MB_a8030b19
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-02-02T23:01:02.570880"
        sha256 = "a8030b195f685a2c1b3a5de807f769d38f87efff8bab8c5bfce5a6fabedcc477"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
