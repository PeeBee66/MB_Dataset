
rule MB_cda28906
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:15:08.411072"
        sha256 = "cda289064177a4e07f03221fda940bf31570fe9fed6d4759ec7ce346899f099c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
