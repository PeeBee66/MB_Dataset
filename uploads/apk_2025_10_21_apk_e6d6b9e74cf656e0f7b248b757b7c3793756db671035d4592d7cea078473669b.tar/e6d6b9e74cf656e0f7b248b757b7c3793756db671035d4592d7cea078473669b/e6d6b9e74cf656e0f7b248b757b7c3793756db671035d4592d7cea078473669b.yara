
rule MB_e6d6b9e7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:42:15.389368"
        sha256 = "e6d6b9e74cf656e0f7b248b757b7c3793756db671035d4592d7cea078473669b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
