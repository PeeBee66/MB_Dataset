
rule MB_7775d841
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-23T23:00:50.756478"
        sha256 = "7775d8411c836f15e525320a984c90941127e7101ded1af8bb5b1234d50ebaf5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
