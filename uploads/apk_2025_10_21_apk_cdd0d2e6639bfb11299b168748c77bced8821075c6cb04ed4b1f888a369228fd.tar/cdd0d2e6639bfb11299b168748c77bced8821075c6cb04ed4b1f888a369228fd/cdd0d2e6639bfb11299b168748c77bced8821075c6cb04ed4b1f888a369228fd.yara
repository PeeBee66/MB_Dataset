
rule MB_cdd0d2e6
{
    meta:
        description = "Auto-generated rule for Ahmyth"
        author = "MB-Collector"
        date = "2025-10-20T11:16:11.875465"
        sha256 = "cdd0d2e6639bfb11299b168748c77bced8821075c6cb04ed4b1f888a369228fd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
