
rule MB_2ef86ba4
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-06T23:01:07.167093"
        sha256 = "2ef86ba4e1a4ac37eea1e31ccbbee2bcfad127378a6e26d8c230fbaddc270ef2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
