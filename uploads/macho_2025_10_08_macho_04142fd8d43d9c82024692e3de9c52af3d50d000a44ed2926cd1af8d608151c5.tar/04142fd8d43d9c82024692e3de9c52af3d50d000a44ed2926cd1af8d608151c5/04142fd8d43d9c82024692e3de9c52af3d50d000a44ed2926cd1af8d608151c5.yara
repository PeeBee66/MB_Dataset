
rule MB_04142fd8
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:00:55.224881"
        sha256 = "04142fd8d43d9c82024692e3de9c52af3d50d000a44ed2926cd1af8d608151c5"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
