
rule MB_561edc0b
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:39.276983"
        sha256 = "561edc0b90ce0e3deb11e2d4aecca1e674702da328c2098852c7d11928df18cb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
