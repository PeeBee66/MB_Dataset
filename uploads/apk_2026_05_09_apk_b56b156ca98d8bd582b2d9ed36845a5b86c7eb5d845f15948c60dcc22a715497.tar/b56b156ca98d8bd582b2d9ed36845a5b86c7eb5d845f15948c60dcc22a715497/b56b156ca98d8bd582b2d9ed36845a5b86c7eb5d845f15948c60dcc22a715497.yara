
rule MB_b56b156c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-09T00:03:48.556546"
        sha256 = "b56b156ca98d8bd582b2d9ed36845a5b86c7eb5d845f15948c60dcc22a715497"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
