
rule MB_8c93845d
{
    meta:
        description = "Auto-generated rule for NGate"
        author = "MB-Collector"
        date = "2026-04-24T00:02:34.188873"
        sha256 = "8c93845d33f36a96a72deb5d0a07a9be93589461dd3bce8c87293d82d18459af"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
