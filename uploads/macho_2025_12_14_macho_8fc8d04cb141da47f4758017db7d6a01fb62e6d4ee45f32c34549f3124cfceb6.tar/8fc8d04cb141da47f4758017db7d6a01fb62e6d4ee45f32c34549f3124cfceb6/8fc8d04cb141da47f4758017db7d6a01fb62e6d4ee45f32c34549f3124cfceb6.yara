
rule MB_8fc8d04c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:01:08.176873"
        sha256 = "8fc8d04cb141da47f4758017db7d6a01fb62e6d4ee45f32c34549f3124cfceb6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
