
rule MB_5be4313d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:30:09.077139"
        sha256 = "5be4313db31d119aaa743ed95c23d925723d8aaccefcf0b00c7dfc2ec737b397"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
