
rule MB_1fa21501
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-06-19T00:00:14.293650"
        sha256 = "1fa2150192384a7abb27ad92295aa937efca1b2ac88dc802d3a68082d61c38e9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
