
rule MB_c0a22b66
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-02T23:00:33.128443"
        sha256 = "c0a22b664867fb8da671f6441260252bac8b7c8f97a61a622c150989bfdc92f4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
