
rule MB_76044f9d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-01-06T23:00:17.707392"
        sha256 = "76044f9de20943bae608b29a0f738a5406b4c108e2d402fbc3341af7e96e90a6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
