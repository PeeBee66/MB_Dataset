
rule MB_fe41e6c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:02:01.014232"
        sha256 = "fe41e6c1725f63582f022a17abe098e49338a78118a00ca87785b2fa0cf3dadf"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
