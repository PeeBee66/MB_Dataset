
rule MB_bd25016d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:05:38.465844"
        sha256 = "bd25016d44078d9c9841a8ed070c34af0145b8fd9f9860d3da71ec62670e16eb"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
