
rule MB_b350162d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:00:38.991342"
        sha256 = "b350162d83bb3fa1a5602679febf4179431d151f753346cde76f7456de1ddbee"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
