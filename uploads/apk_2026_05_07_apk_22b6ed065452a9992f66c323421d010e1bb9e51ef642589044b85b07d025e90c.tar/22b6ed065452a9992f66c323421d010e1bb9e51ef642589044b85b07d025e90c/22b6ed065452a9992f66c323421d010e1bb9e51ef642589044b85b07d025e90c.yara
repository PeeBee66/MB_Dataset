
rule MB_22b6ed06
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:00:33.894617"
        sha256 = "22b6ed065452a9992f66c323421d010e1bb9e51ef642589044b85b07d025e90c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
