
rule MB_9ab30c45
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T12:01:12.144035"
        sha256 = "9ab30c4570060861a6e987a75e28aeb2a2a6c91af8f7dbfd800bf149ebf0c004"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
