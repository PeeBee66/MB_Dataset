
rule MB_334f4374
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:27:49.472256"
        sha256 = "334f437452363ad5e58d84d13861521e6ce52d36232094a1db2f6a5229305372"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
