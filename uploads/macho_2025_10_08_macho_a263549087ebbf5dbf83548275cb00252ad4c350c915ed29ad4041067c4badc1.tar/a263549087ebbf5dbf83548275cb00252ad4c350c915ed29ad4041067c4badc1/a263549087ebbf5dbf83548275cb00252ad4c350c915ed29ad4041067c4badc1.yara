
rule MB_a2635490
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:04.812313"
        sha256 = "a263549087ebbf5dbf83548275cb00252ad4c350c915ed29ad4041067c4badc1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
