
rule MB_7c79f0c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:48.130827"
        sha256 = "7c79f0c52ae011a20ca07817482acfe6dd2eae9a00d8fe1666bbcc39b691b4b9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
