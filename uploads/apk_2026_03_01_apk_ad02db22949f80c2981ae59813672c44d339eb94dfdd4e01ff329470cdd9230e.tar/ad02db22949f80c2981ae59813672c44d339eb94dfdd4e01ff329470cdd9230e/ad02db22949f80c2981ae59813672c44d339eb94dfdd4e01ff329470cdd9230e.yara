
rule MB_ad02db22
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-02-28T23:00:37.607350"
        sha256 = "ad02db22949f80c2981ae59813672c44d339eb94dfdd4e01ff329470cdd9230e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
