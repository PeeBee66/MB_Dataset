
rule MB_5e7548ae
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-20T23:01:05.889871"
        sha256 = "5e7548aec911b788bec7ebf0557c93445b0c901b621e3cf2ecfb0da4b5a676a0"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
