
rule MB_5489c3f1
{
    meta:
        description = "Auto-generated rule for TrickMo"
        author = "MB-Collector"
        date = "2025-10-08T23:00:21.559602"
        sha256 = "5489c3f1f561e1f7fa68f7a6041fba8aed8f682095e1f50b07b4b91ac284e9bd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
