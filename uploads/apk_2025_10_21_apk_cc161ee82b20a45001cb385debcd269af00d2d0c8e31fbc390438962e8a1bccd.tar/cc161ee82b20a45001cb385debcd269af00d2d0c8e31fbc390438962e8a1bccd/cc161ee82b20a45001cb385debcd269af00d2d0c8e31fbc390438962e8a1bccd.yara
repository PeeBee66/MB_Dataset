
rule MB_cc161ee8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:11:05.635381"
        sha256 = "cc161ee82b20a45001cb385debcd269af00d2d0c8e31fbc390438962e8a1bccd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
