
rule MB_6e0b3a77
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-14T23:00:24.883069"
        sha256 = "6e0b3a7731a4f038335ca41c15467a2ff8a2c51b6ce22f62f137c203eb369f53"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
