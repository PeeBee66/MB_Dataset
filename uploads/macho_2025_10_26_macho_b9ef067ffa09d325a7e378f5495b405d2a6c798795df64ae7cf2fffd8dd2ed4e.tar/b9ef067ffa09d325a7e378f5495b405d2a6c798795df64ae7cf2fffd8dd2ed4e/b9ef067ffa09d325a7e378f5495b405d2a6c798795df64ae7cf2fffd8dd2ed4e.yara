
rule MB_b9ef067f
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-25T23:00:26.599984"
        sha256 = "b9ef067ffa09d325a7e378f5495b405d2a6c798795df64ae7cf2fffd8dd2ed4e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
