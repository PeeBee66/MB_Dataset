
rule MB_f388b925
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:00:34.222374"
        sha256 = "f388b925a2c5c43c36301c9fd2aaa1682280b9bbfc47c34ddcd78fcbbe14003d"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
