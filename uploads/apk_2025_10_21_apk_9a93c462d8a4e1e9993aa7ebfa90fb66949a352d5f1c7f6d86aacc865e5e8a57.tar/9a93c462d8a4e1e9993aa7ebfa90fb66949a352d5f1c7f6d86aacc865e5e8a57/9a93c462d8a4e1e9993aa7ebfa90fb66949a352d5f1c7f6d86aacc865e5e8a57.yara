
rule MB_9a93c462
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:17:27.855214"
        sha256 = "9a93c462d8a4e1e9993aa7ebfa90fb66949a352d5f1c7f6d86aacc865e5e8a57"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
