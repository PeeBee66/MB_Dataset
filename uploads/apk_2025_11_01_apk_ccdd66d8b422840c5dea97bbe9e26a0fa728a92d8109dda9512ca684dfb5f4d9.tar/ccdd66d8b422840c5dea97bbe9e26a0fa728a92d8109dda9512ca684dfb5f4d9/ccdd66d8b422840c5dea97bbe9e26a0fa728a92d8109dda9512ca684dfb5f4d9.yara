
rule MB_ccdd66d8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:04:48.465323"
        sha256 = "ccdd66d8b422840c5dea97bbe9e26a0fa728a92d8109dda9512ca684dfb5f4d9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
