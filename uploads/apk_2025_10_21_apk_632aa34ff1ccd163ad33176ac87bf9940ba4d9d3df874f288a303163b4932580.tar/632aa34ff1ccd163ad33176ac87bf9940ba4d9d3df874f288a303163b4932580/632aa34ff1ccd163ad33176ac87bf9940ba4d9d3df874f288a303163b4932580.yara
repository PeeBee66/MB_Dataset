
rule MB_632aa34f
{
    meta:
        description = "Auto-generated rule for SpyLoan"
        author = "MB-Collector"
        date = "2025-10-20T11:47:04.602271"
        sha256 = "632aa34ff1ccd163ad33176ac87bf9940ba4d9d3df874f288a303163b4932580"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
