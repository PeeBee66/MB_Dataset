
rule MB_66549188
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:01.250920"
        sha256 = "665491884aa47f9409ec8fc47bf3d4914cd6f82a25e81962b7a103208358484f"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
