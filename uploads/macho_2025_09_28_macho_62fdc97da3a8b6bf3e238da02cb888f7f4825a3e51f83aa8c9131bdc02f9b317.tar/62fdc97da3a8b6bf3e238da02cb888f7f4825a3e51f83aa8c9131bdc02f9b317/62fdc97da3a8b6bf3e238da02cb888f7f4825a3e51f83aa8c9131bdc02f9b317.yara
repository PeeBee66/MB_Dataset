
rule MB_62fdc97d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:01:56.358614"
        sha256 = "62fdc97da3a8b6bf3e238da02cb888f7f4825a3e51f83aa8c9131bdc02f9b317"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
