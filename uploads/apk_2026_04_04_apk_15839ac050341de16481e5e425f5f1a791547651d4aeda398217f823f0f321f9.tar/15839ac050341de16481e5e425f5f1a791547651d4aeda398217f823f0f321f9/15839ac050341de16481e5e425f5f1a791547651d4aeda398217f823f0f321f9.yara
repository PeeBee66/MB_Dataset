
rule MB_15839ac0
{
    meta:
        description = "Auto-generated rule for SpyNote"
        author = "MB-Collector"
        date = "2026-04-03T23:00:35.274791"
        sha256 = "15839ac050341de16481e5e425f5f1a791547651d4aeda398217f823f0f321f9"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
