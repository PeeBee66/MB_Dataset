
rule MB_8adce5e8
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-03T23:00:56.299356"
        sha256 = "8adce5e888db7e35a5731de025715c95961b459481edd19a2e7fb040c1218063"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
