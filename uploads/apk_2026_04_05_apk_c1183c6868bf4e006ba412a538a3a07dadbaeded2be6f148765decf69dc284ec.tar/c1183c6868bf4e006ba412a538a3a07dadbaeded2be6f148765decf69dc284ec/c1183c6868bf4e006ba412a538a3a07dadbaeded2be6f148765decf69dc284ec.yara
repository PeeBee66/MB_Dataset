
rule MB_c1183c68
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-05T00:00:21.761930"
        sha256 = "c1183c6868bf4e006ba412a538a3a07dadbaeded2be6f148765decf69dc284ec"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
