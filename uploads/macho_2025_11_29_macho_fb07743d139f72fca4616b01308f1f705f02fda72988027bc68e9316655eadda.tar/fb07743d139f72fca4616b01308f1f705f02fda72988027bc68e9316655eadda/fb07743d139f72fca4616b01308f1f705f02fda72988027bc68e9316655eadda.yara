
rule MB_fb07743d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-28T23:00:16.680673"
        sha256 = "fb07743d139f72fca4616b01308f1f705f02fda72988027bc68e9316655eadda"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
