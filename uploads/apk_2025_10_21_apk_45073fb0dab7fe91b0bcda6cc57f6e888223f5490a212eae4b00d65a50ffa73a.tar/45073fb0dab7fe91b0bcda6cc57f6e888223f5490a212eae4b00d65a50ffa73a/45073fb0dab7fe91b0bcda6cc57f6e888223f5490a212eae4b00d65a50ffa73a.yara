
rule MB_45073fb0
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:14.236087"
        sha256 = "45073fb0dab7fe91b0bcda6cc57f6e888223f5490a212eae4b00d65a50ffa73a"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
