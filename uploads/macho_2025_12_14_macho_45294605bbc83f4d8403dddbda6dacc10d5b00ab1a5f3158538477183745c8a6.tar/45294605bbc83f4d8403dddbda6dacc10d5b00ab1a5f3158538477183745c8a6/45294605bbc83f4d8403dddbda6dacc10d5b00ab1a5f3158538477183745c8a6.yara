
rule MB_45294605
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:41.215916"
        sha256 = "45294605bbc83f4d8403dddbda6dacc10d5b00ab1a5f3158538477183745c8a6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
