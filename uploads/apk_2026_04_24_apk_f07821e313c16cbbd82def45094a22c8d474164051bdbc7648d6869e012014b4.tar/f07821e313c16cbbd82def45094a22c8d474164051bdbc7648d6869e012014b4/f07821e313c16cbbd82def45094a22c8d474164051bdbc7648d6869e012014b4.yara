
rule MB_f07821e3
{
    meta:
        description = "Auto-generated rule for Kimwolf"
        author = "MB-Collector"
        date = "2026-04-24T00:02:28.612388"
        sha256 = "f07821e313c16cbbd82def45094a22c8d474164051bdbc7648d6869e012014b4"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
