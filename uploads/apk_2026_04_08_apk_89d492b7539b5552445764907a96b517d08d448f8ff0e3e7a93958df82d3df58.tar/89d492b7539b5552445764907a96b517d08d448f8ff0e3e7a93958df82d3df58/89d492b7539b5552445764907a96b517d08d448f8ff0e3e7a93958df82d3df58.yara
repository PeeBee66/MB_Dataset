
rule MB_89d492b7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-08T00:00:34.367037"
        sha256 = "89d492b7539b5552445764907a96b517d08d448f8ff0e3e7a93958df82d3df58"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
