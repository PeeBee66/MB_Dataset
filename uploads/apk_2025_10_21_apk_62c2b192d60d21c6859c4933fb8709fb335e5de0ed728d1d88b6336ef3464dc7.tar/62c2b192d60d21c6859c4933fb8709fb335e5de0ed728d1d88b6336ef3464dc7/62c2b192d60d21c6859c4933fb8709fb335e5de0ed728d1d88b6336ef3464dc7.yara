
rule MB_62c2b192
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:44:29.695708"
        sha256 = "62c2b192d60d21c6859c4933fb8709fb335e5de0ed728d1d88b6336ef3464dc7"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
