
rule MB_112d9428
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-10T23:01:20.159657"
        sha256 = "112d942831166e2c06b4a6ade90f6807025971a0260e9fba2f03b3bd1910bc13"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
