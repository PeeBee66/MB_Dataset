
rule MB_c2ab5c7e
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-11-13T23:01:11.469511"
        sha256 = "c2ab5c7e802949219686c7ce6ed1c4f66ed9802c8bbb1eea5fdb1b2687c31c70"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
