
rule MB_e17ded9d
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-09T23:01:40.481301"
        sha256 = "e17ded9dacf5bb1c1a3e84918a5ef318f48ef86d766ee2d7565e0915ff5adc90"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
