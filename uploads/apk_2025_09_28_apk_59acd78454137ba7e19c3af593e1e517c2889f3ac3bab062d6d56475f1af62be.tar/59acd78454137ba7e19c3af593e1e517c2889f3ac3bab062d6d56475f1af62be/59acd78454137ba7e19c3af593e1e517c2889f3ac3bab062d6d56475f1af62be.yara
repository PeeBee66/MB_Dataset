
rule MB_59acd784
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-28T00:00:14.460460"
        sha256 = "59acd78454137ba7e19c3af593e1e517c2889f3ac3bab062d6d56475f1af62be"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
