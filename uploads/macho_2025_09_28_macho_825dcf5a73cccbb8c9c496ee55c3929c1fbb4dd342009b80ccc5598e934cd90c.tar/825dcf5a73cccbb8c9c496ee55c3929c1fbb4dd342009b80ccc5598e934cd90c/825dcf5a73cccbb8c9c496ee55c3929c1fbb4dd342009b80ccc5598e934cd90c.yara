
rule MB_825dcf5a
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-09-27T00:01:19.911526"
        sha256 = "825dcf5a73cccbb8c9c496ee55c3929c1fbb4dd342009b80ccc5598e934cd90c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
