
rule MB_e28669c5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:03:38.266739"
        sha256 = "e28669c5f7c9ae330d2838a104ffa7da45a28e011e5c4deb80630aac9aa614ad"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
