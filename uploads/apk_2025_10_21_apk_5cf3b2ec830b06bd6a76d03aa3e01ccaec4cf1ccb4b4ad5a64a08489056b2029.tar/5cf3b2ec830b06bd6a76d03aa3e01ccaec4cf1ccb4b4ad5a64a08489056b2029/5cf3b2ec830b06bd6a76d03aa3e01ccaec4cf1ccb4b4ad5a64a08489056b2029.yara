
rule MB_5cf3b2ec
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:19:46.895040"
        sha256 = "5cf3b2ec830b06bd6a76d03aa3e01ccaec4cf1ccb4b4ad5a64a08489056b2029"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
