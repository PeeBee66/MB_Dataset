
rule MB_80ec9992
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-28T23:00:13.751322"
        sha256 = "80ec9992a61fa47f222ed879bd7f948d321e27517ce3c08231e48127ac6dca39"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
