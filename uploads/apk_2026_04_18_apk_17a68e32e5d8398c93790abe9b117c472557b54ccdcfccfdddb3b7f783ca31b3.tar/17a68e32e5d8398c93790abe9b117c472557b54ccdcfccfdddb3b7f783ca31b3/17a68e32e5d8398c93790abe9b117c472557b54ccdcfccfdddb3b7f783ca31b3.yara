
rule MB_17a68e32
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-04-18T00:00:46.765427"
        sha256 = "17a68e32e5d8398c93790abe9b117c472557b54ccdcfccfdddb3b7f783ca31b3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
