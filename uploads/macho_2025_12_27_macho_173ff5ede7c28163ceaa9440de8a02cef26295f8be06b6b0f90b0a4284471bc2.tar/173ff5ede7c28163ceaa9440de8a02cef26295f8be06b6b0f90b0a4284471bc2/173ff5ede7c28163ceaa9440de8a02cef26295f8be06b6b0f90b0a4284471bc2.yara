
rule MB_173ff5ed
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-26T23:00:20.212454"
        sha256 = "173ff5ede7c28163ceaa9440de8a02cef26295f8be06b6b0f90b0a4284471bc2"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
