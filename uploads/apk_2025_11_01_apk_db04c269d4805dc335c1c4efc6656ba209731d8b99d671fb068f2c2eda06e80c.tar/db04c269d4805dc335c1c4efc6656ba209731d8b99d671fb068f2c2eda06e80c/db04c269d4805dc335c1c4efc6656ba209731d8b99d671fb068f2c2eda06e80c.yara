
rule MB_db04c269
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-31T23:05:48.156655"
        sha256 = "db04c269d4805dc335c1c4efc6656ba209731d8b99d671fb068f2c2eda06e80c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
