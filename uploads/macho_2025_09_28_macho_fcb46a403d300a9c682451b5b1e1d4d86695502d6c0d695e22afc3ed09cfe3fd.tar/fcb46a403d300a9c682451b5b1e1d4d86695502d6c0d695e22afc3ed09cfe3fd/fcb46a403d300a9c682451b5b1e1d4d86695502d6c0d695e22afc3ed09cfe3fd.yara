
rule MB_fcb46a40
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-27T00:00:51.469177"
        sha256 = "fcb46a403d300a9c682451b5b1e1d4d86695502d6c0d695e22afc3ed09cfe3fd"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
