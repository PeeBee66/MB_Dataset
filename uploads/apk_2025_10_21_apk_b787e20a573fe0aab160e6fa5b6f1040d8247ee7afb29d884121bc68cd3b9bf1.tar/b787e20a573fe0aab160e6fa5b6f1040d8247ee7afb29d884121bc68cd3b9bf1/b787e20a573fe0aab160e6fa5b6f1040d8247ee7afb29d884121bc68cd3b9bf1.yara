
rule MB_b787e20a
{
    meta:
        description = "Auto-generated rule for AntiDot"
        author = "MB-Collector"
        date = "2025-10-20T11:22:38.437156"
        sha256 = "b787e20a573fe0aab160e6fa5b6f1040d8247ee7afb29d884121bc68cd3b9bf1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
