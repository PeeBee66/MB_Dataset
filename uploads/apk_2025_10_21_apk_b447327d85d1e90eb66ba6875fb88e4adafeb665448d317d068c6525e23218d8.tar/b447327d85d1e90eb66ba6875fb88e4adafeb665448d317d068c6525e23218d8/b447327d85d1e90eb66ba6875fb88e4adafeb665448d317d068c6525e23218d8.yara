
rule MB_b447327d
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:41:38.862623"
        sha256 = "b447327d85d1e90eb66ba6875fb88e4adafeb665448d317d068c6525e23218d8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
