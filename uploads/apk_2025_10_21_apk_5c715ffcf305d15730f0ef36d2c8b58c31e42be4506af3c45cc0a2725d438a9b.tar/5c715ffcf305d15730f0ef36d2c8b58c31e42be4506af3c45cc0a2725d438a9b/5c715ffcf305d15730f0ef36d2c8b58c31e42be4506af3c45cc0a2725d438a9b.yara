
rule MB_5c715ffc
{
    meta:
        description = "Auto-generated rule for IRATA"
        author = "MB-Collector"
        date = "2025-10-20T11:45:32.907577"
        sha256 = "5c715ffcf305d15730f0ef36d2c8b58c31e42be4506af3c45cc0a2725d438a9b"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
