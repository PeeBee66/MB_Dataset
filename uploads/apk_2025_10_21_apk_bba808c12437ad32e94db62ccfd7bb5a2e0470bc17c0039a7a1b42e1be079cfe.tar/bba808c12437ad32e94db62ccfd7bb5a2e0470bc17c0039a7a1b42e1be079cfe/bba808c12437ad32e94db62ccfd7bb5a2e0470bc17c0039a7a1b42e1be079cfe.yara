
rule MB_bba808c1
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-20T11:43:08.558395"
        sha256 = "bba808c12437ad32e94db62ccfd7bb5a2e0470bc17c0039a7a1b42e1be079cfe"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
