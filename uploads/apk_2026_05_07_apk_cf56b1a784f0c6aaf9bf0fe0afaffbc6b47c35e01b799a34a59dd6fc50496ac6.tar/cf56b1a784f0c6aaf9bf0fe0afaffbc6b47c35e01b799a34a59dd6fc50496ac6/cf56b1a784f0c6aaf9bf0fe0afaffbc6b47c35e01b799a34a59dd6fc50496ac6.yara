
rule MB_cf56b1a7
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-05-07T00:03:24.613286"
        sha256 = "cf56b1a784f0c6aaf9bf0fe0afaffbc6b47c35e01b799a34a59dd6fc50496ac6"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
