
rule MB_970a98d5
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-10-09T23:02:02.442232"
        sha256 = "970a98d53bbcc9ffa0b3b2ad8f6193b280e7ea77d6ef869d4a0af3dfcee44731"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
