
rule MB_7583b972
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-09-25T00:02:05.656881"
        sha256 = "7583b97250af1e6479b336988e87b1254f7c9263591bf6393558ddcfd0720803"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
