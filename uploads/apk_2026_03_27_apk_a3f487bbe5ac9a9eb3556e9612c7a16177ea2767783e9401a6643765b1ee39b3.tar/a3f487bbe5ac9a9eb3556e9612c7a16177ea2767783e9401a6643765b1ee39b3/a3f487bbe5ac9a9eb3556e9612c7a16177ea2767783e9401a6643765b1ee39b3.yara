
rule MB_a3f487bb
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-26T23:00:17.799005"
        sha256 = "a3f487bbe5ac9a9eb3556e9612c7a16177ea2767783e9401a6643765b1ee39b3"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
