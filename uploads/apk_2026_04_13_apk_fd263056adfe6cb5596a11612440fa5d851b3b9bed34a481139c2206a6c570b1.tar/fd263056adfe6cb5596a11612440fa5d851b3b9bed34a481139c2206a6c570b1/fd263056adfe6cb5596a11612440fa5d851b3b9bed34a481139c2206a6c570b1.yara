
rule MB_fd263056
{
    meta:
        description = "Auto-generated rule for Arsink"
        author = "MB-Collector"
        date = "2026-04-13T00:00:39.529862"
        sha256 = "fd263056adfe6cb5596a11612440fa5d851b3b9bed34a481139c2206a6c570b1"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
