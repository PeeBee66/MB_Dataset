
rule MB_9fbbcd80
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-19T23:01:01.558807"
        sha256 = "9fbbcd809b7aee90b3c93d212287282ac35ef0b33aed647a48cbc4ba79c7fcf8"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
