
rule MB_67d09f1c
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2025-12-13T23:00:56.682770"
        sha256 = "67d09f1c76e7ac7339572899180bb98d4dee76c81815f81e803c4da556df41ce"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
