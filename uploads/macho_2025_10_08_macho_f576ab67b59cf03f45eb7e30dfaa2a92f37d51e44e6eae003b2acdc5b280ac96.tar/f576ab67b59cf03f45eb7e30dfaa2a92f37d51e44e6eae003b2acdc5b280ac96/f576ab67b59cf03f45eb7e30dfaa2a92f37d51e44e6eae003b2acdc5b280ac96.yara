
rule MB_f576ab67
{
    meta:
        description = "Auto-generated rule for AmosStealer"
        author = "MB-Collector"
        date = "2025-10-07T23:01:31.190315"
        sha256 = "f576ab67b59cf03f45eb7e30dfaa2a92f37d51e44e6eae003b2acdc5b280ac96"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
