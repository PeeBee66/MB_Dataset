
rule MB_580b3958
{
    meta:
        description = "Auto-generated rule for Joker"
        author = "MB-Collector"
        date = "2026-03-25T23:00:24.603309"
        sha256 = "580b39589c457f66e1feaa1f5e41830d1dc2091f31ec61dd393ca121bf3bed2e"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
