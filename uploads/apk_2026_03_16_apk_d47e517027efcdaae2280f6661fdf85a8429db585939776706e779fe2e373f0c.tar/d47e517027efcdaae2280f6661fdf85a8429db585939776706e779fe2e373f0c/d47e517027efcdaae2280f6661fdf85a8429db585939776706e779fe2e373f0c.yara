
rule MB_d47e5170
{
    meta:
        description = "Auto-generated rule for None"
        author = "MB-Collector"
        date = "2026-03-15T23:01:04.862828"
        sha256 = "d47e517027efcdaae2280f6661fdf85a8429db585939776706e779fe2e373f0c"

    strings:
        $magic = { 4D 5A }  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}
