"""Job scheduler using APScheduler"""

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timedelta
from typing import Dict, Optional
from app.logger import get_logger
from app.config import settings
from app.models import Job, JobType, JobStatus, Tag, db
from app.workers.mb_client import MalwareBazaarClient
from app.workers.backup import BackupWorker
from app.workers.github_api import GitHubAPISync
from app.workers.manual_uploader import ManualUploader
from app.workers.reporter import EmailReporter
import asyncio
import pytz

logger = get_logger(__name__)


class JobScheduler:
    """Manages scheduled jobs for the application"""

    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self.mb_client = None
        self.backup_worker = BackupWorker()
        self.github_sync = GitHubAPISync()
        self.manual_uploader = ManualUploader()
        self.email_reporter = EmailReporter()
        self.timezone = pytz.timezone(settings.timezone)

    def reload_config(self):
        """Reload configuration and reconfigure jobs"""
        settings.reload_config()
        self.timezone = pytz.timezone(settings.timezone)
        self._configure_jobs()
        logger.info("Configuration reloaded, jobs reconfigured")

    def restart_with_new_config(self):
        """Restart scheduler with new configuration"""
        try:
            # Remove all existing jobs
            self.scheduler.remove_all_jobs()

            # Reload configuration
            settings.reload_config()
            self.timezone = pytz.timezone(settings.timezone)

            # Reconfigure jobs with new settings
            self._configure_jobs()

            logger.info("Scheduler restarted with new configuration")
        except Exception as e:
            logger.error(f"Error restarting scheduler: {e}")

    def start(self):
        """Start the scheduler and configure jobs"""

        # Configure jobs based on settings
        self._configure_jobs()

        # Start scheduler
        self.scheduler.start()
        logger.info("Scheduler started")

    def _configure_jobs(self):
        """Configure scheduled jobs from settings"""

        # Download job (10:00)
        if settings.auto_download_time:
            hour, minute = map(int, settings.auto_download_time.split(':'))
            self.scheduler.add_job(
                self.run_download_job,
                CronTrigger(hour=hour, minute=minute, timezone=self.timezone),
                id="download_job",
                name="Daily Download",
                replace_existing=True
            )
            logger.info(f"Scheduled download job at {settings.auto_download_time}")

        # Backup job (11:00)
        if settings.auto_backup_time:
            hour, minute = map(int, settings.auto_backup_time.split(':'))
            self.scheduler.add_job(
                self.run_backup_job,
                CronTrigger(hour=hour, minute=minute, timezone=self.timezone),
                id="backup_job",
                name="Daily Backup",
                replace_existing=True
            )
            logger.info(f"Scheduled backup job at {settings.auto_backup_time}")

        # Upload job (12:00)
        if settings.auto_upload_time:
            hour, minute = map(int, settings.auto_upload_time.split(':'))
            self.scheduler.add_job(
                self.run_upload_job,
                CronTrigger(hour=hour, minute=minute, timezone=self.timezone),
                id="upload_job",
                name="Daily Upload",
                replace_existing=True
            )
            logger.info(f"Scheduled upload job at {settings.auto_upload_time}")

        # Email job (13:00)
        if settings.auto_email_time:
            hour, minute = map(int, settings.auto_email_time.split(':'))
            self.scheduler.add_job(
                self.run_email_job,
                CronTrigger(hour=hour, minute=minute, timezone=self.timezone),
                id="email_job",
                name="Daily Email",
                replace_existing=True
            )
            logger.info(f"Scheduled email job at {settings.auto_email_time}")

    async def run_download_job(self, tags: Optional[list] = None) -> Dict:
        """Run the download job for specified tags or all enabled tags"""

        logger.info("Starting download job")
        session = db.get_session()

        # Create job record
        job = Job(
            type=JobType.DOWNLOAD,
            status=JobStatus.RUNNING,
            scheduled_at=datetime.utcnow(),
            started_at=datetime.utcnow()
        )
        session.add(job)
        session.commit()

        stats = {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "tags": {}
        }

        try:
            # Get tags to process - use current config tags or provided tags
            if tags:
                tags_to_process = tags
            else:
                tags_to_process = settings.tags

            # Process each tag
            async with MalwareBazaarClient() as mb_client:
                for tag_name in tags_to_process:
                    logger.info(f"Processing tag: {tag_name}")

                    tag_stats = {
                        "processed": 0,
                        "success": 0,
                        "failed": 0
                    }

                    # Get samples from last 24 hours
                    since = datetime.utcnow() - timedelta(days=1)
                    samples = await mb_client.search_by_tag(
                        tag_name,
                        limit=settings.max_daily_items_per_tag or 100,
                        since=since
                    )

                    for sample_data in samples:
                        tag_stats["processed"] += 1
                        stats["processed"] += 1

                        # Process sample
                        success = await mb_client.process_sample(
                            sample_data,
                            tag_name,
                            session
                        )

                        if success:
                            tag_stats["success"] += 1
                            stats["success"] += 1
                        else:
                            tag_stats["failed"] += 1
                            stats["failed"] += 1

                    stats["tags"][tag_name] = tag_stats

                    # Ensure tag exists in database and update last_checked
                    tag_obj = session.query(Tag).filter_by(name=tag_name).first()
                    if not tag_obj:
                        tag_obj = Tag(name=tag_name, enabled=True, created_at=datetime.utcnow())
                        session.add(tag_obj)
                    tag_obj.last_checked = datetime.utcnow()
                    session.commit()

            # Update job record
            job.status = JobStatus.COMPLETED
            job.finished_at = datetime.utcnow()
            job.items_processed = stats["processed"]
            job.items_failed = stats["failed"]
            job.message = f"Downloaded {stats['success']} samples"

        except Exception as e:
            logger.error(f"Download job failed: {str(e)}")
            job.status = JobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(e)
            stats["error"] = str(e)

        finally:
            session.commit()
            session.close()

        logger.info(f"Download job completed", **stats)
        return stats

    async def run_backup_job(self) -> Dict:
        """Run the backup job"""

        logger.info("Starting backup job")
        session = db.get_session()

        # Create job record
        job = Job(
            type=JobType.BACKUP,
            status=JobStatus.RUNNING,
            scheduled_at=datetime.utcnow(),
            started_at=datetime.utcnow()
        )
        session.add(job)
        session.commit()

        try:
            # Run backup
            stats = await self.backup_worker.backup_all_pending(session)

            # Update job record
            job.status = JobStatus.COMPLETED
            job.finished_at = datetime.utcnow()
            job.items_processed = stats["processed"]
            job.items_failed = stats["failed"]
            job.message = f"Created {stats['success']} backups"

        except Exception as e:
            logger.error(f"Backup job failed: {str(e)}")
            job.status = JobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(e)
            stats = {"error": str(e)}

        finally:
            session.commit()
            session.close()

        logger.info(f"Backup job completed")
        return stats

    async def run_upload_job(self) -> Dict:
        """Run the automatic GitHub sync job"""

        logger.info("Starting automatic GitHub sync job")
        session = db.get_session()

        # Create job record
        job = Job(
            type=JobType.UPLOAD,
            status=JobStatus.RUNNING,
            scheduled_at=datetime.utcnow(),
            started_at=datetime.utcnow()
        )
        session.add(job)
        session.commit()

        try:
            # Run GitHub sync
            stats = await self.github_sync.sync_with_github()

            # Update job record
            if stats.get("success"):
                uploaded = stats.get("uploaded", 0)
                deleted = stats.get("deleted", 0)
                skipped = stats.get("skipped", 0)
                job.status = JobStatus.COMPLETED
                job.message = f"Synced: +{uploaded} -{deleted} files, skipped: {skipped}"
                job.items_processed = uploaded
            else:
                job.status = JobStatus.FAILED
                job.message = stats.get("error", "Unknown error")

            job.finished_at = datetime.utcnow()

        except Exception as e:
            logger.error(f"GitHub sync job failed: {str(e)}")
            job.status = JobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(e)
            stats = {"success": False, "error": str(e)}

        finally:
            session.commit()
            session.close()

        logger.info(f"GitHub sync job completed")
        return stats

    async def run_email_job(self) -> Dict:
        """Run the email report job"""

        logger.info("Starting email job")
        session = db.get_session()

        # Create job record
        job = Job(
            type=JobType.EMAIL,
            status=JobStatus.RUNNING,
            scheduled_at=datetime.utcnow(),
            started_at=datetime.utcnow()
        )
        session.add(job)
        session.commit()

        try:
            # Send email
            success = await self.email_reporter.send_daily_summary()

            # Update job record
            if success:
                job.status = JobStatus.COMPLETED
                job.message = "Email sent successfully"
            else:
                job.status = JobStatus.FAILED
                job.message = "Failed to send email"

            job.finished_at = datetime.utcnow()

            stats = {"success": success}

        except Exception as e:
            logger.error(f"Email job failed: {str(e)}")
            job.status = JobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(e)
            stats = {"error": str(e)}

        finally:
            session.commit()
            session.close()

        logger.info(f"Email job completed")
        return stats

    async def run_manual_pull(
        self,
        tags: list,
        date_from: datetime,
        date_to: datetime
    ) -> Dict:
        """Run a manual historical pull"""

        logger.info(
            f"Starting manual pull",
            tags=tags,
            date_from=date_from,
            date_to=date_to
        )

        session = db.get_session()

        # Create job record
        job = Job(
            type=JobType.MANUAL_PULL,
            status=JobStatus.RUNNING,
            scheduled_at=datetime.utcnow(),
            started_at=datetime.utcnow(),
            parameters=f"tags={tags}, from={date_from}, to={date_to}"
        )
        session.add(job)
        session.commit()

        stats = {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "tags": {}
        }

        try:
            async with MalwareBazaarClient() as mb_client:
                for tag_name in tags:
                    logger.info(f"Manual pull for tag: {tag_name}")

                    tag_stats = {
                        "processed": 0,
                        "success": 0,
                        "failed": 0
                    }

                    # Get samples in date range
                    samples = await mb_client.search_by_tag(
                        tag_name,
                        limit=1000,  # Higher limit for historical
                        since=date_from
                    )

                    # Filter by date_to
                    filtered_samples = []
                    for sample in samples:
                        try:
                            sample_date = datetime.fromisoformat(
                                sample.get("first_seen", "").replace(" ", "T")
                            )
                            if sample_date <= date_to:
                                filtered_samples.append(sample)
                        except:
                            filtered_samples.append(sample)

                    # Process samples
                    for sample_data in filtered_samples:
                        tag_stats["processed"] += 1
                        stats["processed"] += 1

                        success = await mb_client.process_sample(
                            sample_data,
                            tag_name,
                            session
                        )

                        if success:
                            tag_stats["success"] += 1
                            stats["success"] += 1
                        else:
                            tag_stats["failed"] += 1
                            stats["failed"] += 1

                    stats["tags"][tag_name] = tag_stats

            # Update job record
            job.status = JobStatus.COMPLETED
            job.finished_at = datetime.utcnow()
            job.items_processed = stats["processed"]
            job.items_failed = stats["failed"]
            job.message = f"Processed {stats['success']} samples"

        except Exception as e:
            logger.error(f"Manual pull failed: {str(e)}")
            job.status = JobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(e)
            stats["error"] = str(e)

        finally:
            session.commit()
            session.close()

        logger.info(f"Manual pull completed", **stats)
        return stats

    async def run_manual_upload_job(self, days: int = 1) -> Dict:
        """Run manual upload job - creates TAR files locally"""

        logger.info(f"Starting manual upload job for last {days} day(s)")
        session = db.get_session()

        # Create job record
        job = Job(
            type=JobType.MANUAL_PULL,  # Reuse this type for manual uploads
            status=JobStatus.RUNNING,
            scheduled_at=datetime.utcnow(),
            started_at=datetime.utcnow(),
            parameters=f"days={days}, action=manual_upload"
        )
        session.add(job)
        session.commit()

        try:
            # Create TAR files
            stats = await self.manual_uploader.create_tar_collection(days)

            # Clean up old TAR files
            deleted = await self.manual_uploader.cleanup_old_tars()
            stats["cleaned_up"] = deleted

            # Update job record
            job.status = JobStatus.COMPLETED
            job.finished_at = datetime.utcnow()
            job.items_processed = len(stats.get("created_tars", []))
            job.message = stats.get("message", f"Created {len(stats.get('created_tars', []))} TAR files")

        except Exception as e:
            logger.error(f"Manual upload job failed: {str(e)}")
            job.status = JobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(e)
            stats = {"error": str(e), "created_tars": [], "collected": 0}

        finally:
            session.commit()
            session.close()

        logger.info(f"Manual upload job completed")
        return stats

    def get_jobs(self) -> list:
        """Get list of scheduled jobs in logical workflow order"""

        jobs = []
        for job in self.scheduler.get_jobs():
            jobs.append({
                "id": job.id,
                "name": job.name,
                "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
                "trigger": str(job.trigger)
            })

        # Sort jobs in logical workflow order: Download → Backup → Upload → Email
        job_order = {
            "Daily Download": 1,
            "Daily Backup": 2,
            "Daily Upload": 3,
            "Daily Email": 4
        }

        jobs.sort(key=lambda x: job_order.get(x["name"], 999))
        return jobs

    def shutdown(self):
        """Shutdown the scheduler"""

        if self.scheduler.running:
            self.scheduler.shutdown()
            logger.info("Scheduler shutdown")