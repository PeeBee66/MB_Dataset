"""Main application entry point"""

import asyncio
import signal
import sys
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from app.config import settings
from app.logger import get_logger
from app.models import db, Job
from app.scheduler import JobScheduler
from app.api import api_router, public_router, set_scheduler
from app.utils.filesystem import FileSystemScanner
import uvicorn

logger = get_logger(__name__)

# Initialize services
scheduler = JobScheduler()
scanner = FileSystemScanner()
templates = Jinja2Templates(directory="app/templates")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""

    logger.info("Starting MalwareBazaar Collector")

    # Create necessary directories
    for path in [settings.download_root, settings.backup_root]:
        path.mkdir(parents=True, exist_ok=True)
        logger.info(f"Ensured directory exists: {path}")

    # Initialize database
    db.create_tables()
    db.init_defaults()
    logger.info("Database initialized")

    # Start scheduler
    scheduler.start()
    set_scheduler(scheduler)
    logger.info("Scheduler started")

    # Display safety warning
    print("\n" + "="*60)
    print("⚠️  DEFENSIVE RESEARCH USE ONLY ⚠️")
    print("This tool is for defensive security research purposes only.")
    print("Do NOT execute any downloaded samples.")
    print("Use in accordance with local laws and MalwareBazaar ToS.")
    print("="*60 + "\n")

    yield

    # Shutdown
    logger.info("Shutting down MalwareBazaar Collector")
    scheduler.shutdown()
    logger.info("Scheduler stopped")

# Create FastAPI app
app = FastAPI(
    title="MalwareBazaar Collector",
    description="Automated malware sample collection for defensive research",
    version="1.0.0",
    lifespan=lifespan
)

# Include routers
app.include_router(public_router)
app.include_router(api_router)

# Web UI routes
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Dashboard page"""

    # Get statistics
    stats = {
        "tags": {},
        "totals": {
            "samples": 0,
            "backed_up": 0,
            "data_size": 0,
            "backup_size": 0
        }
    }

    for tag in settings.tags:
        tag_stats = await scanner.scan_tag(tag)
        stats["tags"][tag] = tag_stats
        stats["totals"]["samples"] += tag_stats["total_samples"]
        stats["totals"]["backed_up"] += tag_stats["backed_up"]
        stats["totals"]["data_size"] += tag_stats["data_size"]
        stats["totals"]["backup_size"] += tag_stats["backup_size"]

    # Get recent samples
    recent_result = await scanner.get_recent_samples(limit=10)
    recent_samples = recent_result["samples"]

    # Get scheduled jobs
    scheduled_jobs = scheduler.get_jobs()

    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "stats": stats,
            "recent_samples": recent_samples,
            "scheduled_jobs": scheduled_jobs
        }
    )

@app.get("/samples", response_class=HTMLResponse)
async def samples_page(
    request: Request,
    tag: str = None,
    search: str = None,
    page: int = 1,
    limit: int = 25
):
    """Samples browser page with pagination"""

    # Calculate offset
    offset = (page - 1) * limit

    if search:
        result = await scanner.search_samples(search, tag, limit=limit, offset=offset)
    else:
        result = await scanner.get_recent_samples(limit, tag, offset)

    # Get tag list
    tags = settings.tags

    # Calculate pagination info
    total_pages = (result["total"] + limit - 1) // limit
    has_prev = page > 1
    has_next = page < total_pages

    return templates.TemplateResponse(
        "samples.html",
        {
            "request": request,
            "samples": result["samples"],
            "total": result["total"],
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
            "has_prev": has_prev,
            "has_next": has_next,
            "tags": tags,
            "current_tag": tag,
            "search": search
        }
    )

@app.get("/samples/{sha256}/details", response_class=HTMLResponse)
async def sample_details_page(request: Request, sha256: str, tag: str):
    """Sample details page"""

    details = await scanner.get_sample_details(tag, sha256)

    if not details:
        return templates.TemplateResponse(
            "error.html",
            {"request": request, "error": "Sample not found"},
            status_code=404
        )

    return templates.TemplateResponse(
        "sample_details.html",
        {"request": request, "sample": details}
    )

@app.get("/jobs", response_class=HTMLResponse)
async def jobs_page(request: Request):
    """Jobs management page"""

    # Get job history from database
    session = db.get_session()
    try:
        jobs = session.query(Job).order_by(Job.scheduled_at.desc()).limit(50).all()
        job_list = [
            {
                "id": job.id,
                "type": job.type.value,
                "status": job.status.value,
                "scheduled_at": job.scheduled_at,
                "started_at": job.started_at,
                "finished_at": job.finished_at,
                "message": job.message,
                "items_processed": job.items_processed,
                "items_failed": job.items_failed
            }
            for job in jobs
        ]
    finally:
        session.close()

    # Get scheduled jobs
    scheduled_jobs = scheduler.get_jobs()

    return templates.TemplateResponse(
        "jobs.html",
        {
            "request": request,
            "jobs": job_list,
            "scheduled_jobs": scheduled_jobs,
            "tags": settings.tags
        }
    )

@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    """Settings page"""

    return templates.TemplateResponse(
        "settings.html",
        {
            "request": request,
            "settings": {
                "tags": settings.tags,
                "auto_download_time": settings.auto_download_time,
                "auto_backup_time": settings.auto_backup_time,
                "auto_upload_time": settings.auto_upload_time,
                "auto_email_time": settings.auto_email_time,
                "timezone": settings.timezone,
                "github_upload_retention_days": settings.github_upload_retention_days,
                "max_daily_items_per_tag": settings.max_daily_items_per_tag,
                "github_repo": settings.github_repo,
                "smtp_host": settings.smtp_host,
                "smtp_port": settings.smtp_port,
                "smtp_from": settings.smtp_from,
                "smtp_to": settings.smtp_to_list
            }
        }
    )

@app.get("/cleanup", response_class=HTMLResponse)
async def cleanup_page(request: Request):
    """Cleanup management page"""

    # Get current storage stats
    stats = {
        "tags": {},
        "totals": {
            "samples": 0,
            "data_size": 0,
            "backup_size": 0
        }
    }

    for tag in settings.tags:
        tag_stats = await scanner.scan_tag(tag)
        stats["tags"][tag] = tag_stats
        stats["totals"]["samples"] += tag_stats["total_samples"]
        stats["totals"]["data_size"] += tag_stats["data_size"]
        stats["totals"]["backup_size"] += tag_stats["backup_size"]

    return templates.TemplateResponse(
        "cleanup.html",
        {
            "request": request,
            "stats": stats
        }
    )

def format_size(size_bytes: int) -> str:
    """Format bytes to human readable size"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"

# Add template filters
templates.env.filters['format_size'] = format_size

# Signal handlers
def signal_handler(sig, frame):
    """Handle shutdown signals"""
    logger.info(f"Received signal {sig}")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.listen_host,
        port=settings.listen_port,
        reload=False,
        log_level=settings.log_level.lower()
    )