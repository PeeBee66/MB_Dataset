"""MalwareBazaar Collector - Defensive Security Research Tool"""

__version__ = "1.0.0"