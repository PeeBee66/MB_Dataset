"""API routes for the application"""

from fastapi import APIRouter, HTTPException, Depends, Query, Body, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from pathlib import Path
from app.config import settings
from app.logger import get_logger
from app.models import db, Job, JobStatus, Tag, Sample
from app.scheduler import JobScheduler
from app.utils.filesystem import FileSystemScanner
from app.workers.backup import BackupWorker
from app.workers.uploader import VCSUploader
from app.workers.reporter import EmailReporter
import asyncio

logger = get_logger(__name__)

# Security
security = HTTPBearer()

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify admin token"""
    if credentials.credentials != settings.admin_token.get_secret_value():
        raise HTTPException(status_code=403, detail="Invalid authentication")
    return credentials.credentials

# Create routers
api_router = APIRouter(prefix="/api")
public_router = APIRouter()

# Initialize services
scanner = FileSystemScanner()
scheduler = None  # Will be set from main.py

# Health check - accepts both GET and HEAD methods for Docker healthcheck
@public_router.get("/healthz")
@public_router.head("/healthz")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    }

# Sample endpoints (read from filesystem)
@api_router.get("/samples")
async def get_samples(
    tag: Optional[str] = Query(None),
    limit: int = Query(100, le=1000),
    offset: int = Query(0, ge=0),
    search: Optional[str] = Query(None)
):
    """Get samples directly from filesystem"""

    try:
        if search:
            # Search samples with pagination
            result = await scanner.search_samples(search, tag, limit=limit, offset=offset)
        else:
            # Get recent samples with pagination
            result = await scanner.get_recent_samples(limit, tag, offset)

        return result

    except Exception as e:
        logger.error(f"Error getting samples: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/samples/{sha256}")
async def get_sample_details(sha256: str, tag: str = Query(...)):
    """Get detailed information about a specific sample"""

    try:
        details = await scanner.get_sample_details(tag, sha256)
        if not details:
            raise HTTPException(status_code=404, detail="Sample not found")
        return details

    except Exception as e:
        logger.error(f"Error getting sample details: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/samples/recent")
async def get_recent_samples(
    limit: int = Query(25, ge=1, le=100),
    offset: int = Query(0, ge=0),
    tag: Optional[str] = Query(None)
):
    """Get most recently added samples with pagination"""

    try:
        result = await scanner.get_recent_samples(limit, tag, offset)
        return result

    except Exception as e:
        logger.error(f"Error getting recent samples: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Statistics endpoints
@api_router.get("/stats")
async def get_statistics():
    """Get overall statistics from filesystem"""

    try:
        stats = {
            "tags": {},
            "totals": {
                "samples": 0,
                "backed_up": 0,
                "data_size": 0,
                "backup_size": 0
            }
        }

        for tag in settings.tags:
            tag_stats = await scanner.scan_tag(tag)
            stats["tags"][tag] = tag_stats

            # Update totals
            stats["totals"]["samples"] += tag_stats["total_samples"]
            stats["totals"]["backed_up"] += tag_stats["backed_up"]
            stats["totals"]["data_size"] += tag_stats["data_size"]
            stats["totals"]["backup_size"] += tag_stats["backup_size"]

        return stats

    except Exception as e:
        logger.error(f"Error getting statistics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/stats/{tag}")
async def get_tag_statistics(tag: str):
    """Get statistics for a specific tag"""

    try:
        stats = await scanner.scan_tag(tag)
        return stats

    except Exception as e:
        logger.error(f"Error getting tag statistics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Job endpoints
@api_router.post("/jobs/run/{job_type}")
async def run_job(
    job_type: str,
    background_tasks: BackgroundTasks,
    tags: Optional[List[str]] = Body(None),
    date_from: Optional[str] = Body(None),
    date_to: Optional[str] = Body(None),
    days: Optional[int] = Body(1)
):
    """Run a job manually"""

    global scheduler
    if not scheduler:
        raise HTTPException(status_code=500, detail="Scheduler not initialized")

    try:
        if job_type == "download":
            background_tasks.add_task(scheduler.run_download_job, tags)
            return {"message": "Download job started", "job_type": job_type}

        elif job_type == "backup":
            background_tasks.add_task(scheduler.run_backup_job)
            return {"message": "Backup job started", "job_type": job_type}

        elif job_type == "upload":
            background_tasks.add_task(scheduler.run_upload_job)
            return {"message": "Upload to Git Repository job started", "job_type": job_type}

        elif job_type == "create_archive":
            if days is None or days < 1:
                days = 1
            background_tasks.add_task(scheduler.run_manual_upload_job, days)
            return {"message": f"Collecting backup files to application uploads folder for last {days} day(s)", "job_type": job_type, "days": days}

        elif job_type == "email":
            background_tasks.add_task(scheduler.run_email_job)
            return {"message": "Email job started", "job_type": job_type}

        elif job_type == "manual_pull":
            if not tags or not date_from or not date_to:
                raise HTTPException(
                    status_code=400,
                    detail="Tags, date_from and date_to required for manual pull"
                )

            date_from_obj = datetime.fromisoformat(date_from)
            date_to_obj = datetime.fromisoformat(date_to)

            background_tasks.add_task(
                scheduler.run_manual_pull,
                tags,
                date_from_obj,
                date_to_obj
            )
            return {"message": "Manual pull started", "job_type": job_type}

        else:
            raise HTTPException(status_code=400, detail="Invalid job type")

    except Exception as e:
        logger.error(f"Error running job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/jobs")
async def get_jobs(
    status: Optional[JobStatus] = Query(None),
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0)
):
    """Get job history"""

    session = db.get_session()
    try:
        query = session.query(Job).order_by(Job.scheduled_at.desc())

        if status:
            query = query.filter(Job.status == status)

        total = query.count()
        jobs = query.offset(offset).limit(limit).all()

        return {
            "total": total,
            "offset": offset,
            "limit": limit,
            "jobs": [
                {
                    "id": job.id,
                    "type": job.type.value,
                    "status": job.status.value,
                    "scheduled_at": job.scheduled_at.isoformat() if job.scheduled_at else None,
                    "started_at": job.started_at.isoformat() if job.started_at else None,
                    "finished_at": job.finished_at.isoformat() if job.finished_at else None,
                    "message": job.message,
                    "items_processed": job.items_processed,
                    "items_failed": job.items_failed
                }
                for job in jobs
            ]
        }

    finally:
        session.close()

@api_router.get("/jobs/scheduled")
async def get_scheduled_jobs():
    """Get scheduled jobs"""

    global scheduler
    if not scheduler:
        return {"jobs": []}

    return {"jobs": scheduler.get_jobs()}

# Cleanup endpoints
@api_router.post("/cleanup", dependencies=[Depends(verify_token)])
async def cleanup_old_files(
    days: int = Body(..., ge=1, le=365),
    target: str = Body(..., regex="^(data|backup|both)$"),
    dry_run: bool = Body(True)
):
    """Clean up old files from data and/or backup directories"""

    try:
        stats = await scanner.cleanup_old_files(days, target, dry_run)
        return {
            "message": f"Cleanup {'simulation' if dry_run else 'completed'}",
            "stats": stats
        }

    except Exception as e:
        logger.error(f"Error during cleanup: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Refresh endpoint
@api_router.post("/refresh")
async def refresh_filesystem():
    """Force refresh of filesystem scan (for future caching)"""

    try:
        stats = await scanner.refresh_cache()
        return {
            "message": "Filesystem refreshed",
            "stats": stats
        }

    except Exception as e:
        logger.error(f"Error refreshing: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Test endpoints
@api_router.post("/test/{service}")
async def test_service(service: str):
    """Test external service connections"""

    try:
        if service == "smtp":
            reporter = EmailReporter()
            success = await reporter.test_connection()
            return {
                "service": "smtp",
                "success": success,
                "message": "SMTP connection successful" if success else "SMTP connection failed"
            }

        elif service == "github":
            from app.workers.github_api import GitHubAPISync
            sync = GitHubAPISync()
            success = sync.test_connection()
            return {
                "service": "github",
                "success": success,
                "message": "GitHub connection successful" if success else "GitHub connection failed"
            }

        elif service == "mb":
            from app.workers.mb_client import MalwareBazaarClient
            async with MalwareBazaarClient() as client:
                # Try to search for a common tag with limit 1
                samples = await client.search_by_tag("emotet", limit=1)
                success = samples is not None

            return {
                "service": "mb",
                "success": success,
                "message": "MalwareBazaar API accessible" if success else "MalwareBazaar API failed"
            }

        else:
            raise HTTPException(status_code=400, detail="Invalid service")

    except Exception as e:
        logger.error(f"Error testing service: {e}")
        return {
            "service": service,
            "success": False,
            "message": str(e)
        }

# Settings endpoints
@api_router.get("/settings")
async def get_settings(token: str = Depends(verify_token)):
    """Get current settings (sanitized)"""

    return {
        "tags": settings.tags,
        "auto_download_time": settings.auto_download_time,
        "auto_backup_time": settings.auto_backup_time,
        "auto_upload_time": settings.auto_upload_time,
        "auto_email_time": settings.auto_email_time,
        "timezone": settings.timezone,
        "github_upload_retention_days": settings.github_upload_retention_days,
        "max_daily_items_per_tag": settings.max_daily_items_per_tag,
        "dedupe_strategy": settings.dedupe_strategy,
        "disk_space_min_gb": settings.disk_space_min_gb,
        "github_repo": settings.github_repo,
        "smtp_host": settings.smtp_host,
        "smtp_port": settings.smtp_port,
        "smtp_from": settings.smtp_from,
        "smtp_to": settings.smtp_to_list
    }

# Configuration endpoints
@api_router.get("/config/view")
async def view_config():
    """View current configuration file content"""

    try:
        config_path = Path("/app/MB_config.conf")
        if not config_path.exists():
            return {
                "success": False,
                "message": "Configuration file not found"
            }

        content = config_path.read_text()
        return {
            "success": True,
            "content": content
        }

    except Exception as e:
        logger.error(f"Error reading config file: {e}")
        return {
            "success": False,
            "message": str(e)
        }

@api_router.post("/config/refresh")
async def refresh_config():
    """Reload configuration from file without restarting container"""

    try:
        # Reload the settings
        settings.reload_config()

        # Restart the scheduler with new times if it exists
        global scheduler
        if scheduler:
            scheduler.restart_with_new_config()

        logger.info("Configuration refreshed successfully")
        return {
            "success": True,
            "message": "Configuration reloaded successfully"
        }

    except Exception as e:
        logger.error(f"Error refreshing config: {e}")
        return {
            "success": False,
            "message": str(e)
        }

# Upload statistics endpoint
@api_router.get("/uploads/stats")
async def get_upload_stats():
    """Get statistics about files in upload directory"""

    try:
        from app.workers.manual_uploader import ManualUploader
        uploader = ManualUploader()
        stats = await uploader.get_upload_stats()
        return stats
    except Exception as e:
        logger.error(f"Error getting upload stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Set the scheduler reference
def set_scheduler(sched: JobScheduler):
    """Set the scheduler instance"""
    global scheduler
    scheduler = sched