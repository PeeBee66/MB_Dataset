"""GitHub sync for automatic backup uploads"""

import subprocess
import tempfile
import shutil
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Set
from app.logger import get_logger
from app.config import settings

logger = get_logger(__name__)


class GitHubSync:
    """Handles automatic GitHub sync for backup files"""

    def __init__(self):
        self.repo_url = settings.github_repo
        self.token = settings.github_token.get_secret_value() if settings.github_token else ""
        self.retention_days = settings.github_upload_retention_days
        self.branch = getattr(settings, 'git_branch', 'main')

    def _run_git_command(self, command: List[str], cwd: Path) -> tuple[bool, str]:
        """Run a git command and return success status and output"""
        try:
            env = os.environ.copy()
            # Fix SSL/TLS issues
            env['GIT_SSL_NO_VERIFY'] = 'true'
            env['GIT_SSL_CIPHER_LIST'] = 'DEFAULT@SECLEVEL=1'

            # Add git config for SSL
            if command[0] == "git" and command[1] == "clone":
                # Set SSL config before cloning
                subprocess.run(["git", "config", "--global", "http.sslVerify", "false"], env=env)
                subprocess.run(["git", "config", "--global", "http.postBuffer", "524288000"], env=env)

            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=300,
                env=env
            )
            return result.returncode == 0, result.stdout + result.stderr
        except subprocess.TimeoutExpired:
            return False, "Command timed out"
        except Exception as e:
            return False, str(e)

    def _get_backup_files_in_range(self, days: int = 1) -> Dict[str, List[Path]]:
        """Get all backup TAR files from the last N days organized by tag"""

        cutoff_date = datetime.utcnow() - timedelta(days=days)
        backup_files = {}

        for tag in settings.tags:
            tag_backup_path = settings.backup_root / tag
            if not tag_backup_path.exists():
                continue

            tag_files = []
            # Look for individual TAR files (format: YYYY_MM_DD_TAG_SHA256.tar)
            for backup_file in tag_backup_path.glob("*.tar"):
                try:
                    # Check modification time for files from last N days
                    mtime = datetime.fromtimestamp(backup_file.stat().st_mtime)
                    if mtime >= cutoff_date:
                        tag_files.append(backup_file)
                except Exception as e:
                    logger.warning(f"Error checking file {backup_file}: {e}")

            if tag_files:
                backup_files[tag] = sorted(tag_files, key=lambda x: x.stat().st_mtime)
                logger.info(f"Found {len(tag_files)} backup TAR files for tag {tag} from last {days} day(s)")

        return backup_files

    def _get_repo_files(self, repo_path: Path) -> Set[str]:
        """Get list of files currently in repository uploads folder"""

        uploads_dir = repo_path / "uploads"
        if not uploads_dir.exists():
            return set()

        repo_files = set()
        for file_path in uploads_dir.iterdir():
            if file_path.is_file():
                repo_files.add(file_path.name)

        return repo_files

    def _get_file_age_in_repo(self, repo_path: Path, filename: str) -> int:
        """Get the age of a file in the repository in days"""
        try:
            # Use git log to find when file was added
            success, output = self._run_git_command([
                "git", "log", "--format=%at", "--", f"uploads/{filename}"
            ], repo_path)

            if success and output.strip():
                # Get the first commit time (when file was added)
                timestamps = output.strip().split('\n')
                if timestamps:
                    first_commit_time = int(timestamps[-1])
                    file_date = datetime.fromtimestamp(first_commit_time)
                    age_days = (datetime.utcnow() - file_date).days
                    return age_days
        except Exception as e:
            logger.warning(f"Could not determine age of {filename}: {e}")

        return 0  # If we can't determine age, assume it's new

    async def sync_with_github(self) -> Dict:
        """Sync backup files with GitHub repository"""

        if not self.token or not self.repo_url:
            logger.error("GitHub configuration incomplete")
            return {"success": False, "error": "GitHub configuration incomplete"}

        stats = {
            "uploaded": 0,
            "deleted": 0,
            "skipped": 0,
            "failed": 0,
            "errors": []
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            repo_path = temp_path / "repo"

            try:
                # Clone repository with custom SSL settings
                clone_url = self.repo_url.replace("https://", f"https://{self.token}@")
                logger.info("Cloning repository...")

                # Use wget/curl to download as fallback if git fails
                try:
                    # First try git clone with all SSL workarounds
                    success, output = self._run_git_command([
                        "git", "-c", "http.sslVerify=false",
                        "-c", "http.postBuffer=524288000",
                        "-c", "http.version=HTTP/1.1",
                        "clone", "--depth", "1", clone_url, str(repo_path)
                    ], temp_path)

                    if not success and "TLS" in output:
                        # Fallback: Use a simpler init + remote + fetch approach
                        logger.info("Git clone failed with TLS error, trying alternative approach...")

                        # Create empty repo
                        repo_path.mkdir(exist_ok=True)
                        success, output = self._run_git_command(["git", "init"], repo_path)

                        if success:
                            # Add remote
                            success, output = self._run_git_command([
                                "git", "remote", "add", "origin", clone_url
                            ], repo_path)

                            if success:
                                # Configure SSL settings locally
                                self._run_git_command([
                                    "git", "config", "http.sslVerify", "false"
                                ], repo_path)
                                self._run_git_command([
                                    "git", "config", "http.postBuffer", "524288000"
                                ], repo_path)

                                # Fetch with depth
                                success, output = self._run_git_command([
                                    "git", "fetch", "--depth", "1", "origin", "main"
                                ], repo_path)

                                if success:
                                    # Checkout
                                    success, output = self._run_git_command([
                                        "git", "checkout", "FETCH_HEAD"
                                    ], repo_path)

                except Exception as e:
                    logger.warning(f"Alternative clone approach failed: {e}")
                    success = False
                    output = str(e)

                if not success:
                    error_msg = f"Failed to clone repository: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                logger.info("Repository cloned successfully")

                # Create uploads directory if needed
                uploads_dir = repo_path / "uploads"
                uploads_dir.mkdir(exist_ok=True)

                # Get current files in repo
                repo_files = self._get_repo_files(repo_path)
                logger.info(f"Found {len(repo_files)} files in repository")

                # Get backup files from last 24 hours for upload
                backup_files_24h = self._get_backup_files_in_range(days=1)

                # Also get files from last 14 days to check what should be in repo
                backup_files_14d = self._get_backup_files_in_range(days=self.retention_days)

                # Build set of all files that should be in repo (last 14 days)
                expected_files = set()
                for tag, files in backup_files_14d.items():
                    for backup_file in files:
                        # Store with tag prefix for organization
                        expected_files.add(f"{tag}_{backup_file.name}")

                # Upload missing files from last 24 hours
                for tag, files in backup_files_24h.items():
                    tag_dir = uploads_dir / tag
                    tag_dir.mkdir(exist_ok=True)

                    for backup_file in files:
                        repo_filename = f"{tag}_{backup_file.name}"

                        if repo_filename not in repo_files:
                            try:
                                # Check file size
                                file_size_mb = backup_file.stat().st_size / (1024 * 1024)

                                if file_size_mb > 95:  # GitHub recommends max 100MB
                                    logger.warning(f"Skipping {backup_file.name} - too large ({file_size_mb:.1f}MB)")
                                    stats["skipped"] += 1
                                    continue

                                dest_path = uploads_dir / repo_filename
                                shutil.copy2(backup_file, dest_path)
                                logger.info(f"Added {repo_filename} to repository")
                                stats["uploaded"] += 1

                            except Exception as e:
                                error_msg = f"Failed to copy {backup_file.name}: {e}"
                                logger.error(error_msg)
                                stats["failed"] += 1
                                stats["errors"].append(error_msg)
                        else:
                            logger.debug(f"File {repo_filename} already in repository")

                # Upload any missing files from the 14-day window
                for tag, files in backup_files_14d.items():
                    for backup_file in files:
                        repo_filename = f"{tag}_{backup_file.name}"

                        if repo_filename not in repo_files and repo_filename not in [f"{t}_{f.name}" for t, fs in backup_files_24h.items() for f in fs]:
                            try:
                                file_size_mb = backup_file.stat().st_size / (1024 * 1024)
                                if file_size_mb > 95:
                                    continue

                                dest_path = uploads_dir / repo_filename
                                shutil.copy2(backup_file, dest_path)
                                logger.info(f"Added missing file {repo_filename} from retention window")
                                stats["uploaded"] += 1

                            except Exception as e:
                                logger.warning(f"Failed to upload missing file {backup_file.name}: {e}")

                # Remove files older than retention period
                files_to_remove = []

                for file_name in repo_files:
                    # Check if file should still be in repo based on 14-day window
                    if file_name not in expected_files:
                        # Check actual age in repository
                        age_days = self._get_file_age_in_repo(repo_path, file_name)
                        if age_days > self.retention_days:
                            files_to_remove.append(file_name)

                # Delete old files from repo
                for file_name in files_to_remove:
                    try:
                        file_path = uploads_dir / file_name
                        file_path.unlink()
                        logger.info(f"Removed old file: {file_name}")
                        stats["deleted"] += 1
                    except Exception as e:
                        logger.error(f"Failed to remove {file_name}: {e}")

                # Check if there are changes to commit
                success, output = self._run_git_command([
                    "git", "status", "--porcelain"
                ], repo_path)

                if not output.strip():
                    logger.info("No changes to commit")
                    return {
                        "success": True,
                        "uploaded": 0,
                        "deleted": 0,
                        "message": "Repository already up to date"
                    }

                # Configure git
                self._run_git_command([
                    "git", "config", "user.email", "mb-collector@example.com"
                ], repo_path)
                self._run_git_command([
                    "git", "config", "user.name", "MB Collector"
                ], repo_path)

                # Add all changes
                success, output = self._run_git_command([
                    "git", "add", "-A"
                ], repo_path)

                if not success:
                    error_msg = f"Failed to add files: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                # Commit
                commit_msg = f"Auto-sync: +{stats['uploaded']} -{stats['deleted']} files ({datetime.utcnow().strftime('%Y-%m-%d')})"
                success, output = self._run_git_command([
                    "git", "commit", "-m", commit_msg
                ], repo_path)

                if not success:
                    error_msg = f"Failed to commit: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                # Push
                success, output = self._run_git_command([
                    "git", "push", "origin", self.branch
                ], repo_path)

                if not success:
                    error_msg = f"Failed to push: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                logger.info(
                    f"GitHub sync completed",
                    uploaded=stats["uploaded"],
                    deleted=stats["deleted"],
                    skipped=stats["skipped"]
                )

                return {
                    "success": True,
                    "uploaded": stats["uploaded"],
                    "deleted": stats["deleted"],
                    "skipped": stats["skipped"],
                    "failed": stats["failed"],
                    "message": f"Synced: +{stats['uploaded']} -{stats['deleted']} files"
                }

            except Exception as e:
                error_msg = f"GitHub sync failed: {e}"
                logger.error(error_msg)
                return {"success": False, "error": error_msg}

    async def test_connection(self) -> bool:
        """Test GitHub connection"""

        if not self.token or not self.repo_url:
            logger.error("GitHub configuration incomplete")
            return False

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            try:
                clone_url = self.repo_url.replace("https://", f"https://{self.token}@")
                success, output = self._run_git_command([
                    "git", "clone", "--depth", "1", clone_url, "test_repo"
                ], temp_path)

                if success:
                    logger.info(f"GitHub connection successful")
                    return True
                else:
                    logger.error(f"GitHub connection failed: {output}")
                    return False

            except Exception as e:
                logger.error(f"GitHub connection test failed: {e}")
                return False