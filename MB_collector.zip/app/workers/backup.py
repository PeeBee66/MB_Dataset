"""Backup worker for creating TAR archives"""

import tarfile
import shutil
from pathlib import Path
from datetime import datetime
from typing import List, Optional
from app.logger import get_logger
from app.config import settings
from app.models import Sample, db
import os

logger = get_logger(__name__)


class BackupWorker:
    """Creates TAR backups of samples"""

    def __init__(self):
        pass

    async def create_backup(
        self,
        sample: Sample,
        tag: str
    ) -> Optional[Path]:
        """Create a password-protected ZIP backup of a sample directory"""

        try:
            sha256 = sample.sha256
            sample_dir = settings.get_sample_path(tag, sha256)

            if not sample_dir.exists():
                logger.warning(f"Sample directory not found: {sample_dir}")
                return None

            # Create backup directory
            backup_dir = settings.get_backup_tag_path(tag)
            backup_dir.mkdir(parents=True, exist_ok=True)

            # Define backup path with date
            date_str = datetime.utcnow().strftime("%Y_%m_%d")
            backup_path = settings.get_backup_path(tag, sha256, date_str)

            # Check if backup already exists and is up to date
            if backup_path.exists():
                backup_mtime = backup_path.stat().st_mtime
                sample_mtime = max(
                    f.stat().st_mtime for f in sample_dir.rglob("*") if f.is_file()
                )

                if backup_mtime >= sample_mtime:
                    logger.info(f"Backup already up to date: {sha256}")
                    return backup_path

            logger.info(f"Creating backup for sample: {sha256}")

            # Create temporary TAR file
            temp_path = backup_path.with_suffix('.tmp')

            with tarfile.open(temp_path, 'w:gz') as tf:
                # Add all files from sample directory
                for file_path in sample_dir.rglob("*"):
                    if file_path.is_file():
                        arcname = file_path.relative_to(sample_dir.parent)
                        tf.add(file_path, arcname=str(arcname))

                        logger.debug(
                            f"Added to backup",
                            file=str(file_path),
                            arcname=str(arcname)
                        )

            # Verify the TAR file
            if not self._verify_backup(temp_path):
                logger.error(f"Backup verification failed: {sha256}")
                temp_path.unlink(missing_ok=True)
                return None

            # Move to final location
            temp_path.rename(backup_path)

            # Set restrictive permissions
            backup_path.chmod(0o600)

            logger.info(
                f"Backup created successfully",
                sha256=sha256,
                size=backup_path.stat().st_size,
                path=str(backup_path)
            )

            return backup_path

        except Exception as e:
            logger.error(
                f"Error creating backup",
                sha256=sample.sha256,
                error=str(e)
            )
            return None

    def _verify_backup(self, tar_path: Path) -> bool:
        """Verify the integrity of a backup TAR file"""

        try:
            with tarfile.open(tar_path, 'r:gz') as tf:
                # Check that files are present
                members = tf.getmembers()
                if len(members) == 0:
                    logger.error("Backup TAR is empty")
                    return False

                # Verify all members can be read
                for member in members:
                    if member.isfile():
                        try:
                            tf.extractfile(member)
                        except Exception as e:
                            logger.error(f"Cannot read member {member.name}: {e}")
                            return False

                return True

        except Exception as e:
            logger.error(f"Backup verification error: {str(e)}")
            return False

    async def backup_all_pending(self, db_session) -> dict:
        """Backup all samples that don't have backups - works directly from filesystem"""

        stats = {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "skipped": 0,
            "total_size": 0
        }

        try:
            # Work directly from filesystem instead of database
            pending_samples = []

            # Check each tag directory
            for tag_name in settings.tags:
                tag_path = settings.get_tag_path(tag_name)
                if not tag_path.exists():
                    continue

                # Check each sample directory
                for sample_dir in tag_path.iterdir():
                    if not sample_dir.is_dir():
                        continue

                    sha256 = sample_dir.name
                    if len(sha256) != 64:
                        continue

                    # Check if backup already exists (new .tar format)
                    backup_path = settings.get_backup_path(tag_name, sha256)
                    if backup_path.exists():
                        continue

                    # Check old .zip format
                    old_backup = settings.get_backup_tag_path(tag_name) / f"{sha256}.zip"
                    if old_backup.exists():
                        continue

                    # Add to pending list
                    pending_samples.append({
                        'sha256': sha256,
                        'tag': tag_name,
                        'path': sample_dir
                    })

            logger.info(f"Found {len(pending_samples)} samples pending backup")

            for sample_info in pending_samples:
                stats["processed"] += 1

                sha256 = sample_info['sha256']
                tag_name = sample_info['tag']

                # Create simple object for create_backup
                class SimpleSample:
                    def __init__(self, sha256):
                        self.sha256 = sha256

                sample = SimpleSample(sha256)

                # Create backup
                backup_path = await self.create_backup(sample, tag_name)

                if backup_path:
                    stats["success"] += 1
                    stats["total_size"] += backup_path.stat().st_size

                    # Try to update database if sample exists
                    if db_session:
                        db_sample = db_session.query(Sample).filter_by(sha256=sha256).first()
                        if db_sample:
                            db_sample.has_backup = True
                            db_sample.backup_path = str(backup_path)
                            db_session.commit()
                else:
                    stats["failed"] += 1

            # Skip database update check since we're working from filesystem

        except Exception as e:
            logger.error(f"Error in backup_all_pending: {str(e)}")

        logger.info(
            f"Backup job completed",
            **stats
        )

        return stats

    async def cleanup_orphaned_backups(self, db_session) -> int:
        """Remove backup files that no longer have corresponding samples"""

        cleaned = 0

        try:
            # Get all backup files
            backup_root = settings.backup_root
            if not backup_root.exists():
                return 0

            for tag_dir in backup_root.iterdir():
                if not tag_dir.is_dir():
                    continue

                for backup_file in tag_dir.glob("*.zip"):
                    sha256 = backup_file.stem

                    # Check if sample exists
                    sample = db_session.query(Sample).filter_by(sha256=sha256).first()

                    if not sample:
                        logger.info(f"Removing orphaned backup: {backup_file}")
                        backup_file.unlink(missing_ok=True)
                        cleaned += 1

        except Exception as e:
            logger.error(f"Error cleaning orphaned backups: {str(e)}")

        if cleaned > 0:
            logger.info(f"Cleaned {cleaned} orphaned backup files")

        return cleaned

    def get_backup_stats(self, tag: Optional[str] = None) -> dict:
        """Get statistics about backups"""

        stats = {
            "total_backups": 0,
            "total_size": 0,
            "by_tag": {}
        }

        backup_root = settings.backup_root
        if not backup_root.exists():
            return stats

        if tag:
            # Stats for specific tag
            tag_dir = backup_root / tag
            if tag_dir.exists():
                backups = list(tag_dir.glob("*.zip"))
                stats["total_backups"] = len(backups)
                stats["total_size"] = sum(f.stat().st_size for f in backups)
                stats["by_tag"][tag] = {
                    "count": len(backups),
                    "size": stats["total_size"]
                }
        else:
            # Stats for all tags
            for tag_dir in backup_root.iterdir():
                if not tag_dir.is_dir():
                    continue

                tag_name = tag_dir.name
                backups = list(tag_dir.glob("*.zip"))
                tag_size = sum(f.stat().st_size for f in backups)

                stats["by_tag"][tag_name] = {
                    "count": len(backups),
                    "size": tag_size
                }
                stats["total_backups"] += len(backups)
                stats["total_size"] += tag_size

        return stats