"""Git-based uploader for large backup files"""

import subprocess
import tempfile
import shutil
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from app.logger import get_logger
from app.config import settings

logger = get_logger(__name__)


class GitUploader:
    """Handles Git uploads for daily backup collections"""

    def __init__(self):
        self.repo_url = settings.github_repo
        self.token = settings.github_token.get_secret_value() if settings.github_token else ""
        self.retention_days = settings.github_upload_retention_days
        self.upload_path = settings.upload_root
        self.branch = getattr(settings, 'git_branch', 'main')

    async def collect_daily_backups(self) -> List[Path]:
        """Collect last 24 hours of backups into tag-specific tar files"""

        collected_tars = []

        try:
            # Calculate time window (last 24 hours from backup time)
            now = datetime.utcnow()
            yesterday = now - timedelta(days=1)
            date_str = now.strftime("%Y_%m_%d")

            logger.info(f"Collecting backups from last 24 hours per tag")

            # Ensure upload directory exists
            self.upload_path.mkdir(parents=True, exist_ok=True)

            # Create separate tar for each tag
            for tag in settings.tags:
                tag_backup_path = settings.backup_root / tag
                if not tag_backup_path.exists():
                    continue

                # Find tar files from last 24 hours for this tag
                tag_backup_files = []
                for tar_file in tag_backup_path.glob("*.tar"):
                    # Check if file was created in last 24 hours
                    mtime = datetime.fromtimestamp(tar_file.stat().st_mtime)
                    if mtime >= yesterday:
                        tag_backup_files.append(tar_file)

                if not tag_backup_files:
                    logger.debug(f"No recent backups for tag: {tag}")
                    continue

                # Create tag-specific tar
                import tarfile
                tag_tar = self.upload_path / f"{date_str}_{tag.upper()}_MB_UPLOAD.tar"

                with tarfile.open(tag_tar, 'w') as tar:
                    for backup_file in tag_backup_files:
                        tar.add(backup_file, arcname=backup_file.name)

                file_size = tag_tar.stat().st_size
                logger.info(
                    f"Tag tar created",
                    tag=tag,
                    filename=tag_tar.name,
                    size=file_size,
                    files_included=len(tag_backup_files)
                )

                collected_tars.append(tag_tar)

            if not collected_tars:
                logger.warning("No backup files found from last 24 hours")

            return collected_tars

        except Exception as e:
            logger.error(f"Error collecting daily backups: {e}")
            return []

    def _run_git_command(self, command: List[str], cwd: Path) -> tuple[bool, str]:
        """Run a git command and return success status and output"""
        try:
            # Set environment to disable SSL verification
            env = os.environ.copy()
            env['GIT_SSL_NO_VERIFY'] = 'true'

            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=300,
                env=env
            )
            return result.returncode == 0, result.stdout + result.stderr
        except subprocess.TimeoutExpired:
            return False, "Command timed out"
        except Exception as e:
            return False, str(e)

    def _split_large_file(self, file_path: Path, max_size_mb: int = 45) -> List[Path]:
        """Split a large file into smaller chunks"""

        file_size = file_path.stat().st_size
        max_size_bytes = max_size_mb * 1024 * 1024

        if file_size <= max_size_bytes:
            return [file_path]

        split_files = []
        chunk_num = 0

        try:
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(max_size_bytes)
                    if not chunk:
                        break

                    chunk_num += 1
                    chunk_path = file_path.parent / f"{file_path.stem}.part{chunk_num:03d}{file_path.suffix}"

                    with open(chunk_path, 'wb') as chunk_file:
                        chunk_file.write(chunk)

                    split_files.append(chunk_path)
                    logger.info(f"Created chunk {chunk_num} for {file_path.name}")

            return split_files

        except Exception as e:
            logger.error(f"Failed to split file {file_path.name}: {e}")
            return [file_path]  # Return original file if splitting fails

    async def upload_to_git(self, file_paths: List[Path]) -> Dict:
        """Upload files to Git repository using git push"""

        if not self.token or not self.repo_url:
            logger.error("Git configuration incomplete")
            return {"success": False, "error": "Git configuration incomplete"}

        stats = {"uploaded": 0, "failed": 0, "errors": [], "split_files": []}

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            repo_path = temp_path / "repo"

            try:
                # Clone repository
                clone_url = self.repo_url.replace("https://", f"https://{self.token}@")
                success, output = self._run_git_command([
                    "git", "clone", "--depth", "1", clone_url, str(repo_path)
                ], temp_path)

                if not success:
                    error_msg = f"Failed to clone repository: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                logger.info("Repository cloned successfully")

                # Create uploads directory if it doesn't exist
                uploads_dir = repo_path / "uploads"
                uploads_dir.mkdir(exist_ok=True)

                # Process files
                files_to_upload = []
                for file_path in file_paths:
                    file_size_mb = file_path.stat().st_size / (1024 * 1024)

                    if file_size_mb > 45:  # Split files larger than 45MB
                        logger.info(f"File {file_path.name} is {file_size_mb:.1f}MB, splitting...")
                        split_files = self._split_large_file(file_path)
                        files_to_upload.extend(split_files)
                        stats["split_files"].append(file_path.name)

                        # Create a manifest file for split files
                        if len(split_files) > 1:
                            manifest_path = file_path.parent / f"{file_path.stem}.manifest"
                            with open(manifest_path, 'w') as f:
                                f.write(f"# Manifest for {file_path.name}\n")
                                f.write(f"# Total parts: {len(split_files)}\n")
                                f.write(f"# Original size: {file_path.stat().st_size} bytes\n")
                                f.write(f"# To reassemble: cat {file_path.stem}.part* > {file_path.name}\n")
                                for split_file in split_files:
                                    f.write(f"{split_file.name}\n")
                            files_to_upload.append(manifest_path)
                    else:
                        files_to_upload.append(file_path)

                # Copy files to repository
                for file_path in files_to_upload:
                    try:
                        dest_path = uploads_dir / file_path.name
                        shutil.copy2(file_path, dest_path)
                        logger.info(f"Copied {file_path.name} to repository")
                        stats["uploaded"] += 1
                    except Exception as e:
                        error_msg = f"Failed to copy {file_path.name}: {e}"
                        logger.error(error_msg)
                        stats["failed"] += 1
                        stats["errors"].append(error_msg)

                if stats["uploaded"] == 0:
                    return {"success": False, "error": "No files were copied"}

                # Configure git user (required for commits)
                self._run_git_command([
                    "git", "config", "user.email", "mb-collector@example.com"
                ], repo_path)
                self._run_git_command([
                    "git", "config", "user.name", "MB Collector"
                ], repo_path)

                # Add files
                success, output = self._run_git_command([
                    "git", "add", "uploads/"
                ], repo_path)

                if not success:
                    error_msg = f"Failed to add files: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                # Check if there are changes to commit
                success, output = self._run_git_command([
                    "git", "diff", "--cached", "--exit-code"
                ], repo_path)

                if success:  # No changes to commit
                    logger.info("No changes to commit")
                    return {"success": True, "uploaded": 0, "message": "No changes"}

                # Commit changes
                commit_msg = f"Upload daily backup: {datetime.utcnow().strftime('%Y-%m-%d')}"
                success, output = self._run_git_command([
                    "git", "commit", "-m", commit_msg
                ], repo_path)

                if not success:
                    error_msg = f"Failed to commit: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                # Push changes
                success, output = self._run_git_command([
                    "git", "push", "origin", self.branch
                ], repo_path)

                if not success:
                    error_msg = f"Failed to push: {output}"
                    logger.error(error_msg)
                    return {"success": False, "error": error_msg}

                # Clean up split files after successful upload
                for file_path in file_paths:
                    if file_path.name in stats["split_files"]:
                        # Remove split parts
                        for part_file in file_path.parent.glob(f"{file_path.stem}.part*"):
                            part_file.unlink()
                            logger.debug(f"Cleaned up split file: {part_file.name}")

                        # Remove manifest
                        manifest_file = file_path.parent / f"{file_path.stem}.manifest"
                        if manifest_file.exists():
                            manifest_file.unlink()

                logger.info(f"Successfully pushed {stats['uploaded']} files to repository")
                return {
                    "success": True,
                    "uploaded": stats["uploaded"],
                    "failed": stats["failed"],
                    "split_files": stats["split_files"],
                    "message": f"Uploaded {stats['uploaded']} files"
                }

            except Exception as e:
                error_msg = f"Git upload failed: {e}"
                logger.error(error_msg)
                return {"success": False, "error": error_msg}

    async def cleanup_old_uploads(self) -> int:
        """Remove uploads older than retention days from Git repository"""

        if not self.token or not self.repo_url:
            logger.warning("Git configuration incomplete, skipping cleanup")
            return 0

        deleted_count = 0
        cutoff_date = datetime.utcnow() - timedelta(days=self.retention_days)

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            repo_path = temp_path / "repo"

            try:
                # Clone repository
                clone_url = self.repo_url.replace("https://", f"https://{self.token}@")
                success, output = self._run_git_command([
                    "git", "clone", "--depth", "1", clone_url, str(repo_path)
                ], temp_path)

                if not success:
                    logger.warning(f"Could not clone repository for cleanup: {output}")
                    return 0

                uploads_dir = repo_path / "uploads"
                if not uploads_dir.exists():
                    return 0

                files_to_delete = []

                # Find old files
                for file_path in uploads_dir.glob("*.tar"):
                    try:
                        # Parse date from filename (YYYY_MM_DD_TAG_MB_UPLOAD.tar)
                        date_part = '_'.join(file_path.stem.split('_')[:3])
                        file_date = datetime.strptime(date_part, "%Y_%m_%d")

                        if file_date < cutoff_date:
                            files_to_delete.append(file_path)

                    except ValueError:
                        # Filename doesn't match expected format, skip
                        logger.debug(f"Skipping file with unexpected name: {file_path.name}")
                        continue

                if not files_to_delete:
                    return 0

                # Delete files
                for file_path in files_to_delete:
                    file_path.unlink()
                    logger.info(f"Deleted old upload: {file_path.name}")
                    deleted_count += 1

                # Configure git user
                self._run_git_command([
                    "git", "config", "user.email", "mb-collector@example.com"
                ], repo_path)
                self._run_git_command([
                    "git", "config", "user.name", "MB Collector"
                ], repo_path)

                # Commit deletions
                self._run_git_command(["git", "add", "-A"], repo_path)

                # Check if there are changes to commit
                success, output = self._run_git_command([
                    "git", "diff", "--cached", "--exit-code"
                ], repo_path)

                if not success:  # There are changes
                    commit_msg = f"Remove old uploads: {deleted_count} files"
                    success, output = self._run_git_command([
                        "git", "commit", "-m", commit_msg
                    ], repo_path)

                    if success:
                        # Push changes
                        self._run_git_command([
                            "git", "push", "origin", self.branch
                        ], repo_path)

            except Exception as e:
                logger.error(f"Error cleaning up old uploads: {e}")

        return deleted_count

    async def run_upload_job(self) -> Dict:
        """Run the complete upload job"""

        stats = {
            "collected": 0,
            "uploaded": 0,
            "failed": 0,
            "deleted": 0,
            "error": None
        }

        try:
            # Step 1: Collect last 24h backups into tag-specific tars
            tar_files = await self.collect_daily_backups()

            if not tar_files:
                stats["error"] = "No backups collected"
                return stats

            stats["collected"] = len(tar_files)

            # Step 2: Upload all tars to Git repository
            upload_result = await self.upload_to_git(tar_files)

            if upload_result["success"]:
                stats["uploaded"] = upload_result.get("uploaded", 0)
                stats["failed"] = upload_result.get("failed", 0)
            else:
                stats["error"] = upload_result["error"]
                stats["failed"] = len(tar_files)

            # Step 3: Cleanup old uploads (14 day retention)
            if stats["uploaded"] > 0:
                deleted = await self.cleanup_old_uploads()
                stats["deleted"] = deleted

            logger.info(
                "Upload job completed",
                collected=stats["collected"],
                uploaded=stats["uploaded"],
                failed=stats["failed"],
                deleted=stats["deleted"]
            )

        except Exception as e:
            stats["error"] = str(e)
            logger.error(f"Upload job failed: {e}")

        return stats

    async def test_connection(self) -> bool:
        """Test Git repository connection"""

        if not self.token or not self.repo_url:
            logger.error("Git configuration incomplete")
            return False

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            try:
                # Test clone
                clone_url = self.repo_url.replace("https://", f"https://{self.token}@")
                success, output = self._run_git_command([
                    "git", "clone", "--depth", "1", clone_url, "test_repo"
                ], temp_path)

                if success:
                    logger.info(f"Git connection successful to {self.repo_url}")
                    return True
                else:
                    logger.error(f"Git connection failed: {output}")
                    return False

            except Exception as e:
                logger.error(f"Git connection test failed: {e}")
                return False