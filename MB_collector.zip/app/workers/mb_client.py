"""MalwareBazaar API client with comprehensive sample collection"""

import httpx
import json
import hashlib
import pyzipper
import io
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
from app.logger import get_logger
from app.config import settings
from app.models import Sample, Tag, Artifact, ArtifactType
import asyncio
import time

logger = get_logger(__name__)

# Safety notice
SAFETY_WARNING = """
⚠️ DEFENSIVE RESEARCH USE ONLY ⚠️
This tool is for defensive security research purposes only.
Do NOT execute any downloaded samples.
All samples must be stored in quarantined volumes with noexec mount options.
Use in accordance with local laws and MalwareBazaar Terms of Service.
"""


class MalwareBazaarClient:
    """Safe client for MalwareBazaar API interactions"""

    def __init__(self):
        self.api_url = settings.api_url
        self.api_key = settings.api_key.get_secret_value()
        self.client = httpx.AsyncClient(
            timeout=30.0,
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
            headers={"Auth-Key": self.api_key}
        )
        self.rate_limit_delay = 1.0  # Initial delay between requests
        self.max_retries = 3

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.aclose()

    async def _make_request(
        self,
        endpoint: str,
        data: Dict[str, Any],
        retry_count: int = 0
    ) -> Optional[Dict]:
        """Make API request with rate limiting and retry logic"""

        try:
            url = f"{self.api_url}{endpoint}"

            # Add rate limiting delay
            await asyncio.sleep(self.rate_limit_delay)

            response = await self.client.post(url, data=data)

            # Handle rate limiting
            if response.status_code == 429:
                if retry_count < self.max_retries:
                    # Exponential backoff
                    wait_time = (2 ** retry_count) * 2
                    logger.warning(
                        "Rate limited, waiting",
                        wait_seconds=wait_time,
                        retry=retry_count + 1
                    )
                    await asyncio.sleep(wait_time)
                    return await self._make_request(endpoint, data, retry_count + 1)
                else:
                    logger.error("Max retries exceeded for rate limiting")
                    return None

            response.raise_for_status()
            return response.json()

        except httpx.HTTPError as e:
            logger.error(
                "API request failed",
                endpoint=endpoint,
                error=str(e),
                retry_count=retry_count
            )

            if retry_count < self.max_retries:
                await asyncio.sleep(2 ** retry_count)
                return await self._make_request(endpoint, data, retry_count + 1)

            return None

    async def search_by_tag(
        self,
        tag: str,
        limit: int = 100,
        since: Optional[datetime] = None
    ) -> List[Dict]:
        """Search for samples by tag"""

        logger.info(f"Searching for samples with tag: {tag}")

        data = {
            "query": "get_taginfo",
            "tag": tag,
            "limit": limit
        }

        result = await self._make_request("", data)

        if not result or result.get("query_status") != "ok":
            logger.warning(f"No results for tag: {tag}")
            return []

        samples = result.get("data", [])

        # Filter by date if specified
        if since:
            filtered = []
            for sample in samples:
                # Parse first_seen date from MB
                try:
                    first_seen = datetime.fromisoformat(
                        sample.get("first_seen", "").replace(" ", "T")
                    )
                    if first_seen >= since:
                        filtered.append(sample)
                except (ValueError, TypeError):
                    # Include if we can't parse the date
                    filtered.append(sample)
            samples = filtered

        logger.info(f"Found {len(samples)} samples for tag: {tag}")
        return samples

    async def get_sample_info(self, sha256_hash: str) -> Optional[Dict]:
        """Get detailed information about a sample"""

        data = {
            "query": "get_info",
            "hash": sha256_hash
        }

        result = await self._make_request("", data)

        if not result or result.get("query_status") != "ok":
            logger.warning(f"Could not get info for hash: {sha256_hash}")
            return None

        return result.get("data", [{}])[0] if result.get("data") else None

    async def download_sample(
        self,
        sha256_hash: str,
        sample_folder: Path,
        filename: str = None
    ) -> tuple[bool, Optional[str]]:
        """Download a malware sample and extract with proper naming"""

        if not settings.enable_sample_download:
            logger.info(f"Sample download disabled in settings: {sha256_hash}")
            # Create a dummy file for testing
            dummy_path = sample_folder / (filename or "sample_placeholder.bin")
            dummy_path.write_text(f"SAMPLE_PLACEHOLDER_{sha256_hash}")
            return True, filename or "sample_placeholder.bin"

        logger.info(f"Downloading sample: {sha256_hash}")

        data = {
            "query": "get_file",
            "sha256_hash": sha256_hash
        }

        try:
            url = f"{self.api_url}"
            response = await self.client.post(url, data=data, timeout=60.0)

            if response.status_code != 200:
                logger.error(f"Failed to download sample: {sha256_hash}")
                return False, None

            # Verify the response is a ZIP file (MalwareBazaar packages samples)
            if not response.content.startswith(b'PK'):
                logger.error(f"Invalid response format for sample: {sha256_hash}")
                return False, None

            # Validate the ZIP file (MalwareBazaar uses password "infected")
            try:
                with pyzipper.AESZipFile(io.BytesIO(response.content)) as zip_ref:
                    # Set the password for the encrypted ZIP
                    zip_ref.setpassword(b"infected")
                    zip_files = zip_ref.namelist()
                    if not zip_files:
                        logger.error(f"Empty ZIP file for sample: {sha256_hash}")
                        return False, None

                    # Get the actual sample file (skip directories) for filename reference
                    sample_file = None
                    for file in zip_files:
                        if not file.endswith('/') and not file.startswith('__MACOSX'):
                            sample_file = file
                            break

                    if not sample_file:
                        logger.error(f"No sample file found in ZIP: {sha256_hash}")
                        return False, None

                    # Validate that password works by checking file info (no extraction)
                    try:
                        file_info = zip_ref.getinfo(sample_file)
                        if file_info.file_size == 0:
                            logger.error(f"Empty sample file in ZIP: {sha256_hash}")
                            return False, None
                    except Exception as e:
                        logger.error(f"Failed to validate ZIP file {sample_file}: {e}")
                        return False, None

                    # Use provided filename or original filename
                    final_filename = filename or sample_file

                    # Create zip.password.txt
                    password_file = sample_folder / "zip.password.txt"
                    password_file.write_text("infected")

                    # Save only the original encrypted ZIP file
                    zip_path = sample_folder / f"{sha256_hash}.zip"
                    zip_path.write_bytes(response.content)
                    zip_path.chmod(0o400)

                    logger.info(
                        f"Sample ZIP downloaded",
                        sha256=sha256_hash,
                        filename=final_filename,
                        zip_size=len(response.content),
                        path=str(zip_path)
                    )

                    return True, final_filename

            except zipfile.BadZipFile:
                logger.error(f"Invalid ZIP file for sample: {sha256_hash}")
                return False, None

        except Exception as e:
            logger.error(
                f"Error downloading sample",
                sha256=sha256_hash,
                error=str(e)
            )
            return False, None

    def extract_iocs(self, sample_info: Dict) -> List[str]:
        """Extract IOCs from sample metadata"""

        iocs = []

        # Extract from various fields
        if "tags" in sample_info:
            for tag in sample_info.get("tags", []):
                iocs.append(f"TAG: {tag}")

        if "sha256_hash" in sample_info:
            iocs.append(f"SHA256: {sample_info['sha256_hash']}")

        if "sha1_hash" in sample_info:
            iocs.append(f"SHA1: {sample_info['sha1_hash']}")

        if "md5_hash" in sample_info:
            iocs.append(f"MD5: {sample_info['md5_hash']}")

        if "imphash" in sample_info and sample_info["imphash"]:
            iocs.append(f"IMPHASH: {sample_info['imphash']}")

        if "ssdeep" in sample_info and sample_info["ssdeep"]:
            iocs.append(f"SSDEEP: {sample_info['ssdeep']}")

        if "file_type" in sample_info:
            iocs.append(f"FILE_TYPE: {sample_info['file_type']}")

        if "signature" in sample_info and sample_info["signature"]:
            iocs.append(f"SIGNATURE: {sample_info['signature']}")

        # Extract network IOCs from intelligence if available
        if "intelligence" in sample_info:
            intel = sample_info["intelligence"]

            if "downloads" in intel:
                for download in intel["downloads"]:
                    if "url" in download:
                        iocs.append(f"URL: {download['url']}")

            if "uploads" in intel:
                for upload in intel["uploads"]:
                    if "url" in upload:
                        iocs.append(f"C2_URL: {upload['url']}")

        return iocs

    def get_yara_rules(self, sample_info: Dict) -> Optional[str]:
        """Extract or generate YARA rules for the sample"""

        # Check if YARA rules are provided
        if "yara_rules" in sample_info and sample_info["yara_rules"]:
            return sample_info["yara_rules"]

        # Generate basic YARA rule
        rule = f"""
rule MB_{sample_info.get('sha256_hash', 'unknown')[:8]}
{{
    meta:
        description = "Auto-generated rule for {sample_info.get('signature', 'malware')}"
        author = "MB-Collector"
        date = "{datetime.utcnow().isoformat()}"
        sha256 = "{sample_info.get('sha256_hash', '')}"

    strings:
        $magic = {{ 4D 5A }}  // MZ header

    condition:
        $magic at 0 and
        filesize < 10MB
}}
"""
        return rule

    def generate_intel_file(self, sample_info: Dict, sha256: str, filename: str = None) -> str:
        """Generate comprehensive intel file content"""

        intel_content = f"""# MalwareBazaar Intelligence Report
# Generated: {datetime.utcnow().isoformat()}Z
# Sample: {sha256}

## Basic Information
SHA256: {sample_info.get('sha256_hash', sha256)}
SHA1: {sample_info.get('sha1_hash', 'N/A')}
MD5: {sample_info.get('md5_hash', 'N/A')}
Filename: {filename or sample_info.get('file_name', 'N/A')}
File Size: {sample_info.get('file_size', 'N/A')} bytes
File Type: {sample_info.get('file_type', 'N/A')}
MIME Type: {sample_info.get('file_type_mime', 'N/A')}
SSDeep: {sample_info.get('ssdeep', 'N/A')}
Imphash: {sample_info.get('imphash', 'N/A')}
TLSH: {sample_info.get('tlsh', 'N/A')}

## MalwareBazaar Metadata
First Seen: {sample_info.get('first_seen', 'N/A')}
Last Seen: {sample_info.get('last_seen', 'N/A')}
Signature: {sample_info.get('signature', 'N/A')}
Reporter: {sample_info.get('reporter', 'N/A')}
Comment: {sample_info.get('comment', 'N/A')}
Delivery Method: {sample_info.get('delivery_method', 'N/A')}
Origin Country: {sample_info.get('origin_country', 'N/A')}

## Tags
"""

        if 'tags' in sample_info and sample_info['tags']:
            for tag in sample_info['tags']:
                intel_content += f"- {tag}\n"
        else:
            intel_content += "No tags available\n"

        intel_content += "\n## Intelligence\n"

        if 'intelligence' in sample_info and sample_info['intelligence']:
            intel = sample_info['intelligence']

            if 'clamav' in intel and intel['clamav']:
                # Handle clamav data - could be list, dict, or string
                if isinstance(intel['clamav'], list):
                    # Convert any dict items to strings
                    clamav_items = [str(item) if not isinstance(item, str) else item for item in intel['clamav']]
                    intel_content += f"ClamAV: {', '.join(clamav_items)}\n"
                elif isinstance(intel['clamav'], dict):
                    intel_content += "ClamAV:\n"
                    for key, value in intel['clamav'].items():
                        intel_content += f"  {key}: {value}\n"
                else:
                    intel_content += f"ClamAV: {intel['clamav']}\n"

            if 'downloads' in intel and intel['downloads']:
                intel_content += "\n### Download URLs:\n"
                for download in intel['downloads']:
                    intel_content += f"- {download}\n"

            if 'uploads' in intel and intel['uploads']:
                intel_content += "\n### Upload/C2 URLs:\n"
                for upload in intel['uploads']:
                    intel_content += f"- {upload}\n"

            if 'domains' in intel and intel['domains']:
                intel_content += "\n### Domains:\n"
                for domain in intel['domains']:
                    intel_content += f"- {domain}\n"

            if 'ips' in intel and intel['ips']:
                intel_content += "\n### IP Addresses:\n"
                for ip in intel['ips']:
                    intel_content += f"- {ip}\n"
        else:
            intel_content += "No intelligence data available\n"

        if 'vendor_intel' in sample_info and sample_info['vendor_intel']:
            intel_content += "\n## Vendor Intelligence\n"
            for vendor, data in sample_info['vendor_intel'].items():
                intel_content += f"\n### {vendor}:\n"
                if isinstance(data, dict):
                    for key, value in data.items():
                        intel_content += f"  {key}: {value}\n"
                else:
                    intel_content += f"  {data}\n"

        # Add IOCs section
        iocs = self.extract_iocs(sample_info)
        if iocs:
            intel_content += "\n## Indicators of Compromise (IOCs)\n"
            for ioc in iocs:
                intel_content += f"- {ioc}\n"

        intel_content += f"\n## Additional Information\n"
        intel_content += f"Anonymous: {'Yes' if sample_info.get('anonymous', 0) == 1 else 'No'}\n"
        intel_content += f"Download URL: {sample_info.get('urlhaus_download', 'N/A')}\n"

        if 'code_sign' in sample_info and sample_info['code_sign']:
            # Handle code_sign data - could be list of dicts or strings
            if isinstance(sample_info['code_sign'], list):
                code_signs = []
                for item in sample_info['code_sign']:
                    if isinstance(item, dict):
                        # Format dict items
                        code_signs.append(json.dumps(item))
                    else:
                        code_signs.append(str(item))
                if code_signs:
                    intel_content += f"Code Signing: {', '.join(code_signs)}\n"
            elif isinstance(sample_info['code_sign'], dict):
                intel_content += "Code Signing:\n"
                for key, value in sample_info['code_sign'].items():
                    intel_content += f"  {key}: {value}\n"
            else:
                intel_content += f"Code Signing: {sample_info['code_sign']}\n"

        intel_content += f"\n---\nReport generated by MalwareBazaar Collector\n"
        intel_content += f"Data source: https://bazaar.abuse.ch/\n"
        intel_content += SAFETY_WARNING

        return intel_content

    async def process_sample(
        self,
        sample_info: Dict,
        tag: str,
        db_session
    ) -> bool:
        """Process a single sample with comprehensive data collection"""

        sha256 = sample_info.get("sha256_hash", "")
        if not sha256:
            logger.warning("Sample missing SHA256 hash")
            return False

        try:
            # Check if sample already exists
            existing = db_session.query(Sample).filter_by(sha256=sha256).first()

            if existing and settings.dedupe_strategy == "sha256_only" and not settings.force_redownload:
                logger.info(f"Sample already exists: {sha256}")
                existing.last_seen = datetime.utcnow()
                db_session.commit()
                return True
            elif existing and settings.force_redownload:
                logger.info(f"Force re-downloading sample: {sha256}")

            # Create SHA256-named folder in download directory (overwrite if exists)
            sample_folder = settings.download_root / tag / sha256

            # Remove existing folder to ensure fresh data on re-runs
            if sample_folder.exists():
                import shutil
                logger.info(f"Removing existing sample folder for fresh download: {sample_folder}")
                shutil.rmtree(sample_folder)

            sample_folder.mkdir(parents=True, exist_ok=True)

            logger.info(f"Processing sample in folder: {sample_folder}")

            # Get detailed sample information if not already complete
            if not sample_info.get('intelligence'):
                detailed_info = await self.get_sample_info(sha256)
                if detailed_info:
                    sample_info.update(detailed_info)

            # Download and extract the sample
            original_filename = sample_info.get('file_name', f"{sha256}.bin")
            download_success, actual_filename = await self.download_sample(
                sha256, sample_folder, original_filename
            )

            if not download_success:
                logger.warning(f"Failed to download sample: {sha256}")
                # Continue processing even if download fails
                actual_filename = original_filename

            # Generate comprehensive intel file
            intel_content = self.generate_intel_file(sample_info, sha256, actual_filename)
            intel_path = sample_folder / f"{sha256}.intel"
            intel_path.write_text(intel_content)
            intel_path.chmod(0o600)

            # Write README warning
            readme_path = sample_folder / "README.txt"
            readme_path.write_text(SAFETY_WARNING)

            # Save metadata JSON
            meta_path = sample_folder / f"{sha256}.json"
            meta_path.write_text(json.dumps(sample_info, indent=2))
            meta_path.chmod(0o600)

            # Extract and save IOCs
            iocs = self.extract_iocs(sample_info)
            if iocs:
                iocs_path = sample_folder / f"{sha256}.iocs"
                iocs_path.write_text("\n".join(iocs))
                iocs_path.chmod(0o600)

            # Save YARA rules
            yara = self.get_yara_rules(sample_info)
            if yara:
                yara_path = sample_folder / f"{sha256}.yara"
                yara_path.write_text(yara)
                yara_path.chmod(0o600)

            # Update database if using it
            tag_obj = db_session.query(Tag).filter_by(name=tag).first()
            if tag_obj:
                if existing:
                    existing.last_seen = datetime.utcnow()
                    sample_record = existing
                else:
                    sample_record = Sample(
                        sha256=sha256,
                        tag_id=tag_obj.id,
                        filename=actual_filename,
                        size=sample_info.get("file_size", 0),
                        source_url=sample_info.get("urlhaus_download", ""),
                        stored_path=str(sample_folder),
                        mb_signature=sample_info.get("signature", ""),
                        mb_reporter=sample_info.get("reporter", ""),
                        mb_delivery=sample_info.get("delivery_method", "")
                    )

                    # Parse MB first_seen date
                    try:
                        mb_first = sample_info.get("first_seen", "")
                        if mb_first:
                            sample_record.mb_first_seen = datetime.fromisoformat(
                                mb_first.replace(" ", "T")
                            )
                    except (ValueError, TypeError):
                        pass

                    db_session.add(sample_record)

                db_session.commit()

            logger.info(
                f"Sample processed successfully",
                sha256=sha256,
                folder=str(sample_folder),
                filename=actual_filename
            )
            return True

        except Exception as e:
            logger.error(
                f"Error processing sample",
                sha256=sha256,
                error=str(e)
            )
            if db_session:
                db_session.rollback()
            return False