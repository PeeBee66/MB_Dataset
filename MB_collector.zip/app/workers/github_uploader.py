"""GitHub uploader for daily backup tar files"""

import tarfile
import httpx
import base64
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from app.logger import get_logger
from app.config import settings

logger = get_logger(__name__)


class GitHubUploader:
    """Handles GitHub uploads for daily backup collections"""

    def __init__(self):
        self.repo_url = settings.github_repo
        self.token = settings.github_token.get_secret_value() if settings.github_token else ""
        self.retention_days = settings.github_upload_retention_days
        self.upload_path = settings.upload_root

        # Extract owner and repo from URL
        if self.repo_url:
            parts = self.repo_url.rstrip('/').split('/')
            self.owner = parts[-2] if len(parts) >= 2 else ""
            self.repo = parts[-1] if len(parts) >= 1 else ""
        else:
            self.owner = ""
            self.repo = ""

        self.api_base = f"https://api.github.com/repos/{self.owner}/{self.repo}"

    async def collect_daily_backups(self) -> List[Path]:
        """Collect last 24 hours of backups into tag-specific tar files"""

        collected_tars = []

        try:
            # Calculate time window (last 24 hours from backup time)
            now = datetime.utcnow()
            yesterday = now - timedelta(days=1)
            date_str = now.strftime("%Y_%m_%d")

            logger.info(f"Collecting backups from last 24 hours per tag")

            # Ensure upload directory exists
            self.upload_path.mkdir(parents=True, exist_ok=True)

            # Create separate tar for each tag
            for tag in settings.tags:
                tag_backup_path = settings.backup_root / tag
                if not tag_backup_path.exists():
                    continue

                # Find tar files from last 24 hours for this tag
                tag_backup_files = []
                for tar_file in tag_backup_path.glob("*.tar"):
                    # Check if file was created in last 24 hours
                    mtime = datetime.fromtimestamp(tar_file.stat().st_mtime)
                    if mtime >= yesterday:
                        tag_backup_files.append(tar_file)

                if not tag_backup_files:
                    logger.debug(f"No recent backups for tag: {tag}")
                    continue

                # Create tag-specific tar
                tag_tar = self.upload_path / f"{date_str}_{tag.upper()}_MB_UPLOAD.tar"

                with tarfile.open(tag_tar, 'w') as tar:
                    for backup_file in tag_backup_files:
                        tar.add(backup_file, arcname=backup_file.name)

                file_size = tag_tar.stat().st_size
                logger.info(
                    f"Tag tar created",
                    tag=tag,
                    filename=tag_tar.name,
                    size=file_size,
                    files_included=len(tag_backup_files)
                )

                collected_tars.append(tag_tar)

            if not collected_tars:
                logger.warning("No backup files found from last 24 hours")

            return collected_tars

        except Exception as e:
            logger.error(f"Error collecting daily backups: {e}")
            return []

    async def upload_to_github(self, file_path: Path) -> bool:
        """Upload a file to GitHub repository"""

        if not self.token or not self.owner or not self.repo:
            logger.error("GitHub configuration incomplete")
            return False

        try:
            # Read file content
            with open(file_path, 'rb') as f:
                content = f.read()

            # Encode to base64
            content_encoded = base64.b64encode(content).decode('utf-8')

            # GitHub path in repo
            github_path = f"uploads/{file_path.name}"

            logger.info(f"Uploading {file_path.name} to GitHub")

            # Check if file already exists
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/vnd.github.v3+json"
            }

            async with httpx.AsyncClient(timeout=300.0) as client:
                # Get file SHA if it exists
                get_url = f"{self.api_base}/contents/{github_path}"
                get_response = await client.get(get_url, headers=headers)

                file_sha = None
                if get_response.status_code == 200:
                    file_sha = get_response.json().get('sha')
                    logger.info(f"File exists, will update (SHA: {file_sha[:8]}...)")

                # Upload/Update file
                put_url = f"{self.api_base}/contents/{github_path}"
                payload = {
                    "message": f"Upload daily backup: {file_path.name}",
                    "content": content_encoded,
                    "branch": "main"
                }

                if file_sha:
                    payload["sha"] = file_sha

                put_response = await client.put(put_url, headers=headers, json=payload)

                if put_response.status_code in [200, 201]:
                    logger.info(
                        f"Successfully uploaded to GitHub",
                        file=file_path.name,
                        size=len(content),
                        path=github_path
                    )
                    return True
                else:
                    logger.error(
                        f"GitHub upload failed",
                        status=put_response.status_code,
                        response=put_response.text[:200]
                    )
                    return False

        except Exception as e:
            logger.error(f"Error uploading to GitHub: {e}")
            return False

    async def cleanup_old_uploads(self) -> int:
        """Remove uploads older than retention days from GitHub"""

        if not self.token or not self.owner or not self.repo:
            logger.warning("GitHub configuration incomplete, skipping cleanup")
            return 0

        deleted_count = 0
        cutoff_date = datetime.utcnow() - timedelta(days=self.retention_days)

        try:
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/vnd.github.v3+json"
            }

            async with httpx.AsyncClient(timeout=60.0) as client:
                # List files in uploads directory
                list_url = f"{self.api_base}/contents/uploads"
                response = await client.get(list_url, headers=headers)

                if response.status_code != 200:
                    logger.warning(f"Could not list uploads directory: {response.status_code}")
                    return 0

                files = response.json()

                for file_info in files:
                    filename = file_info['name']

                    # Parse date from filename (YYYY_MM_DD_MB_UPLOAD.tar)
                    try:
                        date_part = '_'.join(filename.split('_')[:3])
                        file_date = datetime.strptime(date_part, "%Y_%m_%d")

                        if file_date < cutoff_date:
                            # Delete file
                            delete_url = f"{self.api_base}/contents/uploads/{filename}"

                            # Need SHA to delete
                            file_sha = file_info['sha']

                            delete_payload = {
                                "message": f"Remove old upload: {filename}",
                                "sha": file_sha,
                                "branch": "main"
                            }

                            delete_response = await client.delete(
                                delete_url,
                                headers=headers,
                                json=delete_payload
                            )

                            if delete_response.status_code == 200:
                                logger.info(f"Deleted old upload from GitHub: {filename}")
                                deleted_count += 1
                            else:
                                logger.error(
                                    f"Failed to delete {filename}",
                                    status=delete_response.status_code
                                )
                    except ValueError:
                        # Filename doesn't match expected format, skip
                        logger.debug(f"Skipping file with unexpected name: {filename}")
                        continue

        except Exception as e:
            logger.error(f"Error cleaning up old uploads: {e}")

        return deleted_count

    async def run_upload_job(self) -> Dict:
        """Run the complete upload job"""

        stats = {
            "collected": 0,
            "uploaded": 0,
            "failed": 0,
            "deleted": 0,
            "error": None
        }

        try:
            # Step 1: Collect last 24h backups into tag-specific tars
            tar_files = await self.collect_daily_backups()

            if not tar_files:
                stats["error"] = "No backups collected"
                return stats

            stats["collected"] = len(tar_files)

            # Step 2: Upload each tar to GitHub
            for tar_file in tar_files:
                upload_success = await self.upload_to_github(tar_file)
                if upload_success:
                    stats["uploaded"] += 1
                else:
                    stats["failed"] += 1

            # Step 3: Cleanup old uploads (14 day retention)
            deleted = await self.cleanup_old_uploads()
            stats["deleted"] = deleted

            logger.info(
                "Upload job completed",
                collected=stats["collected"],
                uploaded=stats["uploaded"],
                failed=stats["failed"],
                deleted=stats["deleted"]
            )

        except Exception as e:
            stats["error"] = str(e)
            logger.error(f"Upload job failed: {e}")

        return stats

    async def test_connection(self) -> bool:
        """Test GitHub API connection"""

        if not self.token or not self.owner or not self.repo:
            logger.error("GitHub configuration incomplete")
            return False

        try:
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/vnd.github.v3+json"
            }

            async with httpx.AsyncClient(timeout=30.0, verify=True) as client:
                # Test by getting repo info
                url = f"{self.api_base}"
                response = await client.get(url, headers=headers)

                if response.status_code == 200:
                    repo_data = response.json()
                    logger.info(
                        f"GitHub connection successful",
                        repo=repo_data.get('full_name'),
                        private=repo_data.get('private')
                    )
                    return True
                else:
                    logger.error(
                        f"GitHub connection failed",
                        status=response.status_code,
                        message=response.text[:200]
                    )
                    return False

        except Exception as e:
            logger.error(f"GitHub connection test failed: {e}")
            return False