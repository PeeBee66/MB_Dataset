"""Manual uploader for creating local TAR files"""

import tarfile
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List
from app.logger import get_logger
from app.config import settings

logger = get_logger(__name__)


class ManualUploader:
    """Handles manual upload job - creates TAR files locally"""

    def __init__(self):
        self.upload_path = settings.upload_root

    async def create_tar_collection(self, days: int = 1) -> Dict:
        """Create TAR files from backup collections for specified number of days"""

        stats = {
            "collected": 0,
            "created_tars": [],
            "failed": 0,
            "errors": [],
            "total_size": 0
        }

        try:
            # Calculate time window
            now = datetime.utcnow()
            cutoff_date = now - timedelta(days=days)
            date_str = now.strftime("%Y_%m_%d")

            logger.info(f"Creating TAR collection for last {days} day(s)")

            # Ensure upload directory exists
            self.upload_path.mkdir(parents=True, exist_ok=True)

            # Create separate tar for each tag
            for tag in settings.tags:
                tag_backup_path = settings.backup_root / tag
                if not tag_backup_path.exists():
                    logger.debug(f"No backup directory for tag: {tag}")
                    continue

                # Find backup files from specified time range
                tag_backup_files = []
                for backup_file in tag_backup_path.glob("*.tar"):
                    try:
                        # Parse date from filename (YYYY_MM_DD_TAG_SHA256.tar)
                        date_str_from_file = '_'.join(backup_file.stem.split('_')[:3])
                        file_date = datetime.strptime(date_str_from_file, "%Y_%m_%d")

                        if file_date >= cutoff_date:
                            tag_backup_files.append(backup_file)

                    except (ValueError, IndexError):
                        # Fallback to modification time
                        mtime = datetime.fromtimestamp(backup_file.stat().st_mtime)
                        if mtime >= cutoff_date:
                            tag_backup_files.append(backup_file)

                if not tag_backup_files:
                    logger.info(f"No backup files found for tag: {tag} in last {days} day(s)")
                    continue

                # Create tag-specific tar
                tag_tar_name = f"{date_str}_{tag.upper()}_MANUAL_UPLOAD.tar"
                tag_tar = self.upload_path / tag_tar_name

                try:
                    with tarfile.open(tag_tar, 'w') as tar:
                        for backup_file in tag_backup_files:
                            tar.add(backup_file, arcname=backup_file.name)

                    file_size = tag_tar.stat().st_size
                    stats["total_size"] += file_size
                    stats["collected"] += len(tag_backup_files)
                    stats["created_tars"].append({
                        "filename": tag_tar.name,
                        "tag": tag,
                        "size": file_size,
                        "files_included": len(tag_backup_files)
                    })

                    logger.info(
                        f"Created manual upload TAR",
                        tag=tag,
                        filename=tag_tar.name,
                        size=file_size,
                        files_included=len(tag_backup_files)
                    )

                except Exception as e:
                    error_msg = f"Failed to create TAR for {tag}: {e}"
                    logger.error(error_msg)
                    stats["failed"] += 1
                    stats["errors"].append(error_msg)

            if not stats["created_tars"]:
                stats["message"] = f"No backup files found in the last {days} day(s)"
            else:
                stats["message"] = f"Created {len(stats['created_tars'])} TAR files from {stats['collected']} backups"

            logger.info(
                "Manual TAR creation completed",
                created_tars=len(stats["created_tars"]),
                collected=stats["collected"],
                total_size=stats["total_size"],
                days=days
            )

            return stats

        except Exception as e:
            error_msg = f"Manual TAR creation failed: {e}"
            logger.error(error_msg)
            return {
                "collected": 0,
                "created_tars": [],
                "failed": 1,
                "errors": [error_msg],
                "message": error_msg
            }

    async def cleanup_old_tars(self, days: int = 7) -> int:
        """Remove old manual TAR files from upload directory"""

        deleted_count = 0
        cutoff_date = datetime.utcnow() - timedelta(days=days)

        try:
            if not self.upload_path.exists():
                return 0

            for tar_file in self.upload_path.glob("*_MANUAL_UPLOAD.tar"):
                try:
                    # Parse date from filename
                    date_part = '_'.join(tar_file.stem.split('_')[:3])
                    file_date = datetime.strptime(date_part, "%Y_%m_%d")

                    if file_date < cutoff_date:
                        tar_file.unlink()
                        logger.info(f"Deleted old manual TAR: {tar_file.name}")
                        deleted_count += 1

                except (ValueError, IndexError):
                    # Skip files with unexpected naming
                    logger.debug(f"Skipping file with unexpected name: {tar_file.name}")
                    continue

        except Exception as e:
            logger.error(f"Error cleaning up old TAR files: {e}")

        return deleted_count

    async def get_upload_stats(self) -> Dict:
        """Get statistics about files in upload directory"""

        stats = {
            "total_files": 0,
            "total_size": 0,
            "files_by_tag": {},
            "oldest_file": None,
            "newest_file": None
        }

        try:
            if not self.upload_path.exists():
                return stats

            oldest_date = None
            newest_date = None

            for tar_file in self.upload_path.glob("*.tar"):
                stats["total_files"] += 1
                file_size = tar_file.stat().st_size
                stats["total_size"] += file_size

                try:
                    # Parse tag from filename
                    parts = tar_file.stem.split('_')
                    if len(parts) >= 4:
                        tag = parts[3].lower()
                        if tag not in stats["files_by_tag"]:
                            stats["files_by_tag"][tag] = {"count": 0, "size": 0}
                        stats["files_by_tag"][tag]["count"] += 1
                        stats["files_by_tag"][tag]["size"] += file_size

                    # Track dates
                    date_part = '_'.join(parts[:3])
                    file_date = datetime.strptime(date_part, "%Y_%m_%d")

                    if oldest_date is None or file_date < oldest_date:
                        oldest_date = file_date
                        stats["oldest_file"] = tar_file.name

                    if newest_date is None or file_date > newest_date:
                        newest_date = file_date
                        stats["newest_file"] = tar_file.name

                except (ValueError, IndexError):
                    continue

        except Exception as e:
            logger.error(f"Error getting upload stats: {e}")

        return stats