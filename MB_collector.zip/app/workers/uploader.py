"""Git VCS uploader with retention management"""

import git
import shutil
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Optional, Dict
from app.logger import get_logger
from app.config import settings
import os
import tempfile

logger = get_logger(__name__)


class VCSUploader:
    """Handles Git operations for backup uploads and retention"""

    def __init__(self):
        self.remote_url = settings.git_remote
        self.branch = settings.git_branch
        self.retention_days = settings.retention_days
        self.repo_path = Path("/tmp/repo")
        self.ssh_key_path = settings.git_ssh_key

    def _setup_git_env(self) -> Dict[str, str]:
        """Setup environment for Git SSH operations"""
        env = os.environ.copy()

        if self.ssh_key_path and Path(self.ssh_key_path).exists():
            # Create SSH command with specific key
            ssh_cmd = f'ssh -i {self.ssh_key_path} -o StrictHostKeyChecking=no'
            env['GIT_SSH_COMMAND'] = ssh_cmd

        return env

    async def upload_backups(self) -> Dict:
        """Upload backup files to Git repository with retention"""

        stats = {
            "uploaded": 0,
            "deleted": 0,
            "failed": 0,
            "commit_sha": None,
            "error": None
        }

        if not self.remote_url:
            logger.warning("No Git remote configured, skipping upload")
            stats["error"] = "No Git remote configured"
            return stats

        try:
            # Clean and recreate repo directory
            if self.repo_path.exists():
                shutil.rmtree(self.repo_path)
            self.repo_path.mkdir(parents=True)

            env = self._setup_git_env()

            # Clone or init repository
            logger.info(f"Cloning repository: {self.remote_url}")
            try:
                repo = git.Repo.clone_from(
                    self.remote_url,
                    self.repo_path,
                    branch=self.branch,
                    env=env,
                    depth=1  # Shallow clone for efficiency
                )
            except git.GitCommandError as e:
                if "does not exist" in str(e):
                    # Repository doesn't exist, create new one
                    logger.info("Repository doesn't exist, creating new")
                    repo = git.Repo.init(self.repo_path)
                    origin = repo.create_remote('origin', self.remote_url)
                else:
                    raise

            # Sync backup files to repo
            backup_root = settings.backup_root
            if backup_root.exists():
                # Copy all backup files to repo
                for tag_dir in backup_root.iterdir():
                    if not tag_dir.is_dir():
                        continue

                    # Create tag directory in repo
                    repo_tag_dir = self.repo_path / "backups" / tag_dir.name
                    repo_tag_dir.mkdir(parents=True, exist_ok=True)

                    # Copy ZIP files
                    for zip_file in tag_dir.glob("*.zip"):
                        dest = repo_tag_dir / zip_file.name
                        if not dest.exists() or dest.stat().st_size != zip_file.stat().st_size:
                            shutil.copy2(zip_file, dest)
                            stats["uploaded"] += 1
                            logger.info(f"Copied backup: {zip_file.name}")

            # Apply retention policy (skip if retention_days is 0)
            if self.retention_days > 0:
                retention_cutoff = datetime.utcnow() - timedelta(days=self.retention_days)
                backups_dir = self.repo_path / "backups"

                if backups_dir.exists():
                    for tag_dir in backups_dir.iterdir():
                        if not tag_dir.is_dir():
                            continue

                        for zip_file in tag_dir.glob("*.zip"):
                            # Check file age
                            file_mtime = datetime.fromtimestamp(zip_file.stat().st_mtime)
                            if file_mtime < retention_cutoff:
                                logger.info(f"Deleting old backup: {zip_file.name}")
                                zip_file.unlink()
                                stats["deleted"] += 1

            # Add README
            readme_path = self.repo_path / "README.md"
            readme_content = f"""# MalwareBazaar Backup Repository

⚠️ **DEFENSIVE RESEARCH USE ONLY** ⚠️

This repository contains password-protected backups of malware samples.
- Do NOT execute any samples
- All ZIP files are password protected
- For defensive security research only
- Use in accordance with local laws

## Structure
```
backups/
  <tag>/
    <sha256>.zip  # Password-protected sample archive
```

## Retention
{f"Files older than {self.retention_days} days are automatically removed." if self.retention_days > 0 else "No automatic retention - files are kept indefinitely."}

Last updated: {datetime.utcnow().isoformat()}
"""
            readme_path.write_text(readme_content)

            # Git add, commit, and push
            repo.index.add(['*'])

            # Check if there are changes to commit
            if repo.is_dirty() or repo.untracked_files:
                commit_message = f"Backup upload - {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
                if stats["uploaded"] > 0:
                    commit_message += f" | Added: {stats['uploaded']} files"
                if stats["deleted"] > 0:
                    commit_message += f" | Removed: {stats['deleted']} old files"

                repo.index.commit(commit_message)

                # Push to remote
                logger.info("Pushing to remote repository")
                origin = repo.remote('origin')
                push_info = origin.push(self.branch, env=env, force=True)

                if push_info:
                    stats["commit_sha"] = repo.head.commit.hexsha[:8]
                    logger.info(f"Push successful: {stats['commit_sha']}")
                else:
                    logger.warning("Push completed but no info returned")

            else:
                logger.info("No changes to commit")

        except Exception as e:
            logger.error(f"VCS upload failed: {str(e)}")
            stats["error"] = str(e)
            stats["failed"] = 1

        finally:
            # Clean up repo directory
            if self.repo_path.exists():
                try:
                    shutil.rmtree(self.repo_path)
                except:
                    pass

        return stats

    async def test_connection(self) -> bool:
        """Test Git repository connection"""

        if not self.remote_url:
            return False

        try:
            env = self._setup_git_env()

            # Try to ls-remote to test connection
            temp_dir = Path(tempfile.mkdtemp())
            try:
                git.cmd.Git().ls_remote(self.remote_url, env=env)
                logger.info("Git connection test successful")
                return True
            finally:
                shutil.rmtree(temp_dir, ignore_errors=True)

        except Exception as e:
            logger.error(f"Git connection test failed: {str(e)}")
            return False