"""GitHub API-based sync for automatic backup uploads"""

import base64
import json
import ssl
import httpx
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from app.logger import get_logger
from app.config import settings

logger = get_logger(__name__)


class GitHubAPISync:
    """Handles automatic GitHub sync using API instead of Git operations"""

    def __init__(self):
        self.repo_url = settings.github_repo
        self.token = settings.github_token.get_secret_value() if settings.github_token else ""
        self.retention_days = settings.github_upload_retention_days

        # Parse owner/repo from URL
        if self.repo_url and "github.com/" in self.repo_url:
            parts = self.repo_url.replace("https://github.com/", "").replace("http://github.com/", "").split("/")
            if len(parts) >= 2:
                self.owner = parts[0]
                self.repo = parts[1].replace(".git", "")
            else:
                self.owner = None
                self.repo = None
        else:
            self.owner = None
            self.repo = None

    def _get_backup_files_in_range(self, days: int = 1) -> Dict[str, List[Path]]:
        """Get all backup TAR files from the last N days organized by tag"""

        cutoff_date = datetime.utcnow() - timedelta(days=days)
        backup_files = {}

        for tag in settings.tags:
            tag_backup_path = settings.backup_root / tag
            if not tag_backup_path.exists():
                continue

            tag_files = []
            # Look for individual TAR files (format: YYYY_MM_DD_TAG_SHA256.tar)
            for backup_file in tag_backup_path.glob("*.tar"):
                try:
                    # Check modification time for files from last N days
                    mtime = datetime.fromtimestamp(backup_file.stat().st_mtime)
                    if mtime >= cutoff_date:
                        tag_files.append(backup_file)
                except Exception as e:
                    logger.warning(f"Error checking file {backup_file}: {e}")

            if tag_files:
                backup_files[tag] = sorted(tag_files, key=lambda x: x.stat().st_mtime)
                logger.info(f"Found {len(tag_files)} backup TAR files for tag {tag} from last {days} day(s)")

        return backup_files

    async def _get_repo_contents(self, path: str = "uploads") -> Dict[str, Dict]:
        """Get contents of repository directory using GitHub API"""

        if not self.owner or not self.repo or not self.token:
            return {}

        url = f"https://api.github.com/repos/{self.owner}/{self.repo}/contents/{path}"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "MB-Collector/1.0"
        }

        try:
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.get(url, headers=headers, timeout=30)

                if response.status_code == 404:
                    # Directory doesn't exist yet
                    return {}
                elif response.status_code == 200:
                    contents = response.json()
                    if isinstance(contents, list):
                        return {item["name"]: item for item in contents if item["type"] == "file"}
                    else:
                        return {}
                else:
                    logger.error(f"Failed to get repo contents: {response.status_code} {response.text}")
                    return {}

        except Exception as e:
            logger.error(f"Error getting repo contents: {e}")
            return {}

    async def _upload_file_to_repo(self, file_path: Path, repo_path: str, file_content: bytes) -> bool:
        """Upload a file to GitHub repository using API"""

        if not self.owner or not self.repo or not self.token:
            return False

        url = f"https://api.github.com/repos/{self.owner}/{self.repo}/contents/{repo_path}"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "MB-Collector/1.0"
        }

        # Encode file content to base64
        content_b64 = base64.b64encode(file_content).decode('utf-8')

        data = {
            "message": f"Add backup file: {file_path.name}",
            "content": content_b64,
            "committer": {
                "name": "MB Collector",
                "email": "mb-collector@example.com"
            }
        }

        try:
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.put(url, headers=headers, json=data, timeout=60)

                if response.status_code == 201:
                    logger.info(f"Successfully uploaded {file_path.name}")
                    return True
                else:
                    logger.error(f"Failed to upload {file_path.name}: {response.status_code} {response.text}")
                    return False

        except Exception as e:
            logger.error(f"Error uploading {file_path.name}: {e}")
            return False

    async def _delete_file_from_repo(self, repo_path: str, sha: str) -> bool:
        """Delete a file from GitHub repository using API"""

        if not self.owner or not self.repo or not self.token:
            return False

        url = f"https://api.github.com/repos/{self.owner}/{self.repo}/contents/{repo_path}"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "MB-Collector/1.0"
        }

        data = {
            "message": f"Remove old backup file: {Path(repo_path).name}",
            "sha": sha,
            "committer": {
                "name": "MB Collector",
                "email": "mb-collector@example.com"
            }
        }

        try:
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.delete(url, headers=headers, json=data, timeout=30)

                if response.status_code == 200:
                    logger.info(f"Successfully deleted {Path(repo_path).name}")
                    return True
                else:
                    logger.error(f"Failed to delete {Path(repo_path).name}: {response.status_code} {response.text}")
                    return False

        except Exception as e:
            logger.error(f"Error deleting {Path(repo_path).name}: {e}")
            return False

    async def _get_file_age_days(self, file_info: Dict) -> int:
        """Get age of file in repository in days"""

        if not self.owner or not self.repo or not self.token:
            return 0

        # Get commit info for the file
        url = f"https://api.github.com/repos/{self.owner}/{self.repo}/commits"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "MB-Collector/1.0"
        }

        params = {
            "path": f"uploads/{file_info['name']}",
            "per_page": 1
        }

        try:
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.get(url, headers=headers, params=params, timeout=30)

                if response.status_code == 200:
                    commits = response.json()
                    if commits:
                        commit_date = datetime.fromisoformat(
                            commits[0]["commit"]["committer"]["date"].replace('Z', '+00:00')
                        )
                        age_days = (datetime.utcnow().replace(tzinfo=None) -
                                  commit_date.replace(tzinfo=None)).days
                        return age_days

        except Exception as e:
            logger.warning(f"Could not determine age of {file_info['name']}: {e}")

        return 0

    async def sync_with_github(self) -> Dict:
        """Sync backup files with GitHub repository using API"""

        if not self.token or not self.owner or not self.repo:
            logger.error("GitHub configuration incomplete")
            return {"success": False, "error": "GitHub configuration incomplete"}

        stats = {
            "uploaded": 0,
            "deleted": 0,
            "skipped": 0,
            "failed": 0,
            "errors": []
        }

        try:
            # Get current files in repository
            repo_files = await self._get_repo_contents("uploads")
            logger.info(f"Found {len(repo_files)} files in repository")

            # Get backup files from last 24 hours for upload
            backup_files_24h = self._get_backup_files_in_range(days=1)

            # Upload missing files from last 24 hours
            for tag, files in backup_files_24h.items():
                for backup_file in files:
                    repo_filename = f"{tag}_{backup_file.name}"

                    if repo_filename not in repo_files:
                        try:
                            # Check file size (GitHub API limit is 100MB)
                            file_size_mb = backup_file.stat().st_size / (1024 * 1024)

                            if file_size_mb > 95:  # Leave some buffer
                                logger.warning(f"Skipping {backup_file.name} - too large ({file_size_mb:.1f}MB)")
                                stats["skipped"] += 1
                                continue

                            # Read file content
                            with open(backup_file, 'rb') as f:
                                file_content = f.read()

                            # Upload to repository
                            repo_path = f"uploads/{repo_filename}"
                            success = await self._upload_file_to_repo(backup_file, repo_path, file_content)

                            if success:
                                stats["uploaded"] += 1
                            else:
                                stats["failed"] += 1

                        except Exception as e:
                            error_msg = f"Failed to upload {backup_file.name}: {e}"
                            logger.error(error_msg)
                            stats["failed"] += 1
                            stats["errors"].append(error_msg)
                    else:
                        logger.debug(f"File {repo_filename} already in repository")

            # Check for files to delete (older than retention period)
            files_to_remove = []
            for file_name, file_info in repo_files.items():
                age_days = await self._get_file_age_days(file_info)
                if age_days > self.retention_days:
                    files_to_remove.append((file_name, file_info))

            # Delete old files
            for file_name, file_info in files_to_remove:
                try:
                    repo_path = f"uploads/{file_name}"
                    success = await self._delete_file_from_repo(repo_path, file_info["sha"])
                    if success:
                        stats["deleted"] += 1
                    else:
                        stats["failed"] += 1
                except Exception as e:
                    logger.error(f"Failed to delete {file_name}: {e}")

            logger.info(
                f"GitHub API sync completed",
                uploaded=stats["uploaded"],
                deleted=stats["deleted"],
                skipped=stats["skipped"]
            )

            return {
                "success": True,
                "uploaded": stats["uploaded"],
                "deleted": stats["deleted"],
                "skipped": stats["skipped"],
                "failed": stats["failed"],
                "message": f"API Sync: +{stats['uploaded']} -{stats['deleted']} files"
            }

        except Exception as e:
            error_msg = f"GitHub API sync failed: {e}"
            logger.error(error_msg)
            return {"success": False, "error": error_msg}

    def test_connection(self) -> bool:
        """Test GitHub API connection"""

        if not self.token or not self.owner or not self.repo:
            logger.error("GitHub configuration incomplete")
            return False

        url = f"https://api.github.com/repos/{self.owner}/{self.repo}"

        try:
            # Create SSL context that ignores certificate verification
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

            # Create request
            request = Request(url)
            request.add_header("Authorization", f"token {self.token}")
            request.add_header("Accept", "application/vnd.github.v3+json")
            request.add_header("User-Agent", "MB-Collector/1.0")

            # Make request with custom SSL context
            with urlopen(request, context=ssl_context, timeout=30) as response:
                if response.status == 200:
                    logger.info("GitHub API connection successful")
                    return True
                else:
                    logger.error(f"GitHub API connection failed: {response.status}")
                    return False

        except Exception as e:
            logger.error(f"GitHub API connection test failed: {e}")
            return False