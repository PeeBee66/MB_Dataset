"""Email reporting service"""

import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from app.logger import get_logger
from app.config import settings
from app.utils.filesystem import FileSystemScanner
from pathlib import Path
import json

logger = get_logger(__name__)


class EmailReporter:
    """Sends email summaries and reports"""

    def __init__(self):
        self.smtp_host = settings.smtp_host
        self.smtp_port = settings.smtp_port
        self.smtp_tls = settings.smtp_tls
        self.smtp_user = settings.smtp_user
        self.smtp_pass = settings.smtp_pass.get_secret_value()
        self.from_email = settings.smtp_from
        self.to_emails = settings.smtp_to_list
        self.subject_prefix = settings.email_subject_prefix
        self.scanner = FileSystemScanner()

    async def send_daily_summary(self, stats: Optional[Dict] = None) -> bool:
        """Send daily summary email"""

        try:
            # Gather statistics from filesystem
            if not stats:
                stats = await self._gather_daily_stats()

            # Create email content
            subject = f"{self.subject_prefix} Daily Summary - {datetime.utcnow().strftime('%Y-%m-%d')}"

            html_body = self._create_html_report(stats)
            text_body = self._create_text_report(stats)

            # Send email
            success = await self._send_email(subject, text_body, html_body)

            if success:
                logger.info("Daily summary email sent successfully")
            else:
                logger.error("Failed to send daily summary email")

            return success

        except Exception as e:
            logger.error(f"Error sending daily summary: {str(e)}")
            return False

    async def _gather_daily_stats(self) -> Dict:
        """Gather statistics from filesystem"""

        stats = {
            "date": datetime.utcnow().isoformat(),
            "window_start": (datetime.utcnow() - timedelta(days=1)).isoformat(),
            "tags": {},
            "totals": {
                "new_samples": 0,
                "total_samples": 0,
                "backup_size": 0,
                "data_size": 0,
                "backups_created": 0,
                "uploads_success": 0,
                "uploads_failed": 0
            },
            "disk": {
                "free_gb": 0,
                "used_gb": 0,
                "total_gb": 0
            }
        }

        # Scan filesystem for each tag
        for tag in settings.tags:
            tag_stats = await self.scanner.scan_tag(tag)
            stats["tags"][tag] = tag_stats

            # Update totals
            stats["totals"]["total_samples"] += tag_stats["total_samples"]
            stats["totals"]["new_samples"] += tag_stats["new_24h"]
            stats["totals"]["backup_size"] += tag_stats["backup_size"]
            stats["totals"]["data_size"] += tag_stats["data_size"]

        # Get disk stats
        stats["disk"] = self._get_disk_stats()

        return stats

    def _get_disk_stats(self) -> Dict:
        """Get disk usage statistics"""

        import shutil

        try:
            usage = shutil.disk_usage("/data")
            return {
                "free_gb": round(usage.free / (1024**3), 2),
                "used_gb": round(usage.used / (1024**3), 2),
                "total_gb": round(usage.total / (1024**3), 2)
            }
        except:
            return {"free_gb": 0, "used_gb": 0, "total_gb": 0}

    def _create_html_report(self, stats: Dict) -> str:
        """Create HTML email report"""

        html = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; }}
        .header {{ background-color: #2c3e50; color: white; padding: 20px; }}
        .warning {{ background-color: #ff6b6b; color: white; padding: 10px; margin: 10px 0; }}
        .content {{ padding: 20px; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #34495e; color: white; }}
        tr:hover {{ background-color: #f5f5f5; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 20px 0; }}
        .stat-box {{ background: #ecf0f1; padding: 15px; border-radius: 5px; }}
        .stat-value {{ font-size: 24px; font-weight: bold; color: #2c3e50; }}
        .stat-label {{ color: #7f8c8d; margin-top: 5px; }}
        .footer {{ margin-top: 40px; padding: 20px; background: #ecf0f1; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>MalwareBazaar Collector - Daily Report</h1>
        <p>{datetime.utcnow().strftime('%B %d, %Y')}</p>
    </div>

    <div class="warning">
        ⚠️ <strong>DEFENSIVE RESEARCH USE ONLY</strong> ⚠️<br>
        Do not execute any samples. For defensive security research only.
    </div>

    <div class="content">
        <h2>Summary Statistics</h2>

        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-value">{stats['totals']['new_samples']}</div>
                <div class="stat-label">New Samples (24h)</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{stats['totals']['total_samples']}</div>
                <div class="stat-label">Total Samples</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{self._format_size(stats['totals']['backup_size'])}</div>
                <div class="stat-label">Backup Size</div>
            </div>
        </div>

        <h2>Tag Statistics</h2>
        <table>
            <tr>
                <th>Tag</th>
                <th>New (24h)</th>
                <th>Total</th>
                <th>Backed Up</th>
                <th>Data Size</th>
                <th>Backup Size</th>
            </tr>
"""

        for tag, tag_stats in stats.get("tags", {}).items():
            html += f"""
            <tr>
                <td><strong>{tag}</strong></td>
                <td>{tag_stats.get('new_24h', 0)}</td>
                <td>{tag_stats.get('total_samples', 0)}</td>
                <td>{tag_stats.get('backed_up', 0)}</td>
                <td>{self._format_size(tag_stats.get('data_size', 0))}</td>
                <td>{self._format_size(tag_stats.get('backup_size', 0))}</td>
            </tr>
"""

        html += f"""
        </table>

        <h2>Disk Usage</h2>
        <p>
            <strong>Free:</strong> {stats['disk']['free_gb']} GB<br>
            <strong>Used:</strong> {stats['disk']['used_gb']} GB<br>
            <strong>Total:</strong> {stats['disk']['total_gb']} GB
        </p>

        <div class="footer">
            <p><em>Report generated at {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC</em></p>
            <p>Web Dashboard: <a href="http://localhost:5070">http://localhost:5070</a></p>
        </div>
    </div>
</body>
</html>
"""
        return html

    def _create_text_report(self, stats: Dict) -> str:
        """Create plain text email report"""

        text = f"""
MalwareBazaar Collector - Daily Report
{datetime.utcnow().strftime('%B %d, %Y')}

⚠️ DEFENSIVE RESEARCH USE ONLY ⚠️

SUMMARY
=======
New Samples (24h): {stats['totals']['new_samples']}
Total Samples: {stats['totals']['total_samples']}
Backup Size: {self._format_size(stats['totals']['backup_size'])}
Data Size: {self._format_size(stats['totals']['data_size'])}

TAG STATISTICS
==============
"""

        for tag, tag_stats in stats.get("tags", {}).items():
            text += f"""
{tag}:
  - New (24h): {tag_stats.get('new_24h', 0)}
  - Total: {tag_stats.get('total_samples', 0)}
  - Backed up: {tag_stats.get('backed_up', 0)}
  - Data size: {self._format_size(tag_stats.get('data_size', 0))}
  - Backup size: {self._format_size(tag_stats.get('backup_size', 0))}
"""

        text += f"""

DISK USAGE
==========
Free: {stats['disk']['free_gb']} GB
Used: {stats['disk']['used_gb']} GB
Total: {stats['disk']['total_gb']} GB

---
Report generated at {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
Web Dashboard: http://localhost:5070
"""

        return text

    def _format_size(self, size_bytes: int) -> str:
        """Format bytes to human readable size"""

        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} PB"

    async def _send_email(
        self,
        subject: str,
        text_body: str,
        html_body: Optional[str] = None
    ) -> bool:
        """Send email via SMTP"""

        try:
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = self.from_email
            msg['To'] = ', '.join(self.to_emails)
            msg['Date'] = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S +0000')

            # Add text part
            text_part = MIMEText(text_body, 'plain')
            msg.attach(text_part)

            # Add HTML part if provided
            if html_body:
                html_part = MIMEText(html_body, 'html')
                msg.attach(html_part)

            # Send email
            await aiosmtplib.send(
                msg,
                hostname=self.smtp_host,
                port=self.smtp_port,
                username=self.smtp_user,
                password=self.smtp_pass,
                start_tls=self.smtp_tls
            )

            logger.info(f"Email sent: {subject}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email: {str(e)}")
            return False

    async def test_connection(self) -> bool:
        """Test SMTP connection"""

        try:
            async with aiosmtplib.SMTP(
                hostname=self.smtp_host,
                port=self.smtp_port,
                username=self.smtp_user,
                password=self.smtp_pass,
                start_tls=self.smtp_tls
            ) as smtp:
                await smtp.connect()
                logger.info("SMTP connection test successful")
                return True

        except Exception as e:
            logger.error(f"SMTP connection test failed: {str(e)}")
            return False