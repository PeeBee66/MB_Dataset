"""Filesystem scanner for reading samples directly from disk"""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from app.config import settings
from app.logger import get_logger
import os
import aiofiles
import asyncio

logger = get_logger(__name__)


class FileSystemScanner:
    """Scans filesystem for samples and metadata instead of using database"""

    def __init__(self):
        self.data_root = settings.download_root
        self.backup_root = settings.backup_root

    async def scan_all_samples(self, tag: Optional[str] = None) -> List[Dict]:
        """Scan filesystem and return all samples"""

        samples = []

        if tag:
            # Scan specific tag
            tag_path = self.data_root / tag
            if tag_path.exists():
                samples = await self._scan_tag_directory(tag, tag_path)
        else:
            # Scan all tags
            for tag_dir in self.data_root.iterdir():
                if tag_dir.is_dir():
                    tag_samples = await self._scan_tag_directory(tag_dir.name, tag_dir)
                    samples.extend(tag_samples)

        # Sort by most recent first
        samples.sort(key=lambda x: x.get('modified_time', 0), reverse=True)

        return samples

    async def _scan_tag_directory(self, tag: str, tag_path: Path) -> List[Dict]:
        """Scan a specific tag directory for samples"""

        samples = []

        for sample_dir in tag_path.iterdir():
            if not sample_dir.is_dir():
                continue

            # SHA256 is the directory name
            sha256 = sample_dir.name

            # Skip if not a valid SHA256
            if len(sha256) != 64:
                continue

            sample_info = await self._read_sample_info(tag, sha256, sample_dir)
            if sample_info:
                samples.append(sample_info)

        return samples

    async def _read_sample_info(self, tag: str, sha256: str, sample_dir: Path) -> Optional[Dict]:
        """Read all information about a sample from its directory"""

        try:
            info = {
                "sha256": sha256,
                "tag": tag,
                "path": str(sample_dir),
                "files": {},
                "metadata": {},
                "has_backup": False,
                "backup_path": None
            }

            # Read metadata from JSON file ({sha256}.json)
            meta_file = sample_dir / f"{sha256}.json"
            if meta_file.exists():
                try:
                    async with aiofiles.open(meta_file, 'r') as f:
                        content = await f.read()
                        info["metadata"] = json.loads(content)

                        # Extract key fields from metadata
                        info["filename"] = info["metadata"].get("file_name", "")
                        info["file_size"] = info["metadata"].get("file_size", 0)
                        info["signature"] = info["metadata"].get("signature", "")
                        info["first_seen"] = info["metadata"].get("first_seen", "")
                        info["reporter"] = info["metadata"].get("reporter", "")
                except Exception as e:
                    logger.error(f"Error reading metadata for {sha256}: {e}")
            else:
                # Fallback to old format (meta.json) for backward compatibility
                meta_file_old = sample_dir / "meta.json"
                if meta_file_old.exists():
                    try:
                        async with aiofiles.open(meta_file_old, 'r') as f:
                            content = await f.read()
                            info["metadata"] = json.loads(content)
                            info["filename"] = info["metadata"].get("file_name", "")
                            info["file_size"] = info["metadata"].get("file_size", 0)
                            info["signature"] = info["metadata"].get("signature", "")
                            info["first_seen"] = info["metadata"].get("first_seen", "")
                            info["reporter"] = info["metadata"].get("reporter", "")
                    except Exception as e:
                        logger.error(f"Error reading old metadata for {sha256}: {e}")

            # Check for each file type
            for file_type in ["sample.bin", "iocs.txt", "yara.txt", "README.txt"]:
                file_path = sample_dir / file_type
                if file_path.exists():
                    stat = file_path.stat()
                    info["files"][file_type] = {
                        "exists": True,
                        "size": stat.st_size,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                    }

            # Get directory modification time
            dir_stat = sample_dir.stat()
            info["modified_time"] = dir_stat.st_mtime
            info["modified"] = datetime.fromtimestamp(dir_stat.st_mtime).isoformat()

            # Check for backup (support both new .tar and old .zip formats)
            backup_path = settings.get_backup_path(tag, sha256)

            # Also check for old .zip format
            old_backup_path = settings.get_backup_tag_path(tag) / f"{sha256}.zip"

            if backup_path.exists():
                info["has_backup"] = True
                info["backup_path"] = str(backup_path)
                backup_stat = backup_path.stat()
                info["backup_size"] = backup_stat.st_size
                info["backup_modified"] = datetime.fromtimestamp(backup_stat.st_mtime).isoformat()
            elif old_backup_path.exists():
                info["has_backup"] = True
                info["backup_path"] = str(old_backup_path)
                backup_stat = old_backup_path.stat()
                info["backup_size"] = backup_stat.st_size
                info["backup_modified"] = datetime.fromtimestamp(backup_stat.st_mtime).isoformat()

            return info

        except Exception as e:
            logger.error(f"Error reading sample {sha256}: {e}")
            return None

    async def get_sample_details(self, tag: str, sha256: str) -> Optional[Dict]:
        """Get detailed information about a specific sample"""

        sample_dir = settings.get_sample_path(tag, sha256)

        if not sample_dir.exists():
            return None

        info = await self._read_sample_info(tag, sha256, sample_dir)

        if info:
            # Read actual file contents for details view
            contents = {}

            # Read the new file formats (.intel, .iocs, .json, .yara)
            # Read Intel file
            intel_file = sample_dir / f"{sha256}.intel"
            if intel_file.exists():
                try:
                    async with aiofiles.open(intel_file, 'r') as f:
                        contents["intel"] = await f.read()
                except Exception as e:
                    logger.error(f"Error reading intel file for {sha256}: {e}")

            # Read IOCs file (new format)
            iocs_file = sample_dir / f"{sha256}.iocs"
            if iocs_file.exists():
                try:
                    async with aiofiles.open(iocs_file, 'r') as f:
                        contents["iocs"] = await f.read()
                except Exception as e:
                    logger.error(f"Error reading iocs file for {sha256}: {e}")
            else:
                # Fallback to old format
                iocs_file_old = sample_dir / "iocs.txt"
                if iocs_file_old.exists():
                    async with aiofiles.open(iocs_file_old, 'r') as f:
                        contents["iocs"] = await f.read()

            # Read JSON metadata file
            json_file = sample_dir / f"{sha256}.json"
            if json_file.exists():
                try:
                    async with aiofiles.open(json_file, 'r') as f:
                        json_content = await f.read()
                        contents["json_metadata"] = json.loads(json_content)
                except Exception as e:
                    logger.error(f"Error reading json file for {sha256}: {e}")

            # Read YARA file (new format)
            yara_file = sample_dir / f"{sha256}.yara"
            if yara_file.exists():
                try:
                    async with aiofiles.open(yara_file, 'r') as f:
                        contents["yara"] = await f.read()
                except Exception as e:
                    logger.error(f"Error reading yara file for {sha256}: {e}")
            else:
                # Fallback to old format
                yara_file_old = sample_dir / "yara.txt"
                if yara_file_old.exists():
                    async with aiofiles.open(yara_file_old, 'r') as f:
                        contents["yara"] = await f.read()

            # Read README if exists
            readme_file = sample_dir / "README.txt"
            if readme_file.exists():
                try:
                    async with aiofiles.open(readme_file, 'r') as f:
                        contents["readme"] = await f.read()
                except Exception as e:
                    logger.error(f"Error reading readme file for {sha256}: {e}")

            # Check for ZIP file
            zip_file = sample_dir / f"{sha256}.zip"
            if zip_file.exists():
                zip_stat = zip_file.stat()
                contents["zip_info"] = {
                    "exists": True,
                    "size": zip_stat.st_size,
                    "modified": datetime.fromtimestamp(zip_stat.st_mtime).isoformat()
                }

            info["contents"] = contents

        return info

    async def scan_tag(self, tag: str) -> Dict:
        """Get statistics for a specific tag"""

        stats = {
            "tag": tag,
            "total_samples": 0,
            "new_24h": 0,
            "new_7d": 0,
            "backed_up": 0,
            "data_size": 0,
            "backup_size": 0,
            "oldest": None,
            "newest": None
        }

        tag_path = self.data_root / tag
        if not tag_path.exists():
            return stats

        now = datetime.utcnow()
        day_ago = now - timedelta(days=1)
        week_ago = now - timedelta(days=7)

        # Scan samples
        for sample_dir in tag_path.iterdir():
            if not sample_dir.is_dir():
                continue

            stats["total_samples"] += 1

            # Get directory stats
            dir_stat = sample_dir.stat()
            dir_time = datetime.fromtimestamp(dir_stat.st_mtime)

            # Count new samples
            if dir_time >= day_ago:
                stats["new_24h"] += 1
            if dir_time >= week_ago:
                stats["new_7d"] += 1

            # Track oldest/newest
            if not stats["oldest"] or dir_time < stats["oldest"]:
                stats["oldest"] = dir_time
            if not stats["newest"] or dir_time > stats["newest"]:
                stats["newest"] = dir_time

            # Calculate data size
            for file in sample_dir.rglob("*"):
                if file.is_file():
                    stats["data_size"] += file.stat().st_size

            # Check for backup (support both new .tar and old .zip formats)
            sha256 = sample_dir.name
            backup_path = settings.get_backup_path(tag, sha256)
            old_backup_path = settings.get_backup_tag_path(tag) / f"{sha256}.zip"

            if backup_path.exists():
                stats["backed_up"] += 1
                stats["backup_size"] += backup_path.stat().st_size
            elif old_backup_path.exists():
                stats["backed_up"] += 1
                stats["backup_size"] += old_backup_path.stat().st_size

        # Convert dates to strings
        if stats["oldest"]:
            stats["oldest"] = stats["oldest"].isoformat()
        if stats["newest"]:
            stats["newest"] = stats["newest"].isoformat()

        return stats

    async def get_recent_samples(self, limit: int = 10, tag: Optional[str] = None, offset: int = 0) -> Dict:
        """Get most recently added/modified samples with pagination"""

        all_samples = await self.scan_all_samples(tag)
        total_count = len(all_samples)

        # Apply pagination
        paginated_samples = all_samples[offset:offset + limit]

        return {
            "samples": paginated_samples,
            "total": total_count,
            "offset": offset,
            "limit": limit,
            "has_more": offset + limit < total_count
        }

    async def search_samples(
        self,
        query: str,
        tag: Optional[str] = None,
        search_in: List[str] = ["filename", "sha256", "signature"],
        limit: int = 50,
        offset: int = 0
    ) -> Dict:
        """Search for samples matching query with pagination"""

        all_samples = await self.scan_all_samples(tag)
        results = []

        query_lower = query.lower()

        for sample in all_samples:
            # Search in specified fields
            for field in search_in:
                value = str(sample.get(field, "")).lower()
                if query_lower in value:
                    results.append(sample)
                    break

        total_count = len(results)
        paginated_results = results[offset:offset + limit]

        return {
            "samples": paginated_results,
            "total": total_count,
            "offset": offset,
            "limit": limit,
            "has_more": offset + limit < total_count,
            "query": query
        }

    async def cleanup_old_files(
        self,
        days: int,
        target: str = "both",
        dry_run: bool = True
    ) -> Dict:
        """Clean up old files from data and/or backup directories"""

        stats = {
            "scanned": 0,
            "deleted": 0,
            "size_freed": 0,
            "errors": 0,
            "dry_run": dry_run
        }

        cutoff_date = datetime.utcnow() - timedelta(days=days)

        # Clean data directory
        if target in ["data", "both"]:
            stats_data = await self._cleanup_directory(
                self.data_root,
                cutoff_date,
                dry_run,
                "data"
            )
            stats["scanned"] += stats_data["scanned"]
            stats["deleted"] += stats_data["deleted"]
            stats["size_freed"] += stats_data["size_freed"]
            stats["errors"] += stats_data["errors"]

        # Clean backup directory
        if target in ["backup", "both"]:
            stats_backup = await self._cleanup_directory(
                self.backup_root,
                cutoff_date,
                dry_run,
                "backup"
            )
            stats["scanned"] += stats_backup["scanned"]
            stats["deleted"] += stats_backup["deleted"]
            stats["size_freed"] += stats_backup["size_freed"]
            stats["errors"] += stats_backup["errors"]

        logger.info(
            f"Cleanup completed",
            dry_run=dry_run,
            **stats
        )

        return stats

    async def _cleanup_directory(
        self,
        root: Path,
        cutoff_date: datetime,
        dry_run: bool,
        dir_type: str
    ) -> Dict:
        """Clean up old files from a directory"""

        stats = {
            "scanned": 0,
            "deleted": 0,
            "size_freed": 0,
            "errors": 0
        }

        if not root.exists():
            return stats

        for tag_dir in root.iterdir():
            if not tag_dir.is_dir():
                continue

            if dir_type == "data":
                # For data dir, check each sample directory
                for sample_dir in tag_dir.iterdir():
                    if not sample_dir.is_dir():
                        continue

                    stats["scanned"] += 1

                    # Check directory age
                    dir_stat = sample_dir.stat()
                    dir_time = datetime.fromtimestamp(dir_stat.st_mtime)

                    if dir_time < cutoff_date:
                        # Calculate size before deletion
                        dir_size = sum(
                            f.stat().st_size for f in sample_dir.rglob("*") if f.is_file()
                        )

                        if dry_run:
                            logger.info(
                                f"[DRY RUN] Would delete sample",
                                path=str(sample_dir),
                                age_days=(datetime.utcnow() - dir_time).days,
                                size=dir_size
                            )
                        else:
                            try:
                                import shutil
                                shutil.rmtree(sample_dir)
                                logger.info(
                                    f"Deleted old sample",
                                    path=str(sample_dir),
                                    age_days=(datetime.utcnow() - dir_time).days
                                )
                                stats["deleted"] += 1
                                stats["size_freed"] += dir_size
                            except Exception as e:
                                logger.error(f"Error deleting {sample_dir}: {e}")
                                stats["errors"] += 1

            elif dir_type == "backup":
                # For backup dir, check each ZIP file
                for backup_file in tag_dir.glob("*.zip"):
                    stats["scanned"] += 1

                    # Check file age
                    file_stat = backup_file.stat()
                    file_time = datetime.fromtimestamp(file_stat.st_mtime)

                    if file_time < cutoff_date:
                        if dry_run:
                            logger.info(
                                f"[DRY RUN] Would delete backup",
                                path=str(backup_file),
                                age_days=(datetime.utcnow() - file_time).days,
                                size=file_stat.st_size
                            )
                        else:
                            try:
                                backup_file.unlink()
                                logger.info(
                                    f"Deleted old backup",
                                    path=str(backup_file),
                                    age_days=(datetime.utcnow() - file_time).days
                                )
                                stats["deleted"] += 1
                                stats["size_freed"] += file_stat.st_size
                            except Exception as e:
                                logger.error(f"Error deleting {backup_file}: {e}")
                                stats["errors"] += 1

        return stats

    async def refresh_cache(self) -> Dict:
        """Force refresh of any cached data (for future use)"""

        # Currently no caching, but this method allows for future optimization
        stats = {
            "refreshed": True,
            "timestamp": datetime.utcnow().isoformat()
        }

        logger.info("Cache refresh requested (no-op currently)")
        return stats