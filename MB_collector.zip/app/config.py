"""Configuration management using Pydantic Settings"""

from typing import List, Optional, Literal
from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
import os
from pathlib import Path


class Settings(BaseSettings):
    """Application configuration with environment variable support"""

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra='ignore'
    )

    # General settings
    api_url: str = Field(
        default="https://mb-api.abuse.ch/api/v1/",
        description="MalwareBazaar API endpoint"
    )
    api_key: SecretStr = Field(
        default=SecretStr("changeme"),
        env="MB_API_KEY",
        description="MalwareBazaar API key"
    )
    tags: List[str] = Field(
        default=["ios", "apk", "macho"],
        description="Tags to track from MalwareBazaar"
    )
    download_root: Path = Field(
        default=Path("/app/download"),
        env="DOWNLOAD_PATH",
        description="Root directory for sample storage"
    )
    backup_root: Path = Field(
        default=Path("/app/backup"),
        env="BACKUP_PATH",
        description="Root directory for backup storage"
    )
    backup_password: SecretStr = Field(
        default=SecretStr("changeme"),
        env="MB_BACKUP_PASSWORD",
        description="Password for ZIP archives"
    )
    dedupe_strategy: Literal["sha256_only", "sha256+size"] = Field(
        default="sha256_only",
        env="DEDUPE_STRATEGY",
        description="Deduplication strategy"
    )
    force_redownload: bool = Field(
        default=False,
        env="FORCE_REDOWNLOAD",
        description="Force re-download samples even if they exist in database"
    )
    max_daily_items_per_tag: Optional[int] = Field(
        default=100,
        env="MAX_DAILY_ITEMS_PER_TAG",
        description="Maximum items to download per tag per day"
    )

    # Scheduling settings
    auto_download_time: str = Field(default="10:00", env="DOWNLOAD_TIME", description="Daily download time")
    auto_backup_time: str = Field(default="11:00", env="BACKUP_TIME", description="Daily backup time")
    auto_upload_time: str = Field(default="12:00", env="UPLOAD_TIME", description="Daily upload time")
    auto_email_time: str = Field(default="13:00", env="EMAIL_TIME", description="Daily email time")
    timezone: str = Field(default="Australia/Sydney", env="TIMEZONE", description="Timezone for schedules")

    # GitHub Upload settings
    github_repo: str = Field(
        default="",
        env="GITHUB_REPO",
        description="GitHub repository URL"
    )
    github_token: SecretStr = Field(
        default=SecretStr(""),
        env="GITHUB_TOKEN",
        description="GitHub personal access token"
    )
    github_upload_retention_days: int = Field(
        default=14,
        env="GITHUB_UPLOAD_RETENTION_DAYS",
        description="Days to retain uploads in GitHub (older files deleted)"
    )
    upload_root: Path = Field(
        default=Path("/app/upload"),
        env="UPLOAD_PATH",
        description="Root directory for upload staging"
    )

    # Email settings
    smtp_host: str = Field(default="smtp.gmail.com", env="SMTP_HOST")
    smtp_port: int = Field(default=587, env="SMTP_PORT")
    smtp_tls: bool = Field(default=True, description="Use TLS for SMTP")
    smtp_user: str = Field(default="", env="SMTP_USER")
    smtp_pass: SecretStr = Field(default=SecretStr(""), env="SMTP_PASS")
    smtp_from: str = Field(default="mb-collector@example.com", env="SMTP_FROM")
    smtp_to: str = Field(default="admin@example.com", env="SMTP_TO")
    email_subject_prefix: str = Field(default="[MB-Collector]")

    # Web UI settings
    listen_host: str = Field(default="0.0.0.0", description="Web server host")
    listen_port: int = Field(default=5070, description="Web server port")
    admin_token: SecretStr = Field(
        default=SecretStr("changeme"),
        env="ADMIN_TOKEN",
        description="Bearer token for admin operations"
    )

    # Database settings
    database_url: str = Field(
        default="sqlite:////db/app.sqlite",
        description="Database connection URL"
    )

    # Logging settings
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        env="LOG_LEVEL",
        description="Logging level"
    )
    log_format: Literal["json", "text"] = Field(
        default="json",
        description="Log output format"
    )

    # Safety settings
    enable_sample_download: bool = Field(
        default=True,
        description="Enable actual sample downloads (disable for testing)"
    )
    disk_space_min_gb: int = Field(
        default=10,
        env="DISK_SPACE_MIN_GB",
        description="Minimum free disk space in GB to continue operations"
    )

    def __init__(self, **kwargs):
        # Load config from MB_config.conf if it exists
        config_file = Path("MB_config.conf")
        if config_file.exists():
            config_data = {}
            # Field name mappings
            field_mapping = {
                "MB_API_KEY": "api_key",
                "MB_BACKUP_PASSWORD": "backup_password",
                "DOWNLOAD_PATH": "download_root",
                "BACKUP_PATH": "backup_root",
                "UPLOAD_PATH": "upload_root",
                "ADMIN_TOKEN": "admin_token",
                "SMTP_HOST": "smtp_host",
                "SMTP_PORT": "smtp_port",
                "SMTP_USER": "smtp_user",
                "SMTP_PASS": "smtp_pass",
                "SMTP_FROM": "smtp_from",
                "SMTP_TO": "smtp_to",
                "GITHUB_REPO": "github_repo",
                "GITHUB_TOKEN": "github_token",
                "GITHUB_UPLOAD_RETENTION_DAYS": "github_upload_retention_days",
                "MAX_DAILY_ITEMS_PER_TAG": "max_daily_items_per_tag",
                "DEDUPE_STRATEGY": "dedupe_strategy",
                "FORCE_REDOWNLOAD": "force_redownload",
                "DISK_SPACE_MIN_GB": "disk_space_min_gb",
                "DOWNLOAD_TIME": "auto_download_time",
                "BACKUP_TIME": "auto_backup_time",
                "UPLOAD_TIME": "auto_upload_time",
                "EMAIL_TIME": "auto_email_time",
                "TIMEZONE": "timezone",
                "LOG_LEVEL": "log_level",
                "LOG_FORMAT": "log_format",
                "ENABLE_SAMPLE_DOWNLOAD": "enable_sample_download"
            }

            for line in config_file.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    key, value = key.strip(), value.strip()
                    if key == "TAGS":
                        config_data["tags"] = [tag.strip() for tag in value.split(",") if tag.strip()]
                    elif key in field_mapping:
                        field_name = field_mapping[key]
                        # Handle boolean values
                        if value.lower() in ('true', 'false'):
                            config_data[field_name] = value.lower() == 'true'
                        # Handle integer values
                        elif value.isdigit():
                            config_data[field_name] = int(value)
                        else:
                            config_data[field_name] = value
            kwargs.update(config_data)

        super().__init__(**kwargs)

    @field_validator("tags", mode="before")
    @classmethod
    def parse_tags(cls, v):
        if isinstance(v, str):
            return [tag.strip() for tag in v.split(",") if tag.strip()]
        return v

    @property
    def smtp_to_list(self) -> List[str]:
        """Get SMTP TO emails as a list"""
        return [email.strip() for email in self.smtp_to.split(",") if email.strip()]

    def reload_config(self):
        """Reload configuration from file"""
        new_settings = Settings()
        for field_name in self.model_fields:
            setattr(self, field_name, getattr(new_settings, field_name))
        return self


    def get_tag_path(self, tag: str) -> Path:
        """Get the data path for a specific tag"""
        return self.download_root / tag

    def get_backup_tag_path(self, tag: str) -> Path:
        """Get the backup path for a specific tag"""
        return self.backup_root / tag

    def get_sample_path(self, tag: str, sha256: str) -> Path:
        """Get the path for a specific sample"""
        return self.get_tag_path(tag) / sha256

    def get_backup_path(self, tag: str, sha256: str, date_str: str = None) -> Path:
        """Get the backup tar path for a specific sample with DATE_TAG_SHA256 format"""
        from datetime import datetime
        if date_str is None:
            date_str = datetime.utcnow().strftime("%Y_%m_%d")
        return self.get_backup_tag_path(tag) / f"{date_str}_{tag}_{sha256}.tar"


# Global settings instance
settings = Settings()