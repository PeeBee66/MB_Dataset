"""Database models using SQLAlchemy"""

from datetime import datetime
from enum import Enum as PyEnum
from typing import Optional
from sqlalchemy import (
    create_engine, Column, String, Integer, Boolean, DateTime,
    Float, ForeignKey, Text, Enum, Index, BigInteger
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from sqlalchemy.pool import StaticPool
from app.config import settings

Base = declarative_base()


class JobStatus(PyEnum):
    """Job execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    WARNING = "warning"


class JobType(PyEnum):
    """Types of jobs"""
    DOWNLOAD = "download"
    BACKUP = "backup"
    UPLOAD = "upload"
    EMAIL = "email"
    MANUAL_PULL = "manual_pull"
    TEST = "test"


class ArtifactType(PyEnum):
    """Types of artifacts"""
    METADATA = "metadata"
    IOCS = "iocs"
    YARA = "yara"
    README = "readme"


class Setting(Base):
    """Key-value settings store"""
    __tablename__ = "settings"

    key = Column(String(100), primary_key=True)
    value = Column(Text)
    is_secret = Column(Boolean, default=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Tag(Base):
    """MalwareBazaar tags to track"""
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False, index=True)
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_checked = Column(DateTime)

    # Relationships
    samples = relationship("Sample", back_populates="tag")


class Job(Base):
    """Job execution history"""
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True)
    type = Column(Enum(JobType), nullable=False, index=True)
    status = Column(Enum(JobStatus), nullable=False, default=JobStatus.PENDING, index=True)
    scheduled_at = Column(DateTime, nullable=False)
    started_at = Column(DateTime)
    finished_at = Column(DateTime)
    message = Column(Text)
    items_processed = Column(Integer, default=0)
    items_failed = Column(Integer, default=0)
    parameters = Column(Text)  # JSON string

    __table_args__ = (
        Index('idx_job_status_type', 'status', 'type'),
        Index('idx_job_scheduled', 'scheduled_at'),
    )


class Sample(Base):
    """Malware samples metadata"""
    __tablename__ = "samples"

    sha256 = Column(String(64), primary_key=True)
    tag_id = Column(Integer, ForeignKey("tags.id"), nullable=False, index=True)
    filename = Column(String(255))
    size = Column(BigInteger)
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    source_url = Column(Text)
    stored_path = Column(Text)
    has_backup = Column(Boolean, default=False, index=True)
    backup_path = Column(Text)
    uploaded_commit = Column(String(40))
    upload_date = Column(DateTime)

    # MalwareBazaar metadata
    mb_signature = Column(String(100))
    mb_first_seen = Column(DateTime)
    mb_reporter = Column(String(100))
    mb_delivery = Column(String(100))

    # Relationships
    tag = relationship("Tag", back_populates="samples")
    artifacts = relationship("Artifact", back_populates="sample", cascade="all, delete-orphan")

    __table_args__ = (
        Index('idx_sample_tag_date', 'tag_id', 'first_seen'),
        Index('idx_sample_backup', 'has_backup'),
    )


class Artifact(Base):
    """Generated artifacts for samples"""
    __tablename__ = "artifacts"

    id = Column(Integer, primary_key=True)
    sha256 = Column(String(64), ForeignKey("samples.sha256"), nullable=False, index=True)
    type = Column(Enum(ArtifactType), nullable=False)
    path = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    sample = relationship("Sample", back_populates="artifacts")


class MetricsDaily(Base):
    """Daily metrics for reporting"""
    __tablename__ = "metrics_daily"

    date = Column(DateTime, primary_key=True)
    tag_name = Column(String(100), primary_key=True)
    new_samples = Column(Integer, default=0)
    total_samples = Column(Integer, default=0)
    backup_size_bytes = Column(BigInteger, default=0)
    data_size_bytes = Column(BigInteger, default=0)
    upload_success = Column(Integer, default=0)
    upload_failed = Column(Integer, default=0)

    __table_args__ = (
        Index('idx_metrics_date', 'date'),
    )


class Database:
    """Database connection manager"""

    def __init__(self, url: str = None):
        self.url = url or settings.database_url

        # SQLite specific configuration
        if self.url.startswith("sqlite"):
            self.engine = create_engine(
                self.url,
                connect_args={"check_same_thread": False},
                poolclass=StaticPool,
                echo=settings.log_level == "DEBUG"
            )
        else:
            self.engine = create_engine(
                self.url,
                pool_pre_ping=True,
                echo=settings.log_level == "DEBUG"
            )

        self.SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine
        )

    def create_tables(self):
        """Create all database tables"""
        Base.metadata.create_all(bind=self.engine)

    def get_session(self):
        """Get a new database session"""
        return self.SessionLocal()

    def init_defaults(self):
        """Initialize default data"""
        session = self.get_session()
        try:
            # Add default tags if none exist
            if session.query(Tag).count() == 0:
                for tag_name in settings.tags:
                    tag = Tag(name=tag_name, enabled=True)
                    session.add(tag)
                session.commit()
        finally:
            session.close()


# Global database instance
db = Database()