#!/bin/bash

# MalwareBazaar Collector Setup Script

set -e

echo "=================================================="
echo "🛡️  MalwareBazaar Collector Setup"
echo "=================================================="
echo ""
echo "⚠️  DEFENSIVE RESEARCH USE ONLY ⚠️"
echo "This tool is for defensive security research purposes only."
echo "Do NOT execute any downloaded samples."
echo "Use in accordance with local laws and MalwareBazaar ToS."
echo ""
echo "=================================================="

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p volumes/{data,backup,db}
chmod 755 volumes
chmod 755 volumes/{data,backup,db}

# Copy environment file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo ""
    echo "✅ Created .env file. Please edit it with your settings:"
    echo "   - MB_API_KEY: Your MalwareBazaar API key"
    echo "   - MB_BACKUP_PASSWORD: Strong password for ZIP archives"
    echo "   - SMTP settings for email notifications"
    echo "   - Git repository settings for backup uploads"
    echo "   - ADMIN_TOKEN: Strong token for web admin access"
    echo ""
    echo "⚠️  IMPORTANT: Update the .env file before continuing!"
    echo ""
    read -p "Press Enter to open .env file for editing..." -r
    ${EDITOR:-nano} .env
else
    echo "✅ .env file already exists"
fi

echo ""
echo "🏗️  Building Docker image..."
docker build -t mb-collector:latest .

echo ""
echo "🔧 Testing configuration..."

# Test if directories are created
if [ -d "volumes/data" ] && [ -d "volumes/backup" ] && [ -d "volumes/db" ]; then
    echo "✅ Directories created successfully"
else
    echo "❌ Failed to create directories"
    exit 1
fi

echo ""
echo "🚀 Starting MalwareBazaar Collector..."
docker-compose up -d

echo ""
echo "⏳ Waiting for service to start..."
sleep 10

# Check if the service is running
if docker-compose ps | grep -q "Up"; then
    echo "✅ Service is running!"
    echo ""
    echo "🌐 Web Interface: http://localhost:5070"
    echo "📚 API Documentation: http://localhost:5070/docs"
    echo ""
    echo "📋 Useful Commands:"
    echo "   docker-compose logs -f          # View logs"
    echo "   docker-compose down             # Stop service"
    echo "   docker-compose restart          # Restart service"
    echo "   docker-compose exec mb-collector bash  # Shell access"
    echo ""
    echo "🔐 Security Notes:"
    echo "   - Web interface is bound to localhost only"
    echo "   - Use ADMIN_TOKEN from .env for admin operations"
    echo "   - Data volumes are mounted with noexec for safety"
    echo ""
    echo "📖 Next Steps:"
    echo "   1. Open http://localhost:5070 in your browser"
    echo "   2. Configure your tags and schedules in Settings"
    echo "   3. Test your MalwareBazaar API key"
    echo "   4. Test SMTP and Git connections"
    echo "   5. Run a manual download to verify everything works"
    echo ""
    echo "✅ Setup completed successfully!"
else
    echo "❌ Service failed to start. Check logs with: docker-compose logs"
    exit 1
fi