#!/usr/bin/env python3
"""
Sample cleanup utility for testing
Usage: python cleanup_sample.py <sha256> [tag]
"""

import sys
import shutil
from pathlib import Path

def cleanup_sample(sha256, tag=None):
    """Clean up a sample from filesystem (and optionally database)"""

    # Default tags if not specified
    tags_to_check = [tag] if tag else ["ios", "apk", "macho"]

    cleaned = []

    for tag_name in tags_to_check:
        # Check download folder
        download_path = Path(f"./download/{tag_name}/{sha256}")
        if download_path.exists():
            print(f"🗑️  Removing download: {download_path}")
            shutil.rmtree(download_path)
            cleaned.append(f"download/{tag_name}/{sha256}")

        # Check backup file
        backup_path = Path(f"./backup/{tag_name}/{sha256}.zip")
        if backup_path.exists():
            print(f"🗑️  Removing backup: {backup_path}")
            backup_path.unlink()
            cleaned.append(f"backup/{tag_name}/{sha256}.zip")

    if cleaned:
        print(f"✅ Cleaned up: {', '.join(cleaned)}")
        print("💡 Database entries remain (they don't affect browsing)")
        print("🔄 Web interface will reflect changes immediately")
    else:
        print(f"❌ No files found for SHA256: {sha256}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python cleanup_sample.py <sha256> [tag]")
        print("Example: python cleanup_sample.py abc123def456 ios")
        sys.exit(1)

    sha256 = sys.argv[1]
    tag = sys.argv[2] if len(sys.argv) > 2 else None

    cleanup_sample(sha256, tag)