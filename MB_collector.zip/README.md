# MalwareBazaar Collector

🛡️ **Automated malware sample collection for defensive security research**

⚠️ **DEFENSIVE RESEARCH USE ONLY** - Do NOT execute any downloaded samples - For defensive security research only ⚠️

## Overview

The MalwareBazaar Collector is a headless service with web UI that automatically:

- Pulls malware metadata and samples from Abuse.ch MalwareBazaar on a schedule
- Stores each sample in its own SHA256-named folder under its tag
- Writes intelligence artifacts (IOCs, YARA, JSON metadata) alongside samples
- Creates password-protected ZIP backups
- Uploads backups to Git repositories with retention management
- Sends daily email summaries
- Provides a web dashboard to browse, configure, and run manual pulls

## Key Features

### Safety First
- **Read-only filesystem** with noexec mount options
- **Password-protected ZIP archives** for all samples
- **No automatic execution** of any downloaded content
- **Quarantined storage** with restrictive permissions
- **Built-in safety warnings** throughout the interface

### Filesystem-Based Design
- **Direct filesystem scanning** - Web UI reads directly from folders
- **No database dependency** for sample browsing
- **Easy addition** of external samples - just refresh to see them
- **Flexible cleanup** options for both raw data and backups

### Automated Operations
- **Scheduled downloads** at configurable times (default 10:00 AEST)
- **Automatic backup creation** (default 11:00 AEST)
- **Git repository uploads** with retention (default 12:00 AEST)
- **Daily email summaries** (default 13:00 AEST)

### Cleanup Management
- **Configurable cleanup** for data older than X days
- **Separate cleanup** for raw samples and backup archives
- **Dry-run testing** before actual deletion
- **Size tracking** and disk space monitoring

## Quick Start

1. **Clone and setup:**
   ```bash
   git clone <your-repo>
   cd MB_Puller
   ./setup.sh
   ```

2. **Configure environment:**
   - Edit `.env` file with your API keys and settings
   - Set MalwareBazaar API key
   - Configure SMTP for email notifications
   - Set Git repository for backup uploads

3. **Access web interface:**
   - Open http://localhost:5070
   - Use ADMIN_TOKEN from .env for admin operations

## Architecture

```
┌─────────────────────┐       ┌─────────────────────┐
│  Web UI (FastAPI)   │◄─────►│  Filesystem Scanner │
│  localhost:5070     │       │  (reads /data)      │
└─────────────────────┘       └─────────────────────┘
           │                             │
           ▼                             ▼
┌─────────────────────┐       ┌─────────────────────┐
│   Job Scheduler     │       │  Storage Structure  │
│   (APScheduler)     │       │  /data/<tag>/<sha>/ │
└─────────────────────┘       └─────────────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────┐
│                  Workers                            │
│  • MalwareBazaar Client   • Git VCS Uploader       │
│  • Backup Creator         • Email Reporter         │
└─────────────────────────────────────────────────────┘
```

## Directory Structure

```
/data/<tag>/<sha256>/
  ├── sample.bin         # Raw sample (never execute!)
  ├── meta.json          # MalwareBazaar metadata
  ├── iocs.txt           # Extracted IOCs
  ├── yara.txt           # YARA rules (if available)
  └── README.txt         # Safety warning

/backup/<tag>/
  └── <sha256>.zip       # Password-protected backup

/db/
  └── app.sqlite         # Job history and settings
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MB_API_KEY` | MalwareBazaar API key | `changeme` |
| `MB_BACKUP_PASSWORD` | ZIP archive password | `changeme` |
| `SMTP_HOST` | Email server hostname | `smtp.gmail.com` |
| `SMTP_USER` | Email username | - |
| `SMTP_PASS` | Email password | - |
| `GIT_REMOTE` | Git repository URL | - |
| `ADMIN_TOKEN` | Web UI admin token | `supersecrettoken` |

### Scheduling

- **10:00 AEST**: Automatic download from MalwareBazaar
- **11:00 AEST**: Create password-protected backups
- **12:00 AEST**: Upload to Git + retention cleanup
- **13:00 AEST**: Send email summary

Times are configurable via environment variables.

## Web Interface

### Dashboard
- **Statistics overview** by tag
- **Recent samples** with file indicators
- **Quick actions** for manual job execution
- **Scheduled job status**

### Sample Browser
- **Filesystem-based** browsing and search
- **Tag filtering** and text search
- **File existence indicators** (IOCs, YARA, backup status)
- **Detailed sample views** with artifact content

### Cleanup Management
- **Configurable retention** for data and backups
- **Dry-run testing** before actual cleanup
- **Storage statistics** and size tracking

## API Endpoints

- `GET /api/samples` - List samples from filesystem
- `GET /api/samples/{sha256}` - Sample details
- `POST /api/jobs/run/{type}` - Execute jobs manually
- `POST /api/cleanup` - Clean old files (with dry-run)
- `GET /api/stats` - Storage and tag statistics
- `POST /api/test/{service}` - Test external connections

Full API documentation: http://localhost:5070/docs

## Safety & Legal

### ⚠️ Important Safety Notes

1. **Never execute downloaded samples** - they are real malware
2. **Use quarantined storage** with noexec mount options
3. **For defensive research only** - not for malicious purposes
4. **Comply with local laws** and MalwareBazaar Terms of Service
5. **Protect API keys** - never commit to version control

### Default Safety Measures

- Docker containers run as non-root user
- Data volumes mounted with `noexec,nodev,nosuid`
- Read-only container filesystem except for data volumes
- Password-protected ZIP archives for all samples
- Automatic safety warnings in all interfaces

## Troubleshooting

### Common Issues

1. **Service won't start:**
   ```bash
   docker-compose logs mb-collector
   ```

2. **API connection fails:**
   - Check MalwareBazaar API key in `.env`
   - Test connection via web interface

3. **Git upload fails:**
   - Verify Git remote URL and SSH key
   - Check Git provider access tokens

4. **Email not sending:**
   - Verify SMTP settings in `.env`
   - Test SMTP connection via web interface

### Log Access

```bash
# View real-time logs
docker-compose logs -f

# Container shell access
docker-compose exec mb-collector bash

# Check disk space
docker-compose exec mb-collector df -h
```

## Development

### Requirements
- Python 3.11+
- Docker & Docker Compose
- Git (for backup uploads)

### Manual Installation
```bash
pip install -r requirements.txt
python -m app.main
```

### Testing
```bash
# Build and test
docker build -t mb-collector:test .
docker run --rm mb-collector:test python -c "import app; print('OK')"
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes with safety in mind
4. Add tests for new functionality
5. Submit a pull request

## License

This project is for defensive security research only. Use responsibly and in accordance with local laws.

---

**Remember: This tool is for defensive research only. Never execute downloaded samples.**