# Configuration Cleanup - Single Source of Truth

## 🧹 What Was Cleaned Up

### Removed from docker-compose.yml
All application-specific environment variables have been removed from docker-compose.yml:

- ❌ `MB_API_KEY`, `MB_BACKUP_PASSWORD`
- ❌ `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`, `SMTP_TO`
- ❌ `GIT_PROVIDER`, `GIT_REMOTE`, `GIT_BRANCH`, `GIT_SSH_KEY`
- ❌ `ADMIN_TOKEN`
- ❌ `DOWNLOAD_PATH`, `BACKUP_PATH`
- ❌ `LOG_LEVEL`

### Kept in docker-compose.yml
Only Docker-specific settings remain:

- ✅ `TZ: "Australia/Sydney"` (timezone for container)
- ✅ Volume mappings
- ✅ Security settings
- ✅ Resource limits
- ✅ Network configuration

## 📋 Single Configuration File

**MB_config.conf** is now the **single source of truth** for all application settings:

```bash
# MalwareBazaar API Configuration
MB_API_KEY=your_api_key_here
MB_BACKUP_PASSWORD=infected1

# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-password
SMTP_FROM=sender@example.com
SMTP_TO=recipient@example.com

# Git Repository Configuration
GIT_PROVIDER=gitlab
GIT_REMOTE=git@gitlab.com:YourOrg/mb-backups.git
GIT_BRANCH=main
SSH_KEY_PATH=/path/to/ssh/key

# Web UI Settings
ADMIN_TOKEN=your_secure_token

# General Settings
TAGS=ios,apk,macho
MAX_DAILY_ITEMS_PER_TAG=100
DEDUPE_STRATEGY=sha256_only
DISK_SPACE_MIN_GB=20

# Storage Paths
DOWNLOAD_PATH=/app/download
BACKUP_PATH=/app/backup

# Schedule Settings (24-hour format HH:MM)
DOWNLOAD_TIME=10:00
BACKUP_TIME=11:00
UPLOAD_TIME=12:00
EMAIL_TIME=13:00
TIMEZONE=Australia/Sydney

# VCS Settings
RETENTION_DAYS=0

# Logging Settings
LOG_LEVEL=INFO
LOG_FORMAT=json

# Safety Settings
ENABLE_SAMPLE_DOWNLOAD=true
```

## 🔄 Configuration Workflow

### Before (Complex)
1. Edit multiple files: docker-compose.yml, .env, config files
2. Restart containers to apply changes
3. Environment variables scattered across files
4. Risk of inconsistency between files

### After (Simple)
1. ✅ Edit **only MB_config.conf**
2. ✅ Click **"Refresh Configuration"** in web UI
3. ✅ Changes apply **immediately**
4. ✅ **No container restart** required

## 🚫 Deprecated Files

- **`.env`**: No longer used, marked as deprecated
- **Environment variables in docker-compose**: Removed

## ✅ Benefits

1. **Single Source of Truth**: All settings in one place
2. **Live Reloading**: No container restarts needed
3. **Simplified Management**: Edit one file only
4. **Consistency**: No risk of conflicting settings
5. **Clear Separation**: Docker settings vs Application settings

## 🔧 Migration Notes

If you have existing configurations:
1. Copy your settings to `MB_config.conf`
2. Remove any custom `.env` file
3. Use the cleaned `docker-compose.yml`
4. Test configuration refresh in web UI

The application now follows the principle of **configuration simplicity** with MB_config.conf as the single, authoritative configuration source.