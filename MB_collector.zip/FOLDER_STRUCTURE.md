# MalwareBazaar Collector - Folder Structure

## 📁 Application Structure

The MalwareBazaar Collector now uses a local folder structure for better organization and easier file management.

### Local Folders (Host System)

```
MB_Puller/
├── download/          # Sample download storage
│   ├── ios/
│   │   └── [SHA256]/
│   │       ├── sample_file.ipa (or original filename)
│   │       ├── [SHA256].intel (comprehensive intelligence report)
│   │       ├── [SHA256].json (raw MB metadata)
│   │       ├── [SHA256].iocs (indicators of compromise)
│   │       ├── [SHA256].yara (YARA rules)
│   │       ├── [SHA256].zip (original MB download)
│   │       ├── zip.password.txt (contains: infected)
│   │       └── README.txt (safety warning)
│   ├── apk/
│   │   └── [SHA256]/
│   │       └── (same structure as ios)
│   └── macho/
│       └── [SHA256]/
│           └── (same structure as ios)
└── backup/            # Backup ZIP storage
    ├── ios/
    │   └── [SHA256].zip
    ├── apk/
    │   └── [SHA256].zip
    └── macho/
        └── [SHA256].zip
```

### Container Paths

Inside the Docker container, these folders are mapped to:
- `/app/download` -> Host `./download`
- `/app/backup` -> Host `./backup`

## ⚙️ Configuration

The folder paths can be customized in `MB_config.conf`:

```bash
# Storage Paths
DOWNLOAD_PATH=/app/download
BACKUP_PATH=/app/backup
```

To change the paths:
1. Edit `MB_config.conf` with your desired paths
2. Update `docker-compose.yml` volume mappings if needed
3. Click "Refresh Configuration" in the web UI

## 🔧 Volume Mappings

In `docker-compose.yml`:
```yaml
volumes:
  # Local folders mapped to container
  - ./download:/app/download
  - ./backup:/app/backup
  - db:/db
  # Configuration file
  - ./MB_config.conf:/app/MB_config.conf:ro
```

## 📋 File Details

### Download Folder Files
- **Original sample**: Extracted from MalwareBazaar ZIP
- **`.intel` file**: Comprehensive intelligence report with all MB data
- **`.json` file**: Raw metadata from MalwareBazaar API
- **`.iocs` file**: Extracted indicators of compromise
- **`.yara` file**: YARA rules (auto-generated or from MB)
- **`.zip` file**: Original password-protected download from MB
- **`zip.password.txt`**: Contains "infected" password
- **`README.txt`**: Safety warnings and instructions

### Backup Folder Files
- **`[SHA256].zip`**: Password-protected backup of entire sample folder
- **Password**: Uses `MB_BACKUP_PASSWORD` from config (default: "infected1")

## 🛡️ Security Features

- All sample files have restrictive permissions (0o400)
- Metadata files protected (0o600)
- Container runs as non-root user (1000:1000)
- Safety warnings in every sample folder
- Password-protected archives for all samples

## 🔄 Migration from Old Structure

If migrating from the old `/data` and `/backup` structure:
1. Copy existing data to new `./download` and `./backup` folders
2. Update folder ownership: `chown -R 1000:1000 download backup`
3. Restart the application

The new structure provides better organization and easier access to sample files directly from the host system.